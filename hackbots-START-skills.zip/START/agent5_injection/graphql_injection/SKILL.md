---
name: graphql_injection
agent: agent5_injection
description: GraphQL abuse — introspection mining, nested-query DoS, field duplication, alias-based authz bypasses, and batching attacks.
---

# GraphQL Injection

## Purpose

Systematically abuses GraphQL endpoints beyond "introspection is on." GraphQL's power features — aliases, fragments, directives, batching — are attacker primitives: nested queries become exponential DoS, aliases bypass rate limits and authorization checks, field duplication amplifies cost, and batching turns one request into a thousand. Real impact: full schema exfiltration, authorization bypass on hidden fields, resource-exhaustion DoS, and credential-stuffing at batch scale.

## Division of labor

- **Consumes:** GraphQL endpoint discovery from `agent2_mapping` (`/graphql`, `/api/graphql`, `/query`, persisted-query hashes), auth model from `agent3_auth`.
- **Produces:** `findings/graphql_injection.md` — per-endpoint verdict table (introspection, DoS, authz, batching sections) with query/response evidence. Finished artifact.

## When to use / when NOT to use

- **Use when:** a `/graphql` (or similar) endpoint exists; POST with `{"query":...}` gets GraphQL-shaped errors; the app is built on Apollo/Hasura/Graphene (check JS bundles and response headers).
- **Skip when (time-pass filter):** introspection is off AND the endpoint enforces persisted queries only (verify: send an ad-hoc query — if it 400s while a captured hash works, stop); depth/cost limits are enforced AND verified (test the nested query in step 4 — if it errors at depth 3, the limit is real); the endpoint requires auth you don't have and exposes nothing unauthenticated (one probe to confirm, then stop).

## Methodology — introspection & schema mining

1. **Baseline the endpoint.** Send `{"query":"{__typename}"}` — record status, timing, error shape. This distinguishes GraphQL from a REST endpoint that happens to accept JSON.
2. **Introspection probe.** Full `__schema{queryType{fields{name}}}` query. If it returns the schema: save it to `graphql_schema.json` — this file drives everything downstream. If disabled, try the one-field-at-a-time variant (`{__type(name:"Query"){fields{name}}}`) — some servers block `__schema` but allow `__type`.
3. **Field-level authz map.** For every query/mutation field, request it unauthenticated. Mark: public / auth-required / error-different. Fields that error differently for nonexistent vs unauthorized (`"Cannot query field"` vs `"Not authorized"`) leak schema shape — enumerate field names from error messages.
4. **Directive and fragment abuse surface.** Note which directives the server supports (`@include`, `@skip`, custom). Directives that change authorization logic are bypass candidates in step 8.

## Methodology — DoS

5. **Nested-query depth test.** Build `{ a { b { c { d { e { id } } } } } }` following a real relation chain from the schema (not random fields — use actual nested types so the server really resolves). Increase depth until it errors or slows. No depth limit + slowdown = DoS vector CONFIRMED at the availability level.
6. **Alias-based amplification.** Same field, 50 aliases: `a1: users { id } a2: users { id } ...`. If the server executes all 50, aliases multiply cost linearly — combine with nesting for exponential. Measure timing vs the single-field baseline.
7. **Field duplication via fragments.** Define a fragment with the expensive field, spread it 20x with aliases. Some cost analyzers count the fragment once — the timing differential proves the bypass.
8. **Circular query.** If the schema has a cycle (User → posts → author → posts...), walk it 10 deep with aliases at each level. A cycle + no depth limit = the classic exponential GraphQL DoS. Time it; if a 10-deep circular query takes >10x the baseline, document and STOP — don't take the target down.
9. **Batching attack.** Send an array of 100 queries in one request (Apollo batching) or use aliased batching. If accepted: this is also the credential-stuffing primitive — 100 login mutations per request bypasses per-request rate limits. Demonstrate with 100 benign introspection queries, not 100 logins.

## Methodology — authorization

10. **Alias-based authz bypass.** Request `viewer { email }` (blocked) vs `a: viewer { email }` — some field-level authz checks run on the field name path and miss aliases. Any differential = bypass CONFIRMED.
11. **Fragment-based bypass.** Same test via named fragments — authz that inspects the query AST textually can miss fragment-spread fields.
12. **IDOR-shaped arguments.** GraphQL IDs are often global/node IDs — test `user(id: "2")` vs `user(id: "1")`, and try the raw database ID vs the base64 node ID. Hand confirmed IDORs to the access-control skill with the exact query.
13. **Mutation authz.** List all mutations from the schema; try each unauthenticated with benign arguments. Mutations that "should" be admin-only but execute = critical. Never mutate real data — use dry-run arguments or your own test objects, and revert what you create.
14. **Introspection-in-production note.** If introspection is on in production, that alone is a (low) finding — but the schema file it yields is the real prize for the other agents.

## Exact commands

Baseline + introspection:
```bash
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{__typename}"}' | head -c 300; echo
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{__schema{queryType{fields{name}}}}"}' -o graphql_schema.json
python3 -c "import json; d=json.load(open('graphql_schema.json')); print(len(str(d)), 'chars'); print([f['name'] for f in d['data']['__schema']['queryType']['fields']][:20])"
```

__type fallback when __schema is blocked:
```bash
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{__type(name:\"Query\"){fields{name}}}"}' | head -c 400; echo
```

Nested depth probe (build from the real schema relations):
```bash
python3 - <<'EOF' > depth10.json
q = "{ a { b { c { d { e { f { g { h { i { j { id } } } } } } } } } } }"
import json; print(json.dumps({"query": q}))
EOF
curl -s -o /dev/null -w 'depth10: %{http_code} %{time_total}s\n' -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d @depth10.json
```

Alias amplification (50x):
```bash
python3 - <<'EOF' > alias50.json
fields = " ".join(f"a{i}: users {{ id }}" for i in range(50))
import json; print(json.dumps({"query": "{" + fields + "}"}))
EOF
curl -s -o /dev/null -w 'alias50: %{http_code} %{time_total}s %{size_download}\n' -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d @alias50.json
curl -s -o /dev/null -w 'single:  %{http_code} %{time_total}s %{size_download}\n' -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{users{id}}"}'
```

Batching (100 benign queries, not logins):
```bash
python3 - <<'EOF' > batch100.json
import json; print(json.dumps([{"query":"{__typename}"} for _ in range(100)]))
EOF
curl -s -o /dev/null -w 'batch100: %{http_code} %{time_total}s %{size_download}\n' -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d @batch100.json
```

Alias authz bypass:
```bash
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{viewer{email}}"}' | head -c 200; echo
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"{a: viewer{email}}"}' | head -c 200; echo
```

Unauthenticated mutation sweep (benign args only):
```bash
curl -s -X POST '<TARGET>/graphql' -H 'Content-Type: application/json' -d '{"query":"mutation{__typename}"}' | head -c 200; echo
```

## Introspection and bypass variants

**When `__schema` is blocked, escalate through these in order:**
1. `{__type(name:"Query"){fields{name}}}` — per-type enumeration; loop over suspected type names (`Mutation`, `User`, `Viewer`)
2. `{__type(name:"Mutation"){fields{name args{name}}}}` — mutations with their arguments; the highest-value fallback
3. Error-message mining: send `{nonexistentField9q}` — `"Cannot query field \"nonexistentField9q\""` vs `"Did you mean ..."` suggestions leak real field names; iterate the suggestions
4. GET-based queries: `GET /graphql?query={__typename}` — some servers apply introspection blocking only to POST

**Persisted-query bypass (where ad-hoc queries 400):**
- Capture a valid persisted hash from the frontend JS (look for `extensions.persistedQuery.sha256Hash`)
- Send your attack query WITH a valid hash but mismatched query text — servers that trust the hash without verifying the query text execute your query
- Hash for `{"query":"{__typename}"}` is computable client-side — try registering it via the `PersistedQueryNotFound` flow if the server supports hash registration

**Cost-limit bypass notes:**
- If depth limiting exists, test whether it counts fragments once (fragment-spread bypass, step 7) and whether it counts aliased fields separately (usually yes — that's the bypass)
- `@include(if: true)` / `@skip(if: false)` wrappers: some cost analyzers skip directive-wrapped fields when estimating but the executor runs them — wrap the expensive field and compare timing

**Subscription/websocket note:** if the endpoint offers subscriptions over websocket (`graphql-ws`), test whether the auth model differs there — subscriptions sometimes skip the field-level authz that HTTP enforces.

## Completion-bias defenses

- [ ] Endpoint baselined with `{__typename}` before any attack query
- [ ] Full schema saved to `graphql_schema.json` where introspection is open
- [ ] `__type` fallback tried where `__schema` is blocked
- [ ] Every query/mutation field probed unauthenticated for the authz map
- [ ] Nested depth increased until error/slowdown — depth limit verified, not assumed
- [ ] Alias amplification timed against the single-field baseline
- [ ] Fragment-spread cost bypass tested separately from plain aliases
- [ ] Circular query walked on real schema cycles, stopped at the timing proof
- [ ] Batching demonstrated with benign queries, not credential stuffing
- [ ] Mutations swept with benign args; anything created reverted
- [ ] `findings/graphql_injection.md` exists with all four sections
- **Review step:** agent10_review must verify (a) DoS claims include baseline-vs-attack timings, (b) no production data was mutated, (c) batching was demonstrated with benign queries only, (d) the schema file is attached for downstream agents.
- **Nudge prompts:**
  - "Keep going until every field in the schema has an authz verdict — the admin-only mutation hiding at the bottom of the schema is the finding."
  - "Timing is the proof for DoS. A slow query without a baseline timing is an anecdote."
  - "Do not report done before findings/graphql_injection.md and graphql_schema.json exist on disk."
- **Finished artifact definition:** `findings/graphql_injection.md` (four sections, per-endpoint verdicts, timings) + `graphql_schema.json` (saved schema for downstream agents).

## Evidence standard

- Baseline: `{__typename}` timing and single-field timing saved before attack queries.
- Reproduction: DoS timings 2x; authz bypass 2x; batching acceptance 2x.
- Raw evidence: the exact query JSON and the response (timings via `%{time_total}`, bodies for authz).
- Verdicts: CONFIRMED (meets section proof bar 2x) / INCONCLUSIVE (single slow response, needs second run) / NEGATIVE (depth/cost limits verified enforced, introspection off + persisted-only).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED authz bypasses and IDOR-shaped arguments — escalation chains.
- `agent2_mapping`: consumes `graphql_schema.json` — enriches the endpoint/data model for all agents.
- `agent10_review`: consumes `findings/graphql_injection.md` — verifies no data was mutated and timings are attached.
