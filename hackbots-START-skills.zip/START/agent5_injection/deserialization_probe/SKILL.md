---
name: deserialization_probe
agent: agent5_injection
description: Insecure deserialization detection — Java/PHP/Python markers, gadget-chain-free canaries, and format-differential mapping.
---

# Deserialization Probe

## Purpose

Detects insecure deserialization where the app unserializes attacker-controlled bytes: Java `readObject`, PHP `unserialize()`, Python `pickle`, .NET `BinaryFormatter`, Node `node-serialize`. This skill is detection-only by design — no gadget chains, no RCE payloads. The canaries prove attacker-controlled objects reach a deserializer, which is itself the reportable finding; weaponization is a human decision at the review gate. Real impact if escalated: remote code execution (the classic critical).

## Division of labor

- **Consumes:** endpoint inventory from `agent2_mapping`, serialized-looking values from `agent1_recon` (base64 cookies, `remember-me` tokens, viewstate, session blobs), stack signals (Java → readObject; PHP → unserialize; Python → pickle).
- **Produces:** `findings/deserialization_probe.md` — per-endpoint verdict table with format identified and canary evidence. Finished artifact; gadget work NEVER proceeds without human approval.

## When to use / when NOT to use

- **Use when:** cookies/tokens/parameters contain base64 blobs that decode to structured bytes; parameters named `data`, `state`, `session`, `token`, `viewstate`, `__viewstate`; Java apps with serialized session cookies; PHP apps with `unserialize` in stack traces or `a:2:{...}`-shaped values.
- **Skip when (time-pass filter):** the blob is a signed JWT (verify the signature validates — decode the header; if it's `{"alg":"HS256"...}` with three dot-segments, it's JWT, not serialization); the blob is encrypted (high entropy, no structure after base64 decode — note and move on); the endpoint HMACs the blob and rejects tampering (verify: flip one byte — if it 400s, the integrity check is real).

## Methodology

1. **Harvest serialized-looking values.** Collect every base64-ish cookie, token, hidden field, and parameter. Decode each: `base64 -d`. Classify by magic bytes and structure (step 2).
2. **Format identification (decode, don't guess).**
   - Java: starts with `ac ed 00 05` (hex) — Java serialization stream.
   - PHP: `a:`, `O:`, `s:`, `i:` prefixes — `a:2:{i:0;s:4:"test";}`.
   - Python pickle: `\x80\x04` / `\x80\x05` prefix, `c`-opcodes, `cos\nsystem` patterns.
   - .NET: `AAEAAAD/////` base64 prefix (BinaryFormatter).
   - Ruby Marshal: `\x04\x08` prefix.
   - Node `node-serialize`: JSON with `"$type"` or function-string values.
   Record the format with the decoded evidence — the format chooses the canary.
3. **Integrity check test.** Flip one byte (or one character) in the blob and resubmit. If the app rejects it (400/error/different behavior), an HMAC/signature protects it — still test whether the SIGNATURE is verified or just the structure (flip a byte in the middle vs at the end). If tampering is silently accepted, the deserializer is fully attacker-controlled.
4. **Java canary (gadget-free).** Send a serialized `java.util.HashMap` with a canary string value, or simpler: the classic `ac ed 00 05 73 72 ...` minimal stream containing only a String. If the app's response changes (different error, different behavior vs the flipped-byte baseline), your object reached `readObject` = CONFIRMED deserialization sink. Use ysoserial-style payload shapes ONLY as format templates — never with a gadget chain.
5. **PHP canary (gadget-free).** `O:8:"stdClass":1:{s:6:"canary";s:9:"CANARY9q";}` — a plain stdClass with no magic methods. If the app behaves differently than with a corrupted blob (different error text, not just "invalid"), `unserialize()` consumed your object. Then test `__destruct`/`__wakeup` reachability with a BENIGN class probe — log which magic methods fire via error messages, don't chain them.
6. **Python pickle canary (gadget-free).** A pickled dict `{'canary': 'CANARY9q'}` (protocol 4). If accepted and reflected/stored differently than the corrupted baseline, `pickle.loads` ran on your bytes. Do NOT use `__reduce__` / `os.system` — the loads() call itself is the finding.
7. **.NET / Ruby / Node canaries.** BinaryFormatter: minimal serialized string object. Ruby Marshal: `Marshal.dump("CANARY9q")`. Node: `{"$type":"canary"}` shapes only if the app uses a known-vulnerable serializer — otherwise just document the JSON-with-functions shape.
8. **Type-confusion differential.** Send the right format with the wrong type (array where object expected, string where int). Deserializer error messages (`ClassNotFoundException: com.example.Foo`, `unserialize(): Error at offset`) leak class names and confirm the sink.
9. **ViewState special case (.NET).** If `__VIEWSTATE` exists: check `EnableViewStateMac` — tamper one byte. Unsigned ViewState + deserialization = the finding. Do not craft malicious ViewState.
10. **Second-order stores.** If the blob is stored (session DB, "remember me" persistent cookie), test whether tampering the STORED value (via another endpoint) reaches the deserializer — stored deserialization has a wider attacker population.
11. **STOP line.** This skill ends at "attacker-controlled bytes reach a deserializer." Gadget-chain enumeration, RCE payloads, and ysoserial gadget selection are explicitly out of scope — they require human approval via `agent10_review` and `agent9_chaining`.

## Exact commands

Harvest and decode:
```bash
for c in session remember_me token data __VIEWSTATE; do
  v=$(curl -s -D - -o /dev/null '<TARGET>/' -b '' | grep -ai "set-cookie: $c=" | cut -d= -f2 | cut -d\; -f1)
  [ -n "$v" ] && echo "== $c ==" && echo "$v" | base64 -d 2>/dev/null | xxd | head -4
done
```

Magic-byte classifier (save blobs to files first):
```bash
xxd -l 8 -p blob.bin
python3 - <<'EOF'
d=open('blob.bin','rb').read()
if d.startswith(b'\xac\xed\x00\x05'): print('JAVA serialization')
elif d[:2]==b'\x80\x04' or d[:2]==b'\x80\x05': print('PYTHON pickle')
elif d[:2]==b'\x04\x08': print('RUBY marshal')
elif d[:1] in b'aOsi': print('PHP serialize?', d[:20])
elif d.startswith(b'\x00\x01\x00\x00\x00\xff\xff\xff\xff'): print('.NET BinaryFormatter')
else: print('unknown/high-entropy (maybe encrypted)')
EOF
```

Integrity/tamper test:
```bash
ORIG='<ORIGINAL_BLOB>'
TAMPERED="${ORIG}A"   # flip/append one char
echo "orig:    $(curl -s -o /dev/null -w '%{http_code} %{size_download}' -b "session=$ORIG" '<TARGET>/dashboard')"
echo "tampered:$(curl -s -o /dev/null -w '%{http_code} %{size_download}' -b "session=$TAMPERED" '<TARGET>/dashboard')"
```

PHP gadget-free canary:
```bash
PHP_BLOB=$(php -r 'echo base64_encode(serialize((object)["canary"=>"CANARY9q"]));' 2>/dev/null || python3 -c "import base64; print(base64.b64encode(b'O:8:\"stdClass\":1:{s:6:\"canary\";s:9:\"CANARY9q\";}').decode())")
curl -s -b "data=$PHP_BLOB" '<TARGET>/' -o php_resp.html -w 'php-canary: %{http_code} %{size_download}\n'
```

Python pickle gadget-free canary:
```bash
PICKLE_BLOB=$(python3 -c "import pickle,base64,urllib.parse; print(urllib.parse.quote(base64.b64encode(pickle.dumps({'canary':'CANARY9q'}))))")
curl -s --get '<TARGET>/api/state' --data-urlencode "state=$PICKLE_BLOB" -o pkl_resp.html -w 'pickle-canary: %{http_code} %{size_download}\n'
```

Type-confusion error mining:
```bash
curl -s -b 'session=acEDAA==' '<TARGET>/dashboard' | grep -oiE 'classnotfoundexception[^<"]{0,50}|unserialize[^<"]{0,50}|pickle[^<"]{0,50}|readobject[^<"]{0,50}' | head -5
```

## Format-specific canary details

**Java — minimal gadget-free stream (a serialized String "CANARY9q"):**
```
aced 0005 7400 0843 414e 4152 5939 71
```
Send as the cookie/parameter value (base64: `rO0ABXQACEFOQVJZEXHn`). If the app's behavior differs from the corrupted-blob baseline (different error, session change, reflection), `readObject` consumed it. Then mine `ClassNotFoundException` messages by sending a stream referencing a fake class — the exception text confirms the deserializer and sometimes the classpath.

**PHP — magic-method reachability (benign, logged, not chained):**
- `__wakeup`: fires on unserialize — detect via timing/error differential with a class defining it (use a class name from error messages, e.g. from step 8)
- `__destruct`: fires at script end — detect by observing delayed effects (log lines, temp files in YOUR test scope only)
- `__toString`: fires on string conversion — probe by placing the object where the app concatenates
- Document WHICH magic methods fire; each one is a rung on the ladder that `agent9_chaining` may climb with human approval

**Python — pickle opcodes to recognize in the wild:**
- `c` (GLOBAL): `cos\nsystem\n` — the RCE opcode; its PRESENCE in an attacker-reachable pickle is the critical marker (you never send it yourself)
- `R` (REDUCE): the other dangerous opcode
- Your canary uses only `NUL`-safe dict opcodes (`}`, `U`, `S`, `u`) — if the app accepts your benign dict pickle, the sink is confirmed without ever touching `c`/`R`

**Node — `node-serialize` / `funcster` shapes:**
- `{"rce": "_$$ND_FUNC$$_function(){...}"}` — the classic; do NOT send a working function. Instead send `{"canary": "_$$ND_FUNC$$_function(){return 'CANARY9q';}"}` and check whether the function VALUE survives (serialized back, reflected, or evaluated) — survival of the marker proves the vulnerable deserializer

**JWT-vs-serialization disambiguation (run before step 3):**
- Three dot-segments + `eyJ` prefix + decodable JSON header = JWT, not serialization — hand to `agent3_auth`
- Base64 blob that decodes to high-entropy bytes with no magic = encrypted or signed-then-encrypted — note it, test the tamper path once, move on

## Completion-bias defenses

- [ ] Every base64-ish value harvested and decoded before any verdict
- [ ] Format identified by magic bytes/structure, not guessed from stack
- [ ] Integrity check performed (tamper test) on every blob
- [ ] Right-format canary AND corrupted-blob baseline compared per endpoint
- [ ] Type-confusion differential attempted for error-message mining
- [ ] ViewState MAC status verified where __VIEWSTATE exists
- [ ] Stored/second-order path checked where blobs persist
- [ ] No gadget chain, no RCE payload, no ysoserial gadget executed — ever
- [ ] STOP line respected: skill ends at "bytes reach the deserializer"
- [ ] `findings/deserialization_probe.md` exists with verdict table
- **Review step:** agent10_review must verify (a) the canary-vs-corrupted differential is saved, (b) no gadget or OS-command payload appears in any saved request, (c) any escalation request is explicitly flagged for human approval, not auto-chained.
- **Nudge prompts:**
  - "Keep going until every encoded blob is decoded and classified — the session cookie you skipped is the Java serialized one."
  - "The tamper test comes before the canary. A signed blob you can't modify is a different finding than an open deserializer."
  - "Do not report done before findings/deserialization_probe.md exists on disk. And do not build a gadget chain — that decision is not yours."
- **Finished artifact definition:** `findings/deserialization_probe.md` — per-endpoint table (location, blob, format, integrity status, canary result, verdict) + decoded samples + raw pairs.

## Evidence standard

- Baseline: original blob behavior and corrupted-blob behavior saved before canaries.
- Reproduction: canary-vs-corrupted differential reproduced 2x.
- Raw evidence: the decoded blob bytes, the canary blob sent, and both responses.
- Verdicts: CONFIRMED (attacker bytes demonstrably reach the deserializer, 2x) / INCONCLUSIVE (behavior change once, or HMAC status unclear) / NEGATIVE (integrity enforced + verified, or blob is encrypted/JWT).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED rows — gadget-chain weaponization is a HUMAN-APPROVED chaining step only; the artifact must flag "escalation requires human approval."
- `agent3_auth`: receives session-token format findings (serialized sessions are also an auth-model concern).
- `agent10_review`: consumes `findings/deserialization_probe.md` — verifies the STOP line held before shipping.
