# Agent 5: Injection

## Role

Agent 5 owns the injection layer of the hunt: every vulnerability class where attacker-controlled input is interpreted as code, query, command, or structure by the server. Ten skills cover SQL, NoSQL, OS commands, template engines, LDAP/XPath, XXE, CSV formulas, HTTP headers, GraphQL, and deserialization. This agent's doctrine is context-first: fingerprint the interpreter (DBMS, engine, parser, serializer) before firing a single exploit, prove every claim with baselines and 2x reproduction, and stop at clearly marked STOP lines — exploitation beyond proof is a human-approved chaining decision, never an autonomous one. Injection findings are the highest-severity class in the hunt, so this agent's evidence bar is the strictest: no finding ships without raw pairs and a review-gate pass.

## The 10 skills

| Skill folder | What it does |
|---|---|
| sqli_context_map | Maps each parameter to error-based / blind / time-based SQLi context with DBMS fingerprinting; benign single-row proof only |
| nosql_injection | MongoDB operator injection ($ne/$gt/$regex), auth bypass with session proof, $where JS-context detection |
| command_injection | OS command contexts, blind/time-based detection, DNS-callback confirmation; benign id/whoami proof only |
| ssti_probe | Per-engine template fingerprinting (Jinja2/Twig/Freemarker/Smarty/ERB), sandbox-escape ladders climbed one rung at a time |
| ldap_xpath_injection | LDAP filter injection and XPath injection; boolean oracles with one-character canaries, auth-bypass shapes |
| xxe_upload | XXE via SVG/OOXML uploads; inline + OOB exfiltration canaries, small billion-laughs DoS canary, parser differentials |
| csv_formula_injection | Formula injection in exports; all four trigger characters, sanitizer differentials, raw-byte evidence |
| header_injection | CRLF/response splitting, log injection, Host header attacks (reset poisoning), cache poisoning via unkeyed headers |
| graphql_injection | Introspection mining, nested-query/alias/fragment DoS, alias-based authz bypass, batching attacks |
| deserialization_probe | Java/PHP/Python/.NET deserialization markers; gadget-chain-free canaries; hard STOP before weaponization |

## Inputs

- Endpoint + parameter inventory from `agent2_mapping` (URLs, methods, parameter names/types, upload endpoints, export endpoints, GraphQL routes)
- Tech-stack signals from `agent1_recon` (language/framework, DB hints, parser hints, serialized-blob sightings)
- Auth model + test accounts from `agent3_auth` (needed for Host-header reset poisoning and authenticated-context injection)
- Cache behavior from `agent4_cache` (needed for the cache-poisoning section of `header_injection`)
- Shared OOB collaborator namespace (coordinated with `command_injection`: `cmdi*` vs `xxe*` prefixes)

## Outputs

- `findings/sqli_context_map.md` — per-parameter SQLi verdict table with context classification
- `findings/nosql_injection.md` — per-endpoint NoSQL verdicts with session proof
- `findings/command_injection.md` — per-parameter command-injection verdicts with OOB evidence
- `findings/ssti_probe.md` — per-field engine fingerprints and escape-ladder rungs
- `findings/ldap_xpath_injection.md` — LDAP + XPath verdict tables with oracle evidence
- `findings/xxe_upload.md` — per-upload-endpoint XXE verdicts
- `findings/csv_formula_injection.md` — per-export formula-injection verdicts with raw-byte evidence
- `findings/header_injection.md` — CRLF / log / Host / cache-poisoning verdicts
- `findings/graphql_injection.md` + `graphql_schema.json` — GraphQL verdicts and mined schema
- `findings/deserialization_probe.md` — per-endpoint deserialization verdicts with STOP-line flags

## Handoffs

- `agent9_chaining` consumes all CONFIRMED rows: SQLi→auth bypass/data chains, command-injection→IMDS/lateral movement, SSTI RCE-context escalation, XXE SSRF, deserialization gadget weaponization — every escalation beyond proof requires human approval, flagged in the artifacts
- `agent7_bypass` consumes WAF/filter-evasion notes from `sqli_context_map` and `command_injection`
- `agent2_mapping` receives discovered attribute/schema names (LDAP/XPath) and the field→column map (CSV) to enrich the data model
- `agent4_cache` receives the unkeyed-header list from `header_injection`
- `xss_hunter` (agent6) consumes header-reflection points from `header_injection`
- `agent10_review` consumes all ten finding files — verifies evidence standards and STOP-line compliance before anything ships to the human

## Review gate

Before this agent's work ships: (1) every CONFIRMED finding has baseline + 2x reproduction + raw request/response pairs saved; (2) proof stayed within benign bounds — single-row reads, id/whoami/hostname, one canary character, no credential files, no IMDS fetches, no executed DDE/OS commands, no gadget chains; (3) every STOP line in `deserialization_probe`, `ssti_probe`, `xxe_upload`, and `command_injection` held — escalations are flagged "requires human approval," never auto-chained; (4) no spreadsheet app was used to open CSV payloads; (5) no password reset was triggered for any non-test account; (6) all ten finished artifacts exist on disk with verdict tables — a skill with no artifact file is not done.
