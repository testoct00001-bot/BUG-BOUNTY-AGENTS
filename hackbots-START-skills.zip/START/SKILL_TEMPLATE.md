---
name: <skill-slug>
agent: <agent-folder-name>
description: <one-line description>
---

# <Skill Name>

## Purpose

2–4 sentences: what this skill does and why it finds real, impactful bugs. Name the vulnerability class and the real-world impact.

## Division of labor

- **Consumes:** what input artifacts/files from other skills (exact filenames or formats)
- **Produces:** the finished artifact — the exact file/format whose existence counts as "done"

## When to use / when NOT to use

- **Use when:** concrete trigger conditions (what you observed that calls for this skill)
- **Skip when (time-pass filter):** conditions where running this skill is wasted effort. Ask: does it leak? Is it sensitive? Is it reachable unauthenticated?

## Methodology

Numbered steps, deep and specific — the actual technique, 10–20 steps. Each step says WHAT to do and WHAT to look for in the response. Include decision branches ("if you see X, do Y; if you see Z, pivot to ...").

## Exact commands

Full runnable commands — `curl`, `python3`, `bash` — copy-paste ready with placeholders like `<TARGET>`, `<HOST>`. Never just a tool name. Include:
- The baseline command (known-dead path for comparison)
- The probe commands
- The verification/reproduction commands

## Completion-bias defenses

- [ ] Markdown checklist of EVERY methodology step — the executing agent must tick each one, no skipping
- [ ] ...
- **Review step:** what the review agent (agent10_review) must verify before this skill's output ships
- **Nudge prompts:** 2–3 prompts, e.g. "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk."
- **Finished artifact definition:** the exact file path/format that proves this skill is done (e.g. `findings/<skill-slug>_confirmed.md` with raw pairs)

## Evidence standard

- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs

Which skills/agents consume this skill's output next, and exactly what they need from the finished artifact.
