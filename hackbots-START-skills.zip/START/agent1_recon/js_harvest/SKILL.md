---
name: js_harvest
agent: agent1_recon
description: Crawl every live HTTP service's homepage, robots.txt, and sitemap.xml to harvest every JavaScript URL (and source-map/config hints) into a harvest list that agent2 mines for endpoints.
---

# JS Harvest

## Purpose

Modern web apps ship their API surface in JavaScript bundles: endpoint paths, API versions, internal hostnames, feature flags, and credentials all hide in `.js` files that the homepage loads. Before any endpoint mining can happen (agent2), someone must collect the complete, deduplicated list of every JS URL each live service references — including bundles loaded from CDNs, lazy-loaded chunks, `robots.txt`-disclosed paths, and `sitemap.xml` URLs. This skill is that collector: it crawls shallow but completely, harvesting JS URLs plus source-map and config-file hints, and produces the single harvest list that agent2's miners consume. Miss a bundle here and agent2 never sees the endpoints inside it.

## Division of labor

- **Consumes:** `recon/http_services.txt` (from skill `port_service_mapping` — every HTTP/HTTPS host:port to crawl); `recon/wildcard_baseline.txt` (skip wildcard-ghost hosts that somehow slipped through).
- **Produces:** `recon/js_harvest.txt` (one absolute JS URL per line, deduplicated, across all services) and `recon/js_harvest_report.md` (per-service: JS count, notable non-JS assets found — source maps, configs, sitemap/robots hits). agent2 consumes `js_harvest.txt` directly.

## When to use / when NOT to use

- **Use when:** http_services.txt is fresh or updated; new hosts arrive from any enum skill; a service's homepage changed since the last harvest (re-run per service on change).
- **Skip when (time-pass filter):** the service returns the same static holding page as 50 siblings (CDN default page — harvest once, note the dedupe); the homepage is a bare API returning JSON with no HTML (no JS to harvest — record and move on, but DO check `/.well-known/`, `/robots.txt`, `/sitemap.xml` anyway).

## Methodology

1. For each entry in `recon/http_services.txt`, fetch `/` with a real browser User-Agent, following up to 3 redirects manually and recording the final URL. Save nothing but the HTML (max 500KB — abort larger; note truncation).
2. **Extract script references.** From the HTML, extract: `<script src="...">`, `<link rel="preload|modulepreload" href="...">` ending in `.js`, `import(` dynamic imports visible in inline scripts, `webpackChunk` public-path hints, `__NEXT_DATA__` / `__NUXT__` / `window.__` config blobs (note their presence — agent2 parses them), and `<script>` bodies containing `"/api/` or `https://` strings (note, don't mine — mining is agent2's job).
3. **Resolve to absolute URLs.** Resolve every relative `src` against the page's final URL (respect `<base href>` if present). Keep CDN-hosted URLs (third-party bundles get their own section — they still contain first-party config sometimes). Drop `data:` URLs and empty srcs.
4. **robots.txt.** Fetch `/robots.txt` per service. Record every `Disallow:` path (they are endpoint hints for agent2 — save to a `robots_hints` section of the report, NOT the JS list). Also fetch any `Sitemap:` URL it advertises.
5. **sitemap.xml.** Fetch `/sitemap.xml` (and `/sitemap_index.xml`). Extract all `<loc>` URLs. Any `.js` loc goes to the harvest list; the rest go to report hints (agent2 uses them as crawl seeds).
6. **Well-known and config probes.** Fetch `/.well-known/security.txt`, `/manifest.json`, `/asset-manifest.json`, `/sw.js`, `/service-worker.js`. Any JS found → harvest list. `security.txt` contact/policy → report (human-useful, not agent2).
7. **Source-map hints.** For each harvested JS URL, do a HEAD/GET on `<url>.map`. A 200 with `mappings` content = exposed source map — record in the report as HIGH-VALUE (agent2's source-map miner takes priority on these). Do NOT download full maps here (size); just flag.
8. **Deduplicate across services.** The same CDN bundle (e.g. a shared design-system JS) appears on 50 hosts — keep ONE copy in `js_harvest.txt` but record the host count in the report (widely-shared bundles with first-party config are interesting).
9. **Freshness check.** For each service, record an ETag/Last-Modified/content-hash of the homepage. On re-runs, skip services whose hash matches (nothing new to harvest) — this is the anti-completion-bias control in reverse: re-running blindly wastes the budget; skipping changed pages misses bundles.
10. **Write artifacts.** `recon/js_harvest.txt` (absolute JS URLs, one per line, deduped) + `recon/js_harvest_report.md` (per-service table: final URL, JS count, source-map hits, robots/sitemap hints, homepage hash).
11. **Chunk-manifest and runtime mining.** Bundlers ship manifests that list EVERY chunk: fetch `webpack-runtime-*.js` / `runtime-*.js` and grep for `chunkMapping`, `u.<name>` chunk IDs, and `publicPath` — each chunk ID is a predictable URL (`/<publicPath><chunkId>.js`) that may not be referenced by the homepage yet (lazy routes = hidden app areas). For Vite apps, fetch `/assets/manifest.json` if present. Add discovered chunk URLs to the harvest list.
12. **Import-map and modulepreload mining.** Parse `<script type="importmap">` blocks: the `imports` map lists bare specifiers → versioned CDN URLs, frequently including INTERNAL package URLs (`@company/internal-sdk@1.2.3` → registry tarball URLs that leak package contents). Also harvest `<link rel="modulepreload">` hrefs — these are JS the page needs but doesn't `<script>`-tag.

## Exact commands

Fetch homepage + extract script URLs (the core harvester, per service):
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
from urllib.parse import urljoin
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"}
def get(url):
    try:
        r=urllib.request.urlopen(urllib.request.Request(url,headers=UA),timeout=15,context=ctx)
        return r.url, r.read(500000).decode('utf-8','ignore')
    except Exception as e: return None, ""
base="https://api.example.com/"
final,html=get(base)
js=set()
for m in re.findall(r'<script[^>]+src=["\']([^"\']+)',html,re.I): js.add(urljoin(final,m))
for m in re.findall(r'<link[^>]+href=["\']([^"\']+\.js[^"\']*)',html,re.I): js.add(urljoin(final,m))
# inline-script API-ish strings -> report hints, not harvest
inline_apis=set(re.findall(r'["\'](/[a-zA-Z0-9_\-/]{3,80})["\']',html))
print("final:",final,"| js files:",len(js))
for u in sorted(js): print(" JS:",u)
print("inline path hints:",len(inline_apis))
open('/tmp/js_api.example.com.txt','w').write('\n'.join(sorted(js))+'\n')
EOF
```
Run per service in http_services.txt; merge all per-service files, dedupe, into `recon/js_harvest.txt`.

robots.txt + sitemap harvest:
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
def get(url):
    try: return urllib.request.urlopen(urllib.request.Request(url,headers=UA),timeout=10,context=ctx).read(200000).decode('utf-8','ignore')
    except Exception: return ""
base="https://api.example.com"
robots=get(base+"/robots.txt")
print("robots disallow:", re.findall(r'Disallow:\s*(\S+)',robots))
sm=re.search(r'Sitemap:\s*(\S+)',robots)
for smurl in [sm.group(1)] if sm else [base+"/sitemap.xml", base+"/sitemap_index.xml"]:
    xml=get(smurl)
    locs=re.findall(r'<loc>([^<]+)</loc>',xml)
    js=[l for l in locs if '.js' in l]
    print(smurl,"->",len(locs),"locs,",len(js),"js")
EOF
```

Source-map exposure check (flag, don't bulk-download):
```bash
python3 - <<'EOF'
import urllib.request, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
for jsurl in [l.strip() for l in open('recon/js_harvest.txt') if l.strip()][:500]:
    try:
        r=urllib.request.urlopen(urllib.request.Request(jsurl+".map",headers=UA),timeout=10,context=ctx)
        head=r.read(2000).decode('utf-8','ignore')
        if '"mappings"' in head or '"sources"' in head:
            print("SOURCEMAP EXPOSED:", jsurl+".map")
    except Exception: pass
EOF
```
Every hit goes to the report as HIGH-VALUE for agent2's source-map miner.

Config/manifest probes:
```bash
base="https://api.example.com"
for p in "/.well-known/security.txt" "/manifest.json" "/asset-manifest.json" "/sw.js"; do
  echo "== $p"; curl -sk -m 10 -A "Mozilla/5.0" "$base$p" | head -c 600; echo
done
```

Chunk-manifest mining (lazy-route chunks the homepage never references):
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
from urllib.parse import urljoin
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
def get(u):
    try: return urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=15,context=ctx).read(2000000).decode('utf-8','ignore')
    except Exception: return ""
# find the runtime chunk on the homepage, then mine its chunk map
html=get("https://api.example.com/")
runtimes=re.findall(r'src="([^"]*runtime[^"]*\.js)"',html)
chunks=set()
for rt in runtimes:
    body=get(urljoin("https://api.example.com/",rt))
    for m in re.findall(r'"([0-9a-z]{8,32})"\s*:\s*"([^"]+\.js)"',body):  # webpack chunkMapping-ish
        chunks.add(urljoin("https://api.example.com/",m[1]))
    for m in re.findall(r'publicPath\s*[:=]\s*["\']([^"\']+)',body):
        print("publicPath:",m)
# importmap mining
for m in re.findall(r'<script type="importmap"[^>]*>(.*?)</script>',html,re.S):
    for k,v in re.findall(r'"(@?[a-zA-Z0-9_/@.-]+)"\s*:\s*"([^"]+)"',m):
        if v.endswith('.js'): chunks.add(urljoin("https://api.example.com/",v)); print("importmap:",k,"->",v[:70])
print(len(chunks),"chunk/importmap JS URLs")
open('/tmp/js_chunks.example.com.txt','w').write('\n'.join(sorted(chunks))+'\n')
EOF
```
Merge chunk URLs into `recon/js_harvest.txt` — lazy chunks map to hidden app routes agent2 will mine.

## Completion-bias defenses

- [ ] Every entry in http_services.txt crawled (not just 443 hosts — odd-port services included)
- [ ] Redirect chains followed to final URL; `<base href>` respected in URL resolution
- [ ] robots.txt fetched per service; Disallow paths recorded as hints
- [ ] sitemap.xml + sitemap_index.xml + robots-advertised sitemaps all fetched; .js locs harvested
- [ ] Well-known/config probes (security.txt, manifest.json, asset-manifest.json, sw.js) attempted per service
- [ ] Source-map check run against every harvested JS URL; exposures flagged HIGH-VALUE
- [ ] Cross-service dedupe done; shared-bundle host counts recorded
- [ ] Homepage content-hash recorded per service for change detection on re-runs
- [ ] `recon/js_harvest.txt` written (absolute URLs, deduped); `recon/js_harvest_report.md` written
- [ ] Spot-check: 3 random services re-crawled; JS sets match
- **Review step:** agent10_review must verify: js_harvest.txt contains only absolute http(s) URLs ending in .js (or with .js path + query); every http_services.txt entry appears in the report's per-service table (or has a documented skip reason: JSON-API, holding page, fetch error); source-map hits are flagged; the dedupe didn't collapse distinct versioned bundles (spot-check 3).
- **Nudge prompts:**
  - "Crawl EVERY service in http_services.txt including the odd-port ones — the admin panel's bundle is the one that matters."
  - "robots.txt Disallow entries are endpoint hints, not JS — put them in the report hints section, and make sure agent2 gets them."
  - "Do not report done before recon/js_harvest.txt exists with absolute, deduplicated JS URLs."
- **Finished artifact definition:** `recon/js_harvest.txt` (one absolute JS URL per line, deduped) + `recon/js_harvest_report.md` (per-service table with JS counts, source-map hits, robots/sitemap hints, homepage hashes).

## Evidence standard

- Baseline: the service's homepage fetch itself — a JS URL counts only if it appeared in a fetched page/asset (no guessed bundle URLs)
- Reproduction: every harvested JS URL re-fetched with HEAD/GET once (200 + JS content-type or .js path) before entering the final list
- Raw evidence: per-service HTML saved to `recon/html/<host>_<port>.html` (truncated at 500KB, noted); robots/sitemap bodies saved alongside
- Verdicts: CONFIRMED (URL fetched, returns JS) / INCONCLUSIVE (fetch flaked — parked for re-run) / NEGATIVE (404/non-JS on re-check — dropped, noted in report so nobody re-adds it)

## Handoffs

- `recon/js_harvest.txt` → agent2 (endpoint mining: regex passes over bundles, source-map mining, config-blob parsing). This is agent1's single most important handoff — guard its completeness.
- Source-map HIGH-VALUE flags → agent2's source-map miner takes these FIRST (full original source > minified bundle).
- robots.txt Disallow paths + sitemap locs (report hints section) → agent2 as crawl seeds and predicted-path seeds.
- `security.txt` contacts → human review gate (disclosure contacts for later).
- Homepage hashes → next run of THIS skill (change detection).
