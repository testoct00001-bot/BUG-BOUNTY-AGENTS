---
name: crt_monitoring
agent: agent1_recon
description: Watch Certificate Transparency logs live for new certificates on watched roots and alert instantly — new certs mean new (often pre-launch, unhardened) subdomains, the highest-value recon signal.
---

# CT-Log Monitoring

## Purpose

New certificates are the earliest public signal of new infrastructure: a staging host gets its cert days or weeks before launch, and in that window it is unhardened, unaudited, and reachable. Polling CT logs for watched roots and alerting the INSTANT a new cert appears turns recon from a one-time sweep into a live tripwire. This skill maintains the watch list, polls the CT sources on a schedule, diffs against everything ever seen, and emits an alert artifact per new cert with the names, issuer, and first-seen timestamp — so the enum pipeline (skill `subdomain_enum`) can ingest the new names within minutes, while the host is still soft.

## Division of labor

- **Consumes:** `recon/watch_roots.txt` (one root domain per line — the watch list); `recon/ct_seen.txt` (every cert SHA256 fingerprint ever processed — the dedupe memory); `recon/subdomains.txt` (to diff "new name" vs "new cert for known name").
- **Produces:** `recon/ct_alerts/<YYYY-MM-DD_HH-MM>.md` (per-poll alert file, only when new certs found) and the maintained `recon/ct_seen.txt`. The alert file is the finished artifact of each poll — downstream skills ingest names from it.

## When to use / when NOT to use

- **Use when:** the watch list exists (run on schedule — hourly for hot targets, daily otherwise); after any major program-scope change; permanently as background infrastructure for the user's standing targets.
- **Skip when (time-pass filter):** a root has produced zero new certs in 30 days AND the program is confirmed inactive — downgrade it to weekly, don't delete (scope can reactivate silently). Never skip the diff step: re-alerting on known certs is noise, and noise gets the alerts ignored.

## Methodology

1. Maintain `recon/watch_roots.txt` — one bare root per line. Validate each line (no scheme, no wildcard prefix, no trailing dot). This file is the contract: every root in it gets polled every run.
2. **Poll source 1 — crt.sh.** For each root: `https://crt.sh/?q=%25.<root>&output=json`. Parse fingerprints — use crt.sh's `id` field per cert, or SHA256 of the cert if fetching PEMs. crt.sh is the primary source but it lags and rate-limits: 2s delay between roots, 3 retries with backoff.
3. **Poll source 2 — Google's CT lookup (independent).** Query `https://ct.googleapis.com/logs/...` is complex; the practical independent source is crt.sh's own mirror behavior PLUS per-name re-verification: for speed, alternate polls between crt.sh and a second aggregator (e.g. `https://api.certspotter.com/v1/issuances?domain=<root>&include_subdomains=true&expand=dns_names`). Two sources catch what one misses.
4. **Fingerprint and diff.** For each returned cert, compute a stable fingerprint (issuer + serial, or cert SHA256). Compare against `recon/ct_seen.txt`. Anything not in seen = NEW. Append new fingerprints to `ct_seen.txt` IMMEDIATELY (before alerting — a crash between alert and persist causes duplicate alerts, which is worse than a missed one... actually no: persist first, then alert; duplicates are noise, misses are lost finds — persist-then-alert is correct).
5. **Extract names.** For each new cert, extract ALL SANs. Classify each name: `NEW-NAME` (not in `recon/subdomains.txt` — highest priority), `KNOWN-NAME` (new cert for a known host — still interesting: cert renewal patterns, new SANs added), `OUT-OF-SCOPE` (SAN pointing outside watched roots — note as pivot, don't ingest).
6. **Triage the new names.** For each NEW-NAME: check issuance time (certs issued <24h ago = HOT — likely pre-launch), issuer (Let's Encrypt = automated, often CI/CD-spun; enterprise CA = deliberate infra), SAN count (single-name cert = dedicated host, more interesting than a 100-SAN CDN cert). Rank HOT first in the alert.
7. **Write the alert.** `recon/ct_alerts/<UTC-timestamp>.md` with: poll time, sources polled, certs seen total, NEW certs list (fingerprint, issuer, not-before, SANs, NEW-NAME vs KNOWN-NAME classification, HOT flag). If zero new certs: write NOTHING (no empty alert files — the absence of a file IS the "all quiet" signal; log the quiet poll to `recon/ct_poll.log` instead).
8. **Ingest path.** Append NEW-NAMEs to a delta file `recon/ct_new_names.txt` (cumulative, deduped). The harness (or human) feeds this delta into skill `subdomain_enum` steps 4+8–10 and skill `port_service_mapping` for the delta only — the full pipeline does NOT re-run.
9. **Backfill on gaps.** If `ct_poll.log` shows a gap >2 poll intervals (outage, rate-limit block), run a backfill: pull crt.sh with no time filter and diff the FULL history against ct_seen.txt (not just "recent") — certs issued during the blind window surface late, and they are exactly the ones that matter.
10. **Rate-limit discipline.** crt.sh blocks aggressive pollers. Rules: ≥2s between requests, ≤1 poll per root per hour minimum spacing, exponential backoff on 429/503 (wait 60s, 300s, 900s), and NEVER parallelize across roots against crt.sh. Getting blocked blinds the tripwire.
11. **Alert scoring rubric.** Score each new cert 0–10 so the human triages in seconds: +3 issued <24h ago (HOT), +2 single-SAN cert (dedicated host), +2 label in {admin, vpn, staging, dev, internal, console, api}, +2 issuer is enterprise/private CA (deliberate infra, not CI noise), +1 SAN count <5. Score ≥6 = surface to the human immediately; 3–5 = batched in the alert file's digest section; <3 = logged only. Write the score next to each cert in the alert.
12. **Quiet-root health metric.** A root quiet for 14+ days is either dormant or your poller is broken. Distinguish: once a week, poll a KNOWN-ACTIVE control root and confirm new certs appear for it (proves the pipeline works). If the control is quiet too, the poller is broken — fix it before trusting any "quiet" verdict. Log control results to `recon/ct_poll.log` with a `CONTROL` tag.

## Exact commands

Watch-list validation + single-root crt.sh poll:
```bash
mkdir -p recon/ct_alerts
cat recon/watch_roots.txt   # one bare root per line, e.g. example.com
ROOT="example.com"
curl -s --retry 3 --retry-delay 5 "https://crt.sh/?q=%25.$ROOT&output=json" -o /tmp/crt_$ROOT.json
python3 -c "
import json
d=json.load(open('/tmp/crt_$ROOT.json'))
print(len(d),'certs returned for $ROOT')
"
sleep 2  # politeness delay between roots — never remove
```

Fingerprint, diff against seen, extract and classify SANs:
```bash
python3 - <<'EOF'
import json, hashlib, os, datetime
ROOT="example.com"
seen=set(open('recon/ct_seen.txt').read().split()) if os.path.exists('recon/ct_seen.txt') else set()
known=set(l.strip() for l in open('recon/subdomains.txt')) if os.path.exists('recon/subdomains.txt') else set()
d=json.load(open(f'/tmp/crt_{ROOT}.json'))
new_certs=[]
for c in d:
    fp=hashlib.sha256(f"{c.get('issuer_name')}|{c.get('serial_number')}".encode()).hexdigest()[:32]
    if fp in seen: continue
    seen.add(fp)
    sans={n.strip().lower().lstrip('*.') for n in c.get('name_value','').split('\n') if n.strip()}
    new_names=sorted(n for n in sans if n.endswith('.'+ROOT) and n not in known)
    oos=sorted(n for n in sans if not n.endswith('.'+ROOT) and '.' in n)
    new_certs.append({"fp":fp,"issuer":c.get('issuer_name','?')[:60],
                      "not_before":c.get('not_before','?'),"sans":sorted(sans),
                      "new_names":new_names,"oos":oos})
open('recon/ct_seen.txt','w').write('\n'.join(sorted(seen))+'\n')
hot=[]
for nc in new_certs:
    try:
        nb=datetime.datetime.fromisoformat(nc["not_before"].replace('Z','+00:00'))
        nc["hot"]=(datetime.datetime.now(datetime.timezone.utc)-nb).total_seconds()<86400
    except Exception: nc["hot"]=False
    if nc["hot"]: hot.append(nc)
if new_certs:
    ts=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d_%H-%M')
    with open(f'recon/ct_alerts/{ts}_{ROOT}.md','w') as f:
        f.write(f"# CT alert {ts} UTC — {ROOT}\n\nnew certs: {len(new_certs)} (HOT <24h: {len(hot)})\n\n")
        for nc in sorted(new_certs,key=lambda x:(not x["hot"],x["not_before"])):
            f.write(f"## fp={nc['fp']} {'[HOT]' if nc['hot'] else ''}\nissuer: {nc['issuer']}\nnot_before: {nc['not_before']}\n")
            f.write(f"NEW names: {', '.join(nc['new_names']) or '-'}\nout-of-scope SANs: {', '.join(nc['oos'][:10]) or '-'}\n\n")
    delta=set()
    if os.path.exists('recon/ct_new_names.txt'): delta=set(open('recon/ct_new_names.txt').read().split())
    for nc in new_certs: delta.update(nc["new_names"])
    open('recon/ct_new_names.txt','w').write('\n'.join(sorted(delta))+'\n')
    print(f"ALERT: {len(new_certs)} new certs, {sum(len(nc['new_names']) for nc in new_certs)} new names -> recon/ct_alerts/{ts}_{ROOT}.md")
else:
    print("quiet: no new certs")
    open('recon/ct_poll.log','a').write(f"{datetime.datetime.now(datetime.timezone.utc).isoformat()} {ROOT} quiet\n")
EOF
```

Second-source cross-check (certspotter, alternate polls):
```bash
ROOT="example.com"
curl -s -m 30 "https://api.certspotter.com/v1/issuances?domain=$ROOT&include_subdomains=true&expand=dns_names" \
 | python3 -c "
import json,sys
d=json.load(sys.stdin)
print(len(d),'issuances from certspotter')
for i in d[:5]:
    print(i.get('not_before','?'), (i.get('dns_names') or [])[:4])
"
```

Backfill after a blind window (full-history diff, not just recent):
```bash
# same fingerprint/diff script as above, but run against a fresh FULL crt.sh pull
# for the root — any cert whose fp is missing from ct_seen.txt is a blind-window catch.
# Tag the alert file name with _BACKFILL so the human knows it's late-arriving.
```

## Completion-bias defenses

- [ ] watch_roots.txt validated (bare roots only, one per line)
- [ ] EVERY root polled every run (not just the first) with ≥2s politeness delay between requests
- [ ] Both sources attempted per run (crt.sh primary, certspotter alternate); source failures logged, not silently skipped
- [ ] Fingerprints persisted to ct_seen.txt BEFORE the alert file is written
- [ ] Every new cert's SANs classified: NEW-NAME / KNOWN-NAME / OUT-OF-SCOPE
- [ ] HOT flag (<24h since not-before) computed and ranked first in the alert
- [ ] Alert file written ONLY when new certs exist; quiet polls logged to ct_poll.log
- [ ] ct_new_names.txt delta updated (cumulative, deduped) for the ingest path
- [ ] Blind windows detected from ct_poll.log gaps; backfill run as full-history diff
- [ ] 429/503 backoff honored (60s → 300s → 900s); no parallel crt.sh requests
- **Review step:** agent10_review must verify (per alert): the alert file's cert fingerprints are absent from the pre-run ct_seen.txt (true novelty); NEW-NAMEs are absent from pre-run subdomains.txt; not-before timestamps support the HOT flags; out-of-scope SANs were not ingested into ct_new_names.txt; quiet periods have ct_poll.log lines (proving the poll ran, not that it was skipped).
- **Nudge prompts:**
  - "Poll EVERY root in watch_roots.txt every run — the quiet root is the one that surprises you."
  - "Persist fingerprints BEFORE writing the alert. A crash between alert and persist creates duplicate noise; noise kills the tripwire."
  - "After any blind window, backfill with a FULL-history diff — the certs issued while you were blind are the ones that matter most."
- **Finished artifact definition:** per poll with findings: `recon/ct_alerts/<UTC-timestamp>_<root>.md` (new certs, SAN classification, HOT flags) + updated `recon/ct_seen.txt` + updated `recon/ct_new_names.txt`. Per quiet poll: one line in `recon/ct_poll.log`.

## Evidence standard

- Baseline: the pre-run `ct_seen.txt` is the baseline — "new" means fingerprint-absent, nothing else
- Reproduction: every NEW-NAME re-verified via an independent lookup (crt.sh entry re-fetched, or the name's own TLS cert pulled per skill `tls_san_oracle`) before entering `ct_new_names.txt`
- Raw evidence: the raw JSON per poll saved to `recon/ct_raw/<timestamp>_<root>.json` (7-day retention, then prune — they're large)
- Verdicts: CONFIRMED (fingerprint-novel + SAN-verified) / INCONCLUSIVE (source returned malformed data — re-poll, don't alert) / NEGATIVE (quiet poll — logged, no alert file)

## Handoffs

- `recon/ct_new_names.txt` (delta) → skill `subdomain_enum` (cert-expansion + normalization on the delta), skill `port_service_mapping` (map the delta hosts), skill `js_harvest` (crawl delta hosts). The delta path exists so the full pipeline never re-runs for one new cert.
- HOT new names → human notification fast-path (pre-launch window is measured in days; the alert file's HOT section is written for skimming).
- Out-of-scope SAN pivots → skill `cloud_bucket_hunt` / `github_osint` vocabulary.
- `recon/ct_poll.log` gaps → this skill's own backfill step.
