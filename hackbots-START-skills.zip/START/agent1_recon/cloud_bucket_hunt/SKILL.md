---
name: cloud_bucket_hunt
agent: agent1_recon
description: Hunt misconfigured cloud storage — S3, GCS, Azure Blob — using bucket names derived from the target's own vocabulary; test each for anonymous list/read, never for write.
---

# Cloud Bucket Hunt

## Purpose

Companies name cloud buckets after themselves: `<company>-backups`, `<product>-uploads`, `<company>assets`, `<env>-<product>-data`. A bucket with public list or read exposes database dumps, user uploads, mobile-app plists with API keys, and CI artifacts — the classic "leaks, sensitive, reachable unauthenticated" trifecta, and frequently a direct critical. This skill generates candidate bucket names from the target's own vocabulary (skill `permutation_target_derived`), tests each against the three providers' anonymous-access endpoints, and classifies the exact exposure level. It NEVER attempts writes (write-testing a stranger's bucket is destructive and out of scope for recon).

## Division of labor

- **Consumes:** `recon/wordlist_target_derived.txt` (from skill `permutation_target_derived` — the vocabulary); `recon/dns_layer_report.md` (CNAME/vendor leaks hint at which cloud the target actually uses — prioritize that provider).
- **Produces:** `recon/buckets_found.md` (every confirmed-accessible bucket: provider, URL, exposure level, sample listing, verdict) — the finished artifact. Negative results go to `recon/buckets_tested.log` (so nobody re-tests).

## When to use / when NOT to use

- **Use when:** a new target root is onboarded; new vocabulary arrives (product launches, acquisitions — regenerate names); CNAME/DNS evidence shows the target on AWS/GCP/Azure.
- **Skip when (time-pass filter):** the target is confirmed 100% on-prem with no cloud footprint after DNS + cert + GitHub evidence all agree (rare — verify, don't assume). Never skip because "bucket names are hard to guess": the target-derived vocabulary is exactly what makes them guessable.

## Methodology

1. Build the vocabulary base: company name variants (with/without Inc/Ltd, camelCase splits), product names, brand names, env words (`prod`, `staging`, `dev`, `backup`, `archive`), asset words (`assets`, `static`, `media`, `uploads`, `downloads`, `files`, `data`, `logs`, `backups`, `dumps`, `private`, `public`, `test`). Source: `recon/wordlist_target_derived.txt` + manual additions from the target's homepage title/about page.
2. **Generate candidates** in provider-aware patterns:
   - S3: `<word>`, `<company>-<word>`, `<word>-<company>`, `<company><word>`, `<env>-<company>-<word>` (S3 names are global, lowercase, 3–63 chars, no underscores).
   - GCS: same patterns (GCS names are also global).
   - Azure: `https://<word>.blob.core.windows.net/<container>` — Azure splits account/container: test `<word>` as STORAGE ACCOUNT name first (account names are the scarce resource), then common container names (`uploads`, `assets`, `data`, `public`, `files`) inside any found account.
3. **Provider priority.** If DNS/CNAME evidence shows AWS (e.g. `s3.amazonaws.com` CNAMEs, `cloudfront.net`), test S3 first and deepest. GCP evidence → GCS first. Azure evidence → Azure first. No evidence → all three, S3 first (largest historical hit rate).
4. **Anonymous access tests per candidate** (read-only, in order):
   - S3: `GET https://<bucket>.s3.amazonaws.com/` → 200 + `<ListBucketResult>` = PUBLIC LIST (critical-class). `GET https://<bucket>.s3.amazonaws.com/?location` distinguishes "exists but private" (403/AccessDenied) from "doesn't exist" (404/NoSuchBucket). Also try the path-style `https://s3.amazonaws.com/<bucket>/` and regional `s3-<region>.amazonaws.com` (some buckets only answer regionally).
   - GCS: `GET https://storage.googleapis.com/<bucket>/` → 200 + list = PUBLIC. 404 vs 403 distinguishes the same way.
   - Azure: `GET https://<account>.blob.core.windows.net/<container>?restype=container&comp=list` → 200 = PUBLIC LIST. Also `https://<account>.blob.core.windows.net/` distinguishes account-exists (400/404 with account error) from account-missing.
5. **Classify exposure** per confirmed bucket: L0 exists-but-private (note only), L1 public LIST (enumerate object keys — keys often contain `backup.sql`, `.env`, `id_rsa`, user PII paths), L2 public READ on objects (fetch headers + first bytes of the 5 most interesting keys by name — NEVER bulk-download user data; record key names, sizes, content-types as the evidence), L3 public WRITE — DO NOT TEST. If a bucket's policy suggests write is possible, STOP and escalate to the human (write-testing is destructive).
6. **Key-name triage.** From any L1 listing, flag keys matching: `*.sql`, `*.dump`, `*.bak`, `.env`, `*.pem`, `*id_rsa*`, `*.p12`, `*password*`, `*secret*`, `*.plist` (mobile configs with API keys), `*prod*`, `*backup*`, `*user*`, `*customer*`. These key names go in the report verbatim — they ARE the finding's impact statement.
7. **Second-bucket pivots.** A confirmed bucket's listing often references sibling buckets (`backup-2024` next to `backup-2023`, `us-` next to `eu-`). Generate siblings from every confirmed bucket name and test them (one extra round).
8. **Dedupe and log.** Every tested candidate → `recon/buckets_tested.log` (`<provider> <name> <result-code>`). Confirmed buckets → `recon/buckets_found.md` with provider, URL, exposure level, sample keys, and the exact anonymous request that proved it.
9. **Rate discipline.** Bucket endpoints rate-limit aggressively. 1s delay between requests, ≤500 candidates per provider per run, stop a provider's round on 10 consecutive 503/SlowDown responses (back off 5 minutes).

## Exact commands

Candidate generation (provider-aware, from target vocabulary):
```bash
python3 - <<'EOF'
COMPANY="example"   # lowercase, no spaces — add variants: exampleinc, example-inc
WORDS=[w.strip() for w in open('recon/wordlist_target_derived.txt') if w.strip()][:120]
ENVS=["prod","production","staging","stage","dev","development","test","backup","backups","archive"]
ASSETS=["assets","static","media","uploads","downloads","files","data","logs","dumps","public","private","images","videos","docs"]
cands=set()
base=[COMPANY]+WORDS[:40]
for w in base:
    cands.add(w); cands.add(f"{COMPANY}-{w}"); cands.add(f"{w}-{COMPANY}")
for e in ENVS:
    cands.add(f"{e}-{COMPANY}"); cands.add(f"{COMPANY}-{e}")
    for a in ASSETS: cands.add(f"{e}-{COMPANY}-{a}")
for a in ASSETS: cands.add(f"{COMPANY}-{a}"); cands.add(f"{COMPANY}{a}")
cands={c.lower().replace('_','-')[:63] for c in cands if 3<=len(c)<=63}
open('recon/bucket_candidates.txt','w').write('\n'.join(sorted(cands))+'\n')
print(len(cands),'candidates')
EOF
```

S3 anonymous test (list vs private vs nonexistent):
```bash
python3 - <<'EOF'
import urllib.request, time, re
def s3test(bucket):
    for url in [f"https://{bucket}.s3.amazonaws.com/", f"https://s3.amazonaws.com/{bucket}/"]:
        try:
            r=urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=10)
            body=r.read(5000).decode('utf-8','ignore')
            if '<ListBucketResult' in body:
                keys=re.findall(r'<Key>([^<]{1,120})</Key>',body)
                return "PUBLIC-LIST", url, keys[:15]
            return f"HTTP{r.status}-nonlist", url, []
        except urllib.error.HTTPError as e:
            body=e.read(2000).decode('utf-8','ignore')
            if 'NoSuchBucket' in body: return "NEXIST", url, []
            if 'AccessDenied' in body: return "PRIVATE", url, []
            return f"HTTP{e.code}", url, []
        except Exception as e: return "ERR", url, []
    return "NEXIST", "", []
found=[]
for b in [l.strip() for l in open('recon/bucket_candidates.txt')][:500]:
    res,url,keys=s3test(b); time.sleep(1)
    print(b,res)
    open('recon/buckets_tested.log','a').write(f"s3 {b} {res}\n")
    if res=="PUBLIC-LIST": found.append((b,url,keys))
print("FOUND:",len(found))
for b,u,k in found: print("==",b,u,"\n  keys:",k[:8])
EOF
```
`PUBLIC-LIST` = finding. `PRIVATE` = exists but locked (note, move on). `NEXIST` = nothing.

GCS anonymous test:
```bash
b="example-assets"
curl -s -m 10 -A "Mozilla/5.0" "https://storage.googleapis.com/$b/" | head -c 800; echo
# 200 + <ListBucketResult> = PUBLIC-LIST; 404 NoSuchBucket vs 403 = same triage as S3
```

Azure account + container test:
```bash
python3 - <<'EOF'
import urllib.request, time
def aztest(account,container):
    url=f"https://{account}.blob.core.windows.net/{container}?restype=container&comp=list"
    try:
        r=urllib.request.urlopen(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=10)
        return "PUBLIC-LIST", r.read(3000).decode('utf-8','ignore')[:200]
    except urllib.error.HTTPError as e:
        return f"HTTP{e.code}", ""
    except Exception as e: return "ERR", ""
for acct in ["example","examplestorage","exampledata","exampleassets"]:
    for cont in ["uploads","assets","data","public","files","backup"]:
        res,_=aztest(acct,cont); time.sleep(1)
        print(acct,cont,res)
        open('recon/buckets_tested.log','a').write(f"azure {acct}/{cont} {res}\n")
EOF
```

Key-name triage on a public listing (headers + first bytes only, never bulk download):
```bash
BUCKET="example-backups"; KEY="db/prod-backup.sql"
curl -s -m 15 -I "https://$BUCKET.s3.amazonaws.com/$KEY" | grep -iE "^(content-length|content-type|last-modified):"
curl -s -m 15 -r 0-400 "https://$BUCKET.s3.amazonaws.com/$KEY" | head -c 400 | strings | head -20
# record key name + size + content-type as evidence; do NOT download the object
```

## Completion-bias defenses

- [ ] Vocabulary base built from wordlist_target_derived.txt + homepage-derived names (not just the company name alone)
- [ ] Provider priority set from DNS/CNAME evidence (documented which provider went first and why)
- [ ] All three providers tested (S3, GCS, Azure) unless evidence rules one out
- [ ] Every candidate classified NEXIST / PRIVATE / PUBLIC-LIST — no untested candidates left in the file
- [ ] Regional S3 endpoints tried for PRIVATE buckets (some only answer regionally — a PRIVATE on global may be PUBLIC-LIST regionally)
- [ ] Exposure leveled L0–L2 per confirmed bucket; L3 (write) NEVER tested — escalated to human if suspected
- [ ] Key-name triage done on every L1 listing; sensitive key patterns flagged verbatim
- [ ] Sibling-bucket round run from every confirmed bucket name
- [ ] `recon/buckets_found.md` written; `recon/buckets_tested.log` complete
- [ ] Rate discipline honored (1s delay, backoff on SlowDown)
- **Review step:** agent10_review must verify: every PUBLIC-LIST claim re-fetches the listing URL live; the report quotes the exact anonymous request proving access; no write attempts appear anywhere in this skill's history; key-name evidence lists names+sizes+content-types, not bulk-downloaded content; PRIVATE buckets were tried on ≥1 regional endpoint before being dismissed.
- **Nudge prompts:**
  - "Test the candidate on the REGIONAL endpoint too — a bucket that's PRIVATE on s3.amazonaws.com is sometimes PUBLIC-LIST on s3-us-west-2."
  - "A PUBLIC-LIST without key-name triage is half a finding. Flag every *.sql, .env, *.pem, *backup* key by name."
  - "NEVER test writes. If the policy suggests write access, stop and escalate to the human."
- **Finished artifact definition:** `recon/buckets_found.md` (provider, URL, exposure level L0–L2, sample key names/sizes/types, proving request per bucket) + `recon/buckets_tested.log` (every candidate + result code).

## Evidence standard

- Baseline: the `NoSuchBucket`/`NEXIST` response is the baseline — a PUBLIC-LIST claim must return `<ListBucketResult>` with actual `<Key>` entries, differing from baseline
- Reproduction: every PUBLIC-LIST re-fetched once (listings can be cached or transient); key headers re-fetched once
- Raw evidence: the listing XML (first 5KB), key names + sizes + content-types, and the exact curl/python request saved per bucket in the report
- Verdicts: CONFIRMED (anonymous GET returns a real listing on re-check) / INCONCLUSIVE (flaky/edge-cached — parked) / NEGATIVE (NEXIST or PRIVATE after regional retry — logged so nobody re-tests it)

## Handoffs

- `recon/buckets_found.md` → human review gate immediately for L1/L2 (public storage with sensitive keys is reportable; the human decides disclosure scope).
- Key names containing API keys/configs → skill `github_osint` (search the key strings — they often appear in public repos too).
- Bucket naming patterns that hit → skill `permutation_target_derived` (feed successful patterns back into the vocabulary: `<env>-<company>-<asset>` becomes a generator rule).
- PRIVATE-but-exists buckets → noted for agent2+ (authenticated paths may reference them; the name is confirmed real).
