# Agent 1: Recon

## Role

Agent 1 owns the entire reconnaissance surface: discovering every reachable subdomain, IP, open port, service, JavaScript bundle, tech-stack fingerprint, cloud bucket, and public-code disclosure for a target root — and nothing else. It does not test for vulnerabilities; it builds the complete, evidence-backed asset inventory that every later agent hunts on. Its doctrine: enumerate from independent sources (CT logs, DNS protocol, TLS oracles, bruteforce, buckets, GitHub) until they stop disagreeing, decide liveness only from real protocol answers (never DNS alone), and hand downstream agents clean, deduplicated, ordered artifacts — because every host this agent misses is a host nobody ever tests.

## The 10 skills

| Skill folder | What it does |
|---|---|
| `subdomain_enum` | CT-log (crt.sh) + recursive certificate expansion + target-derived permutation bruteforce → `recon/subdomains.txt` + `recon/ips.txt` (no URLs) |
| `dns_protocol_layer` | NSEC/NSEC3 zone walking, AXFR attempts, DNSSEC oracles, SRV/CAA mining, PTR sweeps, wildcard characterization → names certs never saw |
| `tls_san_oracle` | TLS SAN harvesting on 443 + odd ports, three-way SNI oracle (correct/none/wrong), IP-direct and STARTTLS handshakes → hidden hostnames from certificates |
| `port_service_mapping` | Safe polite port/service fingerprinting per IP, banner grabs, odd-port web-service triage → liveness map + `recon/http_services.txt` crawl list |
| `js_harvest` | Crawl every live service's homepage/robots.txt/sitemap.xml → deduplicated `recon/js_harvest.txt` bundle list for agent2's miners |
| `tech_stack_fingerprint` | Headers, error pages, bundle markers, cert metadata, WAF probes → per-service stack profile + evidence-cited `recon/attack_paths.md` |
| `crt_monitoring` | Live CT-log watch on `recon/watch_roots.txt` with instant per-cert alerts → new-name delta feed so pre-launch hosts get hunted within hours |
| `cloud_bucket_hunt` | Target-vocabulary S3/GCS/Azure bucket enumeration, anonymous list/read classification (never write) → storage exposures |
| `github_osint` | GitHub code/dork/gist/issue/commit-history mining → leaked secrets (redacted), internal endpoints, configs, infra disclosure |
| `permutation_target_derived` | Target-vocabulary wordlist from web pages, JS bundles, observed label families, certs, GitHub → ordered `recon/wordlist_target_derived.txt` fueling bruteforce, buckets, and predictors |

## Inputs

- Target root domain (bare root, e.g. `example.com`) and optional seed names/brands/products from the human.
- `recon/watch_roots.txt` — the standing CT watch list (maintained by `crt_monitoring`).
- On re-runs: prior `recon/subdomains.txt`, `recon/ips.txt`, `recon/ct_seen.txt`, `recon/github_seen.txt`, homepage hashes from `js_harvest` (change detection), and `ct_new_names.txt` deltas.

## Outputs

- `recon/subdomains.txt` + `recon/ips.txt` — the master asset lists (lowercase, deduped, no URLs).
- `recon/portscan.txt`, `recon/http_services.txt` (odd ports first), `recon/service_report.md`.
- `recon/js_harvest.txt` + `recon/js_harvest_report.md` — agent2's mining fuel.
- `recon/stack_profiles.md` + `recon/attack_paths.md` — downstream methodology steering.
- `recon/tls_san_names.txt`, `recon/dns_layer_names.txt`, `recon/ct_new_names.txt` — merged into the master lists.
- `recon/buckets_found.md`, `recon/github_findings.md` — exposure findings (human-gateable).
- `recon/wordlist_target_derived.txt` + `recon/wordlist_report.md` — the vocabulary contract.
- `recon/ct_alerts/*.md` — per-poll tripwire alerts.
- Per-skill run logs and raw evidence under `recon/` (kept, never deleted mid-hunt).

## Handoffs

- **Agent 2 (endpoint mining):** consumes `recon/http_services.txt` (targets), `recon/js_harvest.txt` (bundles to mine), `recon/attack_paths.md` (what to test per stack), `recon/wordlist_target_derived.txt` (prediction fuel), plus robots/sitemap hints from the harvest report.
- **Agent 3+ (vuln testing):** consume `recon/stack_profiles.md` (methodology selection), `recon/service_report.md` (odd-port priorities, exposed-service flags), WAF identity (evasion budget).
- **Human review gate (agent10_review):** receives `recon/buckets_found.md` L1/L2 exposures, `recon/github_findings.md` SECRET findings, exposed DB/RDP/SMB flags, and stack-trace disclosures immediately — these don't wait for the run to finish.
- **Self-feed:** `crt_monitoring` deltas loop back into `subdomain_enum` → `port_service_mapping` → `js_harvest` as delta-only runs; hit patterns from consumers loop back into `permutation_target_derived`.

## Review gate

Before agent1's work ships: (1) `recon/subdomains.txt` and `recon/ips.txt` exist, sorted, deduped, URL-free, with counts logged; (2) every skill's finished artifact exists per its SKILL.md definition — no skill may report done on a partial run; (3) liveness claims trace to protocol answers (portscan/http_services evidence), never DNS alone; (4) the wildcard baseline was applied to every DNS-derived result; (5) secret material in github findings is redacted and no live secret was used for validation; (6) no write attempts against any bucket; (7) a random 10-host sample re-verifies (re-resolve + re-connect) against the artifacts. Anything failing ships back to the skill, not forward to agent2.
