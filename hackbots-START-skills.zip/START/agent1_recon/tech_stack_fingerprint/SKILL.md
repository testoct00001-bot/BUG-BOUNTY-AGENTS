---
name: tech_stack_fingerprint
agent: agent1_recon
description: Identify each live service's full stack — framework, runtime, WAF/CDN, error signatures — from headers, error pages, JS bundles, and TLS certs, and derive the framework-specific attack paths agent2+ will test.
---

# Tech Stack Fingerprinting

## Purpose

Knowing the stack turns blind fuzzing into targeted hunting: a Next.js app means RSC/server-action endpoints, a Laravel app means debug-mode and route-listing tricks, an Envoy front means `;`-routing differentials, a WAF means filter-evasion planning. This skill fingerprints every live HTTP service across five evidence layers — response headers, error pages, JS bundle markers, TLS certificate metadata, and DNS/edge signals — and produces a per-service stack profile PLUS the derived attack-path checklist that downstream agents execute. Wrong stack assumptions waste entire runs; this skill makes the assumptions evidence-backed.

## Division of labor

- **Consumes:** `recon/http_services.txt` (targets), `recon/js_harvest.txt` (bundle URLs for framework markers), `recon/tls_san_report.md` (cert metadata), `recon/service_report.md` (edge mapping + banners from `port_service_mapping`).
- **Produces:** `recon/stack_profiles.md` (per-service: framework, runtime, WAF/CDN, server, language, confidence, evidence) and `recon/attack_paths.md` (per-service: framework-specific endpoint/attack checklist for agent2+). These two files steer all downstream testing.

## When to use / when NOT to use

- **Use when:** http_services.txt is fresh; any service's fingerprint is unknown or marked low-confidence; a new framework marker appears in harvested JS.
- **Skip when (time-pass filter):** the service is a static holding page with no app behavior AND no interesting headers (fingerprint once as `static/holding`, move on — but re-check if the homepage hash changes per `js_harvest` freshness data).

## Methodology

1. **Header layer.** For each service, record the FULL response header set for `/` and for a known-dead path (`/zzqx-nodead-9f8e7`). Fingerprint signals: `Server`, `X-Powered-By`, `X-AspNet-Version`, `X-Generator`, framework cookies (`_next`, `__session`, `XSRF-TOKEN`→Laravel, `csrftoken`→Django), `Set-Cookie` ordering, `Via`/`CF-RAY`/`Akamai-*`/`X-Amz-Cf-*` (edge), `X-Envoy-*`, `X-Kong-*`, `X-APIGW-*`. Compare live-path vs dead-path headers — frameworks often leak MORE on error paths.
2. **Error-page layer.** Request the dead path, `/admin`, `/.git/HEAD`, `/debug`, and a malformed path (`/%2e%2e/`). Record: status codes, error body signatures (Django debug yellow page, Laravel Ignition, Rails exceptions, Next.js 404 text, Spring Whitelabel, Express `Cannot GET`), stack-trace presence (ANY stack trace = HIGH-VALUE finding, screenshot the raw body for the human), and whether error pages differ by Accept header (`Accept: application/json` often flips an HTML app into a JSON error oracle).
3. **JS bundle marker layer.** Scan `recon/js_harvest.txt` bundle URLs AND filenames per service: `/_next/static/` → Next.js, `/assets/index-*.js` + `__NUXT__` → Nuxt, `main.*.js` + `ng-` → Angular, `/static/js/main.` → CRA/React, `/_astro/` → Astro, `/build/` + `manifest` → Remix, `wp-content`/`wp-includes` → WordPress, `/_svelte/` → SvelteKit. Fetch the LARGEST first-party bundle per service and grep for 20 framework strings (list in commands). Version strings (`"version":"4.2.1"`, `react@18`) → record exact versions for CVE mapping.
4. **TLS certificate layer.** From `tls_san_report.md` per host: issuer (private CA = self-hosted infra), subject O/OU (product names), SAN patterns (SaaS-vendor subdomains = managed service, not first-party code — fingerprint the VENDOR's stack, not the customer's).
5. **Edge/WAF layer.** Correlate with `service_report.md` edge mapping + active WAF probes: send a benign-but-suspicious path (`/?q=<script>`) and a known-WAF-trigger (`/etc/passwd` in query) and record which gets blocked, by what block page, with what status (403 vs 406 vs 419). Identify: Cloudflare (cf-ray + 403 managed challenge), Akamai (AkamaiGHost + reference codes), AWS WAF (405/403 with awselb), Imperva (incapsula cookies), F5 (BIG-IP ASM block page). WAF identity determines the evasion budget downstream.
6. **Behavioral layer.** Test: trailing-slash redirect behavior (`/x` → `/x/`?), case sensitivity (`/ADMIN` vs `/admin`), `;` parameter routing (`/robots.txt;foo` — Envoy/spring differentials), HTTP method set on `/` (OPTIONS → Allow header), and `/.well-known/change-password` style probes. These distinguish nginx vs Apache vs Envoy vs IIS fronting.
7. **Confidence scoring.** Per signal: HIGH (two independent layers agree, e.g. headers + bundle markers), MEDIUM (one layer), LOW (single weak hint). Never present a LOW fingerprint as fact — mark it and let agent2's testing confirm or kill it.
8. **Derive attack paths.** For each CONFIRMED or MEDIUM stack, write the framework-specific checklist into `recon/attack_paths.md`: e.g. Next.js → `/_next/static` chunk mining, RSC payload probes, `/_next/data` routes, server-action invocation; Laravel → `/telescope`, debug mode, route-list; Django → `/admin`, debug toolbar; WordPress → `wp-json`, xmlrpc, plugin paths; Spring → `/actuator`, Whitelabel tricks; Express → `/.git`, open-redirect patterns; Envoy front → `;` routing differentials, RBAC bypass shapes. Each path cites the evidence that justifies it.
9. **Version→CVE mapping.** For every exact version captured (framework, server, JS lib), note the version and check it against known-CVE memory ONLY as a lead (do not claim exploitability — agent2+ validates). EOL versions get flagged in the report regardless.
10. **Write the artifacts.** `recon/stack_profiles.md` (per-service table + evidence bullets + confidence) and `recon/attack_paths.md` (per-service targeted checklist). Both feed agent2's miners and every later agent's methodology choice.
11. **Favicon-hash pivot.** Fetch `/favicon.ico` per service, compute its MurmurHash3 (the Shodan favicon-hash technique): `python3 -c` with mmh3, or compare raw bytes. An identical hash across 50 hosts = shared platform (fingerprint once, apply everywhere); a UNIQUE hash on one host = custom app (prioritize it). Record hashes in the report — they also serve as change-detection alongside homepage hashes.
12. **Cookie and header-order fingerprinting.** Beyond cookie names: record the ORDER of Set-Cookie headers and response headers — frameworks emit them in deterministic order (Express vs Django vs Spring differ). Two services with identical header ORDER and server banners are the same stack even when Server headers are scrubbed. Note matches in the report as corroborating evidence.

## Exact commands

Full header capture, live path vs dead path (the differential is the fingerprint):
```bash
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
base="https://api.example.com"
echo "=== LIVE / headers:"; curl -sk -m 15 -A "$UA" -D - -o /dev/null "$base/"
echo; echo "=== DEAD path headers:"; curl -sk -m 15 -A "$UA" -D - -o /dev/null "$base/zzqx-nodead-9f8e7"
echo; echo "=== JSON Accept on dead path:"; curl -sk -m 15 -A "$UA" -H "Accept: application/json" -D - "$base/zzqx-nodead-9f8e7" | head -30
```

Error-page battery (signatures live here):
```bash
UA="Mozilla/5.0"
base="https://api.example.com"
for p in "/zzqx-nodead-9f8e7" "/admin" "/.git/HEAD" "/debug" "/%2e%2e/%2e%2e/etc/passwd"; do
  echo "===== $p"
  curl -sk -m 15 -A "$UA" -w "HTTP %{http_code} | size %{size_download}\n" "$base$p" -o /tmp/err_body.txt
  grep -oiE "(django|laravel|ignition|whitelabel|traceback|stack trace|exception|Cannot GET|Not Found|rails|spring|express|next\.js|nuxt)" /tmp/err_body.txt | sort | uniq -c | head
done
```
Any `Traceback`, `stack trace`, `at java.`, `in /var/www` output = HIGH-VALUE: save the full body to `recon/stack_traces/<host>_<path>.txt` and flag for the human.

Bundle marker scan (framework strings in the largest first-party bundle):
```bash
python3 - <<'EOF'
import urllib.request, ssl, re
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
MARKERS={"_next/static":"Next.js","__NUXT__":"Nuxt","/_astro/":"Astro","wp-content":"WordPress",
 "ng-version":"Angular","__REACT":"React","/_svelte/":"SvelteKit","remix":"Remix",
 "csrf-token.*laravel":"Laravel","drupalSettings":"Drupal","rails":"Rails","__NEXT_DATA__":"Next.js"}
# pick largest first-party bundle for the service from js_harvest.txt
cands=[l.strip() for l in open('recon/js_harvest.txt') if 'api.example.com' in l]
def size(u):
    try:
        r=urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=15,context=ctx)
        return len(r.read(3000000)), r.read if False else None
    except Exception: return 0,None
best=max(cands,key=lambda u:size(u)[0]) if cands else None
print("largest bundle:",best)
if best:
    body=urllib.request.urlopen(urllib.request.Request(best,headers=UA),timeout=20,context=ctx).read(3000000).decode('utf-8','ignore')
    for pat,name in MARKERS.items():
        if re.search(pat,body,re.I): print("MARKER:",name,"<-",pat)
    for v in set(re.findall(r'"version"\s*:\s*"([0-9][^"]{0,20})"',body)): print("VERSION-STRING:",v)
    for v in set(re.findall(r'(react|vue|angular|next|nuxt)@(\d+\.\d+\.\d+)',body,re.I)): print("LIB:",v)
EOF
```

WAF identification probes:
```bash
UA="Mozilla/5.0"
base="https://api.example.com"
echo "== benign xss-ish:"; curl -sk -m 15 -A "$UA" -w "%{http_code}\n" -o /tmp/w1.txt "$base/?q=<script>alert(1)</script>"; grep -oiE "(cloudflare|akamai|incapsula|imperva|awselb|big-ip|f5|blocked|attention required)" /tmp/w1.txt | sort | uniq -c
echo "== path traversal:"; curl -sk -m 15 -A "$UA" -w "%{http_code}\n" -o /tmp/w2.txt "$base/?f=/etc/passwd"; grep -oiE "(cloudflare|akamai|incapsula|imperva|reference #[0-9]|blocked)" /tmp/w2.txt | sort | uniq -c
echo "== block-page fingerprint:"; head -c 400 /tmp/w1.txt; echo; head -c 400 /tmp/w2.txt
```

Behavioral fronting tests:
```bash
UA="Mozilla/5.0"; base="https://api.example.com"
for u in "$base/x" "$base/x/" "$base/ADMIN" "$base/admin" "$base/robots.txt;foo=.css" "$base/"; do
  curl -sk -m 15 -A "$UA" -o /dev/null -w "%{http_code} %{redirect_url} :: $u\n" "$u"
done
curl -sk -m 15 -A "$UA" -X OPTIONS -D - -o /dev/null "$base/" | grep -i "^allow:"
```

Favicon hash (MurmurHash3, Shodan-style) for cross-host platform clustering:
```bash
python3 - <<'EOF'
import urllib.request, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
def mmh3(data):
    h=0
    for i in range(0,len(data)-len(data)%4,4):
        k=int.from_bytes(data[i:i+4],'little')
        k=(k*0xcc9e2d51)&0xffffffff; k=((k<<15)|(k>>17))&0xffffffff; k=(k*0x1b873593)&0xffffffff
        h^=k; h=((h<<13)|(h>>19))&0xffffffff; h=(h*5+0xe6546b64)&0xffffffff
    h^=len(data); h^=h>>16; h=(h*0x85ebca6b)&0xffffffff; h^=h>>13
    return (h-(1<<31)) if h>=(1<<31) else h
for host in ["api.example.com","admin.example.com","old.example.com"]:
    try:
        ico=urllib.request.urlopen(urllib.request.Request(f"https://{host}/favicon.ico",headers={"User-Agent":"Mozilla/5.0"}),timeout=10,context=ctx).read()
        print(host,"favicon mmh3:",mmh3(ico))
    except Exception as e: print(host,"ERR",str(e)[:40])
EOF
```
Identical hashes across hosts = same platform (fingerprint once); unique hash = custom app (prioritize).

## Completion-bias defenses

- [ ] Header layer done per service for BOTH live `/` and dead path (differential recorded)
- [ ] Error battery run (dead path, /admin, /.git/HEAD, /debug, malformed path) with signature grep
- [ ] JSON-Accept variant tested on the dead path
- [ ] Any stack trace found saved raw to recon/stack_traces/ and flagged HIGH-VALUE
- [ ] Largest first-party bundle per service fetched and marker-scanned; version strings recorded
- [ ] TLS cert layer cross-checked (issuer/subject/SAN patterns vs header findings)
- [ ] WAF probes run; edge/WAF identified with block-page evidence (or "no WAF detected" with the two probe outputs saved)
- [ ] Behavioral fronting tests run (trailing slash, case, `;` routing, OPTIONS)
- [ ] Every fingerprint has a confidence score (HIGH/MEDIUM/LOW) with cited evidence — no LOW presented as fact
- [ ] `recon/attack_paths.md` written with per-service framework-specific checklists, each path citing its evidence
- **Review step:** agent10_review must verify: stack_profiles.md covers every http_services.txt entry; every HIGH-confidence claim cites ≥2 independent layers; stack traces (if any) are saved raw and flagged; attack_paths.md has no generic entries — each path names the framework evidence that justifies it; LOW fingerprints are marked as such.
- **Nudge prompts:**
  - "Fingerprint from at least TWO independent layers before calling a stack CONFIRMED — headers alone lie behind CDNs."
  - "The dead path leaks more than the homepage. Never skip the error battery."
  - "Do not report done before recon/attack_paths.md exists with evidence-cited, framework-specific checklists."
- **Finished artifact definition:** `recon/stack_profiles.md` (per-service stack table + evidence + confidence) + `recon/attack_paths.md` (per-service targeted checklists with evidence citations).

## Evidence standard

- Baseline: the dead-path response is the baseline for error-signature claims; the live-path header set is the baseline for WAF claims (WAF verdict requires the probe to DIFFER from baseline)
- Reproduction: every framework marker re-verified (second fetch of the bundle, or a confirming second marker) before HIGH confidence
- Raw evidence: full header dumps, error bodies (truncated at 50KB), bundle marker hits, and WAF block pages saved under `recon/fp_evidence/<host>/`
- Verdicts: CONFIRMED (≥2 layers agree) / INCONCLUSIVE (single weak hint — marked LOW, agent2 testing will confirm/kill) / NEGATIVE (layers contradict — documented, no attack paths derived from the killed hypothesis)

## Handoffs

- `recon/stack_profiles.md` → agent2 (chooses mining techniques per stack), every later agent (methodology selection).
- `recon/attack_paths.md` → agent2+ as the executed checklist (each path becomes test tasks).
- Stack traces / debug pages → human review gate immediately (real info disclosure, potential critical lead).
- WAF identity → all content-testing skills (evasion budget and filter expectations).
- Exact versions → version→CVE lead list in the report (validation is downstream, never claimed here).
