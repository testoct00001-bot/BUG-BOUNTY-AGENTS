---
name: github_osint
agent: agent1_recon
description: Mine GitHub (code search, dorks, commit history) for the target's leaked secrets, internal endpoints, configs, and employee-side disclosures — public repos are unauthenticated by definition.
---

# GitHub OSINT

## Purpose

Developers commit secrets. Contractors fork internal tools into public repos. Employees paste internal URLs into gists and issues. GitHub code search across the target's org name, product names, domains, and employee handles surfaces: hardcoded API keys and tokens, internal endpoint URLs (`https://internal-api.<TARGET>/v2/...`), config files with production credentials, `.env` files, mobile app plists, Terraform/CI files revealing infrastructure, and historical commits where a secret was added then "removed" (git history never forgets). Everything here is public and unauthenticated — the purest form of the hunt's quality bar: it leaks, it's sensitive, it's reachable.

## Division of labor

- **Consumes:** target org names, product/brand names, domain variants (from `recon/wordlist_target_derived.txt` + human-provided scope); `recon/subdomains.txt` (internal hostnames become search pivots).
- **Produces:** `recon/github_findings.md` (every finding: repo URL, file path, what leaked, exposure class, verification status) and `recon/github_dorks_run.log` (every query executed + hit count). Findings feed the human gate directly (secrets) and agent2 (endpoints/configs).

## When to use / when NOT to use

- **Use when:** a new target root is onboarded; new product/brand names appear; after `cloud_bucket_hunt` finds key names worth searching; periodically (quarterly) — repos appear constantly.
- **Skip when (time-pass filter):** the org has zero public repos AND zero employee-attributable forks after the full dork battery (verify with the org page itself, not by assumption). Never skip the commit-history check on repos that DO exist: the current HEAD may be clean while history leaks.

## Methodology

1. **Org enumeration.** Find the target's GitHub org(s): search GitHub for the company name, check the company's website footer / careers page for github links, check common variants (`<company>`, `<company>-inc`, `<company>dev`, `<company>-oss`). List all public repos of each org with descriptions — forks of internal tools and "demo"/"example" repos are the highest-yield.
2. **Code-search dork battery.** Run each dork against github.com/search (authenticated code search if a token is available; otherwise the web UI queries via browser — note rate limits). Dork classes:
   - Secrets: `"<company>" "api_key"`, `"<company>" "aws_secret_access_key"`, `"<company>" password`, `"<company>" "client_secret"`, `"-----BEGIN RSA PRIVATE KEY" "<company>"`, `"<company>" "xoxb-"` (Slack), `"<company>" "ghp_"`, `"<company>" "sk_live_"` (Stripe)
   - Endpoints: `"<internal-hostname>"` (every interesting name from subdomains.txt, quoted), `"api.<TARGET>"`, `"<TARGET>" "internal"`, `"<TARGET>" "staging"`
   - Configs: `"<company>" filename:.env`, `"<company>" filename:config.json`, `"<company>" "terraform" "s3_bucket"`, `"<company>" filename:docker-compose.yml`
   - Employees: search code by known employee handles for `"<TARGET>"` outside the org (contractor laptops leak the most)
3. **Gist + issue mining.** Search gists for the company/domain (`site:gist.github.com <TARGET>` via web search). Search the org's own issues/PRs for pasted URLs, tokens, and internal hostnames — issues are where employees paste curl commands with `-H "Authorization: Bearer ..."`.
4. **Commit-history archaeology.** For every interesting repo: `git log -p --all -S "<secret-pattern>"` — search history for added-then-removed secrets. Also `git log --diff-filter=D --summary` for deleted files (deleted `.env` files are the classic). Shallow clones lie — always full clone for history work.
5. **Fork network walk.** For each org repo, list forks; forks by non-employees that add "fix" commits sometimes contain the internal config the fork needed to run. Sort forks by "recently pushed."
6. **Verification (no false positives).** Every secret-looking string gets classified: REAL (matches the provider's format AND length AND charset — e.g. AWS `AKIA[0-9A-Z]{16}`, 40-char base64 secret), PLACEHOLDER (`xxx`, `your-key-here`, `changeme`, `example`), TEST (`test`, `fake`, `dummy` in path/name). NEVER validate a live secret by using it (no API calls with someone's key — format-match + context is the evidence; the human decides disclosure). Endpoints found get verified by skill `port_service_mapping` (does the host answer?), not by guessing.
7. **Exposure classification.** Per finding: SECRET (credential/token/key — human gate immediately), ENDPOINT (internal URL — feed agent2), CONFIG (infra disclosure — feed `tech_stack_fingerprint`/`cloud_bucket_hunt`), PII (employee/customer data in repos — human gate, handle carefully, no bulk extraction).
8. **Dedup across runs.** Keep `recon/github_seen.txt` (repo+path+line-hash of every recorded finding). New runs diff against it — only novel findings enter the report update.
9. **Write the artifacts.** `recon/github_findings.md` (findings with repo URL, file path, leaked content REDACTED to format-proof — show `AKIA...XXXX (format-valid, 20 chars)` not the full key — exposure class, verification status) and `recon/github_dorks_run.log` (query → hit count).
10. **Employee-handle discovery.** Find the handles that leak the most: search LinkedIn/company blog for engineers, then GitHub search `user:<handle> "<TARGET>"` — code OUTSIDE the org under a real employee's handle is where staging URLs and test credentials surface. Also search commit AUTHOR emails (`<name>@<TARGET>`) via the GitHub commit search — commits from corporate emails in personal repos are a direct leak vector. Record handles in `recon/github_handles.txt` for re-use across runs.
11. **Organization artifact sweep.** Beyond code: check the org's public Packages (container images often embed `.env`), Releases (binaries/configs attached), Wikis, and Project boards (internal hostnames in task descriptions). A `docker-compose.yml` in a release asset is as good as one in the repo.
12. **Dork rotation schedule.** GitHub indexes new code continuously — re-run the full battery on a schedule: secrets class weekly, endpoints/configs monthly, full history archaeology quarterly (history only grows). Each run diffs against `recon/github_seen.txt`; the dork log gets a dated section per run so coverage gaps are visible.

## Exact commands

Org repo enumeration (via GitHub API, unauthenticated — 60 req/hr; use a token if available):
```bash
ORG="example"
curl -s -m 15 -A "Mozilla/5.0" "https://api.github.com/orgs/$ORG/repos?per_page=100&type=public" \
 | python3 -c "
import json,sys
for r in json.load(sys.stdin):
    print(r['full_name'],'| fork:',r['fork'],'| pushed:',r['pushed_at'][:10],'|', (r['description'] or '')[:70])
" | sort -t'|' -k3
```

Code-search dork battery (web code search; run each, record hit counts):
```bash
# Dorks to execute at https://github.com/search?q=<dork>&type=code (one per line, log hits):
# "<company>" "api_key" | "<company>" "aws_secret_access_key" | "<company>" "client_secret"
# "-----BEGIN RSA PRIVATE KEY" "<company>" | "<company>" "sk_live_" | "<company>" "ghp_"
# "api.<TARGET>" | "<TARGET>" "internal" | "staging.<TARGET>"
# "<company>" filename:.env | "<company>" filename:docker-compose.yml
# Gist variant via web search: site:gist.github.com "<TARGET>"
echo "Run each dork; append '<dork> => <hits>' to recon/github_dorks_run.log"
```

Commit-history secret archaeology (full clone required):
```bash
git clone --quiet https://github.com/example/interesting-repo.git /tmp/ghrepo && cd /tmp/ghrepo
for pat in "AKIA" "aws_secret" "api_key" "BEGIN RSA PRIVATE KEY" "client_secret" "password\s*="; do
  echo "== pattern: $pat"
  git log --all -p -S "$pat" --oneline | head -20
done
echo "== deleted files:"; git log --all --diff-filter=D --name-only --oneline | head -30
```

Fork network check:
```bash
ORG="example"; REPO="interesting-repo"
curl -s -m 15 "https://api.github.com/repos/$ORG/$REPO/forks?per_page=100&sort=stargazers" \
 | python3 -c "
import json,sys
for r in json.load(sys.stdin):
    print(r['full_name'],'| pushed:',r['pushed_at'][:10])
" | head -20
```

Format-validation for candidate secrets (evidence WITHOUT using the secret):
```bash
python3 - <<'EOF'
import re
s="AKIAIOSFODNN7EXAMPLE"  # paste the CANDIDATE only into this local check
checks={
 "AWS access key": r'^AKIA[0-9A-Z]{16}$',
 "AWS secret (40b64)": r'^[A-Za-z0-9/+=]{40}$',
 "GitHub PAT": r'^ghp_[A-Za-z0-9]{36,}$',
 "Slack token": r'^xox[baprs]-[A-Za-z0-9-]{10,}$',
 "Stripe live": r'^sk_live_[A-Za-z0-9]{16,}$',
 "RSA private key": r'-----BEGIN (RSA )?PRIVATE KEY-----',
 "Generic 32+ hex": r'^[a-f0-9]{32,}$',
}
for name,pat in checks.items():
    if re.match(pat,s): print("FORMAT-MATCH:",name)
if any(w in s.lower() for w in ["xxx","your-key","changeme","example","test","fake","dummy"]):
    print("PLACEHOLDER-INDICATOR present — likely not real")
EOF
```

Corporate-email commit author search (leak vector: corp email in personal repos):
```bash
# At https://github.com/search?q=<TARGET>+author-email&type=commits — or via API:
curl -s -m 15 -A "Mozilla/5.0" "https://api.github.com/search/commits?q=author-email:%22dev%40example.com%22" \
 -H "Accept: application/vnd.github.cloak-preview" \
 | python3 -c "
import json,sys
d=json.load(sys.stdin)
for i in d.get('items',[])[:10]:
    print(i['repository']['full_name'],'|',i['commit']['message'][:60])
"
# Any hit = employee committing from corp identity outside the org — clone that repo and run the history archaeology on it.
```

## Completion-bias defenses

- [ ] All org variants found and enumerated (not just the obvious one)
- [ ] Full dork battery executed per class (secrets, endpoints, configs, employees); hit counts logged
- [ ] Gists searched; org issues/PRs searched for pasted tokens/URLs
- [ ] Every interesting repo full-cloned; `-S` history search run for all secret patterns; deleted files listed
- [ ] Fork networks walked for top repos
- [ ] Every candidate secret format-validated locally; placeholders/test keys excluded with reason
- [ ] Findings classified SECRET / ENDPOINT / CONFIG / PII with verification status
- [ ] `recon/github_seen.txt` diffed; only novel findings added
- [ ] `recon/github_findings.md` written with REDACTED secret evidence; `recon/github_dorks_run.log` complete
- [ ] No live secret was ever used for validation (attest in the report)
- **Review step:** agent10_review must verify: every SECRET finding shows a format-match (not just "looks like a key"); placeholder exclusions are documented; the report contains NO full secret values (redaction check); endpoint findings have a verification path assigned (port_service_mapping); dork log covers all four classes.
- **Nudge prompts:**
  - "Clone FULL history, not shallow — the secret was removed from HEAD in 2021 and it's still in the history."
  - "Search the FORKS and the ISSUES, not just the org's code — that's where the curl commands with tokens get pasted."
  - "Format-validate every candidate locally. 'Looks secret-ish' is not a finding."
- **Finished artifact definition:** `recon/github_findings.md` (repo URL, file path, REDACTED evidence, exposure class, verification status per finding) + `recon/github_dorks_run.log` (every query + hit count) + `recon/github_seen.txt` (dedupe memory).

## Evidence standard

- Baseline: the repo's current HEAD is the baseline for "leaked" claims — a secret counts as leaked if present in HEAD OR in history (history-leaks flagged as HISTORICAL with the commit hash)
- Reproduction: every finding re-fetched (raw file URL) once before entering the report — repos get force-pushed and files deleted
- Raw evidence: repo URL + file path + commit hash + REDACTED format proof (pattern name, length, charset class). NEVER the full secret value in any file.
- Verdicts: CONFIRMED (format-valid + context-valid, e.g. in a config file, not in test fixtures) / INCONCLUSIVE (format-valid but in ambiguous context — parked for human) / NEGATIVE (placeholder/test/example — documented pattern so nobody re-flags it)

## Handoffs

- SECRET findings → human review gate IMMEDIATELY (do not wait for the run to finish — a live key in a public repo is time-critical for disclosure).
- ENDPOINT findings (internal URLs) → skill `port_service_mapping` (verify the host answers) then agent2.
- CONFIG findings → skill `tech_stack_fingerprint` (infra disclosure) and skill `cloud_bucket_hunt` (bucket names from configs).
- Search pivots (new product names, employee handles, internal hostnames) → skill `permutation_target_derived` (vocabulary enrichment).
