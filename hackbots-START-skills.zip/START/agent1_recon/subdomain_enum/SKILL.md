---
name: subdomain_enum
agent: agent1_recon
description: Enumerate every reachable subdomain of a target root via CT logs, recursive certificate expansion, and target-derived permutation bruteforce; finished output is subdomains.txt + ips.txt only (no URLs).
---

# Subdomain Enumeration

## Purpose

Subdomain enumeration is the foundation of the entire hunt: every host you miss is a host you never test. This skill finds the widest possible set of live `<label>.<TARGET>` names using three independent sources — Certificate Transparency logs (every publicly-trusted TLS cert is logged, and certs contain the names), recursive certificate expansion (each new name's own certificate reveals still more names), and bruteforce with permutations derived from the target's own vocabulary (skill `permutation_target_derived`). A single overlooked subdomain — a forgotten staging host, a vendor-managed service, an exposed dev console — is exactly the class of target that produced Haddix's 4 criticals in one 6-hour run. This skill finds them all, deduplicates them, resolves them to IPs, and hands the rest of the pipeline a clean list.

## Division of labor

- **Consumes:** `recon/wordlist_target_derived.txt` (from skill `permutation_target_derived` — target-vocabulary wordlist); optional seed list `recon/seeds.txt` if any names are already known.
- **Produces:** `recon/subdomains.txt` (one lowercase bare hostname per line, no wildcards, no URLs) and `recon/ips.txt` (one unique IP per line). These two files are the finished artifacts — nothing else counts as done.

## When to use / when NOT to use

- **Use when:** starting a new target root; before any host-by-host testing begins; after a new cert-log alert arrives from skill `crt_monitoring`; when a recursive expansion round finds new names (re-run until no new names appear).
- **Skip when (time-pass filter):** the root has zero web surface and zero interesting services (pure parking page with no subdomains after 3 rounds — verify with crt.sh first, because parking domains still issue certs for sub-brands). Never skip this skill because "DNS resolved everything" — DNS answers are not liveness.

## Methodology

1. Create the working directory `recon/` and set `TARGET=<root>` (bare root only, e.g. `example.com`, never `https://`).
2. **Round 1 — crt.sh Certificate Transparency pull.** Query crt.sh for `%25.<TARGET>` with `output=json`. Parse every `name_value`, split multi-line entries, strip `*.` wildcard prefixes, lowercase everything, keep only names ending in `.<TARGET>`. This catches names ever issued a public cert.
3. **Round 1b — crt.sh for common-label services.** Repeat the query for `<TARGET>` alone (catches SANs on the bare root) and, if the root is large, split by label: query `%25.<label>.<TARGET>` for the top 20 most frequent second-level labels found in step 2 (this catches deeper-nesting certs that the wildcard query truncates, since crt.sh caps results).
4. **Round 2 — recursive certificate expansion.** For EVERY name found in steps 2–3, fetch its live TLS certificate (`openssl s_client -connect <host>:443 -servername <host>`) and extract ALL SANs. Any new `*.<TARGET>` name goes back into the queue. This is recursive: each new name gets its cert pulled until a full round adds zero new names. Cert-expansion catches names crt.sh missed (certs issued minutes ago, certs via private sub-CAs, SANs on odd names).
5. **Round 3 — permutation bruteforce.** Build candidate labels from `recon/wordlist_target_derived.txt` combined with env prefixes (`dev`, `staging`, `stage`, `test`, `qa`, `uat`, `prod`, `api`, `internal`, `admin`, `vpn`, `legacy`, `old`, `new`, `beta`, `alpha`, `demo`) in the patterns: `<word>`, `<word>-<env>`, `<env>-<word>`, `<word>.<env>` (depth 2). Resolve each candidate via DoH (never trust local resolver — it may be poisoned or synthetic; see wildcard handling in step 6).
6. **Wildcard DNS guard.** BEFORE trusting any resolution: resolve 5 random labels like `zzqx-<RANDOM>.<TARGET>` via DoH. If they resolve, the zone is wildcarded — every bruteforce guess "resolves." Record the wildcard IP set. A guess is a REAL hit only if its answer differs from the wildcard IP set AND answers consistently across two different resolvers (1.1.1.1 and 8.8.8.8 via DoH).
7. **HTTP liveness is NOT decided here.** This skill records names, not live hosts. Resolution to any IP counts as "enumerated." Agent-side service mapping (skill `port_service_mapping`) decides liveness via real HTTP answers. Never delete a name because DNS answered oddly.
8. **Normalize and dedupe.** Lowercase all names; strip trailing dots; drop names that don't end in `.<TARGET>`; drop exact duplicates; drop wildcard-prefixed names (`*.x` → treat as evidence that `x`-zone issues wildcards, keep the base name once).
9. **Resolve every name to IPs.** Query A and AAAA via DoH for every name in `subdomains.txt`. Record all answers. Collapse to unique IPs in `ips.txt`. A name may have zero answers (dark/DNS-only) — keep the name anyway; note `NOANSWER` count.
10. **Second-source spot check.** For the top 20 most interesting labels (admin, vpn, api, staging, dev, console, internal, sso, auth, billing...), verify each via a DIFFERENT enumeration path (cert SAN of the host itself, or an independent CT source like Google's CT lookup). If >2 differ, re-run the round that produced them.
11. **Review pass.** Walk the final `subdomains.txt` looking for patterns a human would miss: label families (`svc-<word>`, `<word>01`, `eu-<word>`), numeric sequences (`db1`..`db9`), region prefixes (`us-`, `eu-`, `ap-`), vendor patterns (`*.cloudprovider.com` CNAMEs — note them for skill `cloud_bucket_hunt`). Feed new patterns back into step 5 for one more targeted round.
12. **Freeze the artifacts.** Write `recon/subdomains.txt` and `recon/ips.txt` sorted and deduplicated. Record counts: total names, names with A records, unique IPs, NOANSWER count. Append a run line to `recon/enum_runs.log` with date, rounds run, and counts. These files are now the contract for every downstream skill.

## Exact commands

Baseline (known-dead label — proves the wildcard guard works; run FIRST, keep the output):
```bash
TARGET="example.com"
for i in 1 2 3 4 5; do
  R="zzqxnodeadbeef$i.$TARGET"
  curl -s "https://cloudflare-dns.com/dns-query?name=$R&type=A" -H "accept: application/dns-json" | python3 -c "import json,sys; d=json.load(sys.stdin); print('$R ->', [a['data'] for a in d.get('Answer',[])])"
done
```
If any of these resolve, you have a wildcard zone — note its IPs and subtract them in step 6.

crt.sh round 1:
```bash
mkdir -p recon
TARGET="example.com"
curl -s --retry 3 "https://crt.sh/?q=%25.$TARGET&output=json" \
 | python3 -c "
import json,sys
seen=set()
for c in json.load(sys.stdin):
    for n in c['name_value'].split('\n'):
        n=n.strip().lower().lstrip('*.')
        if n.endswith('.$TARGET') or n=='$TARGET':
            seen.add(n)
open('recon/subdomains_round1.txt','w').write('\n'.join(sorted(seen))+'\n')
print(len(seen),'names from crt.sh')
"
```

Recursive cert SAN expansion (run until it prints "0 new names"):
```bash
python3 - <<'EOF'
import ssl, socket, subprocess, re
TARGET="example.com"
known=set(open('recon/subdomains_round1.txt').read().split())
new=set()
for h in sorted(known):
    try:
        out=subprocess.run(['openssl','s_client','-connect',f'{h}:443','-servername',h],
                           input=b'',capture_output=True,timeout=15).stdout.decode('utf-8','ignore')
        cert=re.search(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',out,re.S)
        if not cert: continue
        san=subprocess.run(['openssl','x509','-noout','-ext','subjectAltName'],
                           input=cert.group(0).encode(),capture_output=True,timeout=10).stdout.decode()
        for m in re.findall(r'DNS:([^\s,]+)',san):
            n=m.strip().lower().lstrip('*.')
            if (n.endswith('.'+TARGET) or n==TARGET) and n not in known:
                new.add(n)
    except Exception: pass
open('recon/subdomains_certexpand.txt','w').write('\n'.join(sorted(new))+'\n')
print(len(new),'new names from cert expansion')
EOF
```
Merge, dedupe, and repeat the expansion loop on the merged set until a pass adds zero names.

Permutation bruteforce (needs `recon/wordlist_target_derived.txt`; uses DoH so local poisoned resolvers can't lie):
```bash
python3 - <<'EOF'
import json, urllib.request, itertools
TARGET="example.com"
ENVS=["dev","staging","stage","test","qa","uat","prod","api","internal","admin","vpn","legacy","old","new","beta","demo"]
words=[w.strip() for w in open('recon/wordlist_target_derived.txt') if w.strip()]
cands=set()
for w in words:
    cands.add(f"{w}.{TARGET}")
    for e in ENVS:
        cands.update([f"{e}-{w}.{TARGET}",f"{w}-{e}.{TARGET}"])
def doh(name):
    q=urllib.request.Request(f"https://cloudflare-dns.com/dns-query?name={name}&type=A",
                             headers={"accept":"application/dns-json"})
    try:
        d=json.load(urllib.request.urlopen(q,timeout=10))
        return sorted(a['data'] for a in d.get('Answer',[]) if a.get('type')==1)
    except Exception: return []
wild=set()
for i in range(3):
    wild.update(doh(f"zzqxnodead{i}.{TARGET}"))  # wildcard baseline
hits={}
for c in sorted(cands):
    ips=doh(c)
    if ips and set(ips)!=wild:
        hits[c]=ips
open('recon/subdomains_bruteforce.txt','w').write('\n'.join(sorted(hits))+'\n')
print(len(hits),'bruteforce hits after wildcard subtraction')
EOF
```

Resolve all names to IPs and freeze the final artifacts:
```bash
python3 - <<'EOF'
import json, urllib.request
TARGET="example.com"
names=sorted({l.strip().lower().rstrip('.') for f in
    ['recon/subdomains_round1.txt','recon/subdomains_certexpand.txt','recon/subdomains_bruteforce.txt']
    for l in open(f) if l.strip()})
names=[n for n in names if n.endswith('.'+TARGET) or n==TARGET]
def doh(name,rt):
    q=urllib.request.Request(f"https://cloudflare-dns.com/dns-query?name={name}&type={rt}",
                             headers={"accept":"application/dns-json"})
    try:
        d=json.load(urllib.request.urlopen(q,timeout=10))
        return [a['data'] for a in d.get('Answer',[]) if a.get('type') in (1,28)]
    except Exception: return []
ips=set(); noanswer=0
for n in names:
    got=doh(n,'A')+doh(n,'AAAA')
    if got: ips.update(got)
    else: noanswer+=1
open('recon/subdomains.txt','w').write('\n'.join(names)+'\n')
open('recon/ips.txt','w').write('\n'.join(sorted(ips))+'\n')
print(f"names={len(names)} unique_ips={len(ips)} noanswer={noanswer}")
EOF
```

## Completion-bias defenses

- [ ] `recon/` directory exists and `TARGET` is the bare root (no scheme, no path)
- [ ] Wildcard guard run FIRST; wildcard IP set recorded (or "no wildcard" confirmed)
- [ ] crt.sh round 1 executed; `recon/subdomains_round1.txt` exists with count > 0 (or a documented zero with retry evidence — crt.sh does time out)
- [ ] crt.sh split-by-label round executed for top-20 labels (step 3)
- [ ] Cert expansion loop run until a full pass adds ZERO new names (record pass counts)
- [ ] Bruteforce round executed against the target-derived wordlist with DoH + wildcard subtraction
- [ ] Bruteforce hits verified against the wildcard guard from TWO resolvers (1.1.1.1 and 8.8.8.8 DoH)
- [ ] Normalization pass: lowercase, no wildcards, no URLs, only `.<TARGET>` suffixes
- [ ] Every name resolved via DoH (A+AAAA); `NOANSWER` names kept, count recorded
- [ ] Human-pattern review pass done (label families, numeric sequences, region prefixes); at least one targeted re-round run from its findings
- [ ] `recon/subdomains.txt` and `recon/ips.txt` written, sorted, deduplicated, with counts logged to `recon/enum_runs.log`
- [ ] Spot check: 20 interesting labels re-verified via an independent source
- **Review step:** agent10_review must confirm: both finished artifacts exist on disk; counts are consistent (ips.txt lines ≤ names with answers × reasonable factor); a random sample of 10 names from subdomains.txt is re-resolved by the reviewer and matches; no URLs appear anywhere in the artifacts; the enum_runs.log has the final run line.
- **Nudge prompts:**
  - "Keep expanding certificates until a FULL pass adds zero new names — stopping after round 1 is completion bias, and round 3 is where the staging hosts hide."
  - "Do not report done before BOTH recon/subdomains.txt AND recon/ips.txt exist on disk, sorted and deduplicated."
  - "Every bruteforce hit must survive the wildcard subtraction AND a second resolver — a guess that resolves to the wildcard IP is not a find."
- **Finished artifact definition:** `recon/subdomains.txt` (one lowercase bare hostname per line, no wildcards, no URLs) and `recon/ips.txt` (one unique IP per line), plus a final line in `recon/enum_runs.log` with the run date and counts.

## Evidence standard

- Baseline: the wildcard-guard dead labels from the first command, kept as `recon/wildcard_baseline.txt`
- Reproduction: every bruteforce hit re-checked via a second DoH resolver (8.8.8.8) before entering subdomains.txt
- Raw evidence: crt.sh JSON response saved to `recon/crtsh_raw.json`; cert-expansion new-name list kept per round
- Verdicts: CONFIRMED (name appears in ≥2 independent sources or resolves via 2 resolvers with non-wildcard answers) / INCONCLUSIVE (single weak source — parked for the next CT alert round) / NEGATIVE (wildcard-ghost or NXDOMAIN on re-check — documented in enum_runs.log so nobody re-tests it)

## Handoffs

- `recon/subdomains.txt` → skill `port_service_mapping` (liveness via real HTTP), skill `js_harvest` (crawl targets), skill `tech_stack_fingerprint` (per-host analysis), agent2 (endpoint mining targets).
- `recon/ips.txt` → skill `port_service_mapping` (odd-port services per IP), reverse-DNS/ASN grouping for sibling discovery.
- `recon/wildcard_baseline.txt` → every downstream skill that resolves names (they must apply the same subtraction).
- New names from skill `crt_monitoring` alerts feed back here: re-run steps 4, 8–10 on the delta only.
