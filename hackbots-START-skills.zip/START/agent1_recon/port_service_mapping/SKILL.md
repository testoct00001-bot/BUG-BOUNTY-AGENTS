---
name: port_service_mapping
agent: agent1_recon
description: Map every open port and service on every enumerated host/IP with safe, low-noise fingerprinting — banner grabs and unusual-port web services — deciding liveness only from real protocol answers, never DNS.
---

# Port & Service Mapping

## Purpose

A subdomain that resolves is not a live target; a port that answers with a real protocol banner is. This skill turns the flat name/IP lists from `subdomain_enum` into a service map: which ports are open on which hosts, what protocol each speaks, what the banner reveals (software, version, hostname), and — critically — which unusual ports speak HTTP(S) (admin panels on 8443, APIs on 9000, dashboards on 9090 are where unauthenticated finds live). It is deliberately SAFE: no exploit payloads, no aggressive scanning, SYN-level politeness, per-host rate limits — because this runs against live bug-bounty programs and getting the harness's IP blocked ends the hunt. Liveness is decided here, by protocol answers, and nowhere else.

## Division of labor

- **Consumes:** `recon/subdomains.txt`, `recon/ips.txt` (from skill `subdomain_enum`); `recon/wildcard_baseline.txt` (to avoid mapping wildcard-ghost IPs as real services).
- **Produces:** `recon/portscan.txt` (format: `<host-or-ip>:<port> <protocol> <banner-first-line>`), `recon/http_services.txt` (every host:port that answered HTTP/HTTPS — the crawl target list for skill `js_harvest` and agent2), and `recon/service_report.md` (interesting services, version anomalies, odd-port web finds).

## When to use / when NOT to use

- **Use when:** fresh subdomains.txt/ips.txt exists; new names arrive from `tls_san_oracle`, `dns_protocol_layer`, or `crt_monitoring` alerts (map the delta only); before any content-level testing begins.
- **Skip when (time-pass filter):** a host already has a complete recent map (<7 days) and no new ports appeared — re-verify only the interesting ports. Never skip the unusual-port HTTP check on newly found hosts: the standard 80/443-only view misses the admin panels.

## Methodology

1. Deduplicate targets: map each unique IP once for the full port sweep (hosts sharing an IP share the network surface), then do per-HOSTNAME checks only for HTTP/S ports (vhost routing differs per name). This keeps the scan polite and fast.
2. **TCP port sweep per unique IP.** Connect-scan (full TCP handshake, no SYN stealth — stealth scanning against bounty targets is indistinguishable from hostile recon) the port list: 21,22,23,25,53,80,110,111,135,139,143,443,445,993,995,1723,3306,3389,5432,5900,6379,8080,8443,27017, plus the extended list: 444,1080,1433,1521,2049,2082,2083,2087,2096,3000,3001,3128,3307,4000,4040,4443,4567,5000,5001,5433,5601,5672,5901,5985,5986,6379,6443,7000,7001,7070,8000,8001,8006,8008,8009,8010,8020,8030,8040,8042,8081,8088,8089,8090,8100,8140,8181,8200,8300,8403,8444,8500,8543,8880,8888,8983,9000,9001,9042,9043,9060,9080,9090,9091,9092,9200,9300,9443,9444,9700,9999,10000,10443,11211,15672,27018. Timeout 5s per port, max 20 concurrent connections per IP, 1s delay between hosts.
3. **Banner grab every open port.** On connect, wait up to 5s for the server's banner (FTP/SMTP/SSH send first). If silent, send a protocol-appropriate probe: `HEAD / HTTP/1.0\r\n\r\n` for suspected HTTP, `\r\n` for line-based, empty TLS ClientHello for suspected TLS. Record the first 200 chars of the response. NEVER send exploit strings, version-specific probes, or auth attempts — banner only.
4. **Protocol identification per port.** Classify: `http`, `https`, `ssh`, `ftp`, `smtp`, `dns`, `database` (mysql/postgres/mongo/redis banners), `unknown-tcp`. For ambiguous ports, try HTTP first (most odd-port finds are HTTP), then TLS, then record as unknown with the raw bytes.
5. **Unusual-port web service deep check.** For every port that answered HTTP/HTTPS outside 80/443: fetch `/` with a normal browser UA, record status code, title tag, server header, and redirect target. These go to the TOP of `recon/http_services.txt` — odd-port web is disproportionately admin panels, debug dashboards, and forgotten APIs.
6. **Per-hostname HTTP/S check.** For each name in subdomains.txt: request `http://<host>/` and `https://<host>/` (follow redirects manually, max 3, recording each hop). Record final status, title, server header. This catches vhost-routed apps invisible at the IP level (CDN/WAF fronted hosts).
7. **TLS-on-odd-port detection.** For open ports with no cleartext banner, attempt a TLS handshake; on success mark `https` and hand the host:port to skill `tls_san_oracle` for cert harvesting (it owns certs; this skill owns the port map).
8. **Version anomaly triage.** Flag: EOL software versions in banners (OpenSSH 7.x, nginx 1.14, Apache 2.2), default appliance banners (VMware, Citrix, F5 BIG-IP, Palo Alto), database ports open to the world (3306/5432/6379/27017 reachable = immediate critical lead, verify twice then escalate to human — do NOT attempt auth), and SMB/RDP exposed (note only, no auth attempts).
9. **WAF/CDN edge detection.** Note when many hostnames resolve to the same IP set with identical banners — that's an edge (Cloudflare/Akamai/CloudFront). Record the edge provider per IP; downstream content skills must test THROUGH the edge per-hostname, not just at the IP.
10. **Write the artifacts.** `recon/portscan.txt` (every open port with protocol + banner), `recon/http_services.txt` (all HTTP/HTTPS host:ports, odd ports first), `recon/service_report.md` (per-IP tables, odd-port web finds, version anomalies, exposed-database/RDP/SMB flags, edge mapping).

## Exact commands

Polite connect-scan of one IP (the per-IP sweep primitive — loop over ips.txt):
```bash
python3 - <<'EOF'
import socket
PORTS=[21,22,23,25,53,80,110,143,443,445,993,995,1723,3306,3389,5432,5900,6379,8080,8443,27017,
       444,1433,1521,2082,2083,2087,2096,3000,3128,4000,5000,5601,5672,5985,5986,6443,7001,
       8000,8001,8006,8008,8009,8081,8088,8089,8090,8181,8444,8888,9000,9001,9043,9060,9080,
       9090,9091,9200,9300,9443,9999,10000,10443,11211,15672]
ip="203.0.113.10"
open_ports=[]
for p in PORTS:
    s=socket.socket(); s.settimeout(5)
    try:
        s.connect((ip,p)); open_ports.append(p)
    except Exception: pass
    finally: s.close()
print(ip, "open:", open_ports)
EOF
```
Run with 1s sleep between IPs and max ~20 hosts per batch to stay polite. Full-handshake connect() only — no half-open SYN games.

Banner grab with protocol fallback (safe probes only):
```bash
python3 - <<'EOF'
import socket, ssl
def grab(host,port):
    s=socket.socket(); s.settimeout(6)
    try: s.connect((host,port))
    except Exception: return port,"closed",""
    try: data=s.recv(512)  # banner-first protocols
    except Exception: data=b""
    if not data:
        for probe in [b"HEAD / HTTP/1.0\r\nHost: x\r\n\r\n", b"\r\n"]:
            try:
                s.sendall(probe); data=s.recv(512)
                if data: break
            except Exception: pass
    if not data:  # maybe TLS
        try:
            ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            t=ctx.wrap_socket(s,server_hostname=host); data=b"TLS-OK "+t.version().encode()
            s=t
        except Exception: pass
    s.close()
    line=data[:200].decode('utf-8','ignore').replace('\n',' | ')
    return port,"open",line
for p in [22,80,443,3000,8000,8080,8443,9000,9090]:
    print(grab("203.0.113.10",p))
EOF
```

Odd-port web check (status, title, server header — the triage that finds admin panels):
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
def check(url):
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"})
    try:
        r=urllib.request.urlopen(req,timeout=10,context=ctx)
        body=r.read(20000).decode('utf-8','ignore')
        title=re.search(r'<title[^>]*>(.*?)</title>',body,re.I|re.S)
        print(r.status, url, "| server:", r.headers.get('Server'), "| title:", (title.group(1).strip()[:80] if title else '-'))
        return True
    except Exception as e:
        print("ERR", url, str(e)[:60]); return False
for p in [3000,8000,8001,8080,8081,8089,8443,8888,9000,9001,9090,9091,9443,10000]:
    check(f"http://203.0.113.10:{p}/"); check(f"https://203.0.113.10:{p}/")
EOF
```

Per-hostname HTTP/S vhost check (catches CDN-fronted apps):
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
class NoRedir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**k): return None
op=urllib.request.build_opener(NoRedir)
for h in [l.strip() for l in open('recon/subdomains.txt')][:300]:
    for scheme in ("http","https"):
        url=f"{scheme}://{h}/"
        try:
            r=op.open(urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=10,context=ctx)
            body=r.read(15000).decode('utf-8','ignore')
            title=re.search(r'<title[^>]*>(.*?)</title>',body,re.I|re.S)
            loc=r.headers.get('Location')
            print(r.status,url,"->",loc or "-","|",(title.group(1).strip()[:70] if title else '-'))
        except urllib.error.HTTPError as e:
            print(e.code,url,"| HTTPError")
        except Exception as e:
            print("ERR",url,str(e)[:50])
EOF
```

## Completion-bias defenses

- [ ] Every unique IP in ips.txt got the full TCP port sweep (not just 80/443)
- [ ] Every open port got a banner grab with the protocol-fallback sequence
- [ ] Every ambiguous port classified (http/https/ssh/ftp/smtp/dns/database/unknown-tcp) — no "open, unknown" rows left unprobed
- [ ] Every odd-port HTTP/HTTPS service fetched `/` with status/title/server recorded
- [ ] Every hostname in subdomains.txt got the http:// and https:// vhost check (batched, all batches)
- [ ] TLS-on-odd-port detected and handed to tls_san_oracle with host:port list
- [ ] Version anomalies triaged (EOL banners, appliance defaults, exposed DB/RDP/SMB flagged)
- [ ] Edge/CDN mapping recorded per IP (many hostnames → same IP + identical banner = edge)
- [ ] `recon/portscan.txt`, `recon/http_services.txt` (odd ports first), `recon/service_report.md` all written
- [ ] Exposed database/RDP/SMB findings re-verified from a second source IP before flagging (NAT/proxy false positives are common)
- **Review step:** agent10_review must verify: portscan.txt has no "open, unknown" rows; http_services.txt lists odd-port services first with status/title/server columns; a random sample of 5 open ports re-connects successfully; exposed-DB/RDP/SMB flags have second-source verification noted; no exploit payloads or auth attempts appear in any command history for this skill.
- **Nudge prompts:**
  - "Scan the FULL port list on every unique IP — the admin panel on 8443 is worth more than 100 clean 443s."
  - "An 'open, unknown' row is unfinished work, not a result. Classify every port."
  - "Do not report done before recon/http_services.txt exists with odd-port services listed first."
- **Finished artifact definition:** `recon/portscan.txt` (`<host-or-ip>:<port> <protocol> <banner>` per line, no unknowns), `recon/http_services.txt` (every HTTP/HTTPS host:port, odd ports first), `recon/service_report.md` (per-IP tables, odd-port web finds, anomaly flags, edge mapping).

## Evidence standard

- Baseline: port 80/443 behavior per host is the baseline — an odd-port claim must differ from it (different title/server/status) to be flagged interesting
- Reproduction: every open port re-connected once; every odd-port web title re-fetched once (titles on dynamic ports can be load-balancer artifacts)
- Raw evidence: full banner first-lines in portscan.txt; status/title/server/location per HTTP service in the report
- Verdicts: CONFIRMED (port answers with a real protocol banner on re-check) / INCONCLUSIVE (flaky answer — parked, re-check next run) / NEGATIVE (filtered/timeout on re-check — documented so nobody re-tests it)

## Handoffs

- `recon/http_services.txt` → skill `js_harvest` (crawl list), agent2 (endpoint-mining targets), skill `tech_stack_fingerprint` (per-service analysis).
- `recon/portscan.txt` → skill `tls_san_oracle` (TLS-on-odd-port host:port list for cert harvesting).
- Exposed DB/RDP/SMB flags → straight to the human review gate (agent10_review) as potential critical leads — verify twice, never attempt auth.
- Edge/CDN mapping → skill `tech_stack_fingerprint` (WAF/CDN identification) and all content skills (test per-hostname through the edge).
