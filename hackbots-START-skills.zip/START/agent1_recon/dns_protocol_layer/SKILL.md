---
name: dns_protocol_layer
agent: agent1_recon
description: Walk the DNS protocol layer itself — NSEC/NSEC3 zone walking, zone-transfer attempts, DNSSEC oracles, and wildcard detection — to extract names the certificate logs never saw; never trust DNS alone for liveness.
---

# DNS Protocol Layer

## Purpose

Certificate Transparency only shows names that got public certs. The DNS protocol layer shows names that exist regardless of certs: misconfigured DNSSEC exposes entire zones through NSEC/NSEC3 walking, stale zone transfers leak internal names, and wildcard behavior itself is an oracle for bruteforce filtering. This skill extracts subdomains purely from DNS protocol mechanics — no wordlists, no guessing. An NSEC3-walked internal hostname (`vpn-<region>.<TARGET>`) that never got a public cert is invisible to crt.sh and invisible to bruteforce, but fully reachable. Those are the hosts that become SSRF pivots and admin-panel finds.

## Division of labor

- **Consumes:** `TARGET` root; `recon/wildcard_baseline.txt` from skill `subdomain_enum` (wildcard IP set, so walks can be sanity-checked); optional list of authoritative nameservers from a prior NS lookup.
- **Produces:** `recon/dns_layer_names.txt` (new names found ONLY via DNS protocol techniques, one per line) and `recon/dns_layer_report.md` (which technique yielded what, zone-transfer verdict, DNSSEC status, wildcard behavior). These feed back into the master `recon/subdomains.txt`.

## When to use / when NOT to use

- **Use when:** a new target root is onboarded (run alongside subdomain_enum); a zone shows DNSSEC signatures (NSEC/NSEC3 records present); NS records point at self-hosted or obscure providers (higher misconfiguration rate); bruteforce found suspicious label families worth zone-walking around.
- **Skip when (time-pass filter):** the zone is on a major managed DNS (Route53, Cloudflare, Akamai) with no DNSSEC and no AXFR — walking yields nothing and the effort is better spent on cert expansion. Never skip the wildcard check: it protects every other skill's DNS results.

## Methodology

1. Identify the authoritative nameservers: `dig NS <TARGET> +short` via DoH against 1.1.1.1 AND 8.8.8.8. Record them. Try each one directly for every subsequent step — some allow AXFR to the world while the anycast front does not.
2. **Zone transfer attempt (AXFR).** Against EACH authoritative NS, attempt `dig AXFR <TARGET> @<ns>`. Also try IXFR. If AXFR succeeds, you have the whole zone — extract every name, you're done with steps 3–6 for this root (still do step 7). AXFR success is rare but total.
3. **DNSSEC detection.** Query `dig DNSKEY <TARGET>` and `dig DS <TARGET>`. If DNSKEY exists, the zone is signed — check for NSEC vs NSEC3: query a known-nonexistent name (`zzqxnodead.<TARGET>`) for its NSEC/NSEC3 proof records in the authority section.
4. **NSEC walking (unsigned-name disclosure).** If the zone uses NSEC (not NSEC3): each NSEC record's "next name" field chains to the next existing name. Start at the apex, follow the chain: query the next name, read its NSEC, follow again, until you loop back to the apex. Every name in the chain is a real zone name — including names with no certs and no web records (TXT-only, SRV targets, CNAMEs to internal hosts).
5. **NSEC3 walking (hashed-name disclosure).** If the zone uses NSEC3: names are hashed (salt + iterations in the NSEC3PARAM). You cannot read names directly, but you CAN enumerate the hash chain and then crack short/predictable labels offline with the known salt — build candidate labels from `recon/wordlist_target_derived.txt`, hash each with the zone's exact salt+iterations, and match against the walked hashes. Also record ALL hashes: any hash that never cracks is still evidence of an unknown name (note it as `NSEC3-UNKNOWN-<hash>` for the human).
6. **Wildcard characterization.** Query the wildcard-guard labels from `subdomain_enum` plus 3 fresh random ones, against EACH authoritative NS directly. Record: does the wildcard answer differ per NS? Does it answer for ALL types or only A? A wildcard that answers A but not TXT/MX tells you the zone is partially managed — real names often hide behind partial wildcards (e.g. `*.apps.<TARGET>`).
7. **SRV/TXT/CAA record mining.** Query `_sip._tcp`, `_xmpp-server._tcp`, `_autodiscover._tcp`, `_dmarc`, and `CAA` for `<TARGET>` and for every second-level label in `recon/subdomains.txt`. SRV targets and CAA `issue` values leak vendor/CA relationships and internal hostnames. TXT records leak verification tokens (proving ownership of third-party services — pivot to skill `cloud_bucket_hunt` and `github_osint`).
8. **CNAME-chain following.** For every name in `recon/subdomains.txt` that is a CNAME, follow the full chain to the terminal A record. Record the terminal names — they are often `<vendor>-<id>.cloudprovider.com` style names that reveal the hosting stack and sometimes the customer's internal naming scheme.
9. **Reverse-DNS sweep of `recon/ips.txt`.** PTR-query every IP in `recon/ips.txt` via DoH. PTR names frequently reveal the TRUE internal hostname (`ip-10-0-1-5.ec2.internal` is boring; `vpn-gw-02.<TARGET>` is a find). Any PTR ending in `.<TARGET>` not already in subdomains.txt goes to `dns_layer_names.txt`.
10. **Merge and dedupe.** Add all new names to `recon/dns_layer_names.txt`, merge into the master `recon/subdomains.txt` (re-run the normalization from `subdomain_enum` steps 8–10 on the merged set), and write `recon/dns_layer_report.md` documenting: AXFR verdict per NS, DNSSEC/NSEC/NSEC3 status, wildcard behavior, SRV/CAA findings, PTR finds, and counts.

## Exact commands

Authoritative NS discovery (two resolvers, compare):
```bash
TARGET="example.com"
for r in "https://cloudflare-dns.com/dns-query" "https://dns.google/resolve"; do
  echo "== $r"
  curl -s "$r?name=$TARGET&type=NS" -H "accept: application/dns-json" \
   | python3 -c "import json,sys; d=json.load(sys.stdin); print([a['data'] for a in d.get('Answer',[])])"
done
```

Zone transfer attempts against each authoritative NS:
```bash
TARGET="example.com"
for ns in $(dig NS $TARGET +short); do
  echo "== AXFR via $ns"
  dig AXFR $TARGET @$ns +time=10 +tries=1 | grep -E "^[a-zA-Z0-9]" | head -50
done
```
Success looks like a full record dump; `Transfer failed` or timeout = NEGATIVE, move on.

DNSSEC + NSEC/NSEC3 detection:
```bash
TARGET="example.com"
dig DNSKEY $TARGET +short | head -3
echo "--- NSEC/NSEC3 proof for a dead name:"
dig zzqxnodeadbeef.$TARGET +dnssec | grep -E "NSEC3? " | head -5
```

NSEC walk (only if step above shows NSEC records):
```bash
python3 - <<'EOF'
import subprocess, re
TARGET="example.com"
cur=TARGET; seen=set(); names=set()
for _ in range(5000):
    out=subprocess.run(['dig','+short','NSEC',cur],capture_output=True,text=True,timeout=10).stdout
    # NSEC format: <next-name> <types...>; parse next name from full dig
    full=subprocess.run(['dig','NSEC',cur],capture_output=True,text=True,timeout=10).stdout
    m=re.search(rf'{re.escape(cur)}\.\s+\d+\s+IN\s+NSEC\s+(\S+)',full)
    if not m: break
    nxt=m.group(1).rstrip('.').lower()
    names.add(cur); 
    if nxt in seen or nxt==TARGET: break
    seen.add(cur); cur=nxt
open('/tmp/nsec_walk.txt','w').write('\n'.join(sorted(names)))
print(len(names),'names walked via NSEC')
EOF
```

NSEC3 hash cracking with the zone's real salt (extract salt+iterations from NSEC3PARAM first):
```bash
dig NSEC3PARAM example.com +short
# then crack walked hashes against wordlist_target_derived.txt with that salt —
python3 - <<'EOF'
import hashlib, base64
# FILL from NSEC3PARAM output: iterations, salt (hex)
ITERATIONS=10; SALT=bytes.fromhex("A1B2C3")
def nsec3(name):
    h=hashlib.sha1(SALT+name.lower().encode()+SALT).digest()
    for _ in range(ITERATIONS):
        h=hashlib.sha1(h+SALT).digest()
    return base64.b32encode(h).decode().rstrip('=')
walked=set(open('/tmp/nsec3_hashes.txt').read().split())  # hashes from zone walk
words=[w.strip() for w in open('recon/wordlist_target_derived.txt') if w.strip()]
cracked={nsec3(w+".example.com"):w+".example.com" for w in words}
hits=[cracked[h] for h in walked if h in cracked]
open('recon/dns_layer_names.txt','a').write('\n'.join(sorted(hits))+'\n')
print(len(hits),'NSEC3 hashes cracked;',len(walked)-len(hits),'remain unknown')
EOF
```

SRV / TXT / CAA mining:
```bash
TARGET="example.com"
for t in "_sip._tcp" "_xmpp-server._tcp" "_autodiscover._tcp" "_dmarc"; do
  echo "== $t.$TARGET"
  dig +short SRV $t.$TARGET; dig +short TXT $t.$TARGET
done
echo "== CAA $TARGET"; dig +short CAA $TARGET
echo "== CAA per label:"; for n in $(cut -d. -f1 recon/subdomains.txt | sort -u | head -40); do
  dig +short CAA $n.$TARGET | grep -q . && echo "$n.$TARGET: $(dig +short CAA $n.$TARGET | tr '\n' ' ')"
done
```

Reverse-DNS sweep of known IPs:
```bash
python3 - <<'EOF'
import json, urllib.request, ipaddress
def ptr(ip):
    rev=ipaddress.ip_address(ip).reverse_pointer
    q=urllib.request.Request(f"https://cloudflare-dns.com/dns-query?name={rev}&type=PTR",
                             headers={"accept":"application/dns-json"})
    try:
        d=json.load(urllib.request.urlopen(q,timeout=10))
        return [a['data'].rstrip('.').lower() for a in d.get('Answer',[])]
    except Exception: return []
names=set()
for ip in open('recon/ips.txt').read().split():
    for n in ptr(ip.strip()):
        if n.endswith('.example.com'): names.add(n)
open('recon/dns_layer_names.txt','a').write('\n'.join(sorted(names))+'\n')
print(len(names),'PTR-derived names')
EOF
```

## Completion-bias defenses

- [ ] Authoritative NS list captured from TWO resolvers and compared
- [ ] AXFR attempted against EVERY authoritative NS (not just the first), result recorded per NS
- [ ] DNSKEY/DS queried; NSEC vs NSEC3 determined from a dead-name proof (not assumed)
- [ ] If NSEC: full chain walked until loop-back to apex (not stopped at 50 names)
- [ ] If NSEC3: salt+iterations extracted from NSEC3PARAM; wordlist hashed with the EXACT parameters; uncracked hashes logged as NSEC3-UNKNOWN
- [ ] Wildcard re-characterized per-NS directly (not only via anycast front)
- [ ] SRV/TXT/CAA queried for apex AND top-40 labels; vendor/verification leaks noted
- [ ] CNAME chains followed to terminal names for every CNAME in subdomains.txt
- [ ] Every IP in ips.txt PTR-queried; new `.<TARGET>` names captured
- [ ] `recon/dns_layer_names.txt` merged into master subdomains.txt with re-normalization; `recon/dns_layer_report.md` written
- **Review step:** agent10_review must verify: dns_layer_report.md exists with a per-NS AXFR verdict; every claimed NSEC-walked name re-queries to a real NSEC record; NSEC3 salt/iterations in the report match a fresh NSEC3PARAM lookup; no name in dns_layer_names.txt is a wildcard ghost (spot-check 5 against the wildcard baseline).
- **Nudge prompts:**
  - "Try AXFR against EVERY authoritative nameserver — the anycast front refusing does not mean the hidden master refuses."
  - "An NSEC walk is not done until the chain loops back to the apex. Stopping early is completion bias."
  - "Do not report done before recon/dns_layer_report.md exists with per-NS verdicts."
- **Finished artifact definition:** `recon/dns_layer_names.txt` (new protocol-derived names) + `recon/dns_layer_report.md` (AXFR verdicts, DNSSEC status, wildcard behavior, SRV/CAA/PTR findings, counts) + merged master `recon/subdomains.txt`.

## Evidence standard

- Baseline: dead-name NSEC/NSEC3 proof query saved — proves the zone's DNSSEC mode before any walking claim
- Reproduction: every walked name re-queried directly (dig <name> → same NSEC next-pointer); AXFR claims require the full dump saved to `recon/axfr_<ns>.txt`
- Raw evidence: full dig outputs for AXFR attempts, NSEC3PARAM, and the hash list kept in `recon/`
- Verdicts: CONFIRMED (name appears in the NSEC chain or a successful AXFR) / INCONCLUSIVE (NSEC3 hash uncracked — parked as NSEC3-UNKNOWN for the human) / NEGATIVE (AXFR refused on all NS, no DNSSEC — documented per-NS so nobody re-tests it)

## Handoffs

- `recon/dns_layer_names.txt` → merged into `recon/subdomains.txt` (skill `subdomain_enum` normalization), then to `port_service_mapping` for liveness.
- `recon/dns_layer_report.md` → skill `tech_stack_fingerprint` (DNS provider + DNSSEC posture feed the stack profile); SRV/CAA vendor leaks → skill `cloud_bucket_hunt` (vendor naming schemes) and skill `github_osint` (verification tokens as search pivots).
- Wildcard per-NS behavior → appended to `recon/wildcard_baseline.txt` for all downstream skills.
