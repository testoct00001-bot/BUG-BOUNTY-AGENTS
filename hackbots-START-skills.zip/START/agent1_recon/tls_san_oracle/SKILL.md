---
name: tls_san_oracle
agent: agent1_recon
description: Harvest TLS Subject Alternative Names on standard AND odd/nonstandard ports plus SNI probing tricks, to surface hostnames that never appeared in CT logs or DNS — every certificate is an oracle.
---

# TLS SAN Oracle

## Purpose

Every TLS handshake discloses the server's certificate, and every certificate lists the names it is valid for (SANs). Servers on odd ports — 8443, 9443, 10443, 2083, 2096, 8000-series admin panels, VPN gateways on 4433 — are frequently provisioned with certs that carry internal or staging names that never got a public CT-logged cert and never got a DNS record anyone walks. SNI probing (asking for a name and watching which cert comes back, or asking with NO SNI / wrong SNI and watching the default cert) turns every TLS-speaking port into a name oracle. This skill systematically handshakes every TLS port on every known IP/host and extracts every name, then recurses: each new name's own odd-port certs get harvested too.

## Division of labor

- **Consumes:** `recon/subdomains.txt` and `recon/ips.txt` (from skill `subdomain_enum`); `recon/portscan.txt` if skill `port_service_mapping` already ran (its open-port list focuses this skill — but this skill must NOT wait for it; run standalone with the default port list if needed).
- **Produces:** `recon/tls_san_names.txt` (new names found ONLY via TLS oracles, one per line) and `recon/tls_san_report.md` (per-host:port → cert subject/issuer/SAN summary, default-cert vs SNI-cert mismatches, expired/self-signed anomalies). Merged into master `recon/subdomains.txt`.

## When to use / when NOT to use

- **Use when:** a new target root is onboarded; after `port_service_mapping` finds open TLS ports; when a host serves a default cert for wrong-SNI (that default cert is a goldmine); when hunting vendor-managed infrastructure (CDN/WAF edge certs list customer names).
- **Skip when (time-pass filter):** the host's port 443 already serves the exact same cert as every odd port AND crt.sh already listed all its SANs — verify by comparing SAN sets, don't assume. Never skip the no-SNI probe: the default vhost cert is the single highest-yield TLS oracle.

## Methodology

1. Build the target list: every name in `recon/subdomains.txt` (port 443 + odd ports) and every IP in `recon/ips.txt` (IP-based handshakes reveal certs bound to IPs, which often carry different names than the hostname cert).
2. **Port 443 baseline per host.** For each hostname: handshake with correct SNI, record subject, issuer, validity, full SAN list. Also handshake with NO SNI (`-servername` omitted) and with a WRONG SNI (`zzqxnodead.<TARGET>`): if the server returns a different cert for wrong/no SNI, you found the default vhost — harvest ITS SANs, they frequently include internal names the operator forgot.
3. **Odd-port sweep.** For each host AND each IP, handshake the TLS port list: 443, 8443, 9443, 10443, 444, 8444, 9444, 2083, 2087, 2096, 8000? no (usually plain HTTP — test TLS anyway with a 5s timeout), 8001, 8006, 8008(TLS?), 8010, 8080(TLS?), 8081, 8089, 8090, 8100, 8181, 8888, 9000, 9001, 9043, 9060, 9080, 9090, 9091, 9200, 9300, 11211(no), 15672, 27017(no). For each port: first detect TLS (send ClientHello; if the response parses as ServerHello, it's TLS). Record the cert's SANs per port.
4. **SNI-mismatch oracle.** For each host:port, send SNI=`<TARGET>` (apex), SNI=`www.<TARGET>`, SNI=empty, SNI=`notexist-<random>.<TARGET>`. Servers with SNI-based routing return DIFFERENT certs per SNI — each variant is a new oracle. Log every distinct cert (fingerprint by SHA256 of DER).
5. **IP-direct handshake.** Connect to each IP in `recon/ips.txt` on 443 and the odd-port list with SNI set to the IP itself and with no SNI. IP-bound certs (common on VPN concentrators, mail gateways, appliances) carry names like `vpn-<region>.<TARGET>` or vendor defaults that leak the appliance model.
6. **STARTTLS oracles.** On mail ports 25, 587, 110, 143, 21 (FTP): issue the STARTTLS upgrade and harvest the post-upgrade cert. Mail gateways are notorious for internal hostnames in certs (`mx-internal-02.<TARGET>`).
7. **Cert metadata analysis.** For every distinct cert: check issuer (private CA = internal infrastructure, note it), validity period (certs valid 10+ years = appliance defaults; expired certs = abandoned hosts — high value), subject O/OU fields (often contain the real company/asset name), and Authority Information Access (OCSP URLs leak the CA and sometimes the customer ID).
8. **Recurse.** Every new `*.<TARGET>` name from SANs goes into the harvest queue: its own 443 + odd ports get probed (one recursion level per new name, cap at 3 levels to avoid explosion). New names also feed back to skill `subdomain_enum` step 4 for their CT/cert-expansion treatment.
9. **Diff against known.** Compare the full SAN harvest against `recon/subdomains.txt`. Names NOT in the master list go to `recon/tls_san_names.txt`. Also record SANs that point OUTSIDE `<TARGET>` (partner domains, vendor domains, `*.cloudprovider.com`) — those are pivot leads for skill `cloud_bucket_hunt`, noted in the report.
10. **Write the report.** `recon/tls_san_report.md`: per host:port table (cert fingerprint, subject, issuer, SAN count, new names), SNI-mismatch findings, default-cert findings, anomaly list (self-signed, expired, private-CA, subject/issuer mismatches), out-of-scope SAN pivots.
11. **SCT timestamp cross-check.** Each cert carries Signed Certificate Timestamps (SCTs) from CT logs — extract them (`openssl x509 -text | grep -A2 "CT Precertificate SCTs"`) and compare the embedded log timestamps against first-seen in `crt.sh`. A cert whose SCT predates its CT-log visibility by days was logged late (blind-window evidence for skill `crt_monitoring`'s backfill); note the lag in the report.
12. **Cert-clustering by issuer+validity.** Group distinct certs by (issuer, validity-window start month): certs issued in the same batch (same day, same CA) usually belong to the same provisioning event — a new staging fleet, a migration. A fresh batch cluster on previously-seen hosts = infra change = re-run `port_service_mapping` on those hosts. Record batch clusters in the report.

## Exact commands

Port-443 baseline with correct SNI, no SNI, and wrong SNI (the three-way oracle):
```bash
h="api.example.com"
echo "=== correct SNI:"; echo | openssl s_client -connect $h:443 -servername $h 2>/dev/null \
 | openssl x509 -noout -subject -issuer -ext subjectAltName 2>/dev/null | head -20
echo "=== NO SNI:"; echo | openssl s_client -connect $h:443 2>/dev/null \
 | openssl x509 -noout -subject -ext subjectAltName 2>/dev/null | head -10
echo "=== WRONG SNI:"; echo | openssl s_client -connect $h:443 -servername zzqxnodead.example.com 2>/dev/null \
 | openssl x509 -noout -subject -ext subjectAltName 2>/dev/null | head -10
```
If the no-SNI or wrong-SNI cert differs from the correct-SNI cert, harvest the differing cert's SANs — that default vhost is the oracle.

Odd-port TLS sweep with cert extraction (full harvester):
```bash
python3 - <<'EOF'
import socket, ssl, re, subprocess
PORTS=[443,444,8443,8444,9443,9444,10443,2083,2087,2096,8001,8006,8081,8089,8090,8181,8888,9001,9043,9090,9091]
targets=[l.strip() for l in open('recon/subdomains.txt')][:200]  # batch; repeat for rest
seen_certs={}; new_names=set()
for h in targets:
    for p in PORTS:
        try:
            ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
            s=socket.create_connection((h,p),timeout=6)
            tls=ctx.wrap_socket(s,server_hostname=h)
            der=tls.getpeercert(binary_form=True); tls.close()
            fp=__import__('hashlib').sha256(der).hexdigest()[:16]
            if fp in seen_certs: continue
            seen_certs[fp]=(h,p)
            out=subprocess.run(['openssl','x509','-noout','-subject','-issuer','-ext','subjectAltName'],
                               input=der,capture_output=True,timeout=10).stdout.decode('utf-8','ignore')
            for m in re.findall(r'DNS:([^\s,]+)',out):
                n=m.strip().lower().lstrip('*.')
                if n.endswith('.example.com'): new_names.add(n)
            print(f"{h}:{p} fp={fp} SANs={len(re.findall(r'DNS:',out))}")
        except Exception: pass
open('recon/tls_san_names.txt','w').write('\n'.join(sorted(new_names))+'\n')
print(len(seen_certs),'distinct certs;',len(new_names),'candidate names')
EOF
```
Batch the target list (200 hosts per run) so one slow host can't stall the sweep; run with a wrapper loop over chunks.

IP-direct handshake (IP-bound certs differ from hostname certs):
```bash
ip="203.0.113.10"
for p in 443 8443 9443; do
  echo "=== $ip:$p (SNI=IP)"; echo | openssl s_client -connect $ip:$p -servername $ip 2>/dev/null \
   | openssl x509 -noout -subject -issuer -dates -ext subjectAltName 2>/dev/null | head -12
done
```

STARTTLS oracle on mail ports:
```bash
h="mail.example.com"
for p in 25 587; do
  echo "=== $h:$p STARTTLS"
  echo | openssl s_client -connect $h:$p -starttls smtp -servername $h 2>/dev/null \
   | openssl x509 -noout -subject -issuer -ext subjectAltName 2>/dev/null | head -12
done
```

Cert anomaly triage (self-signed? expired? private CA?):
```bash
h="oldvpn.example.com"
echo | openssl s_client -connect $h:443 -servername $h 2>/dev/null \
 | openssl x509 -noout -subject -issuer -dates 2>/dev/null
# self-signed: subject == issuer. expired: notAfter in the past. private CA: issuer not a public CA.
```

SCT timestamp extraction (blind-window evidence for crt_monitoring backfill):
```bash
h="api.example.com"
echo | openssl s_client -connect $h:443 -servername $h 2>/dev/null \
 | openssl x509 -noout -text 2>/dev/null | grep -A3 "CT Precertificate SCTs" | head -12
# Compare the earliest SCT timestamp against the cert's first-seen in crt.sh:
# SCT days older than CT visibility = cert existed before the log showed it = blind window.
```

Cert batch clustering (same-issuer + same-day issuance = one provisioning event):
```bash
python3 - <<'EOF'
# input: lines "host|issuer|notBefore" collected during the sweep -> recon/cert_meta.tsv
from collections import defaultdict
batches=defaultdict(list)
for line in open('recon/cert_meta.tsv'):
    host,issuer,nb=[p.strip() for p in line.split('|')]
    batches[(issuer[:40],nb[:10])].append(host)
for (issuer,day),hosts in sorted(batches.items(),key=lambda x:-len(x[1])):
    if len(hosts)>=3:
        print(f"BATCH {day} {issuer}: {len(hosts)} hosts -> {hosts[:6]}")
print("A fresh batch on previously-seen hosts = infra change -> re-run port_service_mapping there.")
EOF
```

## Completion-bias defenses

- [ ] 443 baseline done for EVERY name in subdomains.txt (batched, all batches run — not just the first 200)
- [ ] Three-way SNI oracle (correct / none / wrong) executed per host; differing default certs harvested
- [ ] Odd-port sweep run against every host AND every IP in ips.txt with the full port list
- [ ] SNI-mismatch variants (apex, www, empty, random) tested per host:port; distinct certs fingerprinted by SHA256
- [ ] IP-direct handshakes done for all of ips.txt (443 + odd ports)
- [ ] STARTTLS oracles attempted on 25/587/110/143/21 where open
- [ ] Cert metadata triaged: self-signed, expired, private-CA, subject/issuer mismatches all listed
- [ ] Recursion: new names got their own 443+odd-port pass (up to 3 levels)
- [ ] SAN harvest diffed against master subdomains.txt; out-of-scope SAN pivots noted
- [ ] `recon/tls_san_report.md` written with per host:port table
- **Review step:** agent10_review must verify: tls_san_report.md exists; a random sample of 5 host:port rows re-handshakes to the same cert fingerprint; the three-way SNI oracle was actually run (report shows no-SNI/wrong-SNI cert subjects); new names in tls_san_names.txt are absent from the pre-run master list; expired/self-signed anomalies have dates quoted.
- **Nudge prompts:**
  - "The no-SNI handshake is the highest-yield TLS probe — do not skip it on any host."
  - "Keep recursing into new names' odd ports until a full level adds zero new names."
  - "Do not report done before recon/tls_san_report.md exists with the per host:port cert table."
- **Finished artifact definition:** `recon/tls_san_names.txt` (new oracle-derived names) + `recon/tls_san_report.md` (per host:port cert table, SNI-mismatch findings, anomaly list), merged into master `recon/subdomains.txt`.

## Evidence standard

- Baseline: the correct-SNI 443 cert per host is the baseline — every odd-port/SNI-variant cert is compared against it (same fingerprint = no new oracle, different = harvested)
- Reproduction: every distinct cert re-handshaked once more before its SANs enter tls_san_names.txt (certs can rotate; a one-off handshake is not a find)
- Raw evidence: per host:port, save subject/issuer/dates/SHA256 fingerprint lines in the report; full SAN lists for certs that yielded new names
- Verdicts: CONFIRMED (name in a re-verified cert's SAN, fingerprint recorded) / INCONCLUSIVE (handshake flaked — parked for re-run) / NEGATIVE (port not TLS / same cert as baseline — documented per port so nobody re-tests it)

## Handoffs

- `recon/tls_san_names.txt` → merged into master `recon/subdomains.txt`, then to `port_service_mapping` (new hosts need service mapping) and `js_harvest`.
- Cert metadata (private CA, appliance subjects, vendor issuers) → skill `tech_stack_fingerprint` (stack profile enrichment).
- Out-of-scope SAN pivots (partner/vendor domains) → skill `cloud_bucket_hunt` and skill `github_osint` as new vocabulary.
- Expired/self-signed/abandoned-cert hosts → flagged in the report for agent2+ priority (abandoned infra = highest unauthenticated-find rate).
