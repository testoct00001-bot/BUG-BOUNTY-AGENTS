---
name: permutation_target_derived
agent: agent1_recon
description: Build deep, target-specific wordlists from the target's own vocabulary — product names, brands, tech terms, label families observed in the wild — the fuel for bruteforce, bucket, and prediction skills.
---

# Target-Derived Permutation Wordlist

## Purpose

Generic wordlists (`subdomains-top1million.txt`) find generic hosts. The hosts that matter — `svc-payments-prod`, `falcon-gw-02`, `mercury-console` — are named from the target's OWN vocabulary: product codenames, brand words, acquired-company names, internal project names, tech-stack terms. This skill harvests that vocabulary from every available source (homepage, about/careers pages, harvested JS, cert subjects, DNS labels, GitHub org, job postings), then generates deep permutations (word-word, prefix-word-suffix, env combinations, numberings, regionals, typo-squats) into the single wordlist file that skills `subdomain_enum`, `cloud_bucket_hunt`, and agent2's predictors consume. A wordlist built from the target beats a 10x larger generic one every time.

## Division of labor

- **Consumes:** `recon/http_services.txt` (pages to mine), `recon/js_harvest.txt` (bundles contain product/codename strings), `recon/subdomains.txt` (observed label families to extend), `recon/github_findings.md` (product names from repos), human-provided brand/product lists if any.
- **Produces:** `recon/wordlist_target_derived.txt` (one lowercase token per line, deduped — the finished artifact) and `recon/wordlist_report.md` (sources, token counts per source, permutation rules applied, generation stats).

## When to use / when NOT to use

- **Use when:** a new target root is onboarded (run BEFORE `subdomain_enum`'s bruteforce round); new vocabulary arrives (CT alerts with new product names, GitHub finds, acquisitions); observed label families suggest extensions (`db1`→`db2..db9`).
- **Skip when (time-pass filter):** the vocabulary hasn't changed since the last generation AND no new label families were observed — regenerate only on new input. Never skip the observed-label extension: `vpn-gw-02` in the wild means `vpn-gw-01` and `-03` exist until proven otherwise.

## Methodology

1. **Homepage + about/careers mining.** Fetch the apex homepage, `/about`, `/products`, `/careers`, `/press`. Extract: product names, brand words, codenames (quoted or CamelCase tokens), technology mentions ("built on Kubernetes", "powered by Snowflake" → `k8s`, `snowflake` as infra tokens), office locations (city names → regional tokens), acquired-company names (press releases).
2. **JS bundle string mining.** Scan the largest 10 first-party bundles from `recon/js_harvest.txt` for: quoted strings 4–30 chars that look like product/feature names, `api.<word>`, `https://<word>.` internal references, enum-like constants (`REGION_US_EAST`, `ENV_STAGING` → `us-east`, `staging`). Keep tokens that appear ≥2 times or in URL-like contexts.
3. **Observed-label family extension.** From `recon/subdomains.txt`, extract label patterns: numeric sequences (`db1`→ generate `db2..db20`, `db01..db09`), env pairs (`prod`↔`staging`/`dev`/`test`/`qa`/`uat`), region pairs (`us`↔`eu`/`ap`/`in`), numbered gateways (`gw-01`→`gw-02..gw-10`), version suffixes (`v1`→`v2`,`v3`). Add the COMPLETIONS, not just what was observed.
4. **Cert/DNS/GitHub vocabulary.** From `tls_san_report.md`: O/OU fields, vendor names. From `dns_layer_report.md`: SRV/CAA vendor tokens. From `github_findings.md`: repo names, product names. Normalize all to lowercase alphanumeric+hyphen tokens.
5. **Token cleaning.** Rules: lowercase; strip non `[a-z0-9-]`; drop tokens <3 or >30 chars; drop pure numbers; drop the 500 most common English words (the, and, with...); drop framework-generic tokens already in every wordlist (`api`, `www`, `mail` stay — they're high-value, but mark them CORE so generators don't duplicate); dedupe.
6. **Permutation generation.** From the cleaned token set T and env set E={dev,staging,stage,test,qa,uat,prod,production,internal,external,beta,alpha,demo,legacy,old,new,dr,backup}: generate `t`, `t-e`, `e-t` for the top 200 tokens by source-weight; `t1..t3` numeric suffixes for infra-ish tokens; `t-us`,`t-eu`,`t-ap`,`t-in` regionals for gateway-ish tokens. Cap total permutations at 50,000 (bruteforce budget discipline — quality over quantity).
7. **Typo-squat variants (bounded).** For the top 20 tokens: single-char omissions and adjacent transpositions (`payments`→`paymnets`, `paymets`). Bounded to top-20 only — typo-squatting the full set is noise.
8. **Weight and order.** Order the final file: CORE high-value tokens first, then observed-family completions, then product/brand tokens, then permutations, then typo-squats. Consumers try the file top-down, so ordering IS the priority.
9. **Write artifacts.** `recon/wordlist_target_derived.txt` (one token per line, ordered, deduped) + `recon/wordlist_report.md` (per-source token counts, cleaning stats, permutation rules, final count, top-30 tokens listed for human sanity-check).
10. **Feedback loop.** When `subdomain_enum` bruteforce or `cloud_bucket_hunt` HITS on a generated token, log the hit pattern back into the report (`HIT-PATTERNS:` section) — the next generation round weights that pattern family higher. The wordlist learns.

## Exact commands

Homepage/about/careers token mining:
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
toks=set()
for path in ["/","/about","/products","/careers","/press","/solutions"]:
    try:
        html=urllib.request.urlopen(urllib.request.Request(f"https://example.com{path}",headers=UA),timeout=15,context=ctx).read(400000).decode('utf-8','ignore')
        text=re.sub(r'<script.*?</script>|<style.*?</style>|<[^>]+>',' ',html,flags=re.S|re.I)
        # CamelCase / codename-ish tokens + quoted product names
        for m in re.findall(r'\b([A-Z][a-z]+(?:[A-Z][a-z]+)+)\b',text): toks.add(m.lower())
        for m in re.findall(r'"([A-Za-z][A-Za-z0-9\- ]{2,28})"',text):
            if ' ' not in m: toks.add(m.lower())
        for m in re.findall(r'\b([a-z]{4,20})\b',text.lower()): toks.add(m)
    except Exception as e: print(path,"ERR",str(e)[:40])
STOP={"the","and","with","from","that","this","will","have","more","your","about","products","solutions","company","contact","privacy","terms"}
toks={t for t in toks if t not in STOP and 3<=len(t)<=30}
open('/tmp/vocab_web.txt','w').write('\n'.join(sorted(toks))+'\n')
print(len(toks),"web tokens")
EOF
```

JS bundle string mining (product/codename strings from code):
```bash
python3 - <<'EOF'
import urllib.request, re, ssl
from collections import Counter
ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA={"User-Agent":"Mozilla/5.0"}
c=Counter()
bundles=[l.strip() for l in open('recon/js_harvest.txt') if 'example.com' in l][:10]
for u in bundles:
    try:
        body=urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=20,context=ctx).read(2500000).decode('utf-8','ignore')
        for m in re.findall(r'https?://([a-z0-9-]+)\.',body): c[m]+=3          # internal host refs, weighted
        for m in re.findall(r'["\']([a-z][a-z0-9-]{3,24})["\']',body): c[m]+=1  # quoted strings
        for m in re.findall(r'\b([A-Z]{2,}_[A-Z0-9_]{2,})\b',body):             # ENUM_CONSTANTS
            for part in m.lower().split('_'):
                if len(part)>2: c[part]+=2
    except Exception as e: print(u[:60],"ERR",str(e)[:40])
keep={t for t,n in c.items() if n>=2 and 3<=len(t)<=30 and not t.isdigit()}
open('/tmp/vocab_js.txt','w').write('\n'.join(sorted(keep))+'\n')
print(len(keep),"js tokens (freq>=2)")
EOF
```

Observed-label family extension:
```bash
python3 - <<'EOF'
import re
labels={l.strip().split('.')[0] for l in open('recon/subdomains.txt') if l.strip()}
out=set()
for lb in labels:
    m=re.match(r'^([a-z-]+?)(\d+)$',lb)          # db1 -> db2..db20
    if m:
        stem,digits=m.groups(); width=len(digits)
        for i in range(1,21): out.add(f"{stem}{str(i).zfill(width)}")
    m=re.match(r'^([a-z-]+?)-(\d+)$',lb)        # gw-01 -> gw-02..gw-10
    if m:
        stem,digits=m.groups(); width=len(digits)
        for i in range(1,11): out.add(f"{stem}-{str(i).zfill(width)}")
    for a,b in [("prod","staging"),("prod","dev"),("us","eu"),("us","ap"),("primary","secondary")]:
        if a in lb: out.add(lb.replace(a,b))    # env/region mirrors
    m=re.match(r'^(.*?)-?v(\d+)$',lb)           # v1 -> v2, v3
    if m:
        for i in range(1,5): out.add(f"{m.group(1)}-v{i}".strip('-'))
open('/tmp/vocab_families.txt','w').write('\n'.join(sorted(out))+'\n')
print(len(out),"family-completion tokens")
EOF
```

Clean, merge, permute, order, and freeze the final wordlist:
```bash
python3 - <<'EOF'
import re
CORE=["api","www","mail","vpn","admin","dev","staging","test","internal","portal","sso","auth","app","cdn","static"]
ENVS=["dev","staging","stage","test","qa","uat","prod","production","internal","beta","demo","legacy","dr","backup"]
srcs={}
for name,path in [("web","/tmp/vocab_web.txt"),("js","/tmp/vocab_js.txt"),("fam","/tmp/vocab_families.txt")]:
    try: srcs[name]={l.strip() for l in open(path) if l.strip()}
    except Exception: srcs[name]=set()
def clean(t):
    t=t.lower()
    t=re.sub(r'[^a-z0-9-]','',t).strip('-')
    return t if 3<=len(t)<=30 and not t.isdigit() else None
tokens={}
for name,s in srcs.items():
    for t in s:
        c=clean(t)
        if c: tokens.setdefault(c,set()).add(name)
ordered=[]
ordered+=CORE
ordered+=[t for t in tokens if "fam" in tokens[t] and t not in ordered]       # observed-family completions first
byweight=sorted([t for t in tokens if t not in ordered], key=lambda t:-len(tokens[t]))
ordered+=byweight[:400]
perms=[]
for t in ordered[:200]:
    for e in ENVS: perms+= [f"{t}-{e}",f"{e}-{t}"]
    if any(k in t for k in ["db","gw","srv","node","host","server","proxy","cache"]):
        perms+= [f"{t}{i}" for i in (2,3)] + [f"{t}-us",f"{t}-eu",f"{t}-ap"]
for t in ordered[20:40]:  # bounded typo-squats on top tokens only
    for i in range(len(t)-1): perms.append(t[:i]+t[i+1]+t[i]+t[i+2:])  # transpose
    for i in range(len(t)): perms.append(t[:i]+t[i+1:])               # omission
final=[]
for t in ordered+perms:
    c=clean(t)
    if c and c not in final: final.append(c)
final=final[:50000]
open('recon/wordlist_target_derived.txt','w').write('\n'.join(final)+'\n')
with open('recon/wordlist_report.md','w') as f:
    f.write(f"# wordlist_target_derived — {len(final)} tokens\n\n")
    for name,s in srcs.items(): f.write(f"- {name}: {len(s)} raw tokens\n")
    f.write(f"- env/permutation rules: {len(ENVS)} envs x top-200 tokens + infra numeric/regional + bounded typo-squats\n")
    f.write(f"- top-30: {', '.join(final[:30])}\n")
print(len(final),"final tokens -> recon/wordlist_target_derived.txt")
EOF
```

## Completion-bias defenses

- [ ] All five vocabulary sources mined (web pages, JS bundles, observed labels, cert/DNS/GitHub, human lists)
- [ ] JS mining covered the 10 largest first-party bundles (not just the homepage)
- [ ] Observed-label families fully extended (numeric ranges, env/region mirrors, version suffixes)
- [ ] Cleaning rules applied (length, charset, stopwords, dedupe) — raw junk tokens removed
- [ ] Permutations generated per the documented rules; total capped at 50,000
- [ ] Typo-squats bounded to top tokens only (documented which)
- [ ] File ordered by priority (CORE → family completions → weighted → permutations → typos)
- [ ] `recon/wordlist_report.md` written with per-source counts and top-30 for human sanity-check
- [ ] HIT-PATTERNS feedback section present in the report (updated when consumers report hits)
- **Review step:** agent10_review must verify: wordlist_target_derived.txt exists with one token per line, all lowercase, no URLs, no duplicates; the report's top-30 reads like the target (product/brand terms present — a generic-looking top-30 means the mining failed); permutation count ≤50,000; family completions exist for every numbered label in subdomains.txt (spot-check 3).
- **Nudge prompts:**
  - "Mine the BUNDLES, not just the homepage — the codenames live in the JavaScript."
  - "Every numbered label you observed implies siblings. Generate the full family or you're leaving hosts on the table."
  - "Order is priority: the file is consumed top-down. Put the highest-signal tokens first."
- **Finished artifact definition:** `recon/wordlist_target_derived.txt` (ordered, deduped, ≤50k tokens, one per line) + `recon/wordlist_report.md` (sources, counts, rules, top-30, HIT-PATTERNS section).

## Evidence standard

- Baseline: the raw per-source token files (`/tmp/vocab_*.txt`, copied to `recon/vocab_raw/`) are the baseline — every final token must trace to a source
- Reproduction: regeneration from the same sources must produce the same file (deterministic ordering — sort everything before permuting)
- Raw evidence: per-source raw token files kept in `recon/vocab_raw/`; cleaning drop-counts in the report
- Verdicts: not a finding skill — but INCONCLUSIVE applies if a source was unreachable (documented, retried next run); a top-30 with zero target-specific terms = failed run, regenerate

## Handoffs

- `recon/wordlist_target_derived.txt` → skill `subdomain_enum` (bruteforce round), skill `cloud_bucket_hunt` (candidate generation), agent2 (predicted-path generation). This file is agent1's vocabulary contract — consumers must use THIS file, not generic wordlists, for target-specific rounds.
- HIT-PATTERNS feedback → this skill's next generation (successful patterns get weighted up).
- New vocabulary from `crt_monitoring` (new product names in certs), `github_osint` (repo/product names), `cloud_bucket_hunt` (successful bucket patterns) → this skill's mining sources on the next run.
