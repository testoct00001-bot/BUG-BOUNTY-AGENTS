# Agent 4: Auth & Session

## Role

Agent 4 owns authentication and session security end-to-end. It maps how the target authenticates (cookies, Authorization schemes, API keys, signed params, SDK key flows, Origin/Referer checks), tears apart every credential-issuance and validation edge case — session tokens, JWTs, MFA, password resets, OAuth/OIDC flows, SSO config — and proves where identity controls actually fail. Every claim ships with a baseline comparison, 2x independent reproduction, and raw request/response evidence. Auth differentials become access ladders: an accidentally-open endpoint feeds the business-logic agent, a JWT weakness feeds token forgery, a rate-limit bypass feeds credential attacks. This agent hunts what leaks, is sensitive, and is reachable unauthenticated — never time-pass surface.

## The 10 skills

| Skill folder | What it does |
|---|---|
| `auth_model_mapping` | Maps cookies, Authorization schemes, API keys, signed params, SDK key flows, Origin/Referer checks — and finds endpoints that should be authenticated but aren't |
| `session_token_analysis` | Measures token entropy, decodes structure, inspects JWT claims, and analyzes session ID patterns for predictability or leakage |
| `mfa_weakness` | Tests MFA enrollment bypass, backup-code bruteforce surface, MFA fatigue paths, and remember-device token weaknesses |
| `password_reset_poison` | Tests Host-header poisoning of reset links, reset-token leakage via Referer, and user-IDOR on reset endpoints |
| `oauth_flow_audit` | Audits redirect_uri validation, state parameter, authorization-code/token leakage, PKCE enforcement, and implicit-flow leftovers |
| `jwt_edge_cases` | Tests alg=none, jku/x5u injection, kid path traversal/SQLi, weak signing secrets, and token replay |
| `session_fixation` | Tests session fixation via login flows, concurrent-session handling, and logout/password-change invalidation gaps |
| `sso_config_leak` | Mines SSO metadata/SAML/OIDC endpoints for leaked tenant IDs, client IDs, and IdP configuration |
| `role_oracle` | Diffs guest vs user vs admin responses across every known endpoint to map hidden roles and endpoints |
| `rate_limit_mapping` | Maps per-endpoint rate limits (login, reset, OTP), then hunts bypasses: header rotation, IP rotation, race windows, endpoint variants |

## Inputs

- Live host and endpoint inventory from the recon agents (subdomains/IPs lists, spidered endpoint maps, JS-harvested API surfaces) — the auth surface to test.
- Any leaked client config (API keys, tenant names, IdP domains) surfaced by recon — seeds for `sso_config_leak` and `oauth_flow_audit`.
- Test credential tiers if the human provided them (low-priv user, admin) — required for full `role_oracle` depth; the skill still runs guest-vs-authenticated without them.

## Outputs

- `findings/<skill-slug>_confirmed.md` per skill — verdict, baseline comparison, 2x reproduction log, raw request/response pairs.
- `artifacts/auth_model_map.md` — the full auth-requirement matrix: every endpoint × every credential type, with accidentally-open endpoints flagged.
- `artifacts/rate_limit_map.md` — per-endpoint thresholds, limiter-key fingerprints, and bypass results.
- `artifacts/token_analysis.md` — token entropy scores, decoded claim inventories, session-ID pattern findings.

## Handoffs

- **agent5_business_logic** consumes the `auth_model_map.md` unauthenticated-endpoint list and `role_oracle` differentials — its function-level access-control tests start where this agent's mapping ends.
- **agent8_data_leak** consumes any auth finding that exposes data (e.g. reset-token leakage, SSO config with internal hostnames) into its canary pipeline.
- **agent10_review** consumes every `findings/*_confirmed.md` for the final verification gate before anything ships to the human.

## Review gate

Before this agent's work ships to the human, all of the following must be true:

- Every CONFIRMED finding has a baseline comparison against a known-dead path on the same host, 2x independent reproduction, and raw request/response pairs saved on disk.
- Every INCONCLUSIVE item is explicitly flagged as needing a second-model run or human eyes — never silently upgraded.
- Every NEGATIVE path is documented so no other agent re-tests it.
- The finished artifacts (`auth_model_map.md`, `rate_limit_map.md`, `token_analysis.md`, all `findings/*_confirmed.md`) exist at their defined paths — no artifact, no "done."
- No finding rests on a single observation, a guessed URL, or an unreproduced differential.
