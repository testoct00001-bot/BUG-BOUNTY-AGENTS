---
name: session_fixation
agent: agent4_auth
description: Test session fixation via login, concurrent-session semantics, logout/password-change invalidation gaps, and timeout/sliding-window behavior.
---

# Session Fixation

## Purpose

Session management bugs are account-takeover primitives hiding in plain sight: a session ID that doesn't rotate on login lets an attacker fixate a victim's session; a logout that only clears the cookie client-side leaves the server-side session alive for replay; a password change that doesn't kill old sessions leaves a compromised session compromised. This skill walks the full session lifecycle — issuance, login rotation, fixation, concurrency, logout, password change, timeout — and proves each transition server-side, not just in the browser cookie jar. Findings here chain directly into takeover scenarios.

## Division of labor

- **Consumes:** a working low-privilege test account (username/password), the login/logout/password-change endpoint list, any session cookie names observed
- **Produces:** the finished artifact — `findings/session_fixation_confirmed.md` with the full lifecycle table (every transition tested, before/after session IDs, raw pairs) and verdicts per transition

## When to use / when NOT to use

- **Use when:** the target uses cookie-based sessions (a `Set-Cookie` session ID appears pre- or post-login); there is a login, logout, or password-change flow you can drive
- **Skip when (time-pass filter):** pure stateless JWT with no server-side session record AND no logout/password-change endpoints (nothing to fixate or invalidate — does it leak? no. is it sensitive? n/a. reachable? n/a). If you cannot obtain a test account and registration is closed, document INCONCLUSIVE for the login-transition steps rather than guessing.

## Methodology

1. Map the session surface: load the login page unauthenticated and record every `Set-Cookie` (name, value, `HttpOnly`, `Secure`, `SameSite`, `Domain`, `Path`, expiry). This is your pre-login session ID. Note whether a session is issued before any authentication at all.
2. Test login rotation: log in with the test account using the same cookie jar, then compare the session ID before and after authentication. Unchanged session ID across the privilege transition = session fixation vulnerability (step 3 confirms exploitability).
3. Test attacker-driven fixation: plant a known session ID yourself (set the cookie to an attacker-chosen value, or use a session ID harvested from your own pre-login visit), then complete the login flow as the victim account inside that jar. If the planted ID becomes an authenticated session, fixation is CONFIRMED — describe the delivery vector (cookie planting via subdomain XSS, MITM on non-Secure cookie, or session ID in URL).
4. Check for session ID in URL or body: look for `?sessionid=`, `;jsessionid=`, or hidden form fields carrying the session. URL-carried sessions leak via Referer, logs, and shoulder-surfing — record as a supporting weakness even when rotation works.
5. Test concurrent-session semantics: log in from jar A, then log in from jar B with the same account. Is jar A's session killed (single-session enforcement), or do both stay valid? Then log in N times (N=5) with fresh jars and count how many remain valid — that number is the session cap. No cap + no device management page = session-hoarding risk; document the exact count.
6. Test logout invalidation server-side: capture a valid authenticated jar, hit the logout endpoint, then replay the old session cookie against a protected endpoint. Do this twice. If the old session still returns 200 with data, logout is client-side-only theater — CONFIRMED.
7. Test password-change invalidation: change the test account's password, then replay sessions established before the change (keep a pre-change jar aside for this). Surviving sessions = compromised-session persistence — CONFIRMED, and high impact because password change is the standard incident-response action.
8. Test session timeout behavior: with a valid session, (a) poll a protected endpoint every few minutes without activity to find the absolute timeout; (b) keep making requests to test for a sliding window (does activity extend the session?). Record both numbers. Absurd values (30-day sliding sessions on a banking-grade app) are findings; note them even when they're "by design" so review can severity them.
9: Test session binding: replay the same session cookie with a different IP (if you have egress variety) and a different User-Agent. Acceptance = no binding. Then test cookie attribute gaps: session cookie without `Secure` on an HTTPS site, without `HttpOnly`, or with `SameSite=None` without `Secure` — each is a supporting weakness for the fixation chain.
10. Test logout CSRF and partial logout: is logout a GET (CSRF-able — attacker can log the victim out, a DoS/annoyance primitive useful in fixation chains)? Does "logout" on one device kill all sessions or just the current one? Does the "log out all devices" feature (if any) actually invalidate server-side — replay every jar after using it.
11. Verdict every transition: CONFIRMED only with baseline + 2x repro + raw pairs; INCONCLUSIVE when a step needs a second account, a real victim interaction, or human judgment; NEGATIVE for dead ends with the negative evidence recorded.

## Exact commands

Baseline (known-dead path control):

```bash
BASE="https://<TARGET>"
DEAD="/this-path-is-dead-9f3k2"
echo "== dead path =="; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$DEAD"
```

Capture the pre-login session and inspect cookie attributes:

```bash
curl -sk -c /tmp/pre.txt -D /tmp/pre.h "$BASE/login" -o /dev/null
echo "== pre-login cookies =="; cat /tmp/pre.txt
echo "== raw Set-Cookie headers =="; grep -i '^set-cookie' /tmp/pre.h
```

Login rotation test — compare session ID before vs after authentication in the same jar:

```bash
PRE=$(awk '/session|sid|token|auth/i {print $NF}' /tmp/pre.txt | head -1); echo "PRE-LOGIN session value: $PRE"
curl -sk -c /tmp/post.txt -b /tmp/pre.txt -D /tmp/post.h -X POST "$BASE/login" \
  --data-urlencode "username=<USER>" --data-urlencode "password=<PASS>" -o /dev/null -w "login HTTP:%{http_code}\n"
POST=$(awk '/session|sid|token|auth/i {print $NF}' /tmp/post.txt | head -1); echo "POST-LOGIN session value: $POST"
[ "$PRE" = "$POST" ] && echo "NO ROTATION — fixation candidate" || echo "rotated OK"
```

Attacker-planted fixation test — set a known session ID, then log in inside that jar:

```bash
FIX="attackerplanted$(date +%s)"
curl -sk -c /tmp/fix.txt -b /tmp/fix.txt "$BASE/login" -H "Cookie: <SESSION_COOKIE_NAME>=$FIX" -o /dev/null
curl -sk -c /tmp/fix.txt -b /tmp/fix.txt -X POST "$BASE/login" \
  --data-urlencode "username=<USER>" --data-urlencode "password=<PASS>" -H "Cookie: <SESSION_COOKIE_NAME>=$FIX" -o /dev/null
echo "== is our planted ID now authenticated? =="
curl -sk -b /tmp/fix.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
grep -i "<SESSION_COOKIE_NAME>" /tmp/fix.txt
```

Concurrent-session semantics — does login B kill login A? What is the cap?

```bash
for i in 1 2 3 4 5; do
  curl -sk -c /tmp/jar$i.txt -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=<PASS>" -o /dev/null
done
for i in 1 2 3 4 5; do
  printf "jar $i -> "; curl -sk -b /tmp/jar$i.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
done
# count survivors = session cap; if jar1 dies after jar2 login => single-session enforcement
```

Logout invalidation — replay the session twice after logout (2x verification):

```bash
curl -sk -c /tmp/logout.txt -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=<PASS>" -o /dev/null
echo "== before logout =="; curl -sk -b /tmp/logout.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
curl -sk -b /tmp/logout.txt -c /tmp/logout.txt -X POST "$BASE/logout" -o /dev/null -w "logout HTTP:%{http_code}\n"
for i in 1 2; do printf "replay after logout try $i -> "; curl -sk -b /tmp/logout.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"; done
```

Password-change invalidation — keep a pre-change jar, change password, replay:

```bash
curl -sk -c /tmp/oldsession.txt -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=<OLD_PASS>" -o /dev/null
curl -sk -b /tmp/oldsession.txt -c /tmp/oldsession.txt -X POST "$BASE/account/change-password" \
  --data-urlencode "current_password=<OLD_PASS>" --data-urlencode "new_password=<NEW_PASS>" -o /dev/null -w "pwchange HTTP:%{http_code}\n"
for i in 1 2; do printf "old session after pw change try $i -> "; curl -sk -b /tmp/oldsession.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"; done
```

Timeout / sliding-window probe (absolute vs activity-extended):

```bash
curl -sk -c /tmp/timeout.txt -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=<PASS>" -o /dev/null
for m in 5 15 30 60 120; do
  sleep 1  # in real runs: sleep ${m}m between polls; shortened here for template
  printf "t+${m}m -> "; curl -sk -b /tmp/timeout.txt -o /dev/null -w "%{http_code}\n" "$BASE/api/me"
done
# sliding window: repeat with a request every minute; if session outlives the absolute timeout found above, activity extends it
```

Session binding + cookie attribute audit:

```bash
printf "different UA -> "; curl -sk -b /tmp/post.txt -A "TotallyDifferentAgent/9.9" -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
echo "== cookie attributes =="; grep -i '^set-cookie' /tmp/post.h
# flag: no "Secure" on https site | no "HttpOnly" | SameSite=None without Secure | Domain=.parent (overly broad)
```

Logout CSRF + "log out everywhere" verification:

```bash
printf "logout via GET -> "; curl -sk -b /tmp/post.txt -o /dev/null -w "%{http_code}\n" "$BASE/logout"
printf "session after GET-logout -> "; curl -sk -b /tmp/post.txt -o /dev/null -w "%{http_code}\n" "$BASE/api/me"
```

## Completion-bias defenses

- [ ] Pre-login session captured; all cookie attributes recorded
- [ ] Login rotation tested (before/after session ID compared in same jar)
- [ ] Attacker-planted fixation attempted with a known session ID
- [ ] Session ID in URL/body checked
- [ ] Concurrent-session semantics tested (B-kills-A? cap counted over 5 logins)
- [ ] Logout invalidation replayed 2x server-side
- [ ] Password-change invalidation tested with a pre-change jar
- [ ] Absolute timeout and sliding-window behavior measured
- [ ] Session binding tested (IP variety / UA change)
- [ ] Cookie attributes audited (Secure, HttpOnly, SameSite, Domain scope)
- [ ] Logout CSRF tested; "log out everywhere" verified by replaying all jars
- [ ] Every transition has a verdict: CONFIRMED / INCONCLUSIVE / NEGATIVE
- **Review step:** agent10_review must verify (1) `findings/session_fixation_confirmed.md` exists with the full lifecycle table, (2) every CONFIRMED transition shows before/after session values (redacted to first 8 chars) plus 2x replay evidence, (3) "rotated OK" claims include the actual compared values, (4) logout/password-change CONFIRMED claims prove server-side survival (200 + data, not just a non-redirect).
- **Nudge prompts:** "Keep going until you have tested every lifecycle transition — login, fixation, concurrency, logout, password change, timeout — not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "A cookie that merely disappears client-side is not invalidation — replay it server-side twice or mark it INCONCLUSIVE."
- **Finished artifact definition:** `findings/session_fixation_confirmed.md` — lifecycle table (transition | before value | after value | verdict), raw request/response pairs for every CONFIRMED gap, cookie-attribute audit, session-cap count.

## Evidence standard

- Baseline: every authenticated probe compared against the known-dead path and the unauthenticated response on the same host
- Reproduction: 2x independent reproduction required (replays run twice; fixation tested with two distinct planted IDs)
- Raw evidence: full request/response pairs saved (request line, Cookie header with session value redacted to first 8 chars, response status + body excerpt proving authenticated vs anonymous)
- Verdicts: CONFIRMED (baseline + 2x repro + raw pairs) / INCONCLUSIVE (needs a second account, victim interaction, or human — state exactly what) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs

- `jwt_edge_cases`: receives post-logout and post-password-change token replay results for stateless-token targets
- `role_oracle`: receives the authenticated jar(s) and session-cap findings — concurrent valid sessions are the credential tiers for differential testing
- `sso_config_leak`: receives SSO-session observations (does SSO login rotate the app session? does SLO kill it?) if SSO is in play
- agent10_review: consumes `findings/session_fixation_confirmed.md` as the shippable evidence bundle
