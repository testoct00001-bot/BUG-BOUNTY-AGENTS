---
name: auth_model_mapping
agent: agent4_auth
description: Map every auth mechanism on the target and build an auth-requirement matrix to find endpoints that should be authenticated but aren't.
---

# Auth Model Mapping

## Purpose

This skill maps how a target actually authenticates — cookies, Authorization schemes, API keys, signed params, SDK-issued keys, Origin/Referer gates — and finds endpoints that should be authenticated but aren't. Missing authentication on a data-touching endpoint is one of the most impactful bug classes: it turns straight into unauthenticated data exposure, IDOR ladders, or unauthenticated action invocation. You build the map by harvesting auth-relevant JS/config, classifying every credential type observed, and testing each endpoint with and without each credential.

## Division of labor

- **Consumes:** `findings/<target>_endpoints.txt` (endpoint inventory from endpoint discovery), JS bundles or harvest notes (`findings/<target>_js_harvest.md`), any captured credential samples
- **Produces:** `findings/auth_model_mapping_confirmed.md` — the auth-requirement matrix (endpoint × credential state → status + verdict), with raw request/response pairs for every CONFIRMED miss

## When to use / when NOT to use

- **Use when:** you have an endpoint inventory and any session/credential (even a low-privilege account or guest token); you see `Authorization:` headers, `Set-Cookie`, API-key headers, or signed query params in traffic; any endpoint returns data or performs an action
- **Skip when (time-pass filter):** the surface is a pure static marketing site with no data endpoints, no login, no API — ask: does it leak? Is it sensitive? Is it reachable unauthenticated? If the only dynamic behavior is a newsletter signup, this skill is wasted effort. Do NOT run it on targets where you never observed any credential mechanism at all.

## Methodology

1. **Harvest auth-relevant JS/config endpoints.** Pull every JS bundle, `/config`, `/api/config`, `/.well-known/*`, `manifest.json`, and env-ish files from the endpoint inventory. Grep them for: `Authorization`, `Bearer`, `api_key`/`apikey`/`x-api-key`, `Set-Cookie` names, `access_token`, `id_token`, `session`, `csrf`, `xsrf`, `Origin`, `Referer`, `client_id`, `sdk`, `sign`/`signature`/`hmac`, `token`. Record every header name, query-param name, and cookie name that carries a credential.
2. **Classify every credential type observed.** Build a list: session cookie (name, `HttpOnly`/`Secure`/`SameSite` flags), Bearer/JWT (where is it stored — `localStorage`? memory?), API-key header, signed query param (which params are signed? what algorithm?), SDK-issued keys (issued by which endpoint? what scopes?). Note which credential each frontend call actually sends — the app may support multiple schemes with different enforcement.
3. **Collect a low-privilege credential and a no-credential baseline.** Register/login as a normal user (or use guest/anonymous-issue endpoints if login needs an invite). Also record: what happens with NO credentials at all.
4. **Establish the baseline.** Pick a known-dead path on the same host (e.g. `/api/v9/no-such-endpoint-xyz`). Record its exact status/body for: no credentials, valid credentials, malformed credentials. This is your comparison anchor — every later "200" must be compared against this shape, not against your hopes.
5. **Build the auth-requirement matrix.** For every endpoint in the inventory, send: (a) no credentials at all, (b) valid low-priv credential, (c) malformed credential (garbage token), (d) credential of the wrong type (API key where a Bearer is expected, and vice versa). Record status code + body type (JSON with data? error string? redirect? HTML?) for each cell.
6. **Strip credentials to find accidentally-open endpoints.** For each endpoint that returned data with a credential, re-send the identical request with the credential header/cookie deleted entirely (not empty — deleted). Then re-send with the header present but empty, and with a random 32-char value. Three different "no valid credential" shapes catch three different server bugs (missing-check vs empty-string-check vs parse-error-fail-open).
7. **Read every unauthenticated 200 like an attacker.** If an endpoint that touches data (user records, orders, files, search over private data, any write action) returns 200 with no credentials: do NOT celebrate yet. Compare body length and keys against the authenticated response. If the unauthenticated body contains real records — CONFIRMED lead. If it returns an empty list / "[]" / generic skeleton — likely fail-closed, mark NEGATIVE. If it returns *different* data (e.g. public subset), note exactly what leaks.
8. **Probe Origin/Referer-gated endpoints.** Some endpoints enforce "auth" only via `Origin` or `Referer` checks (common on GraphQL or JSON-RPC behind a same-origin policy assumption). For each sensitive endpoint: send with no `Origin`, with `Origin: https://<TARGET>`, with `Origin: https://evil.example`, with `Origin: null`, and with a subdomain-spoofed origin (`https://<TARGET>.evil.example`). If the endpoint serves data to a missing/spoofed Origin, the gate is theater — CONFIRMED.
9. **Test HTTP method variance on gated endpoints.** For each endpoint that 401/403s on GET: retry with POST, PUT, PATCH, DELETE, HEAD, OPTIONS, and with `X-HTTP-Method-Override` variants. A 200/500-with-data on a different verb is a finding (hand the exact pair to the verb-smuggling follow-up; log it here too).
10. **Test credential-confusion: swap credential types.** Send the session cookie to an API-key endpoint, the API key as a Bearer token, the JWT in the cookie slot. If any wrong-type credential is accepted, the validator is type-confused — document which combinations authenticate and what privilege they carry.
11. **Test trailing-slash / case / encoding twins.** For each 401/403 endpoint, try the trailing-slash twin (`/api/users` vs `/api/users/`), case twin (`/API/users`), and encoded twin (`/api/%75sers`). Auth middleware that matches exact strings misses twins — a 200 on the twin with data is CONFIRMED.
12. **Check pre-auth vs post-auth route mounting.** Hit API version prefixes and admin-ish prefixes (`/api/v1/`, `/api/v2/`, `/internal/`, `/admin/api/`) with no credentials and list which return 401 (auth exists but denied) vs 404 (no route) vs 200 (open). 401-vs-404 differential itself maps the real route table — feed new 401 paths back into the matrix.
13. **Look for SDK-issued keys and machine tokens.** If the frontend calls a `.../token`, `.../session`, `.../guest`, `.../apikey` endpoint that mints credentials with no prior auth, test: can you mint one with zero credentials? What scopes/roles does it carry? Can it be escalated by parameter tampering (`role=admin`, `scope=*`)? An unauthenticated key-minting endpoint is a critical finding — verify 2x with fresh mints.
14. **Signed-parameter endpoints.** If requests carry `sig`/`signature`/`hmac`/`expires` params: test without the signature, with a garbage signature, with an expired `expires`, and with `expires` far in the future. If the resource serves without a valid signature, signing is decorative — CONFIRMED.
15. **CORS + credentialed cross-origin reads.** For each CONFIRMED-open or confused endpoint, check `Access-Control-Allow-Origin` with an evil origin and `Access-Control-Allow-Credentials: true`. Open endpoint + wildcard CORS with credentials = data exfiltration from any malicious site; note it in the finding.
16. **Re-verify every candidate miss twice, independently.** Fresh shell, fresh connection, re-run the exact no-credential request 2x. Bodies must match (modulo timestamps). If the second run differs (WAF flake, cache), run a third and take the majority; if still flaky, mark INCONCLUSIVE.
17. **Assemble the matrix artifact.** One table: endpoint × (none / valid / malformed / wrong-type / origin-spoofed) → status + one-line body description + verdict. Every CONFIRMED row links to its raw pair file.
18. **Decision branch — endpoint returns 200 with no credentials but the body looks like an error:** compare against baseline. If body shape matches the dead-path shape (same error envelope), it is fail-closed → NEGATIVE. If the error envelope *differs* (different message, stack trace, DB error, verbose validation), the endpoint parsed your input without auth — that is a lead for parameter-injection follow-ups, mark INCONCLUSIVE-LEAD and hand to the injection agent with the raw pair.
19. **Decision branch — endpoint redirects to login when unauthenticated:** check whether the redirect is enforced on the API response or just the HTML page. APIs that 302 to `/login` but still honor the request on retry-with-cookie-stripped-cache-buster may have cache-deception variants — note and move on unless body data appears.
20. **Hand off.** Write the artifact, then route: CONFIRMED open endpoints → IDOR/parameter-ladder skill; auth-confused endpoints → session/token confusion follow-up; 401/403 walls → bypass battery skill.

## Exact commands

Baseline — known-dead path, all four credential states (run first, save output):

```bash
TARGET="<TARGET>"
DEAD="https://$TARGET/api/v9/no-such-endpoint-xyz"
for label in none valid malformed wrongtype; do
  case $label in
    none)       extra=() ;;
    valid)      extra=(-H "Authorization: Bearer <TOKEN>" -b "session=<COOKIE>") ;;
    malformed)  extra=(-H "Authorization: Bearer AAAA-invalid-token") ;;
    wrongtype)  extra=(-H "X-API-Key: <TOKEN>") ;;
  esac
  echo "=== baseline [$label] ==="
  curl -sk -o /tmp/base_$label.txt -w "%{http_code} %{size_download}\n" "${extra[@]}" "$DEAD"
  head -c 400 /tmp/base_$label.txt; echo
done
```

Credential-stripping probe across an endpoint list (endpoints.txt = one path per line):

```bash
TARGET="<TARGET>"
while read -r p; do
  echo "=== $p [no-auth] ==="
  curl -sk -o /tmp/probe_body.txt -w "%{http_code} %{size_download}\n" "https://$TARGET$p"
  head -c 300 /tmp/probe_body.txt; echo
  echo "=== $p [empty-auth-header] ==="
  curl -sk -o /tmp/probe_body2.txt -w "%{http_code} %{size_download}\n" \
    -H "Authorization:" "https://$TARGET$p" | head -c 200; echo
done < endpoints.txt
```

Authenticated-vs-not body diff (the comparison that decides CONFIRMED vs fail-closed):

```bash
TARGET="<TARGET>"; EP="/api/users/me"
curl -sk -H "Authorization: Bearer <TOKEN>" "https://$TARGET$EP" -o /tmp/auth.json
curl -sk "https://$TARGET$EP" -o /tmp/noauth.json
echo "--- auth:";   head -c 500 /tmp/auth.json; echo
echo "--- noauth:"; head -c 500 /tmp/noauth.json; echo
diff <(python3 -c "import json,sys;print(sorted(json.load(open('/tmp/auth.json')).keys()))" 2>/dev/null) \
     <(python3 -c "import json,sys;print(sorted(json.load(open('/tmp/noauth.json')).keys()))" 2>/dev/null) \
  && echo SAME_KEYS || echo DIFFERENT_KEYS
```

Origin/Referer gate probe:

```bash
TARGET="<TARGET>"; EP="/api/graphql"
for o in "" "https://$TARGET" "https://evil.example" "null" "https://$TARGET.evil.example"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" -X POST "https://$TARGET$EP" \
    -H "Content-Type: application/json" -H "Origin: $o" -d '{"query":"{__typename}"}')
  echo "Origin=[$o] -> $code"
done
```

Method variance + method-override on a 401/403 endpoint:

```bash
TARGET="<TARGET>"; EP="/api/admin/users"
for m in GET POST PUT PATCH DELETE HEAD OPTIONS; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" -X $m "https://$TARGET$EP")
  echo "$m -> $code"
done
curl -sk -o /dev/null -w "override-POST-as-DELETE -> %{http_code}\n" \
  -X POST -H "X-HTTP-Method-Override: DELETE" "https://$TARGET$EP"
```

Trailing-slash / case / encoding twins:

```bash
TARGET="<TARGET>"; EP="/api/users"
for v in "$EP" "$EP/" "/API/users" "/api/%75sers" "/api/users%2f" "//api/users"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" "https://$TARGET$v")
  echo "$v -> $code"
done
```

Verification — 2x independent reproduction of a candidate open endpoint (fresh shell each time):

```bash
TARGET="<TARGET>"; EP="/api/orders"
for i in 1 2; do
  echo "=== repro run $i $(date -u +%FT%TZ) ==="
  curl -sk -D /tmp/repro_$i.hdrs -o /tmp/repro_$i.body -w "%{http_code} %{size_download}\n" "https://$TARGET$EP"
  sha256sum /tmp/repro_$i.body
done
diff /tmp/repro_1.body /tmp/repro_2.body && echo BODIES_MATCH || echo BODIES_DIFFER
```

JS/config auth-credential harvest:

```bash
TARGET="<TARGET>"
curl -sk "https://$TARGET/" -o /tmp/home.html
grep -Eo 'src="[^"]+\.js[^"]*"' /tmp/home.html | sed 's/src="//;s/"//' > /tmp/jslist.txt
while read -r j; do
  case "$j" in http*) u="$j";; *) u="https://$TARGET$j";; esac
  curl -sk "$u" | grep -Eoi '(authorization|bearer|api[-_ ]?key|x-api-key|set-cookie|access_token|id_token|client_id|signature|hmac|xsrf|csrf)[^,;"]{0,80}' | sort -u
done < /tmp/jslist.txt | sort -u | tee /tmp/auth_strings.txt
```

## Completion-bias defenses

- [ ] JS bundles, /config, /.well-known/*, manifest harvested and grepped for credential strings
- [ ] Every credential type classified (cookie flags, Bearer storage, API-key header, signed params, SDK-minted keys)
- [ ] Low-priv credential obtained; no-credential state tested
- [ ] Baseline dead-path recorded for none/valid/malformed/wrong-type states
- [ ] Auth-requirement matrix built: every endpoint × (none / valid / malformed / wrong-type)
- [ ] Credential-stripping triple (deleted / empty / garbage) run on every data-touching endpoint
- [ ] Every unauthenticated 200 body-compared against the authenticated body (not eyeballed)
- [ ] Origin/Referer spoof matrix run (missing / correct / evil / null / subdomain-spoof)
- [ ] Method variance + X-HTTP-Method-Override tested on every 401/403 endpoint
- [ ] Wrong-type credential confusion tested (cookie↔Bearer↔API-key swaps)
- [ ] Trailing-slash / case / encoding twins tested on every gated endpoint
- [ ] 401-vs-404 differential used to map real route table; new 401 paths fed back into matrix
- [ ] Unauthenticated key-minting endpoints tested (mint with zero creds? scope tampering?)
- [ ] Signed-param endpoints tested (missing/garbage/expired/future signature)
- [ ] CORS credentialed-read check on every CONFIRMED/confused endpoint
- [ ] Every candidate miss re-verified 2x independently with matching bodies
- [ ] Matrix artifact written with verdict per cell and raw-pair links
- [ ] Decision branches applied (error-envelope compare; login-redirect API check)
- [ ] Handoffs routed (open→IDOR ladder; confused→token confusion; 401/403→bypass battery)
- **Review step:** agent10_review must verify: (1) the baseline dead-path output exists and every CONFIRMED claim's body was diffed against the authenticated body, not just status-compared; (2) the 2x repro runs are timestamped and body-hash matched; (3) no CONFIRMED verdict rests on a single unauthenticated 200 without body comparison; (4) every raw pair is saved on disk at the path cited.
- **Nudge prompts:** "Keep going until you have tested every endpoint in the inventory, not just the first ones that returned 200." / "Do not report done before findings/auth_model_mapping_confirmed.md exists on disk with the full matrix." / "An unauthenticated 200 with an empty list is fail-closed, not a finding — diff the bodies before you claim anything."
- **Finished artifact definition:** `findings/auth_model_mapping_confirmed.md` — contains the endpoint × credential-state matrix table (status + body description + verdict per cell), a credential-type inventory section, and for every CONFIRMED row a link to its raw pair file under `findings/raw/auth_model_mapping_<n>.txt` (full request + response headers + body).

## Evidence standard

- Baseline: every hit compared against the known-dead path on the same host (status, body size, error envelope) — a "200" that matches the dead-path envelope is fail-closed
- Reproduction: 2x independent reproduction required, timestamped, with SHA256 body hashes matching (modulo timestamps)
- Raw evidence: full request/response pairs saved (request line + headers sent, response status + headers + body, curl `-D` dump)
- Verdicts: CONFIRMED (baseline-diffed + 2x repro + real data or real action without credentials) / INCONCLUSIVE (flaky bodies, needs second-model run or human judgment, e.g. ambiguous error envelopes) / NEGATIVE (fail-closed, empty-list, or dead end — documented with the evidence so nobody re-tests)

## Handoffs

- **IDOR / parameter-ladder skill:** consumes CONFIRMED open data endpoints — needs the endpoint path, the exact unauthenticated request, and what object fields leak (from the matrix)
- **Bypass battery skill (agent4_auth):** consumes every 401/403-walled endpoint that touches data — needs path + which credential states were already tried + response envelope
- **Session/token confusion follow-up:** consumes credential-type-confusion accepts — needs which wrong-type combinations authenticated and the privilege observed
- **Injection agent:** consumes INCONCLUSIVE-LEAD error-envelope differentials — needs the raw pair showing unauthenticated input parsing
- **agent10_review:** consumes `findings/auth_model_mapping_confirmed.md` + raw pairs; verifies baseline discipline and repro hashes before anything ships
