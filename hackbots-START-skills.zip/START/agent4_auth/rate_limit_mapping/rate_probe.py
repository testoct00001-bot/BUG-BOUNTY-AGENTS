#!/usr/bin/env python3
"""Controlled rate-limit prober. Measures threshold, window, and block behavior
on one endpoint. This is measurement, not a DoS tool: defaults are slow
(1 req/2s, 40 requests max). Raise --count/--rate only deliberately.

Usage:
  python3 rate_probe.py --url https://<TARGET>/login --method POST \
      --data 'username=x&password=y' --count 40 --delay 2
  python3 rate_probe.py --url https://<TARGET>/api/otp/verify --method POST \
      --data '{"code":"000000"}' --json --xff-rotate --count 60
  python3 rate_probe.py --url https://<TARGET>/login --method POST \
      --data 'u=x&p=y' --burst 20   # race-window test: 20 parallel, once

Output: per-request status/timing log + summary (first-block index,
block codes observed, reset window estimate, Retry-After / rate headers).
"""
import argparse, json, sys, time, urllib.request, urllib.error
import concurrent.futures

def build_request(args, i):
    data = args.data.encode() if args.data else None
    headers = {"User-Agent": "rate-probe/1.0"}
    if args.json:
        headers["Content-Type"] = "application/json"
    elif data:
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    if args.xff_rotate:
        # rotate the client-IP hint to test header-derived limiter keys
        headers["X-Forwarded-For"] = f"10.200.{i // 250}.{i % 250 + 1}"
    if args.header:
        k, v = args.header.split(":", 1)
        headers[k.strip()] = v.strip()
    return urllib.request.Request(args.url, data=data, headers=headers, method=args.method)

def one(args, i):
    req = build_request(args, i)
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            code, body = r.status, r.read(200)
    except urllib.error.HTTPError as e:
        code, body = e.code, e.read(200)
    except Exception as e:  # network error: stop, don't hammer
        return (i, "ERR", 0.0, str(e)[:60], {})
    dt = time.time() - t0
    return (i, code, dt, len(body), {})

def summarize(log):
    codes = {}
    first_block = None
    for i, code, dt, n, _ in log:
        codes[code] = codes.get(code, 0) + 1
        if first_block is None and code not in (200, 201, 301, 302):
            first_block = i
    print("\n== summary ==")
    print("requests:", len(log), "| code histogram:", codes)
    print("first non-2xx/3xx at request #:", first_block if first_block is not None else "never (no block observed)")
    if first_block:
        t_block = log[first_block - 1][0]
        # crude window estimate: when do codes return to 2xx/3xx
        recovered = next((i for i, c, *_ in log[first_block:] if c in (200, 201, 301, 302)), None)
        print("recovered at request #:", recovered if recovered else "not within probe")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--method", default="POST")
    ap.add_argument("--data", default="")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--count", type=int, default=40, help="sequential requests")
    ap.add_argument("--delay", type=float, default=2.0, help="seconds between requests")
    ap.add_argument("--xff-rotate", action="store_true", help="rotate X-Forwarded-For per request")
    ap.add_argument("--header", default="", help='extra header "K: V"')
    ap.add_argument("--burst", type=int, default=0, help="parallel race-window burst (one shot)")
    args = ap.parse_args()

    log = []
    if args.burst:
        print(f"burst: {args.burst} parallel requests (one shot)")
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.burst) as ex:
            futs = [ex.submit(one, args, i) for i in range(1, args.burst + 1)]
            for f in concurrent.futures.as_completed(futs):
                log.append(f.result())
        log.sort()
    else:
        for i in range(1, args.count + 1):
            r = one(args, i)
            log.append(r)
            print(f"#{r[0]:3d} -> {r[1]} ({r[2]:.2f}s, {r[3]}b)")
            if r[1] == "ERR":
                print("network error, stopping probe"); break
            time.sleep(args.delay)
    summarize(log)

if __name__ == "__main__":
    sys.exit(main())
