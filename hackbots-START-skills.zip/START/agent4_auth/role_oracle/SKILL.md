---
name: role_oracle
agent: agent4_auth
description: Diff guest vs user vs admin responses across every endpoint to map hidden roles, endpoints, and parameter-level privilege differentials.
---

# Role Oracle

## Purpose

Access-control flaws rarely announce themselves with a 403. The real signal is differential: an endpoint that returns `200` with an error message for guests but `200` with data for users; a body that grows by 400 bytes when you're admin; an endpoint that exists for one role and 404s for another. This skill builds credential tiers (guest / low-priv user / high-priv admin — at minimum guest vs any authenticated session), hits every known endpoint with each tier, and diffs status codes, body lengths, and content — not just 401-vs-200. Differentials that suggest a role you don't have get mapped as hidden roles, and every differential becomes an access-control test case for the business-logic agent. This is how IDOR and privilege-escalation test lists get built systematically instead of by luck.

## Division of labor

- **Consumes:** the endpoint list (`findings/endpoints_<host>.txt` from endpoint discovery), working credentials per tier (guest = none; user/admin jars from `session_fixation`)
- **Produces:** the finished artifact — `findings/role_oracle_confirmed.md` with the full differential matrix, hidden-role inferences, and the access-control test list for the business-logic agent

## When to use / when NOT to use

- **Use when:** you have at least two distinguishable tiers (guest vs authenticated, or two different users); there is an endpoint list to sweep; any endpoint behaved oddly across users during recon
- **Skip when (time-pass filter):** only one tier exists and no second account can be obtained (no differential possible — does it leak? unknown. is it sensitive? unknown. reachable? yes, but undifferentiable — document INCONCLUSIVE, don't fake a matrix). If the first 20 endpoints show byte-identical responses across tiers including on known-privileged paths, widen the endpoint set before quitting — but a fully identical matrix is a NEGATIVE, not an excuse to re-run it.

## Methodology

1. Build the tier set: Tier 0 = guest (no credentials), Tier 1 = low-priv authenticated user, Tier 2 = high-priv admin where available. Minimum viable = Tier 0 vs Tier 1. Record exactly which credential jar maps to which tier — never mix them mid-run.
2. Assemble the endpoint list: every known endpoint (API routes, admin paths, dashboard URLs, JS-discovered paths). Deduplicate. Add the obvious privileged guesses (`/api/admin`, `/api/users`, `/admin`, `/dashboard/admin`) — but mark guesses separately from discovered endpoints.
3. Establish the baseline: pick one known-dead path and record its guest/user/admin responses. Some apps return role-flavored 404 pages — you need the per-tier dead-path control or you'll misread every differential.
4. Sweep: request every endpoint with every tier. Record status code, body length, and a content hash per (endpoint, tier). Use identical headers apart from the credential — a differing User-Agent between tiers poisons the matrix.
5. Build the differential matrix: for each endpoint, compare tiers pairwise. Flag (a) status changes, (b) same status but body-length delta > 5%, (c) same status and length but content-hash change. Category (b) and (c) are where hidden bugs live — 200-with-error-message vs 200-with-data.
6. Inspect every flagged differential by fetching the bodies: is the guest body an error JSON while the user body is real data? Does the admin body contain extra fields (emails, internal IDs, tokens)? Extract and record the exact differing fields — field-level diffs become the IDOR test list.
7. Infer hidden roles: responses that reference a role you don't hold ("requires moderator", "owner only", menu items for `support`/`auditor` tiers) get logged as hidden-role candidates. Probe whether any endpoint behaves as if you HAVE that role (returns data instead of the role error) — that's a broken role check, not just a string.
8. Parameter-level differentials: for endpoints with differentials, test `?role=admin`, `?is_admin=true`, `role` cookies, and headers (`X-User-Role`, `X-Role`, `X-Forwarded-Role`). A changed response here is only a lead until you verify server-side effect — reflection of the parameter value in the body without data change is NEGATIVE, not a finding.
9. Object-level differential: where endpoints take IDs (`/api/users/<id>`, `/api/orders/<id>`), request your own ID and a neighboring ID with each tier. Tier 1 seeing Tier 2's object, or guest seeing any object, is the IDOR confirmation — record the exact pair.
10. Method-level differential: re-run flagged endpoints with GET/POST/PUT/DELETE/PATCH per tier. An endpoint that 403s GET for guests but 200s POST is a verb-level access-control failure — hand the pair to the verb-smuggling tests.
11. Negative-control pass: re-run the top 5 differentials with tiers swapped (use Tier 1's jar where Tier 0 ran and vice versa) to rule out jar contamination or time-based content changes. Differentials that don't survive the swap are INCONCLUSIVE, not CONFIRMED.
12. Compile the access-control test list: every CONFIRMED differential becomes one line — endpoint, method, tier that shouldn't see it, what it leaked, raw pair reference. This list is the handoff to the business-logic agent.
13. Verdict every endpoint: CONFIRMED (differential reproduced 2x with tier-swap control) / INCONCLUSIVE (needs a tier you don't have) / NEGATIVE (identical across tiers, documented so nobody re-sweeps it).

## Exact commands

Baseline (per-tier dead-path control — run once per tier):

```bash
BASE="https://<TARGET>"
DEAD="/this-path-is-dead-9f3k2"
for TIER in guest user admin; do
  case $TIER in guest) JAR="";; user) JAR="-b /tmp/user.jar";; admin) JAR="-b /tmp/admin.jar";; esac
  printf "dead-path as $TIER -> "; curl -sk $JAR -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE$DEAD"
done
```

Tier sweep — status + size + hash per (endpoint, tier). Endpoints file: one path per line:

```bash
: "${ENDPOINTS:=findings/endpoints_target.txt}"
: "${METHOD:=GET}"
> /tmp/matrix.tsv
while read -r EP; do
  [ -z "$EP" ] && continue
  for TIER in guest user admin; do
    case $TIER in guest) JAR="";; user) JAR="-b /tmp/user.jar";; admin) JAR="-b /tmp/admin.jar";; esac
    BODY=$(curl -sk $JAR -X "$METHOD" -o /tmp/body.bin -w "%{http_code} %{size_download}" "$BASE$EP")
    HASH=$(sha256sum /tmp/body.bin | cut -d' ' -f1)
    printf "%s\t%s\t%s\t%s\n" "$EP" "$TIER" "$BODY" "$HASH" >> /tmp/matrix.tsv
  done
done < "$ENDPOINTS"
column -t -s $'\t' /tmp/matrix.tsv | head -30
```

Flag differentials — same endpoint, any pairwise tier difference in status/size/hash:

```bash
python3 <<'EOF'
import itertools
rows = {}
for line in open("/tmp/matrix.tsv"):
    ep, tier, code, size, h = line.rstrip("\n").split("\t")
    rows.setdefault(ep, {})[tier] = (code, size, h)
for ep, t in rows.items():
    tiers = list(t)
    for a, b in itertools.combinations(tiers, 2):
        ca, sa, ha = t[a]; cb, sb, hb = t[b]
        flags = []
        if ca != cb: flags.append(f"STATUS {ca}->{cb}")
        if sa != sb:
            try:
                if abs(int(sa) - int(sb)) / max(int(sa), 1) > 0.05: flags.append(f"SIZE {sa}->{sb}")
            except ValueError: flags.append(f"SIZE {sa}->{sb}")
        if ha != hb and not flags: flags.append("CONTENT-DIFF same size")
        if flags: print(f"{ep} [{a} vs {b}]: {'; '.join(flags)}")
EOF
```

Inspect a flagged differential — fetch both bodies and diff the actual content:

```bash
EP="<FLAGGED_ENDPOINT>"
curl -sk -o /tmp/guest.body "$BASE$EP"
curl -sk -b /tmp/user.jar -o /tmp/user.body "$BASE$EP"
echo "== guest body =="; head -c 800 /tmp/guest.body; echo
echo "== user body =="; head -c 800 /tmp/user.body; echo
diff <(python3 -m json.tool /tmp/guest.body 2>/dev/null || cat /tmp/guest.body) \
     <(python3 -m json.tool /tmp/user.body 2>/dev/null || cat /tmp/user.body) | head -40
```

Hidden-role string hunt across all captured bodies:

```bash
grep -rhoiE '(requires|role|only)[^"'"'"'<>]{0,60}(admin|moderator|owner|support|auditor|superuser|staff)[^"'"'"'<>]{0,40}' /tmp/*.body 2>/dev/null | sort -u | head -20
```

Parameter-level differential probes (verify server-side effect, not reflection):

```bash
EP="<FLAGGED_ENDPOINT>"
for P in '?role=admin' '?is_admin=true' '?role=superuser'; do
  printf "param $P -> "; curl -sk -b /tmp/user.jar -o /tmp/p.body -w "%{http_code} %{size_download}\n" "$BASE$EP$P"
done
for H in 'X-User-Role: admin' 'X-Role: administrator' 'X-Forwarded-Role: admin'; do
  printf "header [$H] -> "; curl -sk -b /tmp/user.jar -H "$H" -o /tmp/h.body -w "%{http_code} %{size_download}\n" "$BASE$EP"
done
echo "== check: does the body contain NEW DATA (not just our reflected parameter)? =="
grep -c -i 'admin' /tmp/h.body
```

Object-level differential (your ID vs neighbor ID, per tier):

```bash
for TIER_JAR in "/tmp/none" "/tmp/user.jar" "/tmp/admin.jar"; do
  [ "$TIER_JAR" = "/tmp/none" ] && J="" || J="-b $TIER_JAR"
  for ID in <MY_ID> <NEIGHBOR_ID>; do
    printf "tier=$(basename $TIER_JAR) id=$ID -> "
    curl -sk $J -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/users/$ID"
  done
done
```

Tier-swap negative control on the top differential (rules out jar contamination):

```bash
EP="<TOP_DIFFERENTIAL_ENDPOINT>"
echo "== original: guest vs user =="
curl -sk -o /dev/null -w "guest: %{http_code} %{size_download}\n" "$BASE$EP"
curl -sk -b /tmp/user.jar -o /dev/null -w "user:  %{http_code} %{size_download}\n" "$BASE$EP"
echo "== swap repeat (fresh request, same tiers) =="
curl -sk -o /dev/null -w "guest: %{http_code} %{size_download}\n" "$BASE$EP"
curl -sk -b /tmp/user.jar -o /dev/null -w "user:  %{http_code} %{size_download}\n" "$BASE$EP"
# differential must survive both runs; then re-verify with a second user account if available
```

## Completion-bias defenses

- [ ] Tier set built and jar-to-tier mapping recorded (guest/user/admin)
- [ ] Endpoint list assembled; guesses marked separately from discovered endpoints
- [ ] Per-tier dead-path baseline recorded
- [ ] Full sweep executed: every endpoint × every tier (status/size/hash in /tmp/matrix.tsv)
- [ ] Differential flags generated (status / size>5% / content-hash)
- [ ] Every flagged differential body-inspected (error-message vs real-data determined)
- [ ] Differing fields extracted at field level
- [ ] Hidden-role strings hunted; hidden-role candidates probed
- [ ] Parameter/header role differentials tested with server-side-effect verification
- [ ] Object-level differentials tested (own ID vs neighbor ID per tier)
- [ ] Method-level differentials tested on flagged endpoints
- [ ] Tier-swap negative control passed on top differentials
- [ ] Access-control test list compiled for the business-logic agent
- [ ] Every endpoint has a verdict: CONFIRMED / INCONCLUSIVE / NEGATIVE
- **Review step:** agent10_review must verify (1) `findings/role_oracle_confirmed.md` exists with the differential matrix, (2) every CONFIRMED differential shows the tier-swap control AND two reproductions AND raw body excerpts proving data (not just status), (3) parameter-differential claims prove new data returned (not parameter reflection), (4) the access-control test list is present and machine-readable (one finding per line with endpoint/method/tiers).
- **Nudge prompts:** "Keep going until you have body-inspected every flagged differential, not just the first status-code change." / "Do not report done before the finished artifact exists on disk with the access-control test list." / "A reflected parameter is not a privilege escalation — verify new data server-side or mark it NEGATIVE."
- **Finished artifact definition:** `findings/role_oracle_confirmed.md` — differential matrix table (endpoint | guest | user | admin | delta class | verdict), field-level diffs for CONFIRMED items, hidden-role inferences, and the access-control test list (endpoint, method, unauthorized tier, leaked data, raw-pair reference).

## Evidence standard

- Baseline: per-tier dead-path control on the same host — differentials are only meaningful against it (role-flavored 404 pages exist)
- Reproduction: 2x independent reproduction required plus the tier-swap negative control on every CONFIRMED differential
- Raw evidence: full request/response pairs saved per tier (request line, credential tier used, response status/headers/body excerpt); body diffs for content-class differentials
- Verdicts: CONFIRMED (baseline + 2x repro + tier-swap + raw pairs showing data) / INCONCLUSIVE (needs a tier you don't have — state which) / NEGATIVE (identical across tiers, documented so nobody re-sweeps it)

## Handoffs

- Business-logic agent: consumes the access-control test list — every CONFIRMED differential becomes an IDOR/privilege-escalation test case with the exact endpoint, method, and tier
- `jwt_edge_cases`: receives role-claim observations (which claims the server actually enforces) to focus forgery payloads
- `session_fixation`: provides the tier jars; receives any session-tier confusion observed (one jar acting as another tier)
- agent10_review: consumes `findings/role_oracle_confirmed.md` as the shippable evidence bundle
