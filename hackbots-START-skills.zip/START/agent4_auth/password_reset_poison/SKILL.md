---
name: password_reset_poison
agent: agent4_auth
description: Poison reset-link generation via Host headers, measure reset-token strength, and test user-IDOR, replay, and binding flaws on reset consume for account takeover.
---

# Password Reset Poison

## Purpose

Password reset flows are one of the most reliable account-takeover primitives in bug bounty: a single poisoned reset link handed to a victim (or a reset token that isn't bound, single-use, or high-entropy) becomes full account compromise. This skill systematically attacks every stage of the reset flow — link generation (Host header poisoning), token delivery (Referer leakage), and token consumption (user-IDOR, replay, binding gaps). A confirmed poisoned reset link is a critical finding; a replayable or unbound token is high.

## Division of labor

- **Consumes:** endpoint inventory (`auth_model_map.md` unauthenticated endpoints, reset/forgot-password entry points from the spider), a test account with an inbox the operator controls, optionally a second test account for cross-user tests.
- **Produces:** `findings/password_reset_poison_confirmed.md` — verdict per sub-flow (link generation / token delivery / token consumption), raw request/response pairs, and a working exploit chain where confirmed.

## When to use / when NOT to use

- **Use when:** you found any forgot-password / reset-password / magic-link entry point; reset emails arrive with clickable links; the app is multi-tenant (cross-user IDOR surface); you can receive mail for your test accounts.
- **Skip when (time-pass filter):** the reset flow is email-code-only with no link and no token in any URL (poisoning surface is nil — check quickly, then move on); you have no inbox access for test accounts (you cannot confirm link contents — mark INCONCLUSIVE, don't guess); the target explicitly excludes account takeover from scope (check scope first, then skip cleanly).

## Methodology

1. **Map the reset surface.** Find every reset-adjacent entry point: `/forgot-password`, `/reset-password`, `/password/reset`, `/api/*/password-reset`, magic-link login, "resend" variants. Record method, parameters (email? user_id? username?), and response shape.
2. **Baseline.** Request the dead path `GET /forgot-password-dead-<rand>` and a reset request for a syntactically-invalid email. Record status/body/timing — every later differential is compared against these.
3. **Normal reset (control).** Request a reset for your own test account with clean headers. Save the full response and fetch the email. Record: link format, token length/charset, expiry stated, single-use?, does the email contain the raw token?
4. **Host-header poisoning matrix.** Re-run step 3 with each header variant below, one at a time, and check whether the emailed link's domain follows your injection:
   - `Host: evil-collaborator.example`
   - `X-Forwarded-Host: evil-collaborator.example`
   - `X-Forwarded-Server`, `X-Host`, `Forwarded: host=evil-collaborator.example`
   - Dual Host headers / Host with port / Host with `@` tricks
   - **If the link domain follows your header → proceed to step 5. If nothing changes after all variants → mark link-generation NEGATIVE and move to token tests (step 6).**
5. **Prove the poison.** With the successful variant, request a reset for your second test account, fetch the email, and confirm the link points at your collaborator domain AND that the token in it is valid (load it in a clean browser / curl the reset page and confirm it renders the "set new password" state — do not actually change a password you shouldn't). 2x reproduction required. This is account takeover: CONFIRMED critical.
6. **Token entropy and expiry.** Request 3+ resets for your own account. Measure token length, charset, Shannon entropy. Check expiry: inspect email text/headers, and test the token after the stated window (or at 1h/24h boundaries if unstated). **If tokens are short (<16 chars from a small alphabet) or non-expiring → high-severity finding.**
7. **Referer leakage.** After a reset request, navigate the app (help pages, analytics-heavy pages) and check: does any page URL contain the reset token? Does any response embed third-party trackers that would receive the token via Referer? (Inspect page source for analytics pixels on the token-bearing page.)
8. **User enumeration via reset.** Request resets for: your account, a definitely-nonexistent email, and a malformed email. Diff responses AND timing. **If the app distinguishes existing vs non-existing users → user-enumeration finding (low/medium, but it feeds brute-force and phishing).**
9. **User-IDOR on reset request.** If the request takes `user_id`, `username`, or `account_id` in addition to email, try mismatched pairs (your email + another user_id; another username + your email). **If a reset is issued for a mismatched identity → IDOR finding.**
10. **User-IDOR on reset consume.** With two test accounts: request a reset for account A, then try consuming A's token while presenting B's identifiers (cookie, email param, user_id param). Try consuming A's token in a session authenticated as B. **If the token works cross-user → critical.**
11. **Replay and binding semantics.** For your own token: consume it once (set a password), then try consuming it AGAIN. Try consuming a token requested in session/incognito-A from a different session/IP. Try consuming account A's token while logged in as account A (pre-existing session) — does the old session survive?
12. **Post-reset session handling.** After a successful reset, test whether OTHER active sessions for that account are killed. **If old sessions survive a password reset → session-invalidation gap (feeds session_fixation findings).**
13. **Rate-limit check.** Note the reset-request rate behavior and hand exact numbers to `rate_limit_mapping` for the bypass battery — reset endpoints are prime brute-force targets if tokens are weak.
14. **Chain it.** A poisoned link + user enumeration = targeted takeover. A replayable token + Referer leak = passive takeover. Write the chain in the artifact, not just the single bug.

## Exact commands

Baseline (known-dead path + invalid-email control):

```bash
TARGET="https://<HOST>"
# dead path baseline
curl -sk -i "$TARGET/forgot-password-dead-9f3k2" -o /tmp/reset_baseline.txt -w "HTTP %{http_code} | %{time_total}s | %{size_download}b\n"
# invalid email control — record response + timing for the enumeration diff
curl -sk -i -X POST "$TARGET/api/forgot-password" \
  -H "Content-Type: application/json" \
  -d '{"email":"definitely-not-a-user-9f3k2@example.com"}' \
  -o /tmp/reset_invalid.txt -w "HTTP %{http_code} | %{time_total}s | %{size_download}b\n"
```

Normal reset for your own account (control):

```bash
curl -sk -i -X POST "$TARGET/api/forgot-password" \
  -H "Content-Type: application/json" \
  -d '{"email":"<YOUR_TEST_EMAIL>"}' \
  -o /tmp/reset_control.txt -w "HTTP %{http_code} | %{time_total}s\n"
# then fetch the email from your inbox and save the raw message to /tmp/reset_email.eml
```

Host-header poisoning matrix (one per run; check the emailed link each time):

```bash
EVIL="evil-collaborator.example"  # your collaborator/inbox-controlled domain
for HDR in "Host: $EVIL" "X-Forwarded-Host: $EVIL" "X-Forwarded-Server: $EVIL" "X-Host: $EVIL"; do
  echo "=== trying: $HDR ==="
  curl -sk -i -X POST "$TARGET/api/forgot-password" \
    -H "Content-Type: application/json" \
    -H "$HDR" \
    -d '{"email":"<YOUR_TEST_EMAIL>"}' \
    -o "/tmp/reset_poison_$(echo $HDR | tr ' :/' '___').txt" -w "HTTP %{http_code}\n"
done
# Forwarded-header form
curl -sk -i -X POST "$TARGET/api/forgot-password" \
  -H "Content-Type: application/json" \
  -H "Forwarded: host=$EVIL" \
  -d '{"email":"<YOUR_TEST_EMAIL>"}' -o /tmp/reset_poison_forwarded.txt -w "HTTP %{http_code}\n"
```

Token entropy + expiry measurement (3 tokens, python3):

```bash
python3 - <<'EOF'
import math, collections
toks = ["<TOKEN1>", "<TOKEN2>", "<TOKEN3>"]  # paste from the 3 emails
for t in toks:
    freq = collections.Counter(t)
    ent = -sum((c/len(t))*math.log2(c/len(t)) for c in freq.values())
    print(f"len={len(t)} charset={len(freq)} shannon/char={ent:.2f} total_bits~{ent*len(t):.0f}")
EOF
```

Replay test (after consuming the token once via the legitimate reset page):

```bash
# First consumption happens in the browser/curl against the real reset page.
# Replay attempt: reuse the SAME token a second time.
curl -sk -i -X POST "$TARGET/api/reset-password" \
  -H "Content-Type: application/json" \
  -d '{"token":"<CONSUMED_TOKEN>","password":"ReplayTest123!"}' \
  -o /tmp/reset_replay.txt -w "HTTP %{http_code}\n"
# If this succeeds (or behaves like the first consumption) -> replayable token: CONFIRMED
```

User-IDOR on reset request (mismatched identity):

```bash
curl -sk -i -X POST "$TARGET/api/forgot-password" \
  -H "Content-Type: application/json" \
  -d '{"email":"<ACCOUNT_A_EMAIL>","user_id":"<ACCOUNT_B_USERID>"}' \
  -o /tmp/reset_idor_req.txt -w "HTTP %{http_code}\n"
# check inbox of BOTH accounts: did B get a reset email it never asked for?
```

## Completion-bias defenses

- [ ] Reset surface mapped: every forgot/reset/magic-link entry point listed with method + params
- [ ] Baseline captured: dead-path response AND invalid-email response saved
- [ ] Normal control reset completed and email contents recorded (link format, token, expiry)
- [ ] Full Host-header poisoning matrix run (Host, X-Forwarded-Host, X-Forwarded-Server, X-Host, Forwarded) with emailed-link check per variant
- [ ] If poisoned: 2x reproduction on a second test account, token validity confirmed without harming others
- [ ] Token entropy measured across 3+ tokens; expiry tested or bounded
- [ ] Referer-leakage check done on token-bearing pages
- [ ] User-enumeration differential tested (existing vs nonexistent vs malformed)
- [ ] User-IDOR tested on reset request (mismatched identifiers)
- [ ] User-IDOR tested on reset consume (cross-user token use, 2 test accounts)
- [ ] Replay tested (consume twice); binding tested (different session/IP)
- [ ] Post-reset session invalidation tested
- [ ] Rate-limit behavior noted and handed to rate_limit_mapping
- [ ] Finished artifact exists: `findings/password_reset_poison_confirmed.md` with raw pairs
- **Review step:** agent10_review must verify: (a) every CONFIRMED claim has a matching baseline file, (b) poisoning claims include the raw email showing the attacker domain in the link, (c) replay/IDOR claims show two independent reproductions, (d) no password was changed on any account the operator doesn't own.
- **Nudge prompts:**
  - "Keep going until every header in the poisoning matrix has been tested and the emailed link checked for each — a 200 OK means nothing until you read the email."
  - "Do not report done before you have tested the token TWICE: once for strength, once for replay. Single-use is a claim, not an assumption."
  - "Do not report done before the finished artifact exists on disk with raw request/response pairs for every CONFIRMED and INCONCLUSIVE item."
- **Finished artifact definition:** `findings/password_reset_poison_confirmed.md` containing, per sub-flow, verdict + baseline file reference + 2x reproduction log + full raw request/response pairs (headers redacted only for your own test credentials).

## Evidence standard

- Baseline: every differential (enumeration, poisoning, IDOR) compared against the dead-path and invalid-email controls captured first.
- Reproduction: 2x independent reproduction required — for poisoning, on two separate reset requests; for replay, two separate consume attempts.
- Raw evidence: full request/response pairs saved, plus the raw reset email (`.eml`) for poisoning claims.
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (e.g. no inbox access to verify link contents — needs human) / NEGATIVE (dead end, documented so nobody re-tests it).

## Handoffs

- **rate_limit_mapping** consumes the reset endpoint's observed rate behavior (threshold guesses, block responses) to run its full bypass battery — weak tokens + no rate limit = brute-forceable resets.
- **session_fixation** consumes post-reset session-survival results — sessions surviving a password reset are its core finding class.
- **agent5_business_logic** consumes any confirmed account-takeover chain (poisoned link, cross-user token) as a privilege-escalation primitive.
- **agent10_review** consumes `findings/password_reset_poison_confirmed.md` for the final gate.
