---
name: mfa_weakness
agent: agent4_auth
description: Audit MFA enrollment, enforcement, backup codes, push fatigue, remember-device tokens, and MFA disable flows for bypasses.
---

# MFA Weakness

## Purpose

This skill audits multi-factor authentication end to end: enrollment bypass, server-side enforcement gaps, backup/recovery-code bruteforce surface, push-fatigue abuse, remember-device token theft, and MFA disable flows. MFA bypasses are high-impact by definition — they convert a stolen password (or a single leaked session) into full account takeover, defeating the exact control the victim trusted. You map the full MFA state machine, then attack each transition: skip, replay, bruteforce (within rate limits), fatigue, and disable.

## Division of labor

- **Consumes:** a working low-privilege account (credentials you legitimately created/own), `findings/auth_model_mapping_confirmed.md` (auth matrix), any observed MFA endpoints from JS harvest (`/mfa/*`, `/2fa/*`, `/totp/*`, `/webauthn/*`)
- **Produces:** `findings/mfa_weakness_confirmed.md` — the MFA state-machine map, per-transition test results, and raw pairs for every CONFIRMED bypass with attempt counts

## When to use / when NOT to use

- **Use when:** the target offers any second factor — TOTP, SMS, email OTP, push, WebAuthn, backup codes, "remember this device"; you see MFA screens, `mfa_required` responses, or step-up prompts on sensitive actions
- **Skip when (time-pass filter):** the target has no MFA feature at all (no enrollment UI, no second-factor endpoints in JS, no step-up anywhere) — ask: does it leak? Is it sensitive? Is it reachable unauthenticated? Auditing a nonexistent MFA is pure time-pass. Also skip bruteforce the moment you hit a real rate limit — document the limit, do not evade it.

## Methodology

1. **Map the full MFA enrollment flow.** With a fresh account: find enrollment (`/settings/mfa`, `/mfa/enroll`, QR-code endpoint). Record every step: secret issuance → QR → verify-code → backup codes → done. Note: is the TOTP secret delivered over an authenticated endpoint? Is enrollment mandatory or skippable? Save every request/response in the chain — the state machine lives here.
2. **Test enrollment skipping / step manipulation.** During enrollment: try navigating directly to the post-enrollment URL, try calling the "complete" endpoint without the verify step, try `step=done` / `skipped=true` parameters, try enrolling then abandoning mid-flow and logging in fresh. If the account ends up active with MFA marked "enrolled" but no valid secret bound (or enrollable later by an attacker), that is an enrollment-integrity failure — CONFIRMED only if you can log in afterwards with password alone.
3. **Test whether MFA is enforced server-side on every sensitive action or only at login.** With MFA enabled on your account: authenticate fully, then replay sensitive-action requests (password change, email change, API-key issuance, payout/withdrawal, MFA disable itself) with the MFA-step cookie/token stripped or with a session that never completed MFA. If any sensitive action executes without the MFA step — step-up is client-side theater → CONFIRMED.
4. **Test MFA-session fixation / step-skipping at login.** Log in with password to reach the MFA challenge. Then: request the post-MFA landing page directly with only the pre-MFA session cookie; replay the login response's redirect without submitting a code; try `?mfa=passed`, `?verified=1`, or a `mfa_verified=true` cookie. Any path that lands you authenticated without a valid code = CONFIRMED bypass. Compare against the baseline: what does a *wrong* code return (exact envelope)?
5. **Baseline the OTP verification endpoint.** Pick the verify endpoint (`/mfa/verify`, `/2fa/confirm`). Record: wrong code → status/body/envelope; correct code → status/body; no code → status/body; malformed (5 digits, 7 digits, letters) → status/body. This baseline is your oracle for every bruteforce/fatigue test below.
6. **Backup/recovery-code bruteforce surface — measure, don't hammer.** Read the backup-code format from enrollment (length? charset? how many issued?). Test rate limiting first: send 5 wrong codes, then a 6th — is there a delay, a lockout, a CAPTCHA, an exponential backoff? Count precisely. Rules: stay within the observed rate limit; stop at the first hard limit (lockout/CAPTCHA/429); NEVER attempt to bypass the limit (no IP rotation, no account rotation to dodge it). Compute the theoretical space (charset^length) vs the allowed attempts: if the code is 6 digits and unlimited attempts are allowed, that is the finding — CONFIRMED by demonstrating e.g. 50 sequential attempts all accepted-for-processing without lockout (document the count; do not actually bruteforce a real code to success unless it is your own test account AND within limits).
7. **Test OTP reuse and cross-context confusion.** Submit the same valid TOTP code twice (replay within its window, and after the window). Submit an email-OTP code to the TOTP endpoint and vice versa. Submit a *password-reset* OTP to the MFA endpoint. If any code is accepted twice or cross-context, the verifier is not binding codes to purpose/single-use — CONFIRMED with both raw pairs.
8. **MFA fatigue / push-spam paths.** If push-based MFA exists: find the push-trigger endpoint (login with password → "send push"). Trigger it repeatedly — how many pushes can you fire? Is there any cooldown? Can pushes be triggered without the password (username only)? Document the count and the interval. Push-spam enabling social-engineering approval is a real finding when unbounded; CONFIRMED by showing N pushes in M minutes with no throttle (use your own account only). Also check: does the push approval response contain a session token (approval phishing value)?
9. **Number-matching / context display.** If push uses number-matching: is the number shown to the user also shown to the attacker triggering it? If the attacker sees the number, matching is theater — note it. If no context (no IP/device shown), note the downgrade.
10. **Remember-device cookie/token analysis.** Enroll with "remember this device" checked. Capture the remember-me/remember-device cookie or token. Analyze: lifetime (decode JWT exp or observe longevity), entropy (run it through the session-token skill's helper), binding (does it work from a different IP/User-Agent? — test if you have egress variety). Then the kill test: delete all other session state, replay ONLY the remember-device token — does it grant a full session without any MFA? If yes, that token *is* the MFA bypass — its theft equals MFA bypass. CONFIRMED with 2x replays. Check also: is it revoked when MFA is disabled or password changed?
11. **Disabling-MFA flows.** Attempt to disable MFA: does it require re-authentication (password re-entry)? Does it require a valid TOTP code at disable time? Try disabling via direct API call with the code parameter omitted, empty, or `000000`. Try CSRF-ing the disable endpoint (GET-able? no CSRF token?). If MFA can be disabled with password alone after a session hijack — or worse, with no re-auth at all — that collapses the whole MFA model → CONFIRMED. Baseline: record the exact wrong-code envelope for the disable endpoint first.
12. **Recovery / "lost device" flows.** Find account-recovery-when-MFA-lost: does it fall back to email-only? to support ticket? Request recovery and see what it takes — an email-link-only recovery with no identity proofing is an MFA bypass by design → CONFIRMED if the recovered session has no MFA gate. Document every step; this is often the weakest link.
13. **SMS/voice OTP specifics (if applicable).** Check: is the OTP also accepted at the password-reset endpoint (cross-function)? Is there a "resend" endpoint without throttling (SMS pumping cost + bruteforce oracle)? Does the verify response leak validity ("code expired" vs "code invalid" = oracle)? Voice-call fallback reading the code — can the call be triggered to an attacker-controlled number via profile phone change without re-auth?
14. **WebAuthn / passkey specifics (if applicable).** Check: is `userVerification` required or merely preferred? Is the challenge actually validated (replay an old assertion)? Can a weaker factor be enrolled *after* WebAuthn (downgrade)? Is there a fallback "use TOTP instead" link that skips the hardware check?
15. **Re-verify every bypass twice.** Each CONFIRMED bypass (skip, step-strip, reuse, remember-device replay, disable-without-reauth, recovery fallback) gets 2x independent replays with fresh timestamps. Save both raw pairs. If the second run behaves differently, third run decides; persistent flake = INCONCLUSIVE.
16. **Decision branch — MFA is properly enforced server-side, codes single-use, throttled, disable requires re-auth + valid code:** the MFA core is NEGATIVE as a direct bypass. Pivot to the edges: remember-device token theft value (step 10), recovery fallback (step 12), and enrollment integrity (step 2) — bypasses usually live at the edges, not the verify endpoint.
17. **Decision branch — you hit a hard rate limit during backup-code probing:** STOP. Document the exact limit (N attempts → 429/lockout/CAPTCHA, duration). Do not evade. The limit itself is evidence of a control — record it as a NEGATIVE-with-control, and move to non-bruteforce transitions.
18. **Write the artifact.** State-machine diagram (text), per-transition results table, attempt counts for every bruteforce-surface probe, and raw-pair links for CONFIRMED items.

## Exact commands

Baseline — OTP verify endpoint behavior (wrong / missing / malformed), run first:

```bash
TARGET="<TARGET>"; EP="/api/mfa/verify"  # adjust path from JS harvest
for code in "000000" "" "12345" "1234567" "abcdef"; do
  echo "=== code=[$code] ==="
  curl -sk -o /tmp/mfa_base.txt -w "%{http_code} %{size_download}\n" -X POST "https://$TARGET$EP" \
    -H "Content-Type: application/json" -b "pre_mfa=<PRE_MFA_COOKIE>" -d "{\"code\":\"$code\"}"
  head -c 300 /tmp/mfa_base.txt; echo
done
```

MFA step-skipping at login (pre-MFA session → protected resource directly):

```bash
TARGET="<TARGET>"
# 1) login with password only, capture the pre-MFA session cookie
curl -sk -D /tmp/mfa_login.hdrs -o /dev/null -X POST "https://$TARGET/api/login" \
  -H "Content-Type: application/json" -d '{"email":"<EMAIL>","password":"<PASS>"}'
grep -i '^set-cookie' /tmp/mfa_login.hdrs
# 2) try the app landing + a sensitive API with ONLY the pre-MFA cookie (no code submitted)
PRE=$(grep -ioP '^set-cookie:\s*\K[^;]+' /tmp/mfa_login.hdrs | tr '\n' ';')
for u in "/app" "/api/users/me" "/api/settings" "/api/billing"; do
  code=$(curl -sk -o /dev/null -w "%{http_code}" -H "Cookie: $PRE" "https://$TARGET$u")
  echo "$u -> $code (compare: wrong-code baseline above)"
done
```

Sensitive action without the MFA step (step-up enforcement test):

```bash
TARGET="<TARGET>"
# full login WITH mfa -> capture full session; then strip the mfa-step marker and replay a sensitive action
FULL="session=<FULL_SESSION_COOKIE>"
echo "=== password-change WITH full MFA session ==="
curl -sk -o /tmp/su_full.txt -w "%{http_code}\n" -X POST "https://$TARGET/api/account/password" \
  -H "Cookie: $FULL" -H "Content-Type: application/json" -d '{"new_password":"NewPass123!"}'
echo "=== same action with pre-MFA session only ==="
curl -sk -o /tmp/su_pre.txt -w "%{http_code}\n" -X POST "https://$TARGET/api/account/password" \
  -H "Cookie: $PRE" -H "Content-Type: application/json" -d '{"new_password":"NewPass123!"}'
head -c 300 /tmp/su_full.txt; echo; head -c 300 /tmp/su_pre.txt; echo
```

Rate-limit measurement on backup/OTP codes (STOP at first hard limit):

```bash
TARGET="<TARGET>"; EP="/api/mfa/verify"
for i in $(seq 1 12); do
  code=$(printf "%06d" $((RANDOM % 1000000)))
  r=$(curl -sk -o /dev/null -w "%{http_code} %{time_total}" -X POST "https://$TARGET$EP" \
    -H "Content-Type: application/json" -b "pre_mfa=<PRE_MFA_COOKIE>" -d "{\"code\":\"$code\"}")
  echo "attempt $i code=$code -> $r"
  sleep 1
done
# If you see 429 / lockout / captcha: STOP, record N, do not continue or rotate identity.
```

OTP reuse + cross-context confusion:

```bash
TARGET="<TARGET>"; EP="/api/mfa/verify"; GOOD="<VALID_TOTP_JUST_USED>"
for i in 1 2; do
  echo "=== reuse run $i ==="
  curl -sk -o /tmp/reuse_$i.txt -w "%{http_code}\n" -X POST "https://$TARGET$EP" \
    -H "Content-Type: application/json" -b "pre_mfa=<PRE_MFA_COOKIE>" -d "{\"code\":\"$GOOD\"}"
  head -c 200 /tmp/reuse_$i.txt; echo
done
```

Remember-device token replay (strip everything else):

```bash
TARGET="<TARGET>"
REM="remember_device=<REMEMBER_COOKIE_VALUE>"
for i in 1 2; do
  echo "=== remember-device-only replay $i $(date -u +%FT%TZ) ==="
  curl -sk -D /tmp/rd_$i.hdrs -o /tmp/rd_$i.body -w "%{http_code} %{size_download}\n" \
    -H "Cookie: $REM" "https://$TARGET/api/users/me"
  head -c 300 /tmp/rd_$i.body; echo
done
```

MFA disable without re-auth:

```bash
TARGET="<TARGET>"
echo "=== disable, code omitted ==="
curl -sk -o /tmp/dis1.txt -w "%{http_code}\n" -X POST "https://$TARGET/api/mfa/disable" \
  -H "Cookie: session=<FULL_SESSION_COOKIE>" -H "Content-Type: application/json" -d '{}'
head -c 300 /tmp/dis1.txt; echo
echo "=== disable, empty code ==="
curl -sk -o /tmp/dis2.txt -w "%{http_code}\n" -X POST "https://$TARGET/api/mfa/disable" \
  -H "Cookie: session=<FULL_SESSION_COOKIE>" -H "Content-Type: application/json" -d '{"code":""}'
head -c 300 /tmp/dis2.txt; echo
# then verify server-side: log out, log back in with password only — MFA challenged or not?
```

Push-fatigue count (your own account only):

```bash
TARGET="<TARGET>"
for i in $(seq 1 10); do
  r=$(curl -sk -o /dev/null -w "%{http_code}" -X POST "https://$TARGET/api/mfa/push" \
    -H "Content-Type: application/json" -b "pre_mfa=<PRE_MFA_COOKIE>")
  echo "push trigger $i -> $r"
  sleep 5
done
# Document: N pushes in M minutes, any cooldown observed? Record, do not exceed 10.
```

## Completion-bias defenses

- [ ] Full MFA enrollment flow mapped step-by-step (secret issuance → verify → backup codes → done)
- [ ] Enrollment skip / step-manipulation tested (direct-to-complete, abandoned flow, param tampering)
- [ ] Server-side step-up enforcement tested on sensitive actions (password/email change, key issuance, MFA disable) with the MFA step stripped
- [ ] Login MFA step-skipping tested (pre-MFA cookie → landing + APIs directly; param/cookie tricks)
- [ ] OTP verify baseline recorded (wrong / missing / malformed code envelopes)
- [ ] Backup-code bruteforce surface measured: format noted, rate limit probed (≤ ~12 attempts), hard stop honored at first 429/lockout/CAPTCHA, attempt count documented
- [ ] OTP reuse (double-submit) and cross-context confusion (email-OTP→TOTP, reset-OTP→MFA) tested
- [ ] Push-fatigue path counted (triggers per minute, cooldown or none) on own account only
- [ ] Number-matching/context display assessed (attacker-visible number? device/IP shown?)
- [ ] Remember-device token captured, entropy/lifetime/binding analyzed, replay-with-nothing-else tested 2x
- [ ] Remember-device revocation on MFA-disable/password-change tested
- [ ] MFA disable flow tested (re-auth required? valid code required? omitted/empty code? CSRF-able?)
- [ ] Lost-device/recovery fallback mapped (email-only recovery = bypass by design?)
- [ ] SMS/voice specifics checked if applicable (cross-function codes, resend throttle, validity oracle)
- [ ] WebAuthn specifics checked if applicable (userVerification, challenge replay, weaker-factor downgrade)
- [ ] Every CONFIRMED bypass replayed 2x independently with matching results
- [ ] Decision branches applied (strong core → pivot to edges; hard rate limit → stop and document)
- [ ] Artifact written with state machine, per-transition table, attempt counts, raw-pair links
- **Review step:** agent10_review must verify: (1) no bruteforce probe exceeded the first observed rate limit and attempt counts are documented; (2) each CONFIRMED bypass has 2x timestamped raw pairs showing the bypass vs the wrong-code baseline envelope; (3) all tests used the agent's own test account — no other user's MFA was touched; (4) "unlimited attempts" claims include the actual attempt log.
- **Nudge prompts:** "Keep going until you have tested every MFA state transition, not just the verify-code endpoint." / "Do not report done before findings/mfa_weakness_confirmed.md exists on disk with the state-machine map." / "The verify endpoint is usually the strongest link — the bypass lives in enrollment, disable, recovery, or remember-device. Test the edges."
- **Finished artifact definition:** `findings/mfa_weakness_confirmed.md` — MFA state-machine map (enroll → challenge → verified → step-up → disable → recovery), per-transition result table (test, attempt count, result, verdict), and for every CONFIRMED bypass two raw pairs under `findings/raw/mfa_weakness_<n>.txt`.

## Evidence standard

- Baseline: wrong/missing/malformed-code envelopes recorded first on each endpoint; every bypass is judged against that deny shape
- Reproduction: 2x independent replays, timestamped; both must show the bypass (authenticated session or executed action without the MFA step)
- Raw evidence: full request/response pairs — including which cookies/tokens were present vs stripped in each run
- Verdicts: CONFIRMED (2x bypass with raw pairs vs baseline deny, own test account only) / INCONCLUSIVE (needs second-model run or human — e.g. push-fatigue social-engineering likelihood, ambiguous recovery flows) / NEGATIVE (enforced server-side, single-use throttled codes, re-auth on disable — documented with the control observed so nobody re-tests)

## Handoffs

- **Session-token-analysis skill:** consumes remember-device token values for entropy/lifetime scoring — needs the raw token + capture context
- **Auth-model-mapping skill:** consumes step-up enforcement gaps — needs which sensitive actions executed without the MFA step
- **Account-takeover chaining (agent5_chain):** consumes any CONFIRMED bypass — needs the exact replay sequence to chain with credential-stuffing or session theft
- **agent10_review:** consumes `findings/mfa_weakness_confirmed.md` + raw pairs + attempt logs; verifies rate-limit discipline and 2x repro before anything ships
