---
name: client_side_access_control
agent: agent9_interceptor
description: Prove admin UI hidden by CSS or route guards is unprotected server-side via direct navigation and API-level confirmation.
---

# Client-Side Access Control

## Purpose

"Hidden" is not "protected." SPAs routinely gate admin functionality with CSS (`display:none`), client-side route guards, or role flags in `localStorage` — while the server happily serves the underlying views and APIs to anyone who asks directly. This skill takes every UI-gated feature found by `spa_state_crawl` and `dom_event_probe` and proves, with direct navigation and API calls, whether the gate exists anywhere except the browser. Real-world impact: full admin panel access as a low-privilege user, or admin APIs callable with a tampered role flag.

## Division of labor

- **Consumes:** `findings/spa_state_crawl_confirmed.md` (CLIENT-GATED-ONLY routes), `findings/dom_event_probe_confirmed.md` (hidden admin panels, disabled controls, role-gated handlers); a low-privilege authenticated session (and admin session if available for comparison)
- **Produces:** the finished artifact — `findings/client_side_access_control_confirmed.md` containing the gate inventory, direct-navigation results, role-flag tamper results, API-level confirmations, and verdicts

## When to use / when NOT to use

- **Use when:** `spa_state_crawl` or `dom_event_probe` found anything gated client-side; the app has visible role differences (admin vs user views); role/permission data lives in `localStorage` or JWT claims.
- **Skip when (time-pass filter):** every gated route returned a real server-side redirect/403 in `spa_state_crawl` step 11 (gates are real — verify once per gate type, then stop); the app has a single role with no privileged views at all.

## Methodology

1. **Inventory every client-side gate.** Collect from the consumed artifacts: route guards (router `beforeEach`/guards), CSS-hidden admin UI, `disabled` admin controls, role checks in JS (`if (user.role === 'admin')`), and `localStorage`/JWT role flags. One row per gate: what it guards, how it's implemented, what it assumes.
2. **Direct-navigation test.** For each gated route: navigate directly (fresh load, low-priv session). Classify: (a) server 302/403 = real gate; (b) shell loads + data loads = **no server gate — CONFIRMED**; (c) shell loads + data missing = UI gate only, API may still be open — proceed to step 3.
3. **API-level confirmation.** For case (c): call the underlying APIs directly with the low-priv session (use the exact calls `spa_api_replay` captured). Data returned = the gate is purely cosmetic — CONFIRMED. Denied = the API is properly gated and only the view leaks (lower severity — note it).
4. **Role-flag tampering.** Where the gate reads a client-side flag (`localStorage.role`, JWT `role` claim, `window.__STATE__.user.isAdmin`): flip it in the low-priv session and re-render. If the admin UI appears AND its APIs respond, the server trusts the client — CONFIRMED privilege escalation. If UI appears but APIs deny, it's UI-only (note it).
5. **JWT claim tampering (unsigned-test).** If the role lives in a JWT: try `alg:none`, strip the signature, and re-sign with an empty secret — one quick attempt each. Then try flipping the `role` claim and re-signing *if* you can (you can't without the secret — the point is to confirm you can't). A server that accepts `alg:none` = critical, CONFIRMED.
6. **Guard-bypass via router internals.** In page context, call the router directly (`router.push('/admin')`, `history.pushState`) bypassing the guard component. Some guards only run on link clicks, not programmatic navigation. If the view renders + data loads, the guard is incomplete — CONFIRMED.
7. **Guard-bypass via chunk URL.** Fetch the admin chunk JS directly (from `spa_state_crawl` step 6) as the low-priv user. If the chunk itself is served without auth, the code — including API paths and logic — is public. Then check whether those API paths are gated (step 3).
8. **Disabled-control re-fire at API level.** For each admin control `dom_event_probe` re-enabled: capture the exact request it fires and replay it as the low-priv user via curl (no DOM tricks). Server honors it = missing function-level access control — CONFIRMED. This is the cleanest proof: no browser trickery, just the request.
9. **Cross-role UI diff.** With admin + low-priv sessions, diff the full DOM inventories (`dom_event_probe` step 2) on the same view. Every element present for low-priv that triggers an admin API = vertical access issue. Feed each to step 8.
10. **Parameter-level privilege.** For admin actions that take a target (user ID, tenant ID): as low-priv, call the admin API with *your own* ID first (control), then with another user's ID. Own-ID works + other-ID works = horizontal too. Own-ID denied = the endpoint is actually gated (NEGATIVE for this vector).
11. **Check the guard's own API.** Route guards often call `/api/me` or `/api/permissions` — tamper *that* response (proxy or mock) to return `role: admin` and see if the client unlocks. If the entire authZ decision rides on one client-read response, document the single point of failure.
12. **Flip client-side feature flags.** Admin features are often gated by feature flags (`LaunchDarkly`-style: `localStorage` keys, `/api/flags` responses, URL `?ff=` params). Enumerate the flags (bundle grep for `flag`, `feature`, `ff_`), flip each to `true` in the low-priv session, and re-render. A flag-gated admin panel whose APIs answer = the flag was the only gate — CONFIRMED.
13. **Probe legacy admin API versions.** Admin UIs removed from the nav often leave `/api/v1/admin/...` endpoints live while the UI moved to `/api/v2/`. Take every admin API path found and try `v1`/`v0`/`beta`/`internal` prefixes as the low-priv user. Legacy versions predate the current authZ checks more often than you'd expect.
14. **Write the finished artifact.** Gate inventory + per-gate test results (navigation, API, flag-tamper) + raw pairs + verdicts.

## Exact commands

Direct navigation as low-priv (compare to the admin-session render):
```bash
# Low-priv session, fresh cookie jar:
curl -s -b <LOWPRIV_JAR> "https://<TARGET>/admin/users" -o /tmp/gate_lowpriv.html -w "HTTP:%{http_code} SIZE:%{size_download}\n"
curl -s -b <ADMIN_JAR> "https://<TARGET>/admin/users" -o /tmp/gate_admin.html -w "HTTP:%{http_code} SIZE:%{size_download}\n"
sha256sum /tmp/gate_lowpriv.html /tmp/gate_admin.html
# lowpriv == admin (and != 404 baseline) -> no server-side gate (CONFIRMED).
```

API-level confirmation (the clean proof — no DOM tricks):
```bash
# Exact request the hidden admin control fires, replayed as low-priv:
curl -s -X POST "https://<TARGET>/api/admin/users/<ID>/promote" \
  -b <LOWPRIV_JAR> -H "X-CSRF-Token: <LOWPRIV_CSRF>" \
  -H "Content-Type: application/json" -d '{"role":"admin"}' -w "\nHTTP:%{http_code}\n"
```

Role-flag flip (page context, low-priv session):
```javascript
// RUN IN PAGE CONTEXT
localStorage.setItem('role', 'admin');           // adapt key to the app's actual flag
// If JWT-based, decode first: JSON.parse(atob(localStorage.getItem('token').split('.')[1])).role
location.reload();
// Does the admin UI appear? Then test whether its APIs respond (step 3) — UI alone is not enough.
```

Router-internals bypass (page context):
```javascript
// RUN IN PAGE CONTEXT — bypass guard components via direct router access
window.history.pushState({}, '', '/admin/users');
window.dispatchEvent(new PopStateEvent('popstate'));
// Vue: __VUE_ROUTER__.push('/admin/users') ; React Router: use the history object from devtools hook
```

Admin chunk fetch as low-priv:
```bash
curl -s -b <LOWPRIV_JAR> "https://<TARGET>/static/js/AdminPanel.ab12cd34.js" -o /tmp/admin_chunk.js -w "HTTP:%{http_code} SIZE:%{size_download}\n"
grep -oE '/api/[a-zA-Z0-9/_-]+' /tmp/admin_chunk.js | sort -u
# Chunk served (200) -> admin code is public; feed each /api path to step 3.
```

Feature-flag enumeration and flip (page context, low-priv session):
```javascript
// RUN IN PAGE CONTEXT
Object.keys(localStorage).filter(k => /flag|feature|ff_|ld_/i.test(k));  // flag keys
// If flags come from an API, find it:
performance.getEntriesByType('resource').map(r=>r.name).filter(u=>/flag|feature|config/i.test(u));
```
```bash
# Then flip each flag and re-test the gated UI + its APIs:
grep -oE '(flag|feature)[_A-Za-z]*["'\'']?\s*[:=]\s*(true|false)' /tmp/app.bundle.js | sort -u | head -20
```

Legacy admin API version probe:
```bash
for V in v1 v0 beta internal api; do
  echo "=== /$V/admin/users ==="
  curl -s "https://<TARGET>/$V/admin/users" -b <LOWPRIV_JAR> -w "\nHTTP:%{http_code}\n" -o /dev/null
done
# Any 200 as low-priv on a legacy prefix the UI no longer uses -> stale authZ (CONFIRMED).
```

JWT alg:none quick test:
```bash
python3 - <<'EOF'
import base64, json, requests
tok = "<LOWPRIV_JWT>"
h, p, s = tok.split('.')
def b64d(x): return base64.urlsafe_b64decode(x + '=' * (-len(x) % 4))
payload = json.loads(b64d(p)); payload['role'] = 'admin'
def b64e(o): return base64.urlsafe_b64encode(json.dumps(o).encode()).rstrip(b'=').decode()
forged = b64e({"alg": "none", "typ": "JWT"}) + "." + b64e(payload) + "."
r = requests.get("https://<TARGET>/api/admin/users", headers={"Authorization": f"Bearer {forged}"})
print("alg:none ->", r.status_code, r.text[:200])
EOF
```

## Completion-bias defenses

- [ ] Step 1: every client-side gate inventoried (one row per gate: guards what, how, assumes what)
- [ ] Step 2: every gated route direct-navigated as low-priv and classified a/b/c
- [ ] Step 3: every case-(c) route confirmed at API level with low-priv session
- [ ] Step 4: every client-side role flag flipped and re-tested (UI + API)
- [ ] Step 5: JWT alg:none / claim-tamper quick tests run where role is JWT-based
- [ ] Step 6: router-internals bypass attempted on guarded routes
- [ ] Step 7: admin chunks fetched as low-priv; embedded API paths fed to step 3
- [ ] Step 8: every re-enabled admin control replayed at API level via curl as low-priv
- [ ] Step 9: cross-role DOM diff done if two accounts exist
- [ ] Step 10: parameter-level privilege tested (own-ID control, then other-ID)
- [ ] Step 11: guard's own permission API identified and its trust model documented
- [ ] Step 12: every client-side feature flag enumerated and flipped, gated UI + APIs re-tested
- [ ] Step 13: legacy admin API versions probed (v1/v0/beta/internal prefixes)
- [ ] Step 14: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) every CONFIRMED claim has a curl-level API proof (not just "the UI appeared"), (b) the low-priv vs admin hash pairs are in the artifact, (c) UI-only appearances without API confirmation are marked as lower severity, not as privesc.
- **Nudge prompts:** "Keep going until every gate has an API-level verdict — 'the admin UI rendered' is not a privilege escalation until the API answers." / "Do not report done before findings/client_side_access_control_confirmed.md exists on disk with per-gate results." / "If you only tested as admin, you tested the wrong principal — every test in this skill runs as the low-priv user."
- **Finished artifact definition:** `findings/client_side_access_control_confirmed.md` — gate inventory, per-gate results (navigation hashes, API proofs, flag-tamper outcomes), raw pairs, severity-graded verdicts.

## Evidence standard

- Baseline: the admin-session render (hash) + the low-priv control (own-ID API call) — every claim needs both
- Reproduction: 2x independent reproduction required — direct-navigate twice fresh; API replay twice with fresh tokens
- Raw evidence: navigation hash pairs, full API request/response pairs for the low-priv replay, the exact flag/claim tampered
- Verdicts: CONFIRMED (low-priv principal reproducibly performs a privileged action or reads privileged data at the API level) / INCONCLUSIVE (UI appeared but API untested, or flaky — needs a second model run / human) / NEGATIVE (server gates hold — documented so nobody re-tests it)

## Handoffs

- `spa_state_crawl` and `dom_event_probe` supply the gate inventory (their CLIENT-GATED-ONLY / hidden-admin findings).
- `spa_api_replay` supplies exact API call shapes for the API-level confirmations and receives new admin endpoints discovered here.
- `storage_secret_audit` supplies the role-flag locations (localStorage keys, JWT claims).
- agent10_review consumes `findings/client_side_access_control_confirmed.md` and requires curl-level API proof for every CONFIRMED privesc before anything ships.
