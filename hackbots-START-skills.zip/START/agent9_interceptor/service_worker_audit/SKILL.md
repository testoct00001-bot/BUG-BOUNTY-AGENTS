---
name: service_worker_audit
agent: agent9_interceptor
description: Inspect service-worker registrations, cache contents, background sync, and push handlers for offline data leaks and scope abuse.
---

# Service Worker Audit

## Purpose

Service workers are a privileged proxy between the app and the network: they cache responses (including authenticated API data), intercept fetches, run background sync, and receive push messages — all persisting after the tab closes and sometimes after logout. Mis-scoped workers cache other users' data, serve stale privileged content to the wrong session, or exfiltrate via background sync. This skill inventories every registration, dumps what it cached, and tests the trust boundaries. Real-world impact: a cached admin API response served to a logged-out browser, or a background-sync queue replaying privileged actions with a dead session's credentials.

## Division of labor

- **Consumes:** an authenticated browser session on `https://<TARGET>` (fresh profile recommended — SW state persists); optionally `findings/storage_secret_audit_confirmed.md` (cache entries already listed there)
- **Produces:** the finished artifact — `findings/service_worker_audit_confirmed.md` containing the registration inventory, cache dump analysis, sync/push test results, and verdicts

## When to use / when NOT to use

- **Use when:** the app registers any service worker (check `navigator.serviceWorker.getRegistrations()`); the app works offline or sends push notifications; background sync exists.
- **Skip when (time-pass filter):** `getRegistrations()` returns empty AND no worker script is fetched on load (verify, don't assume — check DevTools Application → Service Workers); the only worker is a well-known third-party one (e.g. Firebase messaging) with no app caching — still log one inventory line to prove you checked.

## Methodology

1. **Inventory registrations.** In page context, list all SW registrations: script URL, scope, state (installing/waiting/active). Record which origins they control — a worker scoped at `/` controls the whole origin.
2. **Read the worker source.** Download every SW script URL. Read it fully: cache names, fetch-event handlers, background-sync tags, push handlers, and any hardcoded URLs/keys. This is the worker's complete logic — understand it before testing.
3. **Dump Cache Storage.** List every cache name and every cached request URL. Authenticated API responses in cache = data at rest in the browser. Note `Response` staleness headers the worker ignores.
4. **Classify cached content.** For each cached API URL: is the content user-specific? privileged? does it contain PII/tokens (run the `storage_secret_audit` pattern battery on cache dumps)? A cached `/api/admin/users` response is a finding regardless of who can read it — then determine who *can*.
5. **Test cross-session cache serving.** With user A logged in, warm the cache (visit the privileged view). Log out, log in as user B (lower priv) in the same profile. Revisit the URL: does the SW serve user A's cached response to user B? If yes — cross-user data leak, CONFIRMED. Repeat A→logged-out.
6. **Test offline serving.** Warm the cache as an admin, go offline (DevTools), revisit privileged URLs. What renders offline that shouldn't? Offline availability of admin data widens every other bug's blast radius.
7. **Audit fetch-handler logic.** From the worker source: does it cache opaque responses? Does it serve cache-first for API paths (stale privileged data)? Does it forward `Authorization` headers to third-party origins? Does it strip or add headers? Each flaw gets a targeted test.
8. **Test background sync.** Trigger the app's sync-tagged actions (usually offline-then-online flows), then inspect `SyncManager` tags. Queue a privileged action, log out, go back online: does the worker replay it with the dead session? Replay-after-logout = broken invalidation, CONFIRMED.
9. **Test push handlers.** If push is registered: inspect the push subscription endpoint and what the worker does with push payloads (renders notification with data? fetches a URL?). Send yourself a test push if the app allows it; check whether payload data (potentially other users') is displayed or cached.
10. **Check update flow.** How does the worker update? `skipWaiting`/`clients.claim`? A worker that never updates can pin a vulnerable cached version indefinitely — note the update cadence and whether the server can force-refresh.
11. **Check scope overreach.** A worker registered at `/` from a path that should be scoped to `/app/` can intercept the whole origin including other apps on the same host. Verify the registration call's `scope` argument vs the script's path.
12. **Check for worker-injected exfiltration.** Diff the worker script against the version served to a fresh profile — or against the app's own repo if public. Unexpected `fetch()` calls to third-party origins inside the worker = supply-chain compromise indicator. Treat any delta as a lead, not noise.
13. **Clear-site-data behavior.** Call `Clear-Site-Data` semantics manually: unregister workers, clear caches, then verify nothing privileged remains. If the app never cleans up on logout, document the residue.
14. **Write the finished artifact.** Registration inventory + worker-source summary + cache classification + cross-session/offline/sync test results + verdicts.

## Exact commands

Registration inventory (page context):
```javascript
// RUN IN PAGE CONTEXT
const regs = await navigator.serviceWorker.getRegistrations();
regs.map(r => ({script: r.active?.scriptURL || r.installing?.scriptURL, scope: r.scope,
  state: r.active?.state, updateViaCache: r.updateViaCache}));
```

Download and fingerprint the worker source:
```bash
curl -s -b <COOKIE_JAR> "https://<TARGET>/sw.js" -o /tmp/sw.js
wc -l /tmp/sw.js
grep -nE 'caches\.open|cache\.add|fetch\(|background|sync|push|skipWaiting|clients\.claim|Authorization' /tmp/sw.js | head -50
```

Cache Storage dump (page context):
```javascript
// RUN IN PAGE CONTEXT
const names = await caches.keys();
for (const n of names) {
  const c = await caches.open(n);
  const reqs = await c.keys();
  console.log('CACHE:', n, 'entries:', reqs.length);
  reqs.slice(0,100).forEach(r => console.log('  ', r.method, r.url));
}
```

Read a cached API response body (page context):
```javascript
// RUN IN PAGE CONTEXT — inspect what the worker actually stored
const c = await caches.open('<CACHE_NAME>');
const res = await c.match('https://<TARGET>/api/<privileged-path>');
console.log(res?.status, (await res?.text())?.slice(0,2000));
```

Cross-session test (manual sequence — script it if you have two accounts):
```bash
# 1. As user A (admin): visit privileged view in the profile (warms SW cache).
# 2. Log out via UI. 3. Log in as user B (low-priv) in the SAME profile.
# 4. In page context as B:
#    const c = await caches.open('<CACHE_NAME>');
#    const res = await c.match('https://<TARGET>/api/<privileged-path>');
#    console.log((await res?.text())?.slice(0,500));
# If B reads A's cached admin data -> cross-user leak (CONFIRMED). Screenshot + save body.
```

Background-sync tag inspection (page context):
```javascript
// RUN IN PAGE CONTEXT
const reg = await navigator.serviceWorker.ready;
const tags = await reg.sync.getTags();
console.log('SYNC TAGS:', tags);
```

Push subscription inspection (page context):
```javascript
// RUN IN PAGE CONTEXT
const reg = await navigator.serviceWorker.ready;
const sub = await reg.pushManager.getSubscription();
console.log(JSON.stringify(sub?.toJSON(), null, 1));  // endpoint URL reveals the push service
```

Scope-overreach check:
```bash
grep -nE 'register\(|scope' /tmp/app.bundle.js | grep -i 'serviceworker\|sw\.js' | head -10
# Compare the requested scope against the worker script's path: scope must not exceed it.
```

Logout cleanup verification (page context):
```javascript
// RUN IN PAGE CONTEXT — after UI logout, before closing the tab:
(await caches.keys()).length + ' caches remain';
(await navigator.serviceWorker.getRegistrations()).length + ' workers remain';
Object.keys(localStorage).length + ' localStorage keys remain';
// Non-zero caches/workers holding privileged data after logout -> residue (document it).
```

## Completion-bias defenses

- [ ] Step 1: every registration inventoried (script URL, scope, state)
- [ ] Step 2: every worker script downloaded and fully read
- [ ] Step 3: every cache name + every cached URL listed
- [ ] Step 4: every cached API URL classified (user-specific? privileged? PII?)
- [ ] Step 5: cross-session cache test run (A → logout → B, and A → logged-out)
- [ ] Step 6: offline serving tested for privileged URLs
- [ ] Step 7: fetch-handler logic audited against the worker source
- [ ] Step 8: background-sync replay-after-logout tested
- [ ] Step 9: push subscription + payload handling inspected
- [ ] Step 10: worker update flow documented (skipWaiting/clients.claim?)
- [ ] Step 11: scope overreach checked (scope vs script path)
- [ ] Step 12: worker source diffed against fresh-profile version for injected exfiltration
- [ ] Step 13: logout cleanup verified (unregister + clear, residue documented)
- [ ] Step 14: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the worker source was actually read (summary of its caching strategy in the artifact, not just "checked"), (b) the cross-session test names both accounts/roles used, (c) every "cached privileged data" claim quotes the cache name + URL.
- **Nudge prompts:** "Keep going until every cache entry URL has been classified, not just the ones under /api/." / "Do not report done before findings/service_worker_audit_confirmed.md exists on disk with cross-session test results." / "If you never logged out and back in as a different role in the same profile, you have not tested the cache trust boundary."
- **Finished artifact definition:** `findings/service_worker_audit_confirmed.md` — registration inventory, worker-source logic summary, cache classification table, cross-session/offline/sync/push test results with raw excerpts, verdict per test.

## Evidence standard

- Baseline: the fresh-profile cache state (empty) and the same-URL network response — a "worker served stale/privileged data" claim must show the network would have denied it
- Reproduction: 2x independent reproduction required — the cross-session test must reproduce with fresh logins; SW state is sticky, so clear between runs
- Raw evidence: worker script excerpts, cache entry lists, cached response bodies (redacted), before/after screenshots of the cross-session test
- Verdicts: CONFIRMED (cross-user/offline/post-logout data serving reproducibly demonstrated) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (no privileged caching, clean lifecycle — documented so nobody re-tests it)

## Handoffs

- `storage_secret_audit` consumes cached response bodies for its secret/PII pattern battery.
- `spa_api_replay` consumes cached API URLs as extra endpoints for its tampering battery (cached = the app considers them fetchable).
- `authenticated_flow_record` consumes background-sync findings (replay-after-logout is a flow-integrity bug).
- agent10_review consumes `findings/service_worker_audit_confirmed.md` and verifies the worker-source summary before anything ships.
