---
name: dom_event_probe
agent: agent9_interceptor
description: Probe the live DOM for hidden buttons, disabled controls, event handlers, keyboard shortcuts, and debug menus the UI never shows.
---

# DOM Event Probe

## Purpose

What the user *sees* is a subset of what the DOM *contains*. Disabled buttons, `display:none` panels, debug menus, keyboard shortcuts, and orphaned event handlers frequently wire up to real functionality — including admin actions — that the visible UI hides. This skill inventories every interactive element in the live DOM (visible or not), fires what can be fired, and finds the handlers the designers forgot. Real-world impact: a hidden "Delete tenant" button that only needs its `disabled` attribute removed, or a debug menu exposing internal endpoints and tokens.

## Division of labor

- **Consumes:** an authenticated browser session on `https://<TARGET>`; optionally `findings/spa_state_crawl_confirmed.md` (routes whose DOM should be probed per-view)
- **Produces:** the finished artifact — `findings/dom_event_probe_confirmed.md` containing the interactive-element inventory, hidden-handler findings, fired-action results, and verdicts

## When to use / when NOT to use

- **Use when:** probing any authenticated view, especially admin/settings/billing areas; after `spa_state_crawl` finds CLIENT-GATED-ONLY routes; when the DOM is large relative to the visible UI.
- **Skip when (time-pass filter):** the page is a static marketing page with no authenticated functionality (no handlers worth firing); you already probed this exact view and its bundle hash is unchanged (no new handlers possible).

## Methodology

1. **Snapshot the visible UI.** Screenshot + list of visible interactive elements (buttons, links, inputs). This is your "intended surface" baseline.
2. **Inventory ALL interactive elements in the DOM.** In page context, collect every `button`, `a`, `input`, `select`, `textarea`, `[onclick]`, `[role=button]`, `[tabindex]` — including `display:none`, `visibility:hidden`, `opacity:0`, off-screen, and `disabled` ones. Count them; the delta vs step 1 is your hidden attack surface.
3. **Enumerate event listeners.** Monkey-patch `addEventListener` before page load (or use CDP `DOMDebugger.getEventListeners`) to list every registered listener: element, event type, handler source. Orphaned listeners on hidden elements are prime targets.
4. **Inspect disabled controls.** For each `disabled` button/input: record its label/handler, remove the `disabled` attribute in the DOM, and click it. Record the network activity and UI response. A disabled "Make admin" that fires a real request = broken client-side authorization.
5. **Inspect hidden panels.** For each `display:none` container with interactive children: unhide it (`style.display=''`), screenshot, and interact. Hidden admin drawers and feature-flagged panels live here.
6. **Fire orphaned handlers.** For elements with listeners but no visible affordance: dispatch the event (`el.click()`, `el.dispatchEvent(new Event('submit'))`). Record what happens — network calls, state changes, errors. Errors that leak stack traces or internal paths are findings too.
7. **Enumerate keyboard shortcuts.** Search bundles for `keydown`/`keyup` handlers and `key:` mappings; then press candidate combos (Ctrl+Shift+D, Alt+D, `g d`, `?`). Debug consoles and shortcut-triggered admin views are a classic hidden surface.
8. **Look for debug menus and flags.** Search the DOM and bundles for `debug`, `devtools`, `__debug`, `data-debug`, `?debug`, React/Vue devtools hooks, and `console.*` calls that print internal state. Activate anything found and record what it exposes.
9. **Enumerate window-exposed functions.** List `Object.keys(window)` for app globals (`window.app`, `window.__STATE__`, `window.debugAPI`). Call read-only ones (`getConfig()`, `getState()`); many dump tokens, feature flags, or internal URLs. Do NOT call state-changing ones blind — read their source first.
10. **Check framework devtools leakage.** If React/Vue/Angular devtools hooks are present in production, use them to inspect component props/state — props frequently contain full user objects, roles, and tokens the UI never renders.
11. **Probe form actions.** For every `<form>` (visible or hidden): record `action`, `method`, and inputs including `type=hidden`. Submit hidden forms with the browser's own values, then with tampered values. Hidden forms often point at legacy endpoints.
12. **Test handler behavior across roles.** If you have two accounts (admin + low-priv), repeat the inventory on the same view for both. Elements/handlers present for the low-priv user that mirror admin functionality = vertical privilege issue (confirm server-side with `spa_api_replay`).
13. **Re-probe after state changes.** Some handlers only attach after an action (modal opens, tab switches, data loads). Repeat the inventory after each major interaction — one pass is never enough.
14. **Pierce shadow DOM.** Web components hide interactive elements inside shadow roots that `querySelectorAll` on `document` never sees. Walk `el.shadowRoot` recursively and repeat the inventory inside each. Admin widgets built as web components live entirely in here.
15. **Extract hidden input values.** For every `type=hidden` input (and `data-*` attributes on interactive elements): record name + value. Hidden inputs carry IDs, tokens, return URLs, and price/role fields — each one is a tamper candidate for `spa_api_replay`.
16. **Classify every anomaly.** For each hidden/firable element: does firing it produce a network request? A state change? Data? Nothing? Only network-or-state effects ship as findings; pure UI toggles are NEGATIVE.
17. **Write the finished artifact.** Full inventory + per-anomaly evidence (element HTML, handler source, fired result, network log excerpt, verdict).

## Exact commands

Interactive-element inventory (run in page context):
```javascript
// RUN IN PAGE CONTEXT — full inventory including hidden/disabled
const els = [...document.querySelectorAll('button,a,input,select,textarea,[onclick],[role="button"],[tabindex]')];
const inv = els.map(e => {
  const cs = getComputedStyle(e);
  return { tag: e.tagName, type: e.type||'', id: e.id||'', text: (e.innerText||e.value||'').slice(0,60),
    hidden: cs.display==='none'||cs.visibility==='hidden'||+cs.opacity===0,
    disabled: e.disabled===true, rect: e.getBoundingClientRect().width+'x'+e.getBoundingClientRect().height };
});
console.table(inv); inv.length; // record total; delta vs visible UI = hidden surface
```

Listener enumeration via monkey-patch (inject BEFORE page scripts run — use a fresh load with this as an init script):
```javascript
// RUN IN PAGE CONTEXT as early as possible
window.__listeners = [];
const _ael = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function(type, fn, opt){
  window.__listeners.push({el: (this===window?'window':(this.tagName||'document')), type, src: String(fn).slice(0,200)});
  return _ael.call(this, type, fn, opt);
};
// ... interact with the page, then:
console.table(window.__listeners);
```

Re-enable and fire a disabled control:
```javascript
// RUN IN PAGE CONTEXT
const b = [...document.querySelectorAll('button[disabled]')].find(x=>/admin|delete|approve|impersonat/i.test(x.innerText));
b.removeAttribute('disabled'); b.disabled = false; b.click();
// Watch DevTools Network: a real request firing = broken client-side authorization.
```

Hidden panel reveal:
```javascript
// RUN IN PAGE CONTEXT
[...document.querySelectorAll('*')].filter(e=>getComputedStyle(e).display==='none' && e.querySelector('button,a,input'))
  .forEach(e=>{ e.style.display='block'; e.style.border='3px solid red'; });
```

Window globals dump:
```javascript
// RUN IN PAGE CONTEXT — read-only recon first
Object.keys(window).filter(k=>/app|state|config|debug|api|token|auth/i.test(k));
// Then inspect, e.g.: JSON.stringify(window.__STATE__||window.app?.getState?.(), null, 1).slice(0,2000)
```

Shadow-DOM inventory (page context — recursive):
```javascript
// RUN IN PAGE CONTEXT
function walk(root, out=[]) {
  root.querySelectorAll('*').forEach(e => {
    if (e.shadowRoot) { out.push('SHADOW: '+e.tagName+'#'+e.id); walk(e.shadowRoot, out); }
    if (/^(BUTTON|A|INPUT|SELECT|TEXTAREA)$/.test(e.tagName)) out.push(e.tagName+' '+(e.innerText||e.value||'').slice(0,40));
  });
  return out;
}
const all = walk(document);
console.log('total incl. shadow:', all.length);
all.filter(x=>x.startsWith('SHADOW')).forEach(x=>console.log(x));
```

Hidden input + data-attribute extraction:
```javascript
// RUN IN PAGE CONTEXT
[...document.querySelectorAll('input[type=hidden]')].map(i => i.name+' = '+(i.value||'').slice(0,120));
[...document.querySelectorAll('button,a,input')].flatMap(e => [...e.attributes]
  .filter(a=>a.name.startsWith('data-')).map(a=>e.tagName+'.'+a.name+' = '+a.value.slice(0,80))).slice(0,50);
```

Bundle search for shortcuts and debug hooks:
```bash
grep -oE '(keydown|keyup|keypress)[^;]{0,80}' /tmp/app.bundle.js | sort -u | head -40
grep -oE '(debug|__debug|devtools|data-debug)[^"'\'';]{0,60}' /tmp/app.bundle.js | sort -u | head -40
```

## Completion-bias defenses

- [ ] Step 1: visible-UI baseline captured (screenshot + element list)
- [ ] Step 2: full DOM inventory taken, hidden count recorded
- [ ] Step 3: event listeners enumerated (monkey-patch or CDP)
- [ ] Step 4: EVERY disabled control re-enabled and fired, network watched
- [ ] Step 5: EVERY hidden panel with interactive children revealed and interacted with
- [ ] Step 6: EVERY orphaned handler fired, results recorded
- [ ] Step 7: keyboard shortcuts enumerated from bundles AND pressed
- [ ] Step 8: debug menus/flags searched and activated
- [ ] Step 9: window globals enumerated; read-only ones called
- [ ] Step 10: framework devtools hooks checked for prop/state leakage
- [ ] Step 11: EVERY form (visible + hidden) submitted, then tampered
- [ ] Step 12: inventory repeated across roles if two accounts exist
- [ ] Step 13: inventory re-run after each major state change (not a single pass)
- [ ] Step 14: shadow DOM walked recursively; shadow-hidden elements inventoried
- [ ] Step 15: every hidden input value + data-* attribute recorded (tamper candidates for spa_api_replay)
- [ ] Step 16: every anomaly classified by effect (network/state/nothing)
- [ ] Step 17: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the inventory count is in the artifact (proves the DOM was actually walked, not eyeballed), (b) every "fires a request" claim has the Network log excerpt, (c) no disabled control was skipped without a reason.
- **Nudge prompts:** "Keep going until every disabled button has been re-enabled and clicked, not just the ones with interesting labels." / "Do not report done before findings/dom_event_probe_confirmed.md exists on disk with the full inventory count." / "If you only probed the initial page load, you missed the handlers that attach later — re-run after every major interaction."
- **Finished artifact definition:** `findings/dom_event_probe_confirmed.md` — inventory summary (total elements, hidden count, disabled count, listener count), per-anomaly records (element HTML, handler source, fire result, network excerpt), verdict per anomaly.

## Evidence standard

- Baseline: the visible-UI element list from step 1 — a "hidden" claim must name an element absent from that baseline
- Reproduction: 2x independent reproduction required — re-fire the control in a fresh page load; one-off JS errors are INCONCLUSIVE
- Raw evidence: element outerHTML + handler source + the fired request/response pair (or the exact "nothing happened" observation)
- Verdicts: CONFIRMED (hidden/disabled control reproducibly triggers a server-side effect or leaks data) / INCONCLUSIVE (fires once, needs a second model run or human) / NEGATIVE (pure UI toggle or no effect — documented so nobody re-tests it)

## Handoffs

- `spa_api_replay` consumes every fired request (method + path + body) for parameter-tampering batteries.
- `client_side_access_control` consumes hidden admin panels/drawers for direct-navigation confirmation.
- `storage_secret_audit` consumes anything the debug menu or window globals exposed (tokens, internal URLs).
- agent10_review consumes `findings/dom_event_probe_confirmed.md` and checks the inventory count before anything ships.
