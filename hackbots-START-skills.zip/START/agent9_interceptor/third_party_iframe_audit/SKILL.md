---
name: third_party_iframe_audit
agent: agent9_interceptor
description: Audit iframes, postMessage bridges, and third-party scripts for origin-validation failures and cross-origin data leaks.
---

# Third-Party Iframe Audit

## Purpose

Modern apps embed payment processors, chat widgets, analytics, and auth flows in iframes and load dozens of third-party scripts — each one running with access to the page's storage, DOM, or a `postMessage` bridge into the app. A single `postMessage` handler that doesn't validate `event.origin`, or a third-party script with DOM access on a page holding tokens in `localStorage`, turns a trusted integration into a data leak. This skill inventories every cross-origin embed, tests the message bridges, and maps what each third party can reach. Real-world impact: a chat widget's `postMessage` handler that hands out the session token to any origin, or a payment iframe leaking PII to its parent.

## Division of labor

- **Consumes:** an authenticated browser session on `https://<TARGET>`; optionally `findings/storage_secret_audit_confirmed.md` (what secrets exist for third parties to reach)
- **Produces:** the finished artifact — `findings/third_party_iframe_audit_confirmed.md` containing the embed inventory, postMessage bridge test results, script-capability map, and verdicts

## When to use / when NOT to use

- **Use when:** the app embeds any iframe (payment, chat, auth, docs) or loads third-party scripts; especially on pages that handle tokens, PII, or payments.
- **Skip when (time-pass filter):** the app loads zero third-party resources and zero iframes (verify via the inventory in step 1 — one clean run proves it); the only third party is a cookieless static CDN serving images with no script execution (log one line, move on).

## Methodology

1. **Inventory every cross-origin resource.** In page context, list: all `<iframe>` (src, `sandbox`, `allow`, `name`), all `<script src>` with a foreign origin, all `link`/fetch targets to foreign origins, and WebSocket/EventSource connections to foreign origins. Record which are on authenticated pages vs public pages.
2. **Map the trust each embed gets.** For each iframe: `sandbox` attribute present? `allow` list (camera? microphone? `payment`? `fullscreen`?)? Is it same-origin or cross-origin? For each script: `async`/`defer`? SRI `integrity` hash? A payment iframe without `sandbox` or a script without SRI is a finding's precondition — note it.
3. **Enumerate postMessage listeners.** Monkey-patch `window.addEventListener('message', ...)` (and `onmessage`) before page load to capture every registered handler with its source. Also enumerate `parent.postMessage` / `frames[...].postMessage` *senders* — what data does the app push out, and to which `targetOrigin` (`*` = broadcast to any origin).
4. **Read every message handler's source.** For each `message` listener: does it check `event.origin` against an allowlist? Does it validate `event.data` shape/type? Does it act on the data (DOM write, navigation, storage write, API call)? No origin check + action = the core bug shape. `indexOf`/`includes` origin checks (substring match) = bypassable — flag them.
5. **Probe handlers with crafted messages.** From a *different origin* (a test page you control, or `data:`/attacker-origin iframe), `postMessage` each handler with: valid-shaped data, wrong-origin expectations, `__proto__` pollution payloads, and oversized data. If the handler acts on a message from your evil origin, that's a postMessage origin-validation failure — CONFIRMED. This is the highest-ROI test in the skill.
6. **Test the reverse direction.** For app-to-iframe bridges: does the app send sensitive data (`postMessage(token, '*')`)? Intercept by embedding the app's iframe URL in your test page and logging everything it posts. Tokens/PII posted with `targetOrigin='*'` = leak to any embedder — CONFIRMED.
7. **Clickjacking check.** For sensitive actions in iframes (or the app framed by others): check `X-Frame-Options` / `frame-ancestors` CSP on the app's own pages. If the app can be iframed by an attacker origin AND has state-changing GETs or drag-drop actions, that's UI redressing — verify with a proof-of-concept frame, don't just read headers.
8. **Third-party script capability map.** For each third-party script on authenticated pages: can it read `localStorage` (any script on the page can)? Does the page hold tokens in storage (`storage_secret_audit`)? Does the script exfiltrate (check its network calls in DevTools)? A session token in `localStorage` + 12 third-party scripts = the blast radius is 12 vendors. Document it.
9. **Supply-chain drift check.** For each third-party script URL: is it version-pinned (`/v3.2.1/`) or floating (`/latest/`)? Floating + no SRI = the vendor can ship arbitrary code tomorrow. Record pinning + SRI status per script. (Not a vuln alone — it's the precondition that makes every other finding worse.)
10. **Payment/auth iframe isolation.** For payment or auth iframes: verify the sensitive fields (card, password) render inside the iframe (not the parent DOM), the parent can't read iframe DOM (cross-origin check), and the iframe's `allow` doesn't include `payment` delegation it shouldn't. Then check what the iframe posts back to the parent — full card data in a `message` event the parent logs = leak.
11. **postMessage → XSS chain.** If a handler writes `event.data` into the DOM (`innerHTML`, `document.write`, `eval`, `location`), send an XSS payload from your evil origin. Execution = postMessage-to-XSS, CONFIRMED with execution proof (alert/domain or DOM marker — use a harmless marker, never a real payload).
12. **Audit nested frames.** Iframes inside iframes (grandchild frames) each get their own `postMessage` bridge — and developers audit only the top level. Walk `frames[i].frames` recursively, enumerate handlers at every depth, and probe each. A grandchild chat widget with no origin check is the same bug one level down.
13. **Test sandbox escapes.** For each sandboxed iframe, check the `allow` tokens: `allow-top-navigation` / `allow-top-navigation-by-user-activation` lets the frame break out of the embed context; combined with `allow-scripts` and a postMessage bridge, that's navigation hijack. Also verify `sandbox` isn't dropped on dynamically created iframes (the app may sandbox static embeds but not JS-created ones — check the creation code).
14. **Write the finished artifact.** Embed inventory + handler source analysis + origin-probe results + script capability map + verdicts.

## Exact commands

Embed inventory (page context):
```javascript
// RUN IN PAGE CONTEXT
[...document.querySelectorAll('iframe')].map(f => ({src: f.src.slice(0,120), sandbox: f.getAttribute('sandbox'),
  allow: f.getAttribute('allow'), name: f.name}));
[...document.querySelectorAll('script[src]')].map(s => s.src)
  .filter(u => new URL(u).origin !== location.origin);
// Also: foreign fetch/WS targets from DevTools Network, filtered by origin.
```

Message-listener capture (inject before page scripts):
```javascript
// RUN IN PAGE CONTEXT as early as possible
window.__msgHandlers = [];
const _ael = window.addEventListener;
window.addEventListener = function(type, fn, opt){
  if (type === 'message') window.__msgHandlers.push(String(fn).slice(0,600));
  return _ael.call(this, type, fn, opt);
};
// ... use the app, then inspect window.__msgHandlers for origin checks.
```

Evil-origin probe page (host on any origin you control, e.g. a local server):
```html
<!-- evil_probe.html — served from http://127.0.0.1:8000, opened while the app is loaded -->
<iframe id="t" src="https://<TARGET>/<page-with-handler>"></iframe>
<script>
  const t = document.getElementById('t');
  t.onload = () => {
    // Probe 1: valid-shaped message from EVIL origin
    t.contentWindow.postMessage({type: 'auth', token: 'probe'}, '*');
    // Probe 2: proto pollution attempt
    t.contentWindow.postMessage(JSON.parse('{"__proto__":{"polluted":"yes"},"type":"config"}'), '*');
  };
  window.addEventListener('message', e => console.log('APP POSTED BACK:', e.origin, JSON.stringify(e.data).slice(0,500)));
</script>
```
```bash
python3 -m http.server 8000  # serve evil_probe.html, open http://127.0.0.1:8000/evil_probe.html
# If the app's handler ACTS on the evil-origin message -> origin-validation failure (CONFIRMED).
# If the app POSTS BACK sensitive data -> leak to any embedder (CONFIRMED).
```

Header check for framing policy:
```bash
curl -s -D - -o /dev/null -b <COOKIE_JAR> "https://<TARGET>/<sensitive-page>" | grep -iE '^(x-frame-options|content-security-policy)'
# Absent XFO + no frame-ancestors = framable. Then build the clickjacking PoC frame before claiming.
```

postMessage-to-XSS probe (only after confirming a DOM-sink handler):
```javascript
// From the evil-origin probe page:
t.contentWindow.postMessage({type: 'render', html: '<img src=x onerror="document.title=\'PWNED-'+document.domain+'\'">'}, '*');
// Check the app iframe's document.title — execution from evil origin = CONFIRMED.
```

Nested-frame walk (page context):
```javascript
// RUN IN PAGE CONTEXT — enumerate frames at every depth
function walkFrames(win, depth=0, out=[]) {
  for (let i = 0; i < win.frames.length; i++) {
    try { out.push('  '.repeat(depth) + win.frames[i].location.href.slice(0,100)); walkFrames(win.frames[i], depth+1, out); }
    catch(e) { out.push('  '.repeat(depth) + '(cross-origin, opaque)'); }
  }
  return out;
}
console.log(walkFrames(window).join('\n'));
```

Sandbox token audit:
```bash
# For each iframe from the step-1 inventory, verify the sandbox attribute is present on
# BOTH static HTML embeds and JS-created ones:
grep -oE 'sandbox="[^"]*"' /tmp/page.html | sort | uniq -c
grep -oE 'createElement\(.iframe.\)[^;]{0,120}' /tmp/app.bundle.js | head -10
# allow-top-navigation + allow-scripts on a frame with a postMessage bridge = breakout risk.
```

Script pinning + SRI audit:
```bash
curl -s -b <COOKIE_JAR> "https://<TARGET>/" | grep -oE '<script[^>]+src="[^"]+"' | sort -u
# For each foreign src: version-pinned path? integrity= attribute present? Document per script.
```

## Completion-bias defenses

- [ ] Step 1: every cross-origin iframe/script/fetch/WS target inventoried (auth pages + public pages)
- [ ] Step 2: sandbox/allow/SRI/pinning recorded per embed
- [ ] Step 3: every postMessage listener AND sender enumerated with source
- [ ] Step 4: every handler's source read for origin checks and data validation
- [ ] Step 5: EVERY handler probed from an evil origin (valid-shaped + malformed + proto-pollution)
- [ ] Step 6: reverse direction tested (what the app posts out, and to whom)
- [ ] Step 7: framing policy checked; clickjacking PoC built where framable + sensitive
- [ ] Step 8: third-party script capability map built against the storage audit
- [ ] Step 9: pinning + SRI status recorded per third-party script
- [ ] Step 10: payment/auth iframe isolation verified (fields, DOM boundary, postback data)
- [ ] Step 11: postMessage→XSS chained where a DOM sink exists (execution proof)
- [ ] Step 12: nested frames walked recursively; handlers at every depth probed from evil origin
- [ ] Step 13: sandbox tokens audited (allow-top-navigation, static vs JS-created iframes)
- [ ] Step 14: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the evil-origin probes actually ran from a different origin (not the app's own console — console messages carry the app's origin), (b) every CONFIRMED origin-failure has the sent message + observed handler action, (c) XSS claims have execution proof, not just a reflected string.
- **Nudge prompts:** "Keep going until every message handler has been probed from a foreign origin, not just the ones with obvious missing checks." / "Do not report done before findings/third_party_iframe_audit_confirmed.md exists on disk with the handler inventory." / "If you tested postMessage from the app's own console, you tested nothing — the origin was trusted. Use the evil-origin probe page."
- **Finished artifact definition:** `findings/third_party_iframe_audit_confirmed.md` — embed inventory, handler source analysis, evil-origin probe results (message sent → handler action), reverse-direction leak log, script capability map, verdict per embed/handler.

## Evidence standard

- Baseline: the handler's behavior with a same-origin, well-formed message (control) — the evil-origin probe is judged against it
- Reproduction: 2x independent reproduction required — reload the probe page and re-send; handler behavior must be stable
- Raw evidence: handler source excerpt, the exact evil-origin message sent, the observed handler action (network log / DOM change / posted reply), execution proof for XSS
- Verdicts: CONFIRMED (handler acts on / leaks to a foreign origin, reproducibly, or XSS executes) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (all handlers validate origin + data — documented so nobody re-tests it)

## Handoffs

- `storage_secret_audit` supplies the secret inventory that the script-capability map (step 8) is built against.
- `dom_event_probe` supplies hidden iframes/panels that may host additional bridges.
- `xss_hunter`-style validation (if available in the harness) consumes confirmed postMessage→XSS pairs for hardened execution proof.
- agent10_review consumes `findings/third_party_iframe_audit_confirmed.md` and verifies the evil-origin discipline before anything ships.
