#!/usr/bin/env python3
"""
ws_capture.py — capture WebSocket frames via Chrome DevTools Protocol.

Attaches to a debuggable browser tab, enables the Network domain, and logs
every webSocketFrameSent / webSocketFrameReceived event with timestamp and
direction to an output file.

Requires: pip install websocket-client

Usage:
    python3 ws_capture.py --cdp http://127.0.0.1:9222 --out ws_capture.log [--tab-index 0]

Start the browser with remote debugging first, e.g.:
    chromium --remote-debugging-port=9222 --user-data-dir=/tmp/hackbot-profile
"""
import argparse
import datetime
import json
import sys
import urllib.request

try:
    import websocket
except ImportError:
    sys.exit("missing dependency: pip install websocket-client")


def get_debugger_url(cdp_base: str, tab_index: int) -> str:
    with urllib.request.urlopen(cdp_base.rstrip("/") + "/json", timeout=10) as r:
        targets = json.load(r)
    pages = [t for t in targets if t.get("type") == "page"]
    if not pages:
        sys.exit("no debuggable page targets found at " + cdp_base)
    return pages[tab_index]["webSocketDebuggerUrl"]


def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="milliseconds")


def main() -> None:
    ap = argparse.ArgumentParser(description="Capture WebSocket frames via CDP")
    ap.add_argument("--cdp", default="http://127.0.0.1:9222", help="CDP http endpoint")
    ap.add_argument("--out", default="ws_capture.log", help="output log file")
    ap.add_argument("--tab-index", type=int, default=0, help="which page target to attach to")
    args = ap.parse_args()

    dbg_url = get_debugger_url(args.cdp, args.tab_index)
    print(f"[{now()}] attaching to {dbg_url}", flush=True)

    ws = websocket.create_connection(dbg_url, timeout=30)
    msg_id = 0

    def send(method: str, params: dict | None = None) -> None:
        nonlocal msg_id
        msg_id += 1
        ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))

    send("Network.enable")
    print(f"[{now()}] Network domain enabled; logging to {args.out}", flush=True)

    with open(args.out, "a", encoding="utf-8") as log:
        log.write(f"# ws_capture started {now()} cdp={args.cdp}\n")
        log.flush()
        try:
            while True:
                raw = ws.recv()
                try:
                    evt = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                method = evt.get("method", "")
                if method in ("Network.webSocketFrameSent", "Network.webSocketFrameReceived"):
                    direction = "C->S" if method.endswith("FrameSent") else "S->C"
                    resp = evt.get("params", {}).get("response", {})
                    payload = resp.get("payloadData", "")
                    opcode = resp.get("opcode", "")
                    line = f"{now()} {direction} opcode={opcode} len={len(payload)} {payload[:4000]}\n"
                    log.write(line)
                    log.flush()
                elif method == "Network.webSocketCreated":
                    p = evt.get("params", {})
                    log.write(f"{now()} WS-OPEN url={p.get('url')}\n")
                    log.flush()
                elif method == "Network.webSocketClosed":
                    p = evt.get("params", {})
                    log.write(f"{now()} WS-CLOSE {p}\n")
                    log.flush()
        except KeyboardInterrupt:
            print(f"\n[{now()}] stopped; log at {args.out}", flush=True)
        finally:
            log.write(f"# ws_capture ended {now()}\n")
            ws.close()


if __name__ == "__main__":
    main()
