---
name: websocket_intercept
agent: agent9_interceptor
description: Capture WebSocket traffic, test handshake authentication, and tamper messages to find auth and data-leak flaws in real-time channels.
---

# WebSocket Intercept

## Purpose

SPAs increasingly move sensitive operations onto WebSockets — chat, live data, notifications, even state-changing commands — where developers forget the auth checks they put on REST. The WS handshake often inherits the page's cookies without validating them, message handlers trust client-supplied fields, and servers broadcast data the subscriber shouldn't see. This skill captures all WS traffic, tests whether the handshake actually authenticates, and tampers with messages in both directions. Real-world impact: subscribing to another tenant's channel, sending forged messages as another user, or receiving PII in a broadcast you were never meant to join.

## Division of labor

- **Consumes:** an authenticated browser session on `https://<TARGET>`; optionally `findings/authenticated_flow_record_flows.md` (flows where a WS message carried a state transition)
- **Produces:** the finished artifact — `findings/websocket_intercept_confirmed.md` containing the WS endpoint inventory, captured message log, handshake-auth test results, tamper results, and verdicts. Raw captures live in `ws_capture.log` (produced by the helper script).

## When to use / when NOT to use

- **Use when:** DevTools Network shows `ws://`/`wss://` connections; the app has chat, live dashboards, notifications, collaborative editing, or real-time anything.
- **Skip when (time-pass filter):** no WS connections exist after exercising the full app (verify in DevTools — don't assume); the only WS traffic is a third-party analytics socket with no app data (still log one session to prove it).

## Methodology

1. **Inventory every WS endpoint.** With the app fully exercised, list all `ws://`/`wss://` URLs from DevTools Network → WS filter. Record URL, protocols (`Sec-WebSocket-Protocol`), and what UI feature each serves.
2. **Start the capture helper.** Run `ws_capture.py` against the browser's CDP endpoint (see Exact commands). It logs every frame in both directions with timestamps to `ws_capture.log`. Keep it running for the whole skill.
3. **Map the message protocol.** From the log, identify: handshake/auth messages, subscription messages (`subscribe`, `join`, `channel`), heartbeat/ping, data messages, and error messages. Document the JSON schema of each type.
4. **Test handshake authentication.** Connect to each WS endpoint with: (a) no cookies/headers, (b) an invalid token, (c) an expired token, (d) a valid session. If (a) or (b) connects and receives data, the handshake is unauthenticated — CONFIRMED lead. Record the exact server response for each case.
5. **Test subscription authorization.** With a valid low-priv session, send subscription messages for: another user's channel/ID, an admin channel, a wildcard (`*`, `#`), and a guessed tenant ID. If the server streams data for a channel you shouldn't access, that's a broken object-level authorization on the socket — CONFIRMED.
6. **Tamper message fields.** For each message type, mutate: sender/user ID fields, channel/room IDs, timestamps, sequence numbers, and any `role`/`admin` flags. If the server acts on client-supplied identity fields (e.g. `{"from": "victim-id"}` posts as the victim), that's forged-identity — CONFIRMED.
7. **Replay captured messages.** Take a privileged message from the log (e.g. an admin command) and replay it verbatim in a fresh connection, then with slight mutations. If privileged actions execute from a replayed frame, there's no nonce/sequence binding.
8. **Fuzz message types.** Send unknown `type`/`op` values, malformed JSON, oversized payloads (1 MB), deeply nested JSON (100 levels), and binary frames. Record crashes, verbose errors (stack traces = info leak), and any type that triggers an unexpected handler.
9. **Test heartbeat/timeout abuse.** Stop responding to pings; hold the connection open for 30+ minutes; open 100 parallel connections. Ghost sessions that never die and connection-count DoS are availability findings — note them, don't weaponize them.
10. **Inspect server-to-client data for leaks.** Grep the full capture log with the `storage_secret_audit` pattern battery. Broadcasts frequently include emails, tokens, internal IDs, and other users' PII. Every leak gets the exact message quoted (redacted).
11. **Test the close/reconnect cycle.** Kill the connection mid-flow and reconnect: does the server re-authenticate or resume on a client-supplied session ID? Session fixation on reconnect = CONFIRMED.
12. **Check origin validation.** Connect with a forged `Origin` header (cross-origin page). If the handshake accepts arbitrary origins AND relies on cookies, that's CSWSH (cross-site WebSocket hijacking) — CONFIRMED when you can demonstrate a cross-origin page completing the handshake.
13. **Correlate with REST auth.** For every WS action, check whether the equivalent REST endpoint enforces authZ. WS-missing-what-REST-has is the signature bug of this skill — document each pair.
14. **Write the finished artifact.** Endpoint inventory + protocol map + handshake matrix + tamper results + leak excerpts + verdicts.

## Exact commands

List CDP targets to confirm the debugger endpoint:
```bash
curl -s http://127.0.0.1:9222/json | python3 -c "import json,sys; [print(t['title'], t['webSocketDebuggerUrl']) for t in json.load(sys.stdin)]"
```

Start the capture helper (keep running for the whole skill):
```bash
# Requires: pip install websocket-client
python3 ws_capture.py --cdp http://127.0.0.1:9222 --out ws_capture.log
# Logs every webSocketFrameSent / webSocketFrameReceived event with timestamp + direction.
```

Handshake auth matrix (no browser — raw connections):
```bash
# (a) no auth at all:
python3 - <<'EOF'
import websocket
ws = websocket.create_connection("wss://<HOST>/ws/<endpoint>")
print("NO-AUTH CONNECT:", ws.recv())  # any data = unauthenticated handshake
ws.close()
EOF
# (b) invalid token: repeat with headers={"Authorization": "Bearer invalid"}
# (c) expired token: repeat with a known-expired token
# (d) valid session: repeat with the real session cookie -> the control case
```

Subscription authorization probe:
```bash
python3 - <<'EOF'
import websocket, json
ws = websocket.create_connection("wss://<HOST>/ws/<endpoint>", header=["Cookie: <SESSION_COOKIE>"])
for target in ["user/1", "user/99999", "admin", "*", "#", "tenant/other-tenant-id"]:
    ws.send(json.dumps({"op": "subscribe", "channel": target}))
    ws.settimeout(3)
    try:
        print(target, "->", ws.recv()[:300])
    except Exception as e:
        print(target, "-> no data", e)
ws.close()
# Data returned for a channel you should not access = broken authZ (CONFIRMED).
EOF
```

Message-field tamper (forged identity):
```bash
python3 - <<'EOF'
import websocket, json
ws = websocket.create_connection("wss://<HOST>/ws/<endpoint>", header=["Cookie: <SESSION_COOKIE>"])
# Baseline: your own legitimate message first (control). Then:
ws.send(json.dumps({"op": "message", "from": "<VICTIM_USER_ID>", "channel": "<CHANNEL>", "text": "tamper probe <RANDOM>"}))
print(ws.recv()[:500])
ws.close()
# Server broadcasts it as the victim = forged identity (CONFIRMED). Verify in the UI as the victim if possible.
EOF
```

Fuzz unknown message types:
```bash
python3 - <<'EOF'
import websocket, json
ws = websocket.create_connection("wss://<HOST>/ws/<endpoint>", header=["Cookie: <SESSION_COOKIE>"])
probes = [{"op": "admin"}, {"op": "eval", "code": "1"}, {"type": "subscribe", "channel": "../.."},
          "not json at all", {"op": "x", "a": {"b": {"c": {"d": 1}}}}, "A"*1000000]
for p in probes:
    ws.send(p if isinstance(p, str) else json.dumps(p)); ws.settimeout(2)
    try: print(str(p)[:60], "->", ws.recv()[:300])
    except Exception as e: print(str(p)[:60], "->", type(e).__name__, e)
ws.close()
EOF
```

Leak scan over the capture log:
```bash
grep -oiE '(eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+|[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|AKIA[0-9A-Z]{16})' ws_capture.log | sort | uniq -c | sort -rn | head -20
```

## Completion-bias defenses

- [ ] Step 1: every WS endpoint inventoried (URL, protocol, UI feature)
- [ ] Step 2: capture helper running, `ws_capture.log` accumulating
- [ ] Step 3: message protocol mapped (all message types documented)
- [ ] Step 4: handshake tested with no-auth / invalid / expired / valid (full matrix)
- [ ] Step 5: subscription authZ tested (other-user, admin, wildcard, cross-tenant)
- [ ] Step 6: every message type's identity/channel fields tampered
- [ ] Step 7: privileged messages replayed verbatim and mutated
- [ ] Step 8: fuzz battery sent (unknown types, malformed, oversized, nested, binary)
- [ ] Step 9: heartbeat/timeout behavior tested (ghost sessions noted)
- [ ] Step 10: full capture log scanned with the secret/PII pattern battery
- [ ] Step 11: close/reconnect cycle tested for re-authentication
- [ ] Step 12: Origin validation tested with forged Origin
- [ ] Step 13: WS actions correlated against their REST equivalents
- [ ] Step 14: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) `ws_capture.log` exists and covers the whole skill run (timestamps span start→end), (b) the handshake matrix shows all four cases with raw server responses, (c) every CONFIRMED subscription/tamper claim has the exact sent frame + received frame quoted.
- **Nudge prompts:** "Keep going until every WS endpoint has a four-case handshake matrix, not just the first one you found." / "Do not report done before findings/websocket_intercept_confirmed.md exists on disk with the protocol map." / "If you only watched traffic and never sent a tampered frame, you observed — you did not test. Send the frames."
- **Finished artifact definition:** `findings/websocket_intercept_confirmed.md` — endpoint inventory, protocol map, handshake matrix (4 cases × N endpoints), tamper/fuzz results with raw frames, leak excerpts (redacted), verdict per endpoint. Raw capture: `ws_capture.log`.

## Evidence standard

- Baseline: the valid-session handshake + legitimate message flow is the control — every tamper claim must show the control succeeding first, on the same endpoint
- Reproduction: 2x independent reproduction required — reconnect fresh and re-send the tamper frame; socket bugs must reproduce across connections
- Raw evidence: exact sent frames and received frames, timestamped, from `ws_capture.log`
- Verdicts: CONFIRMED (tamper/leak reproducibly demonstrated with frames) / INCONCLUSIVE (flaky or needs a second model run / human) / NEGATIVE (handshake + subscription + tamper all resisted — documented so nobody re-tests it)

## Handoffs

- `authenticated_flow_record` consumes any flow where a WS message carried a state transition (race the WS message too).
- `spa_api_replay` consumes the WS↔REST correlation pairs (step 13) for unified authZ testing.
- `storage_secret_audit` pattern battery is reused for the leak scan (step 10).
- agent10_review consumes `findings/websocket_intercept_confirmed.md` + `ws_capture.log` and verifies the handshake matrix before anything ships.
