---
name: authenticated_flow_record
agent: agent9_interceptor
description: Record authenticated login-to-action flows as deterministic, replayable request sequences for tampering and step-skipping tests.
---

# Authenticated Flow Record

## Purpose

Browsers do multi-step flows (login → verify → act → confirm); APIs behind them often trust the *sequence* instead of re-validating each step. This skill records complete authenticated flows — every request and response, in order, with tokens and timing — and converts them into deterministic replay scripts. Replay with steps skipped, reordered, or tampered is where broken state machines live: the IDP race condition from Haddix's talk (two requests racing the same state transition) is exactly this class. Real-world impact: skipping a verification step to enable an action the UI gates, double-submitting a state-changing request, replaying a "confirmed" action with different parameters.

## Division of labor

- **Consumes:** a working authenticated session in the browser (established by the human-in-the-loop or a prior login step); target base URL `https://<TARGET>`
- **Produces:** the finished artifact — `findings/authenticated_flow_record_confirmed.md` containing every recorded flow (ordered request/response log, replay script path, tamper-test results, verdict per flow)

## When to use / when NOT to use

- **Use when:** the app has multi-step authenticated flows (signup, checkout, invite/accept, password reset, approval chains, onboarding wizards); you need a ground-truth request log before any tampering skill runs.
- **Skip when (time-pass filter):** the app is read-only content with no state-changing authenticated actions (nothing to sequence); flows are single-request (no sequence to break); you cannot authenticate at all (record nothing — do not fake a session).

## Methodology

1. **Define the flow catalog first.** List the app's state-changing flows before touching the browser: login, registration, password change/reset, profile update, invite/send, accept/approve, payment/submit, delete/disable, role change, 2FA enroll/verify. Write the list down — this is your coverage contract.
2. **Start clean capture.** Open a fresh browser profile/incognito. Enable full request logging (DevTools Network → Preserve log, or CDP `Network.enable`). You must see *everything* including preflights, redirects, and WS upgrades.
3. **Record the login flow verbatim.** Perform login slowly, one action at a time. Save the complete ordered sequence: each request's method, URL, headers (auth-relevant), body, and each response's status + body. Note every token issued (session cookie, JWT, CSRF token) and where each is stored.
4. **Map token lineage.** For each subsequent request in the flow, annotate which token from which earlier response authorizes it. If a request works *without* the token it should need, flag it immediately — that is a broken binding.
5. **Record one canonical flow end-to-end.** Pick the highest-value flow (e.g. invite → accept, or payment). Perform it completely. Save the raw sequence as `flows/<flow-name>.json` (ordered array of {request, response, timing}).
6. **Convert to a deterministic replay script.** Translate the raw sequence into a `python3`/`curl` script that replays requests in order with variables for tokens/IDs (`{{SESSION}}`, `{{CSRF}}`, `{{INVITE_ID}}`). The script must run headless with zero browser.
7. **Verify replay fidelity.** Run the replay script against a *fresh* instance of the flow (new invite, new object). It must reproduce the same end state as the browser. If it doesn't, your capture missed a request (preflight, beacon, WS message) — find it and re-record. Do not proceed on an unfaithful replay.
8. **Tamper test 1 — step skipping.** Replay the flow with each middle step removed, one at a time. If the final action still succeeds without its prerequisite step (e.g. "confirm" without "verify"), that's a broken state machine — CONFIRMED lead.
9. **Tamper test 2 — step reordering.** Swap adjacent steps. If the server accepts an out-of-order sequence the UI never produces, document the accepted order — it reveals which validations are client-only.
10. **Tamper test 3 — parameter swap at the final step.** Replay the full valid sequence but change the *final* request's parameters (different target ID, amount, email). If the server honors it, the earlier steps' context is not bound to the final action — classic mass-assignment/IDOR shape.
11. **Tamper test 4 — double submission / race.** Fire the state-changing request twice in parallel (same tokens, same body). Then fire it 10x in parallel. Compare end states: double-applied effects, negative balances, duplicate objects = race condition. This is the IDP-race class from the talk — chase it.
12. **Tamper test 5 — token substitution.** Replay with: no token, another user's token (if you have two test accounts), expired token, token from a different flow. Record exactly which combinations the server accepts.
13. **Tamper test 6 — replay after logout.** Complete the flow's final request *after* logging out in the browser (session destroyed server-side?). If the captured request still works, session invalidation is broken.
14. **Time-box each flow, then move on.** 20 minutes per flow max for recording + fidelity check. Tamper tests get 10 minutes each. A flow that resists all six tamper tests is NEGATIVE — log it and move to the next flow in the catalog.
15. **Test session fixation on login.** Note the session cookie value *before* login (anonymous session). Complete login. If the session ID is unchanged after authentication, the app is vulnerable to session fixation — an attacker who plants a known session ID gets the victim's authenticated session. CONFIRMED when you can demonstrate the pre-login ID surviving login.
16. **Test concurrent-session handling.** Log in as the same user in two separate profiles. Change the password / revoke sessions in one. Does the other session die immediately, on next request, or never? A password change that leaves old sessions alive = broken invalidation — CONFIRMED.
17. **Cover the full catalog.** Repeat steps 5–16 for every flow in the step-1 catalog. An unrecorded flow is an untested state machine.
18. **Write the finished artifact.** Per flow: ordered request/response log, replay script path, which tamper tests ran, raw pairs for anomalies, verdict.

## Exact commands

Start CDP network capture (run once per session; adapt host/port to your browser's remote-debugging endpoint):
```bash
# List debuggable targets to confirm CDP is reachable:
curl -s http://127.0.0.1:9222/json | python3 -c "import json,sys; [print(t['title'], t['webSocketDebuggerUrl']) for t in json.load(sys.stdin)]"
```

Convert a captured sequence to replay — template (fill from your capture):
```python
#!/usr/bin/env python3
# flows/invite_accept_replay.py — deterministic replay of the recorded invite->accept flow
import requests, sys, json
BASE = "https://<TARGET>"
s = requests.Session()
def step(name, method, path, **kw):
    r = s.request(method, BASE + path, **kw)
    print(f"[{r.status_code}] {name} {method} {path}")
    return r
# 1. login (tokens captured at record time become variables)
r = step("login", "POST", "/api/auth/login", json={"email": "<EMAIL>", "password": "<PASSWORD>"})
s.headers["X-CSRF-Token"] = r.json()["csrf"]
# 2. create invite
r = step("invite", "POST", "/api/invites", json={"email": "victim@example.com", "role": "viewer"})
invite_id = r.json()["id"]
# 3. accept invite
r = step("accept", "POST", f"/api/invites/{invite_id}/accept", json={})
print("END STATE:", r.status_code, r.text[:200])
```
```bash
chmod +x flows/invite_accept_replay.py && python3 flows/invite_accept_replay.py
```

Tamper test — step skipping (remove step 2, keep 1 and 3):
```bash
python3 - <<'EOF'
# Edit the replay script programmatically: comment out the "invite" step, re-run accept with a guessed ID.
# If accept succeeds without a valid invite existing -> broken state machine (CONFIRMED).
EOF
```

Tamper test — parallel double-submit race:
```bash
python3 - <<'EOF'
import requests, concurrent.futures
BASE="https://<TARGET>"; H={"Authorization":"Bearer <TOKEN>","X-CSRF-Token":"<CSRF>"}
def fire(_): return requests.post(BASE+"/api/<state-changing-path>", headers=H, json={<BODY>}).status_code
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
    print(list(ex.map(fire, range(10))))
# Then GET the object and check for duplicated/over-applied effects.
EOF
```

Tamper test — replay after logout:
```bash
# In the browser: log out. Then replay ONLY the final captured request with curl:
curl -s -X POST "https://<TARGET>/api/<final-path>" -H "Authorization: Bearer <TOKEN>" -H "X-CSRF-Token: <CSRF>" -d '<BODY>' -w "\n%{http_code}\n"
# 200 with effect applied AFTER logout -> broken session invalidation (CONFIRMED).
```

Tamper test — session fixation on login:
```bash
# 1. Fresh profile: record the anonymous session cookie BEFORE login.
curl -s -c /tmp/prefix.jar "https://<TARGET>/" -o /dev/null && grep -E 'session|sid' /tmp/prefix.jar
# 2. Log in using that same jar:
curl -s -b /tmp/prefix.jar -c /tmp/prefix.jar -X POST "https://<TARGET>/api/auth/login" -d '{"email":"<EMAIL>","password":"<PASSWORD>"}' -o /dev/null
grep -E 'session|sid' /tmp/prefix.jar
# Same session ID before and after login -> session fixation (CONFIRMED).
```

Tamper test — concurrent session invalidation:
```bash
# Profile A and B both log in as the same user. In A, change the password.
# Then in B:
curl -s "https://<TARGET>/api/me" -b /tmp/profileB.jar -w "\nHTTP:%{http_code}\n"
# 200 after password change -> old sessions not invalidated (CONFIRMED).
```

## Completion-bias defenses

- [ ] Step 1: flow catalog written down before any recording (coverage contract)
- [ ] Step 2: clean capture session started, full request logging on
- [ ] Step 3: login flow recorded verbatim with every token noted
- [ ] Step 4: token lineage mapped for the login sequence
- [ ] Step 5: one canonical high-value flow recorded end-to-end as ordered JSON
- [ ] Step 6: replay script written, runs headless
- [ ] Step 7: replay fidelity verified against a fresh flow instance (no proceeding on unfaithful replay)
- [ ] Step 8: step-skipping tamper test run (each middle step removed once)
- [ ] Step 9: step-reordering tamper test run
- [ ] Step 10: final-step parameter swap tested
- [ ] Step 11: double-submit + 10x parallel race tested, end state inspected
- [ ] Step 12: token substitution matrix tested (none / other-user / expired / cross-flow)
- [ ] Step 13: post-logout replay tested
- [ ] Step 14: time-boxes respected (20 min record, 10 min per tamper set)
- [ ] Step 15: session fixation tested (pre-login ID vs post-login ID compared)
- [ ] Step 16: concurrent-session invalidation tested (password change kills other sessions?)
- [ ] Step 17: EVERY flow in the catalog covered, none skipped
- [ ] Step 18: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the replay script actually runs headless and reproduces the browser end-state (re-run it once), (b) every CONFIRMED tamper finding has the raw request/response pair in the artifact, (c) no flow from the step-1 catalog is missing without a written reason.
- **Nudge prompts:** "Keep going until every flow in your catalog has a faithful replay script, not just the first one that worked." / "Do not report done before findings/authenticated_flow_record_confirmed.md exists on disk with a verdict per flow." / "If your replay script needs the browser open to work, it is not a replay script — find the missing request."
- **Finished artifact definition:** `findings/authenticated_flow_record_confirmed.md` — per-flow: ordered request/response log, replay script path (`flows/<flow>.py`), tamper-test matrix with results, raw pairs for anomalies, verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE).

## Evidence standard

- Baseline: every tamper test compared against the faithful full-sequence replay on the same flow — the "valid sequence succeeds" control must be demonstrated first
- Reproduction: 2x independent reproduction required — re-run the tamper variant twice with fresh objects/IDs; state-machine bugs must reproduce, not flake
- Raw evidence: full request/response pairs for the control run AND the tamper run, saved side by side
- Verdicts: CONFIRMED (tamper variant reproducibly changes the security outcome vs control) / INCONCLUSIVE (flaky or needs a second model run / human) / NEGATIVE (all six tamper tests resisted — documented so nobody re-tests it)

## Handoffs

- `spa_api_replay` consumes the faithful replay scripts and the per-request token lineage to build targeted parameter-tampering batteries.
- `spa_state_crawl` consumes confirmed multi-step states (wizard routes) for deeper route enumeration.
- `websocket_intercept` consumes any flow where a WS message carried a state transition (race the WS message too).
- agent10_review consumes `findings/authenticated_flow_record_confirmed.md` and re-runs one replay script as the fidelity check before anything ships.
