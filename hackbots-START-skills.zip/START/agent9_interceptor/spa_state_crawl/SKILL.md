---
name: spa_state_crawl
agent: agent9_interceptor
description: Crawl authenticated SPAs to discover every route, lazy-loaded view, and hidden UI state the public surface never links to.
---

# SPA State Crawl

## Purpose

Single-page apps ship their entire client to the browser and only *link* a fraction of it. This skill systematically discovers every route, lazy-loaded chunk, modal/drawer state, and query-param-driven view inside an authenticated SPA — including admin panels, debug views, and legacy screens that are registered in the router but unreachable from any menu. These hidden states are where authorization bugs, unlinked APIs, and sensitive data live. Real-world impact: direct navigation to a route-guarded admin view that the server never actually protects (unauthorized data access, privilege escalation).

## Division of labor

- **Consumes:** `findings/authenticated_flow_record_flows.md` (a working authenticated session + cookie jar from agent9), JS bundle inventory if any other agent harvested it (format: list of `.js` URLs, one per line)
- **Produces:** the finished artifact — `findings/spa_state_crawl_confirmed.md` containing the full route inventory (URL, how discovered, auth behavior, API calls fired, verdict per route)

## When to use / when NOT to use

- **Use when:** the target is a React/Vue/Angular/Svelte SPA (HTML shell + JS bundles); you have an authenticated session; menus/navigation look sparse relative to the JS bundle size; you suspect hidden or legacy views.
- **Skip when (time-pass filter):** the app is server-rendered with no client router (nothing to crawl beyond links); you cannot obtain an authenticated session and the SPA renders nothing unauthenticated (no states to enumerate); the route table is trivially public AND every route is statically linked (nothing hidden to find).

## Methodology

1. **Baseline the router's 404 behavior.** Load `https://<TARGET>/__zz_no_such_route_9f31` in the authenticated session. Record status code AND a SHA-256 of the body. Most SPAs return `200` with `index.html` for unknown routes — your baseline is the *content hash*, not the status.
2. **Identify the router type.** In page context, check `window.React`, `window.Vue`, `window.ng`, URL style (`#/hash` vs `/history`), and look for `data-router` attributes. Router type dictates which introspection hooks work.
3. **Harvest the JS bundles.** List every `<script src>` on the shell page. Download each bundle. These contain the full route table, chunk map, and often API path strings.
4. **Extract route definitions statically.** Grep bundles for route patterns: `path:"/..."`, `path: "/..."`, `route:`, `component:`, `loadChildren`, `React.lazy`. Record every literal path string found.
5. **Extract the lazy-chunk manifest.** Find `webpackChunk`, `__webpack_require__.u`, `import(` dynamic imports, or Vite `/_astro/` chunks. List every chunk filename — each chunk is a view the menu may never link.
6. **Fetch and fingerprint every chunk.** Download each chunk, grep it for distinctive strings (e.g. `admin`, `debug`, `impersonate`, `billing`, `api/`). A chunk named `AdminPanel.ab12.js` that no menu links to is a lead.
7. **Introspect the live router.** In page context, walk the DOM for all `<a href>`, `<button>`, `[data-route]`, `[routerLink]`, `<Link to=...>`. Also check `window.__REACT_DEVTOOLS_GLOBAL_HOOK__` and router history objects for the registered route list.
8. **Click-crawl the navigation.** Click every nav element one by one; after each click record the URL, the `<title>`, and a DOM snapshot hash. New URL + changed snapshot = a distinct state.
9. **Deep-link every discovered route.** Navigate directly to each route URL (fresh page load, authenticated). Compare body hash to the 404 baseline from step 1. Divergent content = a real registered route.
10. **Probe route parameters.** For routes like `/users/:id` or `/org/:slug/settings`, substitute values: your own ID, `1`, `0`, `-1`, `me`, `admin`, another tenant's ID from the app's own UI. Record which render vs which fall back to baseline — divergent renders are IDOR groundwork (hand the list to `spa_api_replay`).
11. **Test auth gating per route.** Repeat step 9 in an unauthenticated/incognito session. Three outcomes: (a) redirected to login = real gate; (b) same content as authenticated = **missing server-side gate — CONFIRMED lead**; (c) shell loads but data missing = client-gated, API may still be open (check Network tab / `spa_api_replay`).
12. **Hunt query-param-driven states.** For each real route, try `?debug=1`, `?debug=true`, `?preview=1`, `?admin=1`, `?test=1`, `?env=staging`, `?mode=dev`. Compare DOM snapshot hash to the clean route. Any divergence = hidden state; document what changed.
13. **Hunt modal/drawer/hash states.** Click every element that opens overlays; record `#modal`, `#/dialog`, and hash-fragment URLs. Many "hidden admin" features live in drawers triggered only from other hidden states.
14. **Look for dead/legacy routes.** Try `/v1/...`, `/legacy/...`, `/old/...`, `/beta/...`, `/internal/...` variants of real routes, plus route names found in chunks but not in the live router (removed from nav, still registered). Legacy views rot and their APIs rot with them.
15. **Capture the API surface per route.** For every confirmed route, record which XHR/fetch/WS calls fire on load (method + path + status). This list is the input contract for `spa_api_replay` — the app's real attack surface.
16. **Diff chunk versions over time.** If the app redeploys during your hunt, re-download the entry bundle and diff the route table. New or removed routes between deploys are high-signal.
17. **Classify every route.** Mark each: PUBLIC / AUTH-GATED / CLIENT-GATED-ONLY (UI hides, server open — vuln) / DEAD (baseline match). Only CLIENT-GATED-ONLY and AUTH-GATED-with-divergence ship as findings.
18. **Write the finished artifact.** Route inventory table + per-route evidence (baseline hash, deep-link hash, unauth behavior, API calls fired, verdict). Nothing ships without the artifact on disk.

## Exact commands

Baseline the SPA 404 (content hash is the real baseline — status is usually 200):
```bash
curl -s -b <COOKIE_JAR> -c <COOKIE_JAR> "https://<TARGET>/__zz_no_such_route_9f31" -o /tmp/spa_404.html
sha256sum /tmp/spa_404.html && wc -c /tmp/spa_404.html
# Record: status is meaningless here; the SHA-256 above IS the baseline.
```

List script bundles from the shell page:
```bash
curl -s -b <COOKIE_JAR> "https://<TARGET>/" | grep -oE 'src="[^"]+\.js[^"]*"' | sort -u
```

Static route extraction from a downloaded bundle:
```bash
grep -oE 'path:\s*"[^"]+"' /tmp/app.bundle.js | sort -u
grep -oE '"/[a-zA-Z0-9_\-/{}\.:]+"' /tmp/app.bundle.js | sort -u | head -100
```

Chunk manifest discovery:
```bash
grep -oE '[a-zA-Z0-9_.-]+\.[a-f0-9]{8,}\.js' /tmp/app.bundle.js | sort -u
```

Deep-link probe with baseline comparison (run for EVERY candidate route):
```bash
ROUTE="/admin/users"
curl -s -b <COOKIE_JAR> "https://<TARGET>${ROUTE}" -o /tmp/route_probe.html
sha256sum /tmp/route_probe.html
# Compare against the /tmp/spa_404.html hash from the baseline step.
# SAME hash  -> dead route (NEGATIVE, log it and move on).
# DIFFERENT  -> real registered route, continue to auth-gate test.
```

Unauthenticated gate test (fresh jar, no cookies):
```bash
curl -s -c /tmp/nocookie.jar "https://<TARGET>${ROUTE}" -o /tmp/route_noauth.html
sha256sum /tmp/route_noauth.html
# If noauth hash == authenticated hash (and != 404 baseline): server renders
# the gated view for anonymous users -> CONFIRMED client-side-only access control.
```

Page-context route introspection (run in browser console / CDP Runtime.evaluate):
```javascript
// RUN IN PAGE CONTEXT
[...document.querySelectorAll('a[href]')].map(a => a.getAttribute('href')).filter(h => h && h.startsWith('/')).sort();
// Router globals:
Object.keys(window).filter(k => /router|route|history|ng_|__REACT|__VUE/i.test(k));
// Hash-state / modal triggers:
[...document.querySelectorAll('[data-toggle],[data-target],[aria-haspopup]')].map(e => e.outerHTML.slice(0,120));
```

Query-param state probe (compare DOM hash, not eyeballs):
```javascript
// RUN IN PAGE CONTEXT — snapshot hash of current view
async function domHash(){ const t=document.documentElement.outerHTML;
  const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t));
  return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('').slice(0,16); }
await domHash(); // record, then navigate with ?debug=1 and re-run; divergence = hidden state
```

Redeploy diff (re-run when the entry bundle changes):
```bash
curl -s -b <COOKIE_JAR> "https://<TARGET>/" | grep -oE 'src="[^"]+\.js[^"]*"' | sort -u > /tmp/bundles_new.txt
# Re-download, re-extract routes, then:
diff <(grep -oE 'path:\s*"[^"]+"' /tmp/app.bundle.js | sort -u) <(grep -oE 'path:\s*"[^"]+"' /tmp/app.bundle_new.js | sort -u)
# Added/removed routes between deploys = high-signal; new routes go straight to step 9.
```

## Completion-bias defenses

- [ ] Step 1: 404 baseline hash recorded (not just status)
- [ ] Step 2: router type identified and noted
- [ ] Step 3: every script bundle downloaded
- [ ] Step 4: static route strings extracted from all bundles
- [ ] Step 5: lazy-chunk manifest fully listed
- [ ] Step 6: every chunk fetched and fingerprinted
- [ ] Step 7: live-router introspection run in page context
- [ ] Step 8: every nav element click-crawled with URL+snapshot recorded
- [ ] Step 9: every candidate route deep-linked and hash-compared to baseline
- [ ] Step 10: route parameters substituted (own ID / 1 / 0 / me / admin / cross-tenant)
- [ ] Step 11: every real route re-tested unauthenticated (gate classified a/b/c)
- [ ] Step 12: query-param states probed on every real route
- [ ] Step 13: modal/drawer/hash states enumerated
- [ ] Step 14: legacy/dead route variants attempted
- [ ] Step 15: API calls per route captured (input list for spa_api_replay)
- [ ] Step 16: bundle re-downloaded and route table diffed if a redeploy happened
- [ ] Step 17: every route classified PUBLIC / AUTH-GATED / CLIENT-GATED-ONLY / DEAD
- [ ] Step 18: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the baseline hash exists and was actually used for comparison, (b) every CLIENT-GATED-ONLY claim has an authenticated-vs-unauthenticated hash pair in the artifact, (c) the route inventory has no "assumed dead" entries without a hash comparison.
- **Nudge prompts:** "Keep going until every chunk filename has been fetched and fingerprinted, not just the ones with interesting names." / "Do not report done before findings/spa_state_crawl_confirmed.md exists on disk with a verdict for every discovered route." / "If you tested only the routes linked in the menu, you have not done this skill — the hidden ones are the point."
- **Finished artifact definition:** `findings/spa_state_crawl_confirmed.md` — route inventory table (route, discovery method, baseline hash, deep-link hash, unauth behavior, APIs fired, verdict) plus raw request/response pairs for every CONFIRMED finding.

## Evidence standard

- Baseline: every route claim compared against the known-dead-path content hash on the same host, same session state
- Reproduction: 2x independent reproduction required — deep-link the route twice (fresh navigation each time); flaky renders are INCONCLUSIVE until stable
- Raw evidence: full request/response pairs saved for every CONFIRMED route (headers included — cache headers matter for gated views)
- Verdicts: CONFIRMED (hash-divergent route + reproduced + gate classified) / INCONCLUSIVE (divergence seen once, needs a second model run or human) / NEGATIVE (matches baseline hash — documented so nobody re-tests it)

## Handoffs

- `spa_api_replay` consumes the per-route API call list (method + path + status) — that is the app's real attack surface for parameter tampering.
- `client_side_access_control` consumes every CLIENT-GATED-ONLY route for direct-navigation exploit confirmation.
- `authenticated_flow_record` consumes confirmed multi-step states (e.g. wizard routes) that need deterministic replay.
- agent10_review consumes `findings/spa_state_crawl_confirmed.md` and verifies the baseline discipline above before anything ships.
