---
name: storage_secret_audit
agent: agent9_interceptor
description: Audit localStorage, sessionStorage, IndexedDB, and cookies for tokens, PII, internal URLs, and secrets the client should never hold.
---

# Storage Secret Audit

## Purpose

SPAs persist authentication tokens, user PII, internal API URLs, feature flags, and sometimes outright secrets in browser storage — readable by any script on the page (XSS → full account takeover) and often surviving logout. This skill dumps every storage mechanism, classifies what it finds against a secret/PII pattern battery, and tests the lifecycle: what survives logout, what is scoped wrong, what leaks to third parties. Real-world impact: a long-lived refresh token in `localStorage` with no rotation, or an internal admin API URL + API key sitting in storage waiting for one XSS.

## Division of labor

- **Consumes:** an authenticated browser session on `https://<TARGET>`; optionally `findings/dom_event_probe_confirmed.md` (window globals that hint at storage keys)
- **Produces:** the finished artifact — `findings/storage_secret_audit_confirmed.md` containing the full storage dump inventory, classified findings with patterns matched, lifecycle test results, and verdicts

## When to use / when NOT to use

- **Use when:** any authenticated SPA; after login, after logout, and after role changes; when the app "remembers" you suspiciously well.
- **Skip when (time-pass filter):** the app sets no cookies and uses no storage at all (verify by dumping, don't assume — an empty dump IS the result); the only stored values are opaque session IDs with HttpOnly+Secure+SameSite=Strict and nothing else (still dump once to prove it).

## Methodology

1. **Dump localStorage.** In page context, enumerate every key and value. Record key names, value lengths, and whether values look structured (JSON/JWT/base64).
2. **Dump sessionStorage.** Same treatment. Compare key sets between the two — tokens duplicated in both is a smell.
3. **Dump cookies.** List every cookie with its attributes: `HttpOnly`, `Secure`, `SameSite`, `Domain`, `Path`, `Expires/Max-Age`. A session cookie without `HttpOnly` is readable by XSS — flag it.
4. **Dump IndexedDB.** List databases, object stores, and sample records. Apps hide offline caches, PII, and tokens here where `localStorage` audits never look.
5. **Dump Cache Storage and application cache entries.** (Overlaps `service_worker_audit` — record URLs cached; this skill classifies their *content* for secrets.)
6. **Run the pattern battery.** Against every value from steps 1–5, run regexes for: JWT (`eyJ...`), AWS keys (`AKIA...`), private keys (`-----BEGIN`), API keys/tokens (`api[_-]?key`, `sk-`, `ghp_`, `xox`), emails, phone numbers, internal hostnames (`.internal`, `.corp`, `.local`, RFC-1918 IPs), passwords, and full URLs with query-string secrets.
7. **Decode structured values.** Base64-decode and JSON-parse every structured value. JWTs: decode header+payload *without verifying* — read `exp`, `aud`, `scope`/`roles`, and whether sensitive claims (email, role, tenant) are client-mutable. Note token lifetimes: a 30-day access token in `localStorage` is a finding.
8. **Test logout lifecycle.** Dump everything, log out via the UI, dump again. Anything auth-related that survives logout (tokens, user objects, tenant IDs) = broken session teardown. Then close the tab, reopen, dump again — persistence beyond the session is the XSS blast radius.
9. **Test role-change lifecycle.** If you have two roles/accounts: log in as low-priv, dump; log in as admin in the same profile, dump; compare. Admin-only values (keys, URLs, flags) that persist into the low-priv session = cross-role leakage.
10. **Check token binding and rotation.** Perform a privileged action, then check whether the access token rotated. Replay an old token value after rotation — if it still works, there is no rotation/invalidation.
11. **Check cookie scoping.** `Domain=.example.com` on an auth cookie exposes it to every subdomain (subdomain takeover → session theft). `Path=/` vs narrow paths. `SameSite=None` without `Secure`. Document each mis-scoping with the exact cookie.
12. **Check what JavaScript can read.** From page context, confirm each auth token is reachable via `document.cookie` / `localStorage.getItem` — i.e., confirm the XSS blast radius is real, not theoretical. `HttpOnly` cookies are correctly *un*readable — verify that too.
13. **Check third-party exposure.** List third-party scripts/iframes on the page (`third_party_iframe_audit` territory) and ask: can they read the same storage? Any token in `localStorage` is readable by every script on the page — map which third parties are present.
14. **Classify every hit.** SECRET (key/token/password) / PII (email/phone/user data beyond the logged-in user) / INTERNAL (URLs, hostnames, paths not meant for clients) / BENIGN (opaque IDs, UI prefs). Only the first three ship; BENIGN is logged as NEGATIVE with the reason.
15. **Write the finished artifact.** Storage inventory + classified hits with matched patterns + lifecycle test results + verdicts.

## Exact commands

Full storage dump (run in page context — save the output, don't eyeball it):
```javascript
// RUN IN PAGE CONTEXT
const dump = { localStorage: {...localStorage}, sessionStorage: {...sessionStorage},
  cookies: document.cookie, idb: [] };
for (const db of await indexedDB.databases()) dump.idb.push(db.name);
console.log(JSON.stringify(dump, null, 1).slice(0, 20000)); // save FULL output to a file
```

IndexedDB record sampling:
```javascript
// RUN IN PAGE CONTEXT — sample first 5 records of each store in each DB
for (const name of (await indexedDB.databases()).map(d=>d.name)) {
  const db = await new Promise((res,rej)=>{ const q=indexedDB.open(name); q.onsuccess=()=>res(q.result); q.onerror=rej; });
  for (const store of db.objectStoreNames) {
    const tx = db.transaction(store, 'readonly').objectStore(store).getAll();
    const rows = await new Promise(r=>{ tx.onsuccess=()=>r(tx.result); });
    console.log(name, '/', store, ':', JSON.stringify(rows).slice(0,1500));
  }
}
```

Cookie attribute audit:
```bash
curl -s -D /tmp/headers.txt -o /dev/null -b <COOKIE_JAR> "https://<TARGET>/"
grep -i '^set-cookie' /tmp/headers.txt
# For EACH cookie check: HttpOnly present? Secure present? SameSite value? Domain scope? Max-Age?
# Also check __Host- / __Secure- prefix discipline: a __Host- cookie without Secure+Path=/+no-Domain is malformed.
```

Pattern battery (run against the saved dump file):
```bash
DUMP=/tmp/storage_dump.json
grep -oE 'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+' $DUMP | sort -u          # JWTs
grep -oE 'AKIA[0-9A-Z]{16}' $DUMP | sort -u                                            # AWS keys
grep -oE '-----BEGIN [A-Z ]+PRIVATE KEY-----' $DUMP | sort -u                         # private keys
grep -oiE '(api[_-]?key|secret|passwd|password)["'\'']?\s*[:=]\s*["'\''][^"'\'']{4,}' $DUMP | sort -u
grep -oE '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' $DUMP | sort -u              # emails
grep -oE 'https?://[a-zA-Z0-9.-]+\.(internal|corp|local|lan)(:[0-9]+)?[^"'\'' ]*' $DUMP | sort -u
```

JWT payload decode (no verification — reading claims only):
```bash
python3 - <<'EOF'
import base64, json
tok = "<JWT_FROM_STORAGE>"
payload = tok.split('.')[1] + '=' * (-len(tok.split('.')[1]) % 4)
print(json.dumps(json.loads(base64.urlsafe_b64decode(payload)), indent=1))
# Read: exp (lifetime?), aud, scope/roles (client-mutable?), email/tenant claims
EOF
```

Logout lifecycle test:
```javascript
// RUN IN PAGE CONTEXT — run BEFORE logout, save output; click logout in UI; run again; diff
JSON.stringify({ls:{...localStorage}, ss:{...sessionStorage}, ck:document.cookie}).length + ' chars';
Object.keys(localStorage).sort().join(',');  // compare key lists before/after
```

Role-change lifecycle diff (same profile, two accounts):
```javascript
// RUN IN PAGE CONTEXT — as low-priv, save: Object.keys(localStorage).sort().join(',')
// Log out, log in as admin in the SAME profile, save again, diff the key lists.
// Then log back in as low-priv and check: any admin-only keys still present = cross-role leakage.
JSON.stringify({...localStorage}).length + ' chars as ' + (JSON.parse(localStorage.getItem('user')||'{}').role || 'unknown');
```

Old-token replay after rotation:
```bash
# Save the access token value BEFORE a privileged action, then:
curl -s "https://<TARGET>/api/me" -H "Authorization: Bearer <OLD_TOKEN>" -w "\n%{http_code}\n"
# 200 AFTER the app rotated to a new token -> no invalidation (CONFIRMED).
```

## Completion-bias defenses

- [ ] Step 1: localStorage fully dumped and saved
- [ ] Step 2: sessionStorage fully dumped and saved
- [ ] Step 3: every cookie listed WITH attributes
- [ ] Step 4: every IndexedDB database/store sampled
- [ ] Step 5: Cache Storage entries listed
- [ ] Step 6: pattern battery run against the complete dump (all six pattern classes)
- [ ] Step 7: every structured value decoded; JWT claims read and lifetimes noted
- [ ] Step 8: logout lifecycle tested (dump → logout → dump → diff; tab close/reopen)
- [ ] Step 9: role-change lifecycle tested if two accounts exist
- [ ] Step 10: token rotation tested; old token replayed
- [ ] Step 11: every auth cookie's Domain/Path/SameSite/Secure documented
- [ ] Step 12: JS-readability of each auth token confirmed (or HttpOnly verified)
- [ ] Step 13: third-party scripts on the page listed against storage readability
- [ ] Step 14: every hit classified SECRET / PII / INTERNAL / BENIGN
- [ ] Step 15: finished artifact written to disk
- **Review step:** agent10_review must verify: (a) the raw dump file exists and the pattern battery was run against it (not eyeballed), (b) every SECRET/PII claim quotes the exact stored value redacted to first/last 4 chars, (c) logout-lifecycle diffs are in the artifact.
- **Nudge prompts:** "Keep going until IndexedDB and Cache Storage are dumped too — localStorage-only audits miss the real caches." / "Do not report done before findings/storage_secret_audit_confirmed.md exists on disk with lifecycle test results." / "If you have not tested what survives logout, you have not audited the lifecycle — go back and do step 8."
- **Finished artifact definition:** `findings/storage_secret_audit_confirmed.md` — storage inventory, classified hits (pattern matched, redacted value, location), lifecycle diffs (before/after logout, role change), token lifetime analysis, verdict per hit.

## Evidence standard

- Baseline: the pre-login / logged-out storage dump — a "leaks after logout" claim must diff against it; a "secret in storage" claim must show the value was present in the saved dump
- Reproduction: 2x independent reproduction required — dump twice in fresh sessions; storage contents must be stable, not one-off
- Raw evidence: the saved dump excerpts (values redacted to first/last 4 chars in the artifact; full values never leave the local machine), cookie headers verbatim
- Verdicts: CONFIRMED (secret/PII/internal value present + lifecycle or scoping flaw demonstrated) / INCONCLUSIVE (pattern matched but context unclear — needs a second model run or human) / NEGATIVE (opaque IDs, UI prefs, properly-scoped HttpOnly cookies — documented so nobody re-tests it)

## Handoffs

- `dom_event_probe` findings about window globals feed back here as extra storage keys to check.
- `spa_api_replay` consumes tokens/keys found here as auth material for replay batteries (note: use the *session's own* tokens only — never another user's).
- `third_party_iframe_audit` consumes the third-party script list to assess who can read this storage.
- agent10_review consumes `findings/storage_secret_audit_confirmed.md` and verifies the dump file + redaction discipline before anything ships.
