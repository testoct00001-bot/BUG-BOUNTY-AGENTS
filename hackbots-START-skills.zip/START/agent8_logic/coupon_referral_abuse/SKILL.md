---
name: coupon_referral_abuse
agent: agent8_logic
description: Abuse promo, coupon, and referral logic — stacking, reuse, self-referral loops, and predictable codes — quantified in currency.
---

# Coupon & Referral Abuse

## Purpose
Promo and referral systems are business-logic code written by marketing-driven deadlines, and they fail in ways scanners never catch: server trusts the client on coupon validity, used coupons apply twice, referrals pay for fake accounts. This skill maps every discount surface, then systematically tests reuse, stacking, transfer, self-referral, and code predictability. Impact is money — quantify every finding in currency terms, because a "$0.50 discount bug" that scales to unlimited orders is a five-figure loss.

## Division of labor
- **Consumes:** endpoint lists with cart/checkout/payment flows (`<host>_endpoints.txt` from `hidden_endpoint_discovery`); JS-observed coupon parameters (field names like `promo_code`, `coupon`, `voucher` from `sdk_source_mining`); state notes on order lifecycle from `state_machine_audit`
- **Produces:** the finished artifact — `findings/coupon_referral_abuse_confirmed.md` containing raw request/response pairs, verdicts, and currency-quantified impact

## When to use / when NOT to use
- **Use when:** the target has any coupon/promo field, referral program, loyalty points, credits, gift cards, or discount codes visible in checkout, signup, or account pages
- **Skip when (time-pass filter):** no discount surface exists anywhere (no promo field, no referral page, no credits). Ask: does it leak money? A UI-only coupon hint with no backend application path is time-pass — verify the discount actually changes the charged total server-side before investing. Never "test" by completing real paid orders with stolen/fake payment instruments.

## Methodology
1. Map every discount surface: checkout promo field, cart API `coupon` parameter, account credit balance endpoints, referral dashboard, gift-card redemption, loyalty-point conversion. Record exact parameter names and endpoints from JS bundles and network traffic.
2. Test client-vs-server validation: apply a coupon in the UI, then intercept and send a *fake* code (`{"coupon":"FAKECODE123"}`) directly to the apply endpoint. If the server returns a discount for a code it never issued, validation is client-side — game over for their promo budget.
3. Test coupon reuse: apply a valid coupon to order 1, complete (or reach) payment, then apply the *same* coupon to order 2 as the same user. Then try as a *different* user. Single-use enforcement must be server-side and atomic — check for race windows (step 12).
4. Test stacking: apply coupon A, then coupon B on the same cart. Try query/body combos: `coupon=A&coupon=B`, JSON arrays `{"coupons":["A","B"]}`, and sequential apply calls. Then stack a coupon on top of an already-discounted sale price, loyalty points, *and* referral credit in one order.
5. Test coupon transfer: obtain a coupon bound to account A (welcome coupon, targeted promo), then apply it as account B. Targeted coupons must be account-bound server-side.
6. Test referral self-referral: create account B using A's referral code/link. Then create account C using A's code from the same device/IP/fingerprint. Check whether A gets credited each time and whether any device, IP, payment-method, or email-domain deduplication exists. Loop it 3–5 times and watch the credit balance.
7. Test referral credit cashout: once referral credit lands, trace every path it can leave — apply to orders, convert to gift cards, withdraw, transfer to another user. A credit that can become cash or be transferred out is the highest-impact variant.
8. Test predictable/brute-forceable codes: collect 10–20 real codes and analyze structure (length, charset, sequential patterns, date-embedded, `WELCOME10`-style guessables). If codes are short (<8 chars, limited charset), estimate the keyspace and test the validation endpoint's rate limiting — hand the math to `rate_limit_bypass` if the endpoint allows guessing.
9. Test coupon parameters in payment callbacks: after applying a coupon, inspect the payment-gateway redirect/callback URL and webhook payloads for `discount`, `coupon`, `amount` parameters. If the final charge amount is taken from a client-supplied callback parameter, tamper it.
10. Test negative/zero totals: stack discounts until the total hits 0 or negative. Submit the order — does the backend reject it, charge 0, or (worst) issue a *refund* of the negative amount? A negative-total order that completes is a money-printing bug.
11. Test expiry and revocation: use an expired coupon (change system perception via old codes from emails/wayback), a revoked coupon, and a coupon past its usage cap. Enforcement must be checked at *payment* time, not just at *apply* time — apply the coupon, wait, then pay.
12. Race the redemption: fire 5–10 simultaneous apply/redeem requests for a single-use coupon or referral credit. If the check-and-debit isn't atomic, parallel requests all succeed — capture the balance before/after.
13. Test currency/region confusion: apply a coupon issued in one currency/region to a cart in another; check whether percentage discounts compute against the wrong base or fixed-amount coupons convert at wrong rates.
14. Quantify impact in currency: for each confirmed abuse, compute per-order loss × realistic scale (e.g. "$15 coupon reusable indefinitely → $15 × N orders; referral $10 credit × self-referral loop with no dedup → unbounded"). State the maximum loss per attacker, not just the single-transaction delta.
15. Re-verify every positive twice: fresh sessions, fresh carts, and confirm the charged total (in the payment intent / order record / invoice), not just the displayed total.

### Decision branches — what the response tells you to do next
- **Fake code returns a discount:** validation is client-side or missing. Pivot immediately to negative/zero totals, callback-amount tampering, and stacking — the whole promo budget is exposed.
- **Reuse works for the same user:** test cross-user transfer next, then race 10 parallel redeems. Same-user reuse is a bug; cross-user reuse is a scalable bug.
- **Stacking works (A+B):** try triple-stack, then coupon + sale price + loyalty points + referral credit in one order. Each layer that stacks multiplies the loss — document the maximum combined discount.
- **Referral credits land with no dedup:** loop self-referral 5x from the same device/IP. If all 5 credit, trace the cashout path — credit that becomes withdrawable cash is the top-severity variant.
- **Codes look sequential or date-embedded:** stop manual testing and hand the validation endpoint to `rate_limit_bypass` with your structure analysis. Predictable codes + weak limits = practical brute force.
- **Discount shows in UI but charged total unchanged:** the display lies or the backend recomputes. This is NEGATIVE for money impact — verify the payment intent / order record before claiming anything.
- **Coupon rejected at apply but accepted at payment (or vice versa):** enforcement lives in only one of the two paths. Attack the unenforced one and document which check is missing where.

## Exact commands
Baseline — known-dead coupon code for comparison:
```bash
curl -s -i -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"coupon":"ZZZ-DEAD-CODE-000"}'
```
Fake-code server-validation test:
```bash
curl -s -i -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"coupon":"FAKECODE123"}' | head -30
# CONFIRMED if response shows discount_total > 0 for a code never issued
```
Stacking test (sequential applies):
```bash
for c in COUPON_A COUPON_B; do
  curl -s -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
    -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
    --data "{\"coupon\":\"$c\"}"
done
curl -s 'https://<HOST>/api/v1/cart' -H "Authorization: Bearer <TOKEN>" | python3 -m json.tool | grep -i -A2 -E 'discount|total'
```
Reuse test (same coupon, second order):
```bash
curl -s -X POST 'https://<HOST>/api/v1/orders' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"cart_id":"<CART2>","coupon":"<USED_COUPON>","payment_method":"test"}' | python3 -m json.tool | grep -i -E 'discount|total|status'
```
Self-referral loop (repeat 3-5x, watch A's credit):
```bash
curl -s -X POST 'https://<HOST>/api/v1/signup' -H 'Content-Type: application/json' \
  --data '{"email":"refloop1+<rand>@example.com","password":"Test123!","referral_code":"<A_CODE>"}'
curl -s 'https://<HOST>/api/v1/account/credits' -H "Authorization: Bearer <TOKEN_A>"
```
Redemption race (single-use coupon, 10 parallel):
```bash
for i in $(seq 1 10); do
  curl -s -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
    -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
    --data '{"coupon":"<SINGLE_USE>"}' &
done; wait
```
Code-structure sampling:
```bash
python3 - <<'EOF'
import re
codes = ["<CODE1>","<CODE2>","<CODE3>"]  # paste 10-20 real codes
for c in codes:
    print(len(c), "alpha" if c.isalpha() else "alnum" if c.isalnum() else "mixed", c)
EOF
```

# Negative/zero total: stack discounts until total <= 0, then submit
curl -s -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"coupon":"<90PCT>"}'
curl -s -X POST 'https://<HOST>/api/v1/cart/apply-coupon' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"coupon":"<50OFF>"}'
curl -s 'https://<HOST>/api/v1/cart' -H "Authorization: Bearer <TOKEN>" | python3 -m json.tool | grep -i -E 'total|discount'
# Inspect payment initiation for tamperable amount fields in redirects/callbacks
curl -s -i -X POST 'https://<HOST>/api/v1/orders/<ORDER_ID>/pay' \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"payment_method":"test"}' | grep -i -E 'Location|amount|discount|coupon'

## Completion-bias defenses
- [ ] Every discount surface mapped (checkout, cart API, credits, referral, gift card, loyalty) with exact parameter names
- [ ] Client-vs-server validation tested with a fake code
- [ ] Reuse tested: same user second order AND different user
- [ ] Stacking tested: coupon+coupon, coupon+sale, coupon+points+referral-credit combos
- [ ] Transfer tested: A's targeted coupon applied as B
- [ ] Self-referral looped 3–5x with credit balance captured before/after
- [ ] Credit cashout paths traced (orders, gift cards, withdraw, transfer)
- [ ] Code predictability analyzed from 10–20 real samples
- [ ] Payment callback/webhook parameters inspected for tamperable amounts
- [ ] Negative/zero total order attempted
- [ ] Expiry/revocation/usage-cap enforced at payment time, not just apply time
- [ ] Redemption raced 5–10x parallel for atomicity
- [ ] Impact quantified in currency (per-order loss × realistic scale)
- [ ] Every positive reproduced 2x with the *charged* total verified, not the displayed total
- [ ] `findings/coupon_referral_abuse_confirmed.md` exists on disk with raw pairs and verdicts
- [ ] Decision branches followed — pivoted on what the responses actually showed, not the original plan
- [ ] No CONFIRMED verdict rests on UI text alone; every discount verified against the charged total
- **Review step:** agent10_review must verify: (a) the finished artifact exists with raw pairs; (b) every CONFIRMED verdict shows the *server-side charged total* (payment intent/order record), not just UI text; (c) impact is quantified in currency with the scaling math shown; (d) no real paid orders were completed with non-test payment instruments.
- **Nudge prompts:** "Keep going until you have tested every discount surface, not just the checkout promo field." / "Do not report done before findings/coupon_referral_abuse_confirmed.md exists on disk." / "A discount that only shows in the UI is not a finding — verify the charged total."
- **Finished artifact definition:** `findings/coupon_referral_abuse_confirmed.md` with one section per abuse class, raw request/response pairs, before/after totals, the currency impact calculation, and a verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE) per class.

## Evidence standard
- Baseline: compare every hit against a known-dead coupon code — dead code must return an error/zero discount while the abused code returns a real discount on the charged total
- Reproduction: 2x independent reproduction required, with fresh carts/sessions each time
- Raw evidence: full request/response pairs saved, including the cart/order record showing the final charged total
- Verdicts: CONFIRMED (charged total reduced twice vs dead-code baseline, impact quantified) / INCONCLUSIVE (discount shows in UI but charged total unverifiable — needs a second model run or human) / NEGATIVE (server-side enforcement held — documented with the baseline pair so nobody re-tests it)

### Worked verdict example
- CONFIRMED: single-use coupon `SAVE20` applied to order 1 (charged $80) and again to order 2 (charged $80), twice each with fresh carts; dead code `ZZZ-DEAD` returned `{"error":"invalid_coupon"}` with $100 charged. Charged-total delta + clean baseline = CONFIRMED reuse.
- INCONCLUSIVE: discount appeared in cart UI but the payment intent still showed the full amount — charged total unverified; needs a human to complete a test payment.
- NEGATIVE: second apply returned `{"error":"coupon_already_used"}` and the charged total stayed $100 — server-side single-use enforced; pair saved.

## Handoffs
- `agent10_review` consumes `findings/coupon_referral_abuse_confirmed.md` and verifies every CONFIRMED verdict against the evidence standard before the report ships.
- `rate_limit_bypass` consumes the coupon-validation endpoint + code-structure analysis when codes look brute-forceable: it owns the guessing-rate math.
- `state_machine_audit` consumes coupon lifecycle findings: a coupon "used" state that can be re-applied is an illegal state transition — cross-reference.
- The final report writer needs: per-finding currency impact (single-transaction delta AND scaled loss), the exact reproduction commands, and whether exploitation needs one account or many.
- `state_machine_audit` cross-check: if a coupon's `used` state can be forced back to `active`, hand it to that skill — it is a state-transition bug wearing a promo mask.
