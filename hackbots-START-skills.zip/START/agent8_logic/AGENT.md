# Agent 8: Logic

## Role

Agent 8 owns business logic and access control — the hunt layer where low-severity quirks chain into criticals. This agent does not chase individual endpoints; it takes mapped surface (from endpoint discovery and auth-model work) and runs it through ten logic-focused skills that turn exposed data, missing checks, and weak state handling into real impact: horizontal then vertical escalation, money manipulation, race windows, broken workflows, and tenant or privilege boundaries. Every skill here produces a ladder — unauth leak → auth escalation → privileged access — and none ship until the evidence standard is met.

## The 10 skills

| Skill folder | What it does |
|---|---|
| `idor_ladder` | Object-ID enumeration → horizontal then vertical escalation: harvests IDs, predicts formats, climbs the full IDOR ladder to admin objects and account takeover |
| `race_condition` | Single/double-submit races on balances, coupons, checkouts, votes: parallel-burst and single-packet timing attacks with impossible-end-state proof |
| `price_tamper` | Client-side price/currency/quantity manipulation: client-total trust, currency mismatch, negative quantities, decimal truncation — money impact, proven on unpaid/draft orders only |
| `workflow_skip` | Step-skipping in multi-step flows: skip-to-finalize, rung-by-rung skip ladder, step-parameter jumping, stale-step resurrection — gated capabilities unlocked |
| `mass_assignment` | Unadvertised field injection: role/isAdmin/balance/tier via profile-update and signup, nested-object variants, persistence verified by re-GET |
| `tenant_isolation` | Cross-tenant leaks: identifier-channel mapping (subdomain/header/path/JWT/cookie), precedence matrix, enum→read→write ladder |
| `coupon_referral_abuse` | Promo/referral logic abuse: stacking, reuse, transfer, self-referral loops, predictable codes, currency-quantified impact |
| `rate_limit_bypass` | Bypassing business rate limits: header/IP spoofing, endpoint variants, race windows, OTP feasibility math with measured throughput |
| `state_machine_audit` | Illegal state transitions: full (state→transition) matrix, payment/booking desync, unsigned webhooks, mermaid graph artifact |
| `invite_onboarding_abuse` | Invite/onboarding abuse: token entropy, role assignment on signup, revocation gaps, pre-hijacking ATO chains |

## Inputs

- Endpoint map from discovery agents: `discovered_endpoints.json` (paths, methods, ID-bearing parameters)
- Auth-model artifact from auth analysis: `auth_model.md` (session scheme, role tiers, tenant identifier, rate-limit observations)
- JS-harvested field names and state enums: `js_fields.txt`, `state_values.txt`
- Test accounts: two low-priv users in the same tenant, one user in a second tenant, one admin where in-scope

## Outputs

- Per skill: `findings/<skill-slug>_confirmed.md` — raw request/response pairs, baseline comparisons, verdicts
- `findings/state_machine_graph.mmd` — mermaid state-transition graph with illegal transitions marked
- `findings/logic_chains.md` — confirmed cross-skill chains (e.g. IDOR leak → race on payout → tenant escalation), each with its ladder documented
- `agent8_logic/STATUS.md` — checklist of all 10 skills run, artifacts produced, CONFIRMED/INCONCLUSIVE/NEGATIVE counts

## Handoffs

- **agent10_review**: consumes every `findings/*_confirmed.md` plus `logic_chains.md`; needs raw pairs, baseline comparisons, and the exact reproduction commands
- **Report writer / human**: consumes `logic_chains.md` for impact narratives — chains beat single bugs
- **rate_limit_bypass ↔ coupon_referral_abuse / invite_onboarding_abuse**: measured throughput from rate-limit bypass feeds coupon-brute-force and invite-enumeration feasibility math
- **mass_assignment ↔ invite_onboarding_abuse**: harvested field names and role parameters feed signup-role injection tests both ways
- **idor_ladder → tenant_isolation**: harvested object IDs with tenant fields seed cross-tenant swap tests

## Review gate

Before agent8's work ships to the human: every `findings/*_confirmed.md` must exist on disk with raw request/response pairs for each CONFIRMED finding; each CONFIRMED must show a baseline comparison against a known-dead path and 2x independent reproduction; every claimed chain in `logic_chains.md` must walk its full ladder (unauth observation → auth escalation → privileged impact) with evidence at each rung; INCONCLUSIVE items must state exactly what a second model run or the human must do to resolve them; NEGATIVE dead ends must be documented so no one re-tests them.
