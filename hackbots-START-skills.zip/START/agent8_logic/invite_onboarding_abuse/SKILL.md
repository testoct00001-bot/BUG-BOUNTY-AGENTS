---
name: invite_onboarding_abuse
agent: agent8_logic
description: Abuse invite links, signup role assignment, and onboarding flows — predictable tokens, role escalation, and pre-hijacking to tenant takeover.
---

# Invite & Onboarding Abuse

## Purpose
Invites and signup are the front door of every multi-user app, and they fail at the hinges: invite tokens with 6 characters of entropy, "admin" invites anyone can mint, signup endpoints that accept a `role` parameter, and pre-hijacking flows that hand an attacker a victim's account. This skill audits every onboarding path for token weakness, role assignment, revocation gaps, and account-takeover chains. An invite that grants admin is not a misconfiguration — it is a tenant takeover primitive.

## Division of labor
- **Consumes:** endpoint lists covering invites, signup, SSO, and team management (`<host>_endpoints.txt` from `hidden_endpoint_discovery`); tenant-identifier notes and any tenant oracle from `tenant_isolation`; auth-model notes (session/token format) from `auth_model_analysis`
- **Produces:** the finished artifact — `findings/invite_onboarding_abuse_confirmed.md` containing raw request/response pairs, the takeover chains, and verdicts

## When to use / when NOT to use
- **Use when:** the target has invite links, team invites, signup with roles, SSO/JIT provisioning, "accept invite" flows, referral-style join links, or passwordless "magic link" onboarding
- **Skip when (time-pass filter):** signup is a single fixed-role form with no invites, no roles, and no SSO. Ask: does it leak access? An invite flow that only ever creates the lowest-privilege role with unguessable tokens and proper revocation is correctly built — verify the token entropy and move on. Never hijack real users' accounts; test pre-hijacking only between your own controlled accounts.

## Methodology
1. Map every onboarding path: self-signup, invite-accept (link with token), admin "add member", SSO login (SAML/OIDC), JIT provisioning, magic-link login, API-created users. Record the endpoint, parameters, and resulting role for each.
2. Measure invite-token entropy: generate 10–20 invites and analyze the tokens (length, charset, sequentiality, timestamp-embedding, UUIDv4 vs custom). Compute the keyspace. A 6-char alphanumeric token (36^6 ≈ 2.2B) with no rate limit is enumerable — hand the endpoint to `rate_limit_bypass` for the guessing math.
3. Test invite-token predictability directly: request invites in sequence and diff the tokens. Sequential or time-derived tokens mean you can compute other users' invites. Also test whether the token is derivable from public data (user ID, email hash, tenant slug).
4. Test what role an invite grants: create invites as each role you hold (member, admin, owner) and inspect what role the *accept* endpoint assigns. Then tamper: intercept the accept request and try `{"role":"admin"}`, `{"role":"owner"}` — mass-assignment on invite acceptance is a classic.
5. Test signup role mass-assignment: `POST /api/v1/signup` with added fields `role`, `is_admin`, `is_staff`, `permissions`, `tenant_role`. Try `"admin"`, `"owner"`, `true`, `1`, and array forms. Check the created user's actual role by reading it back — never trust the response echo alone.
6. Test expired/revoked invite reuse: accept an invite, then have the inviter revoke it (or let it expire), then accept *again* with the same token — and try registering a second account with it. Revocation must invalidate the token server-side, not just hide the UI button.
7. Test invite reuse across accounts: use one invite token to register two different accounts. Single-use tokens must be consumed atomically on first accept.
8. Test invite enumeration: submit the invite-accept or invite-check endpoint with attacker emails and random tokens. Does the response distinguish "valid token, wrong email" from "invalid token" from "email already a user"? Each distinction is an oracle — valid-token oracle enables targeted phishing; email-exists oracle enables user enumeration.
9: Test the pre-hijacking chain: (a) attacker invites victim-email (an address you control, e.g. `victim+test@` you own) to the attacker's tenant; (b) before "acceptance", register that email via self-signup; (c) accept the invite. Who owns the resulting account — the attacker who invited, or the registrant? If the invite binds the email to the attacker's tenant with attacker-chosen attributes, that is pre-hijacking. Then test the reverse: invite a not-yet-registered email, change the invited email before acceptance if the UI/API allows it.
10. Test email-change-before-acceptance: where the invite-accept flow lets you set or change the email, invite `a@x`, accept as `b@y`. If the account is created under the attacker's control with the victim's intended identity, flag it.
11. Test SSO JIT provisioning with attacker-controlled attributes: if the target supports "login with SSO" against an IdP you control (or a test IdP), assert admin group membership / role attributes in the SAML/OIDC response and see what role the JIT-provisioned account gets. Attacker-controlled `groups`, `role`, or `is_admin` claims honored blindly = privilege escalation.
12. Test invite-link role confusion: an invite issued for role=member — replay the accept with the *link* but modify any role parameter in the URL (`?role=admin`, `?plan=enterprise`). Links sometimes carry signed *and* unsigned parameters side by side.
13. Test tenant-scoping of invites: accept an invite for tenant A while authenticated (or while holding a session) in tenant B. Does the new membership land in the right tenant? Cross-tenant invite acceptance ties directly to `tenant_isolation`.
14. Test invite-quota and invite-spam abuse: is there a limit on invites sent? Unbounded invites from a low-priv account enable spam/phishing from the target's domain — note it as a (lower-severity) abuse primitive, and check whether invited emails leak the inviter's tenant name (information disclosure aiding targeted attacks).
15. Chain the full account-takeover: weak/predictable invite token → accept as admin (role tampering) → inside the victim tenant → invite-revoke the real admin / change tenant settings / exfiltrate data. Document each link with its raw pair. The chain is the finding — a single weak link with no chain is still worth reporting, but the chain sets severity.
16. Re-verify every positive twice with fresh invites, fresh tokens, and fresh test accounts — invite state is sticky, and a "finding" that was actually leftover state from your first accept is a false positive.

### Decision branches — what the response tells you to do next
- **Token under 8 chars or visibly sequential:** compute the keyspace immediately and hand the validation endpoint to `rate_limit_bypass`. Short tokens + weak limits = enumerable invites.
- **Role tampering accepted on invite-accept:** read the role back from `/me` before celebrating. If the server really granted admin, chain into the tenant: list members, revoke the real admin, exfiltrate — the chain sets severity.
- **Revoked/expired token still accepted:** test double-accept race next — revocation that isn't atomic usually isn't revocation at all.
- **Oracle distinguishes token-validity × email-existence:** build the full matrix. A valid-token oracle enables targeted phishing; an email-exists oracle is user enumeration — document both, chain the token oracle into role tampering.
- **Pre-hijack binds the email to the attacker's tenant:** you have the account-takeover chain. Verify the victim (your controlled address) cannot recover the account without the attacker — that is what makes it takeover, not just confusion.
- **SSO JIT honors attacker role claims:** this is unauthenticated-equivalent privilege escalation wherever SSO is enabled. Document the exact claim (`groups`, `role`, `is_admin`) the backend trusted.
- **Invite acceptance lands in the wrong tenant:** cross-tenant invite confusion — hand it to `tenant_isolation` with the raw pairs; the combined finding is tenant takeover.

## Exact commands
Baseline — invite-token structure sampling (generate several, compare):
```bash
for i in 1 2 3; do
  curl -s -X POST 'https://<HOST>/api/v1/invites' \
    -H "Authorization: Bearer <TOKEN_ADMIN>" -H 'Content-Type: application/json' \
    --data '{"email":"invite-test'$i'@example.com","role":"member"}' | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('token') or d.get('invite_link'))"
done
```
Token entropy analysis:
```bash
python3 - <<'EOF'
import math
tokens = ["<T1>","<T2>","<T3>"]  # paste sampled tokens
for t in tokens: print(len(t), t)
charset = 62  # adjust: 62 alnum, 36 lower-alnum, 16 hex
print("keyspace 2^%.1f" % (len(tokens[0]) * math.log2(charset)))
EOF
```
Signup role mass-assignment test:
```bash
curl -s -i -X POST 'https://<HOST>/api/v1/signup' -H 'Content-Type: application/json' \
  --data '{"email":"massassign+<rand>@example.com","password":"Test123!","role":"admin","is_admin":true}' | head -30
# read back the ACTUAL role, never trust the echo:
curl -s 'https://<HOST>/api/v1/me' -H "Authorization: Bearer <NEW_USER_TOKEN>" | python3 -m json.tool | grep -i -E 'role|admin|permissions'
```
Invite-accept role tampering:
```bash
curl -s -i -X POST 'https://<HOST>/api/v1/invites/accept' -H 'Content-Type: application/json' \
  --data '{"token":"<MEMBER_INVITE_TOKEN>","email":"escalate+<rand>@example.com","password":"Test123!","role":"admin"}' | head -30
```
Revoked-invite reuse test:
```bash
# 1. inviter revokes the token (or let it expire), then:
curl -s -i -X POST 'https://<HOST>/api/v1/invites/accept' -H 'Content-Type: application/json' \
  --data '{"token":"<REVOKED_TOKEN>","email":"reuse+<rand>@example.com","password":"Test123!"}' | head -20
# CONFIRMED if a second account is created from a revoked/expired/consumed token
```
Invite oracle enumeration test:
```bash
for t in "<VALID_TOKEN>" "ZZZ-INVALID-000"; do
  for e in "exists+<rand>@example.com" "nouser+<rand>@example.com"; do
    code=$(curl -s -o /dev/null -w "%{http_code}" -X POST 'https://<HOST>/api/v1/invites/check' \
      -H 'Content-Type: application/json' --data "{\"token\":\"$t\",\"email\":\"$e\"}")
    body=$(curl -s -X POST 'https://<HOST>/api/v1/invites/check' \
      -H 'Content-Type: application/json' --data "{\"token\":\"$t\",\"email\":\"$e\"}" | head -c 200)
    echo "token=$t email=$e -> $code :: $body"
  done
done
# distinct responses per (token-validity × email-existence) = oracle; document the matrix
```
Pre-hijacking test (all addresses you control):
```bash
# 1. attacker invites victim-test@example.com to attacker's tenant, gets token T
# 2. victim-test@example.com self-registers via /signup BEFORE accepting
curl -s -X POST 'https://<HOST>/api/v1/signup' -H 'Content-Type: application/json' \
  --data '{"email":"victim-test@example.com","password":"Test123!"}'
# 3. now accept invite T as victim-test@example.com — whose tenant/role wins?
curl -s -X POST 'https://<HOST>/api/v1/invites/accept' -H 'Content-Type: application/json' \
  --data '{"token":"<T>","email":"victim-test@example.com","password":"Test123!"}' | python3 -m json.tool | grep -i -E 'tenant|role|org'
```

# Sequential-token diff: request invites back-to-back, diff the tokens
for i in 1 2 3 4 5; do
  curl -s -X POST 'https://<HOST>/api/v1/invites' \
    -H "Authorization: Bearer <TOKEN_ADMIN>" -H 'Content-Type: application/json' \
    --data '{"email":"seq'$i'@example.com","role":"member"}' | python3 -c "import json,sys; print(json.load(sys.stdin).get('token'))"
done
# Double-accept race: same fresh token consumed twice in parallel
T="<FRESH_TOKEN>"
curl -s -X POST 'https://<HOST>/api/v1/invites/accept' -H 'Content-Type: application/json' \
  --data '{"token":"'"$T"'","email":"race1@example.com","password":"Test123!"}' &
curl -s -X POST 'https://<HOST>/api/v1/invites/accept' -H 'Content-Type: application/json' \
  --data '{"token":"'"$T"'","email":"race2@example.com","password":"Test123!"}' &
wait

## Completion-bias defenses
- [ ] Every onboarding path mapped (signup, invite-accept, add-member, SSO/JIT, magic link) with resulting role recorded
- [ ] Invite-token entropy measured from 10–20 samples, keyspace computed
- [ ] Token predictability tested (sequentiality, time-derivation, public-data derivation)
- [ ] Invite-granted role inspected per inviter role; accept-request role tampering tested
- [ ] Signup role mass-assignment tested (`role`, `is_admin`, `is_staff`, `permissions`) with role read back
- [ ] Expired/revoked invite reuse tested
- [ ] Single invite token used for two accounts (consumption atomicity)
- [ ] Invite oracle matrix built (token-validity × email-existence response differences)
- [ ] Pre-hijacking chain tested between controlled accounts (both directions)
- [ ] Email-change-before-acceptance tested
- [ ] SSO JIT with attacker-controlled role/group attributes tested (where a test IdP is possible)
- [ ] Invite-link URL role parameters tampered
- [ ] Cross-tenant invite acceptance tested
- [ ] Full takeover chain documented link by link with raw pairs
- [ ] Every positive reproduced 2x with fresh invites/tokens/accounts
- [ ] `findings/invite_onboarding_abuse_confirmed.md` exists on disk with pairs and verdicts
- [ ] Decision branches followed — pivoted on what the responses actually showed, not the original plan
- [ ] No escalation claimed from a response echo; every role read back from the server
- **Review step:** agent10_review must verify: (a) the finished artifact exists with raw pairs; (b) every role-escalation verdict shows the role *read back* from the server (`/me` or equivalent), not just the response echo; (c) pre-hijacking tests used only attacker-controlled addresses — no real user was targeted; (d) token-entropy claims show the sampled tokens and the keyspace math.
- **Nudge prompts:** "Keep going until you have tested every onboarding path, not just self-signup." / "Do not report done before findings/invite_onboarding_abuse_confirmed.md exists on disk." / "A role in a response echo is not proof — read the role back from the server before claiming escalation."
- **Finished artifact definition:** `findings/invite_onboarding_abuse_confirmed.md` with one section per onboarding path, the token-entropy analysis, the oracle matrix, raw request/response pairs, the takeover chain written link-by-link, and a verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE) per surface.

## Evidence standard
- Baseline: a correctly-behaving invite (unpredictable token, correct lowest-privilege role, revoked token rejected) captured on the same host — every abuse is compared against this pair
- Reproduction: 2x independent reproduction required, with fresh invites, fresh tokens, and fresh accounts each time (invite state is sticky — stale state is the #1 false-positive source here)
- Raw evidence: full request/response pairs saved, plus the server-read-back role (`/me`) for every escalation claim
- Verdicts: CONFIRMED (abuse reproduced twice vs clean baseline, role read back from server) / INCONCLUSIVE (ambiguous role/tenant outcome or untestable SSO path — needs a second model run or human) / NEGATIVE (onboarding enforced correctly — documented with the baseline pair so nobody re-tests it)

### Worked verdict example
- CONFIRMED: invite-accept with `{"role":"admin"}` returned 200 twice with fresh tokens, and `GET /api/v1/me` showed `"role":"admin"` — role read back from server, not the echo. Dead baseline: untampered accept granted `"role":"member"`. Escalation CONFIRMED.
- INCONCLUSIVE: tampered role echoed `"role":"admin"` in the accept response but `/me` still showed `member` — echo lied; server-side read-back is the only truth.
- NEGATIVE: tampered roles rejected with `{"error":"invalid_role"}`, revoked tokens rejected with `{"error":"token_revoked"}` — onboarding enforced; pairs saved.

## Handoffs
- `agent10_review` consumes `findings/invite_onboarding_abuse_confirmed.md` and verifies every CONFIRMED verdict against the evidence standard before the report ships.
- `tenant_isolation` consumes cross-tenant invite-acceptance results and any tenant oracle: invite + tenant confusion = tenant takeover.
- `rate_limit_bypass` consumes the invite-token endpoint when tokens look enumerable: it owns the guessing-rate math.
- The final report writer needs: the takeover chain written as numbered links (each with its raw pair), the maximum role/tenant reachable, and whether the attack needs an insider inviter or works fully unauthenticated.
- `tenant_isolation` consumes cross-tenant invite-acceptance results: invite confusion that lands in another tenant is a tenant-takeover finding, not just an onboarding bug.
