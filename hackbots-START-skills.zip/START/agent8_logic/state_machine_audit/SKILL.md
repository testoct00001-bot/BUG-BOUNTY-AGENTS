---
name: state_machine_audit
agent: agent8_logic
description: Map order, booking, and invite state graphs and force illegal transitions — refunds on unpaid orders, shipping cancelled ones.
---

# State Machine Audit

## Purpose
Every order, booking, payment, subscription, and invite is a state machine, and backends routinely trust the client about which transitions are legal. This skill enumerates the real states from API responses and JS, maps the allowed transitions by probing, then forces the illegal ones: refund a pending order, ship a cancelled order, cancel after delivery, re-activate an expired subscription. Illegal transitions move money and goods — they are business-logic criticals that no scanner finds.

## Division of labor
- **Consumes:** endpoint lists covering orders/bookings/payments/subscriptions/invites (`<host>_endpoints.txt` from `hidden_endpoint_discovery`); JS bundles showing status enums and transition calls (`sdk_source_mining`); order/booking IDs creatable under test accounts
- **Produces:** the finished artifact — `findings/state_machine_audit_confirmed.md` containing the mermaid state graph, raw request/response pairs, the proven illegal-transition list, and verdicts

## When to use / when NOT to use
- **Use when:** the target has orders, bookings, payments, subscriptions, shipments, refunds, cancellations, invites, or any multi-step workflow with a visible status field
- **Skip when (time-pass filter):** the workflow is a single atomic action with no persisted state (a contact form, a one-shot API call). Ask: does an illegal transition move money, goods, or access? Forcing a cosmetic status label with no downstream effect is time-pass — trace what the state *drives* (payment capture, fulfillment, access grant) before investing. Never trigger real fulfillment, real refunds, or real shipments.

## Methodology
1. Enumerate the states: grep JS bundles and API responses for status enums (`pending`, `paid`, `shipped`, `delivered`, `cancelled`, `refunded`, `failed`, `expired`...). Create test orders/bookings and capture the exact `status` field values the API returns at each step.
2. Map the *claimed* allowed transitions: read the UI/JS for which actions appear in which state (cancel button only when pending, refund button only when paid). This is the developer's intended graph — draw it first.
3. Identify the transition endpoints and their shape: `POST /api/v1/orders/<id>/cancel`, `PUT /api/v1/orders/<id> {"status":"refunded"}`, `POST /api/v1/orders/<id>/transition {"to":"shipped"}`. Note which take an explicit target state parameter — those are the direct-forcing surface.
4. Probe the full transition matrix: for every state S your test objects can reach, attempt a transition to every other state T, including backwards and skipped ones. Record the response for each (S → T) pair: success, error message, or silent no-op. The error messages often leak the *real* allowed set ("cannot refund unpaid order" tells you the check exists — and where it doesn't fire).
5. Force the money transitions first: refund a `pending`/`unpaid` order; cancel an order *after* delivery/fulfillment; mark a `failed` payment as `paid`; re-capture an already-captured payment. Verify against the order record and balance — not the UI toast.
6. Force the goods transitions: ship a `cancelled` order; mark `delivered` on an order never shipped; re-activate a `cancelled` subscription to regain access without paying.
7. Test direct state parameters: where the endpoint accepts `{"status": "..."}`, try every enumerated value plus invented ones (`"refunded"`, `"admin"`, `"true"`). Some backends write the field with no allowlist.
8. Test state confusion between parallel workflows: the booking has a state and the *payment* has a state — desync them. Pay for booking A, then apply the payment confirmation to booking B (`payment_id` from A on B's confirm call). Cancel the booking but not the payment, then re-book — does the orphaned payment get honored twice?
9. Test time-based transitions: expiry (`pending` → `expired` after N minutes), trial → paid, hold → release. Can you act in the expired state (pay for an expired booking and get it honored)? Can you extend a hold indefinitely by re-requesting?
10. Test idempotency and double-transition: fire the same legal transition twice in parallel (cancel × 2, refund × 2). If the guard isn't atomic, the second one may double-apply — capture the balance/order record before and after.
11. Test role-gated transitions as a low-priv user: transitions the UI hides from you (refund, ship, approve) called directly with your token. Hidden ≠ enforced.
12. Test cross-object transitions: transition endpoint takes an object ID — swap in another user's object ID (ties to `tenant_isolation` / IDOR). A cancel that works on someone else's order is both a state bug and an access bug.
13. Test webhook/callback-driven transitions: payment gateways call back with `status=paid` — replay, forge, or reorder the callback. A callback that the backend trusts without signature verification lets you mark anything paid.
14. Draw the final state graph as mermaid: nodes = confirmed states, solid edges = allowed transitions (probed), red dashed edges = illegal transitions you *proved*. Every red edge must cite its raw pair.
15. Re-verify each illegal transition twice: fresh objects, fresh sessions, and confirm the downstream effect (balance changed, access granted, fulfillment triggered) — a 200 with no effect is not a finding.

### Decision branches — what the response tells you to do next
- **Refund on pending/unpaid succeeds:** immediately test double-refund race and refund-then-cancel combos. A refund that moves money without a payment is the highest-impact transition — quantify the balance delta.
- **`{"status":"..."}` is written without an allowlist:** fuzz every enumerated state plus invented values (`"admin"`, `"true"`, `""`). A free-write status field usually hides more than one illegal transition.
- **Payment/booking desync works:** test orphaned-payment reuse — pay once, confirm twice on different bookings. Desync bugs compound: each reuse doubles the impact.
- **Webhook/callback unsigned:** forge and replay callbacks with reordered statuses (`paid` → `refunded` → `paid`). An unsigned callback is remote state control — treat it as critical.
- **200 returned but order record unchanged:** the transition was accepted and ignored, or queued. Poll the order for 60s; if still unchanged, mark INCONCLUSIVE — a 200 with no effect is not a finding.
- **Transition blocked for you but UI shows it for admins:** call it directly with your low-priv token (step 11). Hidden in UI ≠ enforced in API — the direct call is the real test.
- **One object's transition affects another object:** you have cross-object state confusion — hand the primitive to `tenant_isolation` to check whether it crosses tenant boundaries too.

## Exact commands
Baseline — capture the status field of a test order:
```bash
curl -s 'https://<HOST>/api/v1/orders/<ORDER_ID>' \
  -H "Authorization: Bearer <TOKEN>" | python3 -m json.tool | grep -i -E 'status|state'
```
Enumerate status enums from JS:
```bash
grep -rhoE '"status":"[a-z_]+"' /tmp/js/ 2>/dev/null | sort | uniq -c | sort -rn | head -30
grep -rhoE "status:\s*'[^']+'" /tmp/js/ 2>/dev/null | sort | uniq -c | sort -rn | head -30
```
Illegal transition: refund a pending (unpaid) order:
```bash
curl -s -i -X POST "https://<HOST>/api/v1/orders/<PENDING_ORDER_ID>/refund" \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"amount": <ORDER_TOTAL>, "reason":"test"}' | head -30
# then verify the money moved:
curl -s 'https://<HOST>/api/v1/account/balance' -H "Authorization: Bearer <TOKEN>"
```
Direct state-parameter forcing:
```bash
for s in refunded shipped delivered paid cancelled approved; do
  code=$(curl -s -o /dev/null -w "%{http_code}" -X PUT "https://<HOST>/api/v1/orders/<ORDER_ID>" \
    -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
    --data "{\"status\":\"$s\"}")
  echo "status=$s -> $code"
done
curl -s "https://<HOST>/api/v1/orders/<ORDER_ID>" -H "Authorization: Bearer <TOKEN>" | python3 -c "import json,sys; print(json.load(sys.stdin).get('status'))"
```
Double-transition race (refund × 2 in parallel):
```bash
curl -s -X POST "https://<HOST>/api/v1/orders/<PAID_ORDER_ID>/refund" \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' --data '{}' &
curl -s -X POST "https://<HOST>/api/v1/orders/<PAID_ORDER_ID>/refund" \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' --data '{}' &
wait
curl -s 'https://<HOST>/api/v1/account/balance' -H "Authorization: Bearer <TOKEN>"
```
Payment/booking desync test:
```bash
curl -s -X POST "https://<HOST>/api/v1/bookings/<BOOKING_B>/confirm-payment" \
  -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
  --data '{"payment_id":"<PAYMENT_ID_FROM_BOOKING_A>"}' | head -20
```
Mermaid graph template (paste confirmed states/edges into the artifact):
```mermaid
stateDiagram-v2
    [*] --> pending
    pending --> paid : pay
    pending --> cancelled : cancel
    paid --> refunded : refund
    paid --> shipped : ship
    shipped --> delivered : deliver
    pending --> refunded : ILLEGAL (proven)
    cancelled --> shipped : ILLEGAL (proven)
```

# Full transition-matrix sweep: every reachable state -> every target state
for target in pending paid shipped delivered cancelled refunded expired; do
  code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://<HOST>/api/v1/orders/<ORDER_ID>/transition" \
    -H "Authorization: Bearer <TOKEN>" -H 'Content-Type: application/json' \
    --data "{\"to\":\"$target\"}")
  echo "-> $target : $code"
done
# Webhook/callback replay: resend a captured gateway callback verbatim, then reordered
curl -s -X POST 'https://<HOST>/api/v1/payments/callback' \
  -H 'Content-Type: application/json' --data @/tmp/callback_paid.json -o /dev/null -w "replay paid -> %{http_code}\n"

## Completion-bias defenses
- [ ] States enumerated from both JS bundles and live API responses
- [ ] Intended transition graph drawn from UI/JS before probing
- [ ] Transition endpoints identified with their exact parameter shapes
- [ ] Full (S → T) transition matrix probed, every pair recorded
- [ ] Money transitions forced: refund-unpaid, cancel-after-delivery, failed→paid
- [ ] Goods transitions forced: ship-cancelled, deliver-unshipped, reactivate-cancelled
- [ ] Direct `{"status": ...}` parameters fuzzed with all enumerated + invented values
- [ ] Parallel-workflow desync tested (booking state vs payment state)
- [ ] Time-based transitions tested (expiry, trial, hold extension)
- [ ] Double-transition raced for atomicity
- [ ] Role-gated transitions called directly as low-priv user
- [ ] Cross-object transition (another user's object ID) tested
- [ ] Webhook/callback-driven transitions tested for signature verification
- [ ] Mermaid graph drawn with proven illegal edges in red, each citing its raw pair
- [ ] Every illegal transition reproduced 2x with downstream effect verified (balance/access/fulfillment)
- [ ] `findings/state_machine_audit_confirmed.md` exists on disk with graph, pairs, verdicts
- [ ] Decision branches followed — pivoted on what the responses actually showed, not the original plan
- [ ] No CONFIRMED illegal transition rests on a 200 alone; every red edge has downstream-effect evidence
- [ ] Full (S → T) matrix probed — did not stop at the transitions the UI offers
- **Review step:** agent10_review must verify: (a) the finished artifact exists with the mermaid graph and raw pairs; (b) every red (illegal) edge cites a raw pair AND a downstream-effect check (balance delta, access granted) — a 200 alone is not proof; (c) the full matrix was probed, not just the obvious transitions; (d) no real fulfillment, shipment, or refund was triggered against real goods/money.
- **Nudge prompts:** "Keep going until you have probed every (S → T) pair in the matrix, not just the transitions the UI offers." / "Do not report done before findings/state_machine_audit_confirmed.md exists on disk with the mermaid graph." / "A 200 response with no downstream effect is not an illegal transition — verify the money, the goods, or the access."
- **Finished artifact definition:** `findings/state_machine_audit_confirmed.md` with the mermaid state graph (solid = allowed, red dashed = proven illegal), the full probed transition matrix table, raw request/response pairs plus downstream-effect evidence per illegal transition, and a verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE) per transition.

## Evidence standard
- Baseline: the intended graph (from UI/JS) and the error messages for *rejected* transitions — every illegal success is compared against a sibling transition the backend correctly rejects
- Reproduction: 2x independent reproduction required, with fresh objects and sessions each time, and the downstream effect (balance, access, fulfillment record) confirmed both times
- Raw evidence: full request/response pairs saved, plus the before/after order record or balance proving the effect
- Verdicts: CONFIRMED (illegal transition succeeded twice with verified downstream effect) / INCONCLUSIVE (200 returned but effect unverifiable, or behavior inconsistent — needs a second model run or human) / NEGATIVE (transition correctly rejected — documented with the rejecting pair so nobody re-tests it)

### Worked verdict example
- CONFIRMED: `POST /orders/<PENDING_ID>/refund` returned 200 twice with fresh orders, and `/account/balance` increased by the order total each time — money moved without payment. Dead baseline: refunding a *delivered* order correctly returned `{"error":"already_fulfilled"}`. Effect verified = CONFIRMED.
- INCONCLUSIVE: transition returned 200 but the order record still showed `pending` after 60s of polling — accepted-and-ignored or async; needs a second run with longer polling.
- NEGATIVE: every illegal (S → T) pair returned `{"error":"illegal_transition"}` while legal ones succeeded — matrix enforced; pairs saved.

## Handoffs
- `agent10_review` consumes `findings/state_machine_audit_confirmed.md` and verifies every CONFIRMED illegal transition against the evidence standard before the report ships.
- `coupon_referral_abuse` consumes coupon-state findings: a coupon whose "used" state can be forced back to "active" is this skill's transition bug wearing a promo mask.
- `tenant_isolation` consumes cross-object transition results: a transition that works on another tenant's object escalates the finding.
- The final report writer needs: the mermaid graph, the illegal-transition list with per-transition money/goods/access impact, and the exact reproduction commands.
- `finding_validator` consumes the downstream-effect evidence (balance deltas, order records) to independently verify each illegal transition before it ships.
