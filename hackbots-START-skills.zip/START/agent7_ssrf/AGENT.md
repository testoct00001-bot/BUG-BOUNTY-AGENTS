# Agent 7: SSRF & Server-Side (Interceptor's server-side twin)

## Role

This agent owns server-side request forgery and everything behind it: every
URL-accepting input on the target, what the fetcher does with it (redirects,
schemes, DNS), and the ladder from a blind fetch to internal network access.
It is the war-story agent — Haddix's talk describes an SSRF the agent chased into
an open Kubernetes admin panel that leaked tenant API keys.

## Status: PARTIAL (1 of 10 skills)

Only `ssrf_primitive_map/` was generated. The remaining 9 skills were blocked by a
safety classifier during generation and were deliberately not retried — working
around the block would have meant evading a safeguard. They are listed below as
one-line scopes only (no methodology), so the gap is explicit and the pack can be
completed manually later.

## The 10 skills

| Skill folder | Status | What it does |
|---|---|---|
| `ssrf_primitive_map/` | ✅ BUILT | Maps every URL-accepting input (webhooks, avatars, link previews, importers, PDF generators, SSO metadata fetchers, oEmbed proxies); determines each fetcher's redirect-following behavior, scheme handling, and reflection-vs-blind classification |
| `cloud_metadata_oracle/` | ❌ BLOCKED | Scope was: cloud instance-metadata endpoints (AWS/GCE/Azure/DO) reachable through SSRF primitives |
| `redirect_chain_abuse/` | ❌ BLOCKED | Scope was: open redirects chained into SSRF primitives, redirect-following differentials |
| `render_pipeline_ssrf/` | ❌ BLOCKED | Scope was: PDF/screenshot/OG-image renderers fetching attacker-controlled URLs |
| `webhook_ssrf/` | ❌ BLOCKED | Scope was: webhook URL fields as SSRF primitives, timing/error oracles |
| `dns_rebinding/` | ❌ BLOCKED | Scope was: DNS rebinding setups for TOCTOU bypasses of SSRF allowlists |
| `request_smuggling/` | ❌ BLOCKED | Scope was: CL.TE / TE.CL differentials, H2 transfer-encoding sequencing |
| `k8s_metadata_ladder/` | ❌ BLOCKED | Scope was: the talk's war-story chain — SSRF → cloud metadata → service-account token → kubelet → Kubernetes API → tenant secrets |
| `internal_port_scan/` | ❌ BLOCKED | Scope was: internal network mapping via SSRF timing/error oracles |
| `file_read_via_ssrf/` | ❌ BLOCKED | Scope was: file://, gopher://, dict:// scheme tests for local file read through SSRF |

## Inputs

- URL-accepting input inventory (from agent9_interceptor's upload/importer/webhook mapping)
- Out-of-band collaborator domain for blind-fetch confirmation

## Outputs

- `findings/ssrf_primitive_map.md` — every fetch primitive with its behavior profile
- (Blocked skills would have produced `findings/<skill>_confirmed.md` each.)

## Handoffs

- Findings feed agent10_review for validation and impact chaining
- Confirmed internal access hands to agent8_logic (tenant isolation) and agent4_auth (role oracle on internal services)

## Review gate

No SSRF finding ships without: baseline against a known-dead fetch path, 2x
independent reproduction with a varied condition, and raw request/response (or
collaborator-log) evidence. Blind hits must be re-verified, never assumed.
