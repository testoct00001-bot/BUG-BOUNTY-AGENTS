# START — Hackbot Skill System

**Enter here.** This folder is a complete AI bug-bounty "hackbot" skill system built from
Jason Haddix's DEF CON 34 talk **"Hackbots"** (Bug Bounty Village masterclass, 27 Sept 2026).

Core thesis of the talk: fully autonomous hackbots are not here yet — but a well-designed
**agent harness with a human in the loop** finds bugs entire teams of hackers would miss.
One 6-hour run against a live program returned **4 confirmed criticals and 17 confirmed highs**.

## The 10 agents (division of labor)

| # | Folder | Agent | Owns |
|---|--------|-------|------|
| 1 | `agent1_recon/` | Recon & Mapping | Subdomains, DNS, TLS, ports, JS harvest, stack fingerprint, CT monitoring, buckets, GitHub OSINT, wordlists |
| 2 | `agent2_js/` | JS Analyzer | Haddix's flagship "js analyze": sourcemaps, bundles, endpoint/secret mining, API-client reverse, route audits |
| 3 | `agent3_endpoints/` | Hidden Endpoint Discovery | Deep-dig fuzz loop, verb matrix, header tricks, path confusion, param mining, docs, backups, old API versions, GraphQL |
| 4 | `agent4_auth/` | Auth & Session | Auth-model mapping, tokens, MFA, reset poisoning, OAuth, JWT edge cases, SSO leaks, role oracles, rate limits |
| 5 | `agent5_injection/` | Injection | SQLi, NoSQLi, CMDi, SSTI, LDAP/XPath, XXE, CSV, header injection, GraphQL injection, deserialization |
| 6 | `agent6_xss/` | XSS Hunter | Context mapping, filter analysis, DOM sinks, stored chains, CSP bypass, mXSS, postMessage, uploads, blind XSS |
| 7 | `agent7_ssrf/` | SSRF & Server-Side | ⚠️ PARTIAL — see "Known gap" below |
| 8 | `agent8_logic/` | Business Logic | IDOR ladder, races, price tamper, workflow skip, mass assignment, tenant isolation, state machines |
| 9 | `agent9_interceptor/` | Interceptor (browser agent) | Haddix's browser-driving demo: SPA crawl, flow replay, DOM/storage/WS/SW audits, upload pipeline |
| 10 | `agent10_review/` | Review & Verification | The completion-bias killer: checklist audits, finding validation, impact chains, evidence packs, reports, debrief |

Each agent folder contains 10 skill folders (each with a `SKILL.md`) + one `AGENT.md`
describing the agent's role, inputs/outputs, handoffs, and review gate.

**91 skills total** (agent7 is partial — see below).

## How every skill is built (the Haddix doctrine)

Every `SKILL.md` follows `SKILL_TEMPLATE.md` and bakes in the talk's ideas:

1. **Division of labor** — each skill declares what it *consumes* and the exact
   *finished artifact* it must produce. Done = the artifact exists on disk.
2. **Completion-bias defenses** — markdown checklists the agent must tick fully,
   a review step, nudge prompts ("keep going until…", "do not stop before…"),
   and an explicit finished-artifact definition.
3. **Full commands, never tool names** — copy-paste `curl`/`python3` with
   `<TARGET>` placeholders, including baseline commands and 2x-repro commands.
4. **No-false-positive bar** — baseline vs a known-dead path, 2x independent
   reproduction, raw request/response evidence. Verdicts: CONFIRMED / INCONCLUSIVE / NEGATIVE.
5. **Time-pass filter** — each skill says when NOT to run: hunt what leaks, is
   sensitive, and is reachable unauthenticated.
6. **Human in the loop** — every skill's review step points at `agent10_review`.
   Nothing ships without passing the gate.

## How to run a hunt (harness loop)

```
1. SCOPE  → agent10_review/scope_boundary_check   (allowlist manifest first)
2. MAP    → agent1_recon/*                        (subdomains → stack → JS harvest → wordlists)
3. MINE   → agent2_js/*  +  agent3_endpoints/*    (parallel: JS secrets/endpoints + hidden fuzz)
4. ATTACK → agent4_auth/*, agent5_injection/*, agent6_xss/*,
            agent8_logic/*, agent9_interceptor/*  (pick by surface; run multiple models, multiple times)
5. REVIEW → agent10_review/*                      (checklist audit → validate → chain → package → report)
6. LEARN  → agent10_review/hunt_debrief           (pattern library update for the next hunt)
```

Rules from the talk: run **multiple models, multiple times** on the same target;
retune on every new model; keep output folders with full paths; when an agent says
"done" after 3 steps of 20, the checklist + review skill drags it back to finish.

## Known gap — agent7_ssrf

`agent7_ssrf/` contains only `ssrf_primitive_map/SKILL.md` (1 of 10 skills) and its
`AGENT.md`. The remaining 9 skills (cloud metadata oracle, redirect chains, render
pipelines, webhooks, DNS rebinding, request smuggling, the K8s metadata ladder,
internal port scan, file-read via SSRF) were **blocked by a safety classifier**
during generation and were deliberately **not** retried — working around the block
would have meant evading a safeguard. The war-story chain from the talk
(SSRF → open Kubernetes admin panel → tenant API keys) is described at a high level
in `agent7_ssrf/AGENT.md` only. Fill these in manually if you need them.

## Files

- `START.md` — this file (start here)
- `BUILD_BRIEF.md` — the build instructions every skill was generated from
- `SKILL_TEMPLATE.md` — the template every `SKILL.md` follows
- `agent1_recon/` … `agent10_review/` — the 10 agents
