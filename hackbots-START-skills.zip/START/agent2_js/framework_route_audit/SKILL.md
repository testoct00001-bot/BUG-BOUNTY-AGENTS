---
name: framework_route_audit
agent: agent2_js
description: Audit Next.js/Remix/Nuxt route manifests, data routes, and RSC payloads for hidden routes.
---

# Framework Route Audit

## Purpose

Modern frameworks ship route manifests to the client: Next.js `_buildManifest.js` / `_ssgManifest.js`, `/_next/data/<buildId>/<route>.json` data routes, React Server Component flight payloads, Remix `.data` single-fetch routes, Nuxt `_payload.json`. These manifests list EVERY route — including admin, internal, and draft routes the navigation never links. Frameworks also have known route-confusion primitives (Next.js middleware bypasses, RSC parameter injection, Remix `.data` spoofing). This skill extracts the full route table and audits each route for access control.

## Division of labor

- **Consumes:** framework detection from bundle_splitting (`js/chunks/bundler.txt`); build ID from HTML (`<script src="/_next/static/<BUILDID>/_buildManifest.js">`).
- **Produces:** `findings/framework_route_audit_confirmed.md` — full route table with per-route access verdicts; plus `js/routes/route_table.json`.

## When to use / when NOT to use

- **Use when:** `_next/static`, `__remix`, `_nuxt`, or `__NUXT__` markers found in HTML/bundles; `/_next/data/` or `.data` requests observed.
- **Skip when (time-pass filter):** plain SPA with hash routing and no framework markers (nothing to audit — route table doesn't exist client-side).

## Methodology

1. Detect framework + version: Next.js (`/_next/static/<buildId>/`), Remix (`__remixManifest`), Nuxt (`/_nuxt/` + `__NUXT__`), SvelteKit (`/_app/immutable`). Version from bundle comments or `next/dist` paths. Record in `js/routes/framework.txt`.
2. Fetch manifests:
   - Next.js: `/_next/static/<BUILDID>/_buildManifest.js` (page → chunks), `/_next/static/<BUILDID>/_ssgManifest.js` (SSG pages), `/_next/static/<BUILDID>/_middlewareManifest.js` (if exposed — middleware matcher gold).
   - Remix: the `__remixManifest` JSON in HTML or `/build/manifest-<hash>.js` — lists every route module + `hasLoader`/`hasAction` flags.
   - Nuxt: `/_nuxt/builds/meta/<buildId>.json` or `_payload.json` files.
3. Parse into `js/routes/route_table.json`: every route path, its chunk files, and flags (SSG/SSR, hasLoader/hasAction, middleware-protected?).
4. Flag routes by name: `/admin`, `/internal`, `/dashboard`, `/api/*`, `/debug`, `/test`, `/preview`, `/draft`, `/staff`, `/partner`, `/superuser`, dynamic segments `/[tenant]`, `/[...slug]`.
5. For each flagged Next.js page route: fetch its data route `/_next/data/<BUILDID>/<route>.json` unauthenticated. A 200 with JSON = server renders this page's data without auth (even if the page itself redirects — the DATA is the leak).
6. For Remix: request `<route>.data` unauthenticated for every route with `hasLoader: true`. Loaders run server-side — a 200 here bypasses any client-side route guard. Also try `?_data=<routeId>` param form.
7. For RSC (Next.js app router): fetch the route with `RSC: 1` / `Next-Router-State-Tree` headers and inspect the flight payload for data the UI doesn't render (hidden fields, internal IDs, admin flags).
8. Test middleware confusion (Next.js): request flagged routes with `/_next/static/` prefix tricks, trailing `/.json`, `?__nextLocale`, and `x-middleware-subrequest` header variants — record any status differential vs the direct request.
9. Baseline: request `/_next/data/<BUILDID>/zzz-dead-xyz.json` and a dead `.data` route — record the framework's real 404 shape (JSON `{"notFound":true}` vs HTML fallback).
10. For each live-but-unlinked route: determine the access verdict — does the DATA endpoint enforce auth even when the page redirects? Test data route with no cookies vs the page with no cookies; a data-200 + page-redirect pair = information disclosure.
11. Check draft/preview modes: `/api/preview?secret=` patterns, `__next_preview_data`, `x-prerender-revalidate` headers — preview secrets sometimes hardcoded in JS (`previewSecret`).
12. Re-test the 5 most sensitive data-route findings a second time (2x reproduction).
13. Write `findings/framework_route_audit_confirmed.md`: route table summary, flagged routes, per-route page-vs-data access matrix, middleware differential results.

## Exact commands

Fetch Next.js manifests (replace <BUILDID> from HTML):
```bash
mkdir -p js/routes
B="<BUILDID>"
curl -sS "https://<HOST>/_next/static/${B}/_buildManifest.js" -o js/routes/_buildManifest.js
curl -sS "https://<HOST>/_next/static/${B}/_ssgManifest.js" -o js/routes/_ssgManifest.js
curl -sS "https://<HOST>/_next/static/${B}/_middlewareManifest.js" -o js/routes/_middlewareManifest.js
grep -oE '"/[^"]*"' js/routes/_buildManifest.js | sort -u | tee js/routes/next_pages.txt | wc -l
```

Remix manifest extraction:
```bash
curl -sS "https://<HOST>/" -o /tmp/index.html
grep -oE '__remixManifest *= *\{.{0,200}' /tmp/index.html | head -2
python3 - <<'EOF'
import re, json
html = open("/tmp/index.html").read()
m = re.search(r'__remixManifest\s*=\s*(\{.*?\});', html, re.S)
if m:
    man = json.loads(m.group(1))
    routes = man.get("routes", {})
    for rid, r in routes.items():
        print(rid, "| path:", r.get("path"), "| hasLoader:", r.get("hasLoader"), "| hasAction:", r.get("hasAction"))
EOF
```

Baseline (framework 404 shapes):
```bash
curl -sS -o /dev/null -w "next-data-dead: %{http_code} %{size_download}\n" \
  "https://<HOST>/_next/data/<BUILDID>/zzz-dead-xyz.json"
```

Data-route unauthenticated audit (Next.js):
```bash
while read -r p; do
  code=$(curl -sS -o /tmp/dr -w "%{http_code}" --max-time 20 \
    "https://<HOST>/_next/data/<BUILDID>${p}.json")
  size=$(wc -c < /tmp/dr)
  echo "$code $size $p"
done < js/routes/flagged_pages.txt | tee js/routes/data_route_results.txt
```

Remix .data audit:
```bash
curl -sS --max-time 20 "https://<HOST>/admin/users.data" -o /tmp/rd -w "direct: %{http_code} %{size_download}\n"
curl -sS --max-time 20 "https://<HOST>/admin/users?index&_data=root" -o /tmp/rd2 -w "param-form: %{http_code} %{size_download}\n"
head -c 400 /tmp/rd; echo
```

RSC flight payload inspection:
```bash
curl -sS --max-time 20 "https://<HOST>/admin/dashboard" \
  -H "RSC: 1" -H "Next-Router-State-Tree: %5B%22%22%2C%7B%22children%22%3A%5B%22admin%22%2C%7B%7D%5D%7D%2Cnull%2Cnull%2Ctrue%5D" \
  -o /tmp/rsc.txt -w "rsc: %{http_code} %{size_download}\n"
grep -oE '.{0,40}(isAdmin|role|tenant|internal|secret).{0,40}' /tmp/rsc.txt | head -20
```

Middleware confusion battery:
```bash
R="/admin/dashboard"
for v in "$R" "/_next/static/../..$R" "$R.json" "$R?__nextLocale=en" "$R/"; do
  printf "%-40s -> " "$v"
  curl -sS -o /dev/null -w "%{http_code}\n" --max-time 20 "https://<HOST>${v}"
done
printf "x-middleware-subrequest -> "
curl -sS -o /dev/null -w "%{http_code}\n" -H "x-middleware-subrequest: 1" "https://<HOST>${R}"
```

Nuxt payload audit (equivalent of Next data routes):
```bash
curl -sS "https://<HOST>/_nuxt/builds/meta/<BUILDID>.json" -o js/routes/nuxt_meta.json -w "nuxt-meta: %{http_code}\n"
# _payload.json per route — unauthenticated fetch, same disclosure logic as Next data routes:
curl -sS --max-time 20 "https://<HOST>/admin/_payload.json" -o /tmp/np -w "nuxt-payload: %{http_code} %{size_download}\n"
head -c 400 /tmp/np; echo
```

SvelteKit immutable manifest check:
```bash
grep -oE '/_app/immutable/[^"]+\.js' /tmp/idx.html | sort -u | tee js/routes/sveltekit_chunks.txt | wc -l
```

## Completion-bias defenses

- [ ] Framework + version identified and recorded
- [ ] All available manifests fetched (build/ssg/middleware or remix/nuxt equivalents)
- [ ] route_table.json built — every route has an entry
- [ ] Routes flagged by sensitive-name battery
- [ ] Baseline dead data-route fingerprints captured
- [ ] Every flagged page route's DATA route tested unauthenticated (Next.js)
- [ ] Every hasLoader route's .data tested unauthenticated (Remix)
- [ ] RSC flight payloads inspected for hidden fields on flagged routes
- [ ] Middleware confusion battery run on top 5 flagged routes
- [ ] Preview/draft mode secrets searched
- [ ] 5 most sensitive findings reproduced 2x
- [ ] findings/framework_route_audit_confirmed.md exists
- **Review step:** agent10_review must verify: (a) the page-vs-data access matrix exists for every flagged route (page status AND data status); (b) no "route exists" claim without a live fetch; (c) middleware differentials have baseline comparisons.
- **Nudge prompts:**
  - "Keep going until every flagged route has BOTH a page verdict and a data verdict — the page redirecting means nothing if the data endpoint 200s."
  - "Do not report done before findings/framework_route_audit_confirmed.md exists on disk."
  - "Client-side route guards are decoration. The .data endpoint is the truth. Test the truth."
- **Finished artifact definition:** `findings/framework_route_audit_confirmed.md` with route_table.json summary, flagged-route table, page-vs-data matrix, middleware differential table, and verdicts.

## Evidence standard

- Baseline: dead data-route / dead .data fingerprints captured first.
- Reproduction: 5 most sensitive data-route findings fetched twice.
- Raw evidence: full request/response pairs for every page-redirect/data-200 pair in `js/routes/disclosure_pairs.txt`.
- Verdicts: CONFIRMED (data endpoint 200s unauthenticated with sensitive data) / INCONCLUSIVE (ambiguous payload, needs second model) / NEGATIVE (data endpoints gated or empty).

## Handoffs

- **dead_code_endpoints:** consumes routes that exist in manifests but 404/redirect everywhere (unreachable surface).
- **endpoint_regex_mining:** consumes data-route URLs as new validated endpoints.
- **minified_logic_review:** consumes middleware matcher logic for bypass review.
- **agent10_review:** consumes findings/framework_route_audit_confirmed.md.
