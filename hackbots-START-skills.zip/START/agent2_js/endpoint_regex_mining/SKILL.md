---
name: endpoint_regex_mining
agent: agent2_js
description: Run 10 targeted regex passes over JS bundles to extract valid, reachable endpoints.
---

# Endpoint Regex Mining

## Purpose

Every API the frontend calls is written somewhere in its JavaScript: `fetch("/api/v1/users")`, axios instances, WebSocket URLs, GraphQL operations, `new URL(...)` constructions. Ten disciplined regex passes — not one lazy grep — surface the complete endpoint surface, including admin routes the UI never links to. Each candidate is then validated live against the server, because a string in JS is a lead, not a finding. This is the skill that turns bundles into a tested endpoint inventory.

## Division of labor

- **Consumes:** `js/raw/*.js`, `js/chunks/files/*.js`, `js/reconstructed/**` (from sourcemap_recovery) — all harvested bundle text. Priority list: `js/chunks/flagged_chunks.txt`.
- **Produces:** `findings/endpoint_regex_mining_confirmed.md` — validated endpoint inventory with status codes, plus `js/endpoints/candidates_raw.txt` (all regex hits) and `js/endpoints/validated.json`.

## When to use / when NOT to use

- **Use when:** any JS bundle exists from the target; especially after sourcemap reconstruction (original source mines far better).
- **Skip when (time-pass filter):** the only JS is third-party CDN libraries (their endpoints belong to the vendor); bundles are < 5KB (no real app code — verify with `wc -c` first).

## Methodology

1. Assemble the corpus: concatenate all first-party bundle text into `js/endpoints/corpus.txt`. Exclude known vendor files (react-dom, lodash, sentry) — record exclusions in `js/endpoints/excluded_vendor.txt`.
2. Run PASS 1 — string-literal paths: regex `["']/[a-zA-Z0-9/_.-]{2,}["']` — catches `/api/v1/users`, `/admin/export`. Save hits.
3. Run PASS 2 — fetch/XHR calls: regex `(fetch|axios\.(get|post|put|delete|patch)|\.ajax|XMLHttpRequest)` with 120 chars of trailing context. The context reveals method + params.
4. Run PASS 3 — URL constructors: regex `new URL\(|URL\.createObjectURL|location\.origin\s*\+|window\.location` — catches dynamically built URLs.
5. Run PASS 4 — WebSocket: regex `new WebSocket\(|wss?://[^"']+` — WS endpoints are rarely in docs and often unauthenticated.
6. Run PASS 5 — GraphQL: regex `(query|mutation|subscription)\s+[A-Z][A-Za-z]+|/graphql|__typename` — extract operation names; each is a testable query.
7. Run PASS 6 — route definitions: regex `(path|route):\s*["']/[^"']+|createBrowserRouter|Routes?\.` — SPA route tables reveal admin pages.
8. Run PASS 7 — template-literal endpoints: regex `` `/api[^`]*\$\{[^}]+\}` `` — endpoints with interpolated params; the param names (`${userId}`, `${tenantId}`) are IDOR test targets.
9. Run PASS 8 — API client configs: regex `baseURL\s*:\s*["'][^"']+|BASE_URL\s*=|API_(URL|HOST|ENDPOINT)` — feeds api_client_reverse.
10. Run PASS 9 — versioned/internal prefixes: regex `["']/(v[0-9]+|internal|api|rest|private|admin|debug|_next/data|_next/static)[^"']*["']`.
11. Run PASS 10 — action/method strings: regex `["'](GET|POST|PUT|DELETE|PATCH)["']\s*[,}]|method:\s*["'](get|post)` near a path — binds methods to endpoints.
12. Deduplicate all passes into `js/endpoints/candidates_raw.txt` as `<endpoint> <pass#> <source_file>`. Normalize: strip query strings, collapse `${param}` to `:param`.
13. Decision branch: if candidates < 20 from minified bundles, re-run passes 1–10 against `js/reconstructed/` (original source) — expect 3–5x yield. If still < 20, the app is likely server-rendered; pivot to framework_route_audit.
14. Validation: for each candidate, issue the observed method (default GET) unauthenticated. Record status, content-type, body size, and first 200 chars in `js/endpoints/validated.json`. Baseline: also request `https://<HOST>/api/zzz-dead-xyz123` and `https://<HOST>/zzz-dead-page` — the app's real 404 fingerprint (SPA fallback 200 vs API 404 JSON).
15. Classify each validated endpoint: 200+JSON = live API; 200+HTML = SPA fallback (dead as API); 401/403 = auth-gated (→ access ladder, note it); 404 = dead; 405 = exists but wrong method — RETRY with other methods (method confusion is a finding class).
16. For 405s: replay with GET/POST/PUT/DELETE/PATCH/OPTIONS and record the Allow header. For 401/403s: log them for the bypass battery — do NOT claim bypass here.
17. Re-run validation on a 10% random sample a second time (2x reproduction on the validation process itself).
18. Write `findings/endpoint_regex_mining_confirmed.md`: live endpoints table (endpoint → method → status → body type → sensitivity note), auth-gated list, 405 method-confusion list, and dead list marked NEGATIVE.

## Exact commands

Baseline (app's real 404 fingerprints):
```bash
curl -sS -o /dev/null -w "api-dead: %{http_code} %{size_download} %{content_type}\n" \
  "https://<HOST>/api/zzz-dead-xyz123"
curl -sS -o /dev/null -w "page-dead: %{http_code} %{size_download} %{content_type}\n" \
  "https://<HOST>/zzz-dead-page-xyz123"
```

Assemble corpus (exclude vendor):
```bash
mkdir -p js/endpoints
ls -la js/raw/*.js js/chunks/files/*.js 2>/dev/null | awk '{print $5, $9}' | tee js/endpoints/corpus_sizes.txt
grep -L -iE "react-dom|lodash|moment\.min|sentry|google-analytics|gtag" js/raw/*.js js/chunks/files/*.js 2>/dev/null \
  | tee js/endpoints/first_party.txt
cat $(cat js/endpoints/first_party.txt) > js/endpoints/corpus.txt
wc -c js/endpoints/corpus.txt
```

The 10 regex passes (all output to candidates_raw.txt):
```bash
C=js/endpoints/corpus.txt; O=js/endpoints/candidates_raw.txt; : > $O
grep -oE '["'\'']/[a-zA-Z0-9/_.-]{2,}["'\'']' $C | sed 's/^/P1 /' >> $O
grep -oE '(fetch|axios\.(get|post|put|delete|patch)|\.ajax)\([^)]{0,120}' $C | sed 's/^/P2 /' >> $O
grep -oE 'new URL\([^)]{0,100}|wss?://[^"'\''` ]+' $C | sed 's/^/P3-P4 /' >> $O
grep -oE '(query|mutation|subscription) +[A-Z][A-Za-z0-9_]+|/graphql' $C | sed 's/^/P5 /' >> $O
grep -oE '(path|route): *["'\'']/[^"'\'']+' $C | sed 's/^/P6 /' >> $O
grep -oE '`/[^`]*\$\{[^}]+\}[^`]*`' $C | sed 's/^/P7 /' >> $O
grep -oE 'baseURL *: *["'\''][^"'\'']+["'\'']|API_(URL|HOST|ENDPOINT) *= *["'\''][^"'\'']+' $C | sed 's/^/P8 /' >> $O
grep -oE '["'\'']/(v[0-9]+|internal|api|rest|private|admin|debug)[^"'\'']*["'\'']' $C | sed 's/^/P9 /' >> $O
grep -oE 'method: *["'\''](get|post|put|delete|patch)' $C | sed 's/^/P10 /' >> $O
wc -l $O
```

Validate candidates live (python3):
```bash
python3 - <<'EOF'
import json, re, urllib.request
HOST = "<HOST>"
cands = set()
for line in open("js/endpoints/candidates_raw.txt"):
    m = re.search(r'["\'`](/[A-Za-z0-9/_.\-:]+)', line)
    if m:
        p = re.sub(r'\$\{[^}]+\}', ':param', m.group(1))
        p = p.split("?")[0]
        if len(p) > 3 and "node_modules" not in p:
            cands.add(p)
print("unique candidates:", len(cands))
out = []
for p in sorted(cands):
    url = f"https://{HOST}{p}"
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, method="GET"), timeout=15)
        body = r.read(400)
        out.append({"endpoint": p, "status": r.status, "ct": r.headers.get("Content-Type"), "size": len(body), "head": body[:200].decode("utf-8", "replace")})
    except Exception as e:
        out.append({"endpoint": p, "error": str(e)[:120]})
    print(p, out[-1].get("status", out[-1].get("error")))
json.dump(out, open("js/endpoints/validated.json", "w"), indent=2)
EOF
```

405 method-confusion follow-up:
```bash
for m in GET POST PUT DELETE PATCH OPTIONS; do
  printf "%s: " "$m"
  curl -sS -o /dev/null -w "%{http_code}\n" -X "$m" "https://<HOST>/<ENDPOINT>"
done
curl -sSI "https://<HOST>/<ENDPOINT>" | grep -i "^allow:"
```

P2 context enrichment (bind params to endpoints):
```bash
# for each P2 fetch/axios hit, pull the surrounding 200 chars to capture bodies + headers:
grep -oE '.{0,100}(fetch|axios\.(get|post|put|delete|patch))\(.{0,200}' \
  js/endpoints/corpus.txt | grep -oE '["'\'']/api[^"'\'']{0,80}' | sort -u | tee js/endpoints/api_paths_enriched.txt | wc -l
# template-literal param names are IDOR seeds — list them:
grep -oE '\$\{[a-zA-Z0-9_]+\}' js/endpoints/corpus.txt | sort | uniq -c | sort -rn | tee js/endpoints/param_names.txt
```

## Completion-bias defenses

- [ ] Corpus assembled; vendor exclusions recorded; corpus byte count > 5KB sanity-checked
- [ ] All 10 passes run — each pass's hit count logged (zero-hit passes logged too, not skipped)
- [ ] Candidates deduplicated and normalized (:param placeholders)
- [ ] If < 20 candidates from minified, passes re-run against js/reconstructed/
- [ ] Baseline dead-path fingerprints captured BEFORE validation verdicts
- [ ] Every candidate validated live; validated.json complete
- [ ] 200+HTML fallback distinguished from real API responses (no SPA-fallback FPs)
- [ ] All 405s re-tested with 6 methods; Allow headers recorded
- [ ] 401/403s logged as auth-gated leads (not claimed as findings)
- [ ] 10% re-validation sample completed
- [ ] findings/endpoint_regex_mining_confirmed.md exists
- **Review step:** agent10_review must verify: (a) no 200+HTML SPA fallback is listed as a live endpoint; (b) the 10 pass hit counts are all present in the findings; (c) every CONFIRMED endpoint has status + content-type + body-head evidence.
- **Nudge prompts:**
  - "Keep going until all 10 passes have run and every candidate has a validation row — a regex hit without a live test is a rumor."
  - "Do not report done before findings/endpoint_regex_mining_confirmed.md exists on disk."
  - "405 is not a dead end — it means the endpoint EXISTS. Test every method before you move on."
- **Finished artifact definition:** `findings/endpoint_regex_mining_confirmed.md` with the live-endpoint table, auth-gated list, method-confusion list, and raw validated.json referenced; every candidate from candidates_raw.txt accounted for.

## Evidence standard

- Baseline: `/api/zzz-dead-xyz123` and `/zzz-dead-page-xyz123` fingerprints recorded first.
- Reproduction: 10% random re-validation sample, byte-compared.
- Raw evidence: full validated.json saved; 3 representative raw request/response pairs in the findings file.
- Verdicts: CONFIRMED (live endpoint, non-fallback response, reproduced) / INCONCLUSIVE (ambiguous body, needs second model) / NEGATIVE (404/dead or SPA fallback).

## Handoffs

- **api_client_reverse:** consumes js/endpoints/validated.json + P8 baseURL hits to rebuild API clients.
- **dead_code_endpoints:** consumes candidates that 404'd live but exist in code (unreachable surface).
- **minified_logic_review:** consumes template-literal endpoints with :param placeholders for auth/validation logic review.
- **agent10_review:** consumes findings/endpoint_regex_mining_confirmed.md.
