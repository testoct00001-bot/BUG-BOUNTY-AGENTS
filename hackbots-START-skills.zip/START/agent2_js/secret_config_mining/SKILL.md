---
name: secret_config_mining
agent: agent2_js
description: Extract API keys, tokens, internal hosts, feature flags, and build metadata from JS.
---

# Secret & Config Mining

## Purpose

Frontend bundles routinely ship secrets: Firebase configs, Supabase anon keys, Stripe publishable keys, Algolia keys, Sentry DSNs, Mapbox tokens, internal API hosts, feature flags that toggle admin UI, and build metadata revealing CI paths and developer usernames. Some are low-risk by design (publishable keys); others are live credentials or internal hostnames that become SSRF/RCE pivots. This skill extracts every secret-shaped string, classifies it by type, validates which ones are live, and reports only what is real.

## Division of labor

- **Consumes:** `js/raw/*.js`, `js/chunks/files/*.js`, `js/reconstructed/**`; seed list `js/maps/secret_hits.txt` + `js/maps/internal_hosts.txt` (from sourcemap_recovery).
- **Produces:** `findings/secret_config_mining_confirmed.md` — classified secret inventory with live-validation results, plus `js/secrets/all_hits.json`.

## When to use / when NOT to use

- **Use when:** any first-party bundle or reconstructed source exists; especially third-party SDK init calls (`firebase.initializeApp`, `supabase.createClient`).
- **Skip when (time-pass filter):** only minified vendor CDN files; a previous run on the same build hash already classified everything (check build hash first — no re-mining the same bytes).

## Methodology

1. Record the build fingerprint: hash of the main bundle (`sha256sum`). If a prior `js/secrets/` run exists with the same hash, skip — the bytes haven't changed.
2. Run the secret-shape battery over the corpus (see commands): Firebase, Supabase, Stripe (pk_live/sk_live), AWS (AKIA), Google API keys (AIza), Slack (xoxp/xoxb), GitHub (ghp_), SendGrid (SG.), Algolia, Mapbox (pk.), Sentry DSN, JWT-shaped strings, `x-api-key` values, and generic `key\s*[:=]\s*["'][A-Za-z0-9_\-]{16,}["']`.
3. Run the config battery: `firebaseConfig`, `.internal` / `.corp` / `.local` hostnames, `10.x/172.16.x/192.168.x` literals, `staging|dev|qa|uat` hostnames, `*.amazonaws.com` bucket names, `s3://` references, WebSocket hosts, GraphQL endpoints with keys.
4. Run the feature-flag battery: `featureFlags`, `flags:`, `isAdmin`, `enableDebug`, `showInternal`, LaunchDarkly/Darkly keys, `REACT_APP_` / `VITE_` / `NEXT_PUBLIC_` env dumps — `NEXT_PUBLIC_` vars are ALL shipped to the client by design, enumerate every one.
5. Decision branch — classify each hit:
   - **A. Designed-public** (Stripe pk_, Mapbox pk., Firebase apiKey alone): note as informational ONLY. Never a finding alone.
   - **B. Sensitive-by-context** (Supabase anon key + project URL, Algolia key + app ID, Sentry DSN): test whether the service is reachable and what the key permits — e.g. Supabase anon key → try unauthenticated table reads via PostgREST (`/rest/v1/`).
   - **C. Real secret** (sk_live, AKIA + secret, xoxp, ghp_, private keys `-----BEGIN`): CONFIRMED finding candidate — verify live, then escalate to human immediately.
   - **D. Internal hostnames/IPs**: feed to SSRF test planning (do not SSRF blindly — record as leads).
6. Validate Firebase: `https://<project>.firebaseio.com/.json` — 200 with data = open database (critical); 401/permission-denied JSON = locked (informational).
7. Validate Supabase: `https://<project>.supabase.co/rest/v1/` with `apikey: <anon>` header — list tables; try a read on any table name found in JS.
8. Validate S3 bucket names: `https://<bucket>.s3.amazonaws.com/` — 200 listable = open bucket; 403 = exists but closed (note it).
9. Validate `NEXT_PUBLIC_` / `VITE_` dumps: each value gets the same A–D classification. Build-metadata values (CI paths, usernames, commit SHAs) go to the recon notes, not findings.
10. Check for secrets in sourcemap `sourcesContent` that were STRIPPED from the bundle — diff the two corpora: `grep` hits present in reconstructed source but absent from the served bundle indicate build-time secret injection (record the mechanism).
11. Re-validate every Class B/C hit a second time with a fresh request (2x reproduction). For Class C, do NOT redeem or use the secret beyond a read-only liveness check — note "live, not exercised" and hand to the human.
12. Write `findings/secret_config_mining_confirmed.md`: tables per class with hit → location (file:line) → validation result → verdict.

## Exact commands

Build fingerprint (skip if unchanged):
```bash
sha256sum js/raw/main.*.js 2>/dev/null | tee js/secrets/build_hash.txt
# compare with previous run's hash before re-mining
```

Secret-shape battery:
```bash
mkdir -p js/secrets
C=js/endpoints/corpus.txt
grep -oE 'AIza[0-9A-Za-z_-]{35}' $C | sort -u > js/secrets/google_keys.txt
grep -oE 'AKIA[0-9A-Z]{16}' $C | sort -u > js/secrets/aws_keys.txt
grep -oE 'sk_live_[0-9a-zA-Z]{16,}|rk_live_[0-9a-zA-Z]{16,}' $C | sort -u > js/secrets/stripe_secret.txt
grep -oE 'pk_(live|test)_[0-9a-zA-Z]{16,}' $C | sort -u > js/secrets/stripe_pub.txt
grep -oE 'xox[pbar]-[0-9A-Za-z-]{10,}' $C | sort -u > js/secrets/slack.txt
grep -oE 'ghp_[0-9A-Za-z]{30,}|github_pat_[0-9A-Za-z_]{20,}' $C | sort -u > js/secrets/github.txt
grep -oE 'SG\.[0-9A-Za-z_-]{20,}' $C | sort -u > js/secrets/sendgrid.txt
grep -oE 'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}' $C | sort -u > js/secrets/jwts.txt
grep -oE '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----' $C | sort -u > js/secrets/private_keys.txt
grep -oE '"(api[_-]?key|secret|client[_-]?secret)" *: *"[^"]{8,}"' $C | sort -u > js/secrets/generic_kv.txt
wc -l js/secrets/*.txt
```

Firebase validation (read-only liveness):
```bash
# <PROJECT> from firebaseConfig projectId
curl -sS --max-time 20 "https://<PROJECT>.firebaseio.com/.json" | head -c 500; echo
curl -sS --max-time 20 "https://firestore.googleapis.com/v1/projects/<PROJECT>/databases/(default)/documents" | head -c 500; echo
```

Supabase validation (read-only):
```bash
curl -sS --max-time 20 "https://<PROJECT>.supabase.co/rest/v1/" \
  -H "apikey: <ANON_KEY>" -H "Authorization: Bearer <ANON_KEY>" | head -c 800; echo
```

S3 bucket validation:
```bash
curl -sS -o /dev/null -w "%{http_code}\n" --max-time 20 "https://<BUCKET>.s3.amazonaws.com/"
```

Env-dump enumeration:
```bash
grep -oE '(NEXT_PUBLIC|REACT_APP|VITE)_[A-Z0-9_]+' $C | sort -u | tee js/secrets/env_names.txt
grep -oE '(NEXT_PUBLIC|REACT_APP|VITE)_[A-Z0-9_]+["'\'']? *: *["'\''][^"'\'']+' $C | sort -u | tee js/secrets/env_values.txt
```

JWT claim decoding (offline, bundle samples only):
```bash
python3 - <<'EOF'
import base64, json
# paste ONE jwt-shaped string found in the bundle (never a live user session token)
t = "<JWT_FROM_BUNDLE>"
parts = t.split(".")
pad = lambda s: s + "=" * (-len(s) % 4)
try:
    claims = json.loads(base64.urlsafe_b64decode(pad(parts[1])))
    print(json.dumps(claims, indent=2)[:800])
    print("admin-like claims:", [k for k in claims if k.lower() in ("role","isadmin","admin","permissions","scope")])
except Exception as e:
    print("not decodable:", e)
EOF
```

Algolia key scope test (read-only):
```bash
# <APP_ID> and <API_KEY> from bundle
curl -sS --max-time 20 "https://<APP_ID>-dsn.algolia.net/1/indexes" \
  -H "X-Algolia-API-Key: <API_KEY>" -H "X-Algolia-Application-Id: <APP_ID>" | head -c 600; echo
```

Private key handling (never exfiltrate, never use):
```bash
# if -----BEGIN PRIVATE KEY----- found: record file:line, classify C, escalate to human.
# verify shape only (no decryption of anything):
grep -c "BEGIN.*PRIVATE KEY" js/secrets/private_keys.txt
```

## Completion-bias defenses

- [ ] Build hash recorded; unchanged-build skip decision documented
- [ ] All 12 secret-shape patterns run; hit counts logged (zeros logged too)
- [ ] Config battery run (internal hosts, private IPs, staging names, buckets)
- [ ] Feature-flag / env-dump battery run (NEXT_PUBLIC_/VITE_/REACT_APP_)
- [ ] Every hit classified A/B/C/D with the decision branch applied
- [ ] Firebase projects tested (/.json + firestore) where found
- [ ] Supabase projects tested (PostgREST read attempt) where found
- [ ] S3 buckets probed where found
- [ ] Sourcemap-vs-bundle diff run for build-time injection
- [ ] Every Class B/C hit validated 2x; Class C noted "live, not exercised"
- [ ] findings/secret_config_mining_confirmed.md exists
- **Review step:** agent10_review must verify: (a) no Class A designed-public key is presented as a finding; (b) every Class C claim has the exact file:line and a "not exercised beyond liveness" note; (c) the human-escalation flag is set for any live Class C.
- **Nudge prompts:**
  - "Keep going until every secret-shaped string has a classification — unclassified strings are unfinished work."
  - "Do not report done before findings/secret_config_mining_confirmed.md exists on disk."
  - "A Stripe publishable key is not a finding. A live sk_live is a drop-everything escalation. Classify before you claim."
- **Finished artifact definition:** `findings/secret_config_mining_confirmed.md` with A/B/C/D tables, file:line locations, validation results, and the human-escalation flag state for Class C.

## Evidence standard

- Baseline: N/A for shapes (regex is deterministic); validation baselines are the services' own error responses (Firebase `permission_denied`, S3 403) recorded in the findings.
- Reproduction: every Class B/C validation run twice, 60+ seconds apart.
- Raw evidence: full request/response pairs for every validated service in `js/secrets/validation_pairs.txt`.
- Verdicts: CONFIRMED (live secret / open database / listable bucket) / INCONCLUSIVE (shape found, service unreachable, needs second model) / NEGATIVE (designed-public or locked-down).

## Handoffs

- **endpoint_regex_mining:** consumes internal hostnames/bucket names as new endpoint candidates.
- **third_party_sdk_mining:** consumes SDK init configs (Firebase/Supabase/Algolia) for version/vuln checks.
- **api_client_reverse:** consumes baseURL + key pairs to rebuild authenticated clients.
- **Human (via agent10_review):** any live Class C secret escalates immediately — this is the one skill allowed to break the normal queue for a critical.
