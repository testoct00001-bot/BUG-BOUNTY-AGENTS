---
name: api_client_reverse
agent: agent2_js
description: Reconstruct API clients from bundles — base URLs, auth logic, and header schemes.
---

# API Client Reverse Engineering

## Purpose

Frontend code doesn't just list endpoints — it builds clients: axios instances with `baseURL`, interceptors that attach `Authorization` headers, token-refresh flows, CSRF handling, signed-parameter schemes. Reconstructing the client tells you exactly how the app authenticates its API calls, which headers are trusted, where tokens live (localStorage = XSS-stealable), and whether the "auth" is client-side theater. This skill rebuilds the client's auth model from the bundle and tests every trust assumption the code makes.

## Division of labor

- **Consumes:** `js/endpoints/validated.json` + P8 baseURL hits (from endpoint_regex_mining); `js/reconstructed/**` for unminified client code.
- **Produces:** `findings/api_client_reverse_confirmed.md` — the reconstructed auth model: base URLs, header schemes, token storage, refresh logic, and tested trust assumptions; plus `js/apiclient/client_model.json`.

## When to use / when NOT to use

- **Use when:** bundles contain `axios.create`, `fetch` wrappers, `Authorization` header construction, or token refresh logic.
- **Skip when (time-pass filter):** the app makes only same-origin cookie requests with no custom headers (nothing to reverse — note it and move on).

## Methodology

1. Locate client construction: regex `axios\.create\(|new\s+ApiClient|createApi|httpClient\s*=|baseURL` across the corpus. Extract 200 chars of context per hit into `js/apiclient/client_hits.txt`.
2. Extract base URLs: every `baseURL: "..."` value, plus `API_URL` env values. Normalize: record whether absolute (`https://api.<HOST>`) or relative (`/api`). Absolute third-party base URLs are pivot targets.
3. Extract the auth scheme: regex `(Authorization|authorization)['"]?\s*[:=]\s*[`'"][^`'"]*` — capture the exact scheme: `Bearer ${token}`, `Token ${x}`, custom `X-Api-Key`, `Basic ${btoa(...)}`. Record verbatim.
4. Map request interceptors: find `interceptors\.request\.use` blocks — these show what gets attached to EVERY call (auth headers, tenant IDs, device fingerprints, CSRF tokens). List each injected header/param.
5. Map response interceptors: `interceptors\.response\.use` — especially 401 handlers: does it silently refresh and retry? That reveals the refresh endpoint (`/auth/refresh`, `/token/refresh`) — a prime target.
6. Find token storage: regex `(localStorage|sessionStorage)\.(setItem|getItem)\(['"](token|auth|jwt|access|refresh)` — localStorage tokens are XSS-exfiltrable; httpOnly cookies are not. Record storage location per token type.
7. Find token refresh logic: `refresh_token`, `/refresh`, `grant_type` — extract the full refresh request (method, endpoint, params). Test: does the refresh endpoint accept a request without the old refresh token? (Some accept just a user ID — critical.)
8. Find signed-request schemes: `hmac|sign\(|signature|timestamp.*nonce|CryptoJS\.Hmac` — if the client signs requests, extract the signing inputs (is the secret in the bundle? is it just `md5(url + staticSalt)`?). A client-side secret = no secret.
9. Find CSRF handling: `X-CSRF-Token|xsrf|csrfToken` — is the token fetched from an endpoint (fetchable unauthenticated?) or from a meta tag? If the API accepts the CSRF token from a GET-able endpoint, note the chain.
10. Decision branch — test each trust assumption live:
    - If `Authorization: Bearer <token>` → request an endpoint with NO header (baseline 401?), with `Bearer null`, `Bearer undefined`, `Bearer <garbage>`. Any non-401 = auth-confusion lead.
    - If custom header `X-Api-Key: <key>` → try the endpoint with the header removed, and with the key value from the bundle (keys in bundles are often valid).
    - If tenant/org ID injected by interceptor (`X-Tenant-Id: ${orgId}`) → try swapping to another tenant's ID format (IDOR ladder seed).
11. Test token refresh endpoint unauthenticated: POST to it with empty body, with `{"refresh_token":""}`, with a garbage token. Record whether it 200s, 400s (validation exists), or 401s (gated).
12. Check for auth logic that NEVER reaches the server: `if (!isAdmin) hideButton` or route guards `canActivate` — client-side-only authorization. List every client-side role check; each is a candidate for "hidden endpoint exists server-side" (feed to dead_code_endpoints).
13. Write `js/apiclient/client_model.json`: `{base_urls[], auth_scheme, headers_injected[], token_storage{}, refresh_endpoint, csrf_model, client_side_checks[]}`.
14. Re-run the 3 most interesting trust-assumption tests a second time (2x reproduction).
15. Write `findings/api_client_reverse_confirmed.md`: the full client model + a table of tested assumptions (assumption → test → result → verdict).

## Exact commands

Extract client construction sites:
```bash
mkdir -p js/apiclient
grep -oE '.{0,60}(axios\.create|baseURL|interceptors\.(request|response)\.use).{0,140}' \
  js/endpoints/corpus.txt | tee js/apiclient/client_hits.txt | head -40
```

Extract auth scheme verbatim:
```bash
grep -oE '(Authorization|authorization)["'\'']? *: *[`"'\''][^`"'\'']{0,60}' \
  js/endpoints/corpus.txt | sort -u | tee js/apiclient/auth_schemes.txt
grep -oE '(localStorage|sessionStorage)\.(setItem|getItem)\(["'\''][^"'\'']*["'\'']' \
  js/endpoints/corpus.txt | sort -u | tee js/apiclient/token_storage.txt
```

Extract refresh + signing logic:
```bash
grep -oE '.{0,80}(refresh[_-]?token|/auth/refresh|/token/refresh|grant_type).{0,120}' \
  js/endpoints/corpus.txt | sort -u | tee js/apiclient/refresh_hits.txt
grep -oE '.{0,60}(hmac|Hmac|sign\(|signature|CryptoJS).{0,100}' \
  js/endpoints/corpus.txt | sort -u | tee js/apiclient/signing_hits.txt
```

Baseline auth-gated behavior:
```bash
# pick a validated 401/403 endpoint <EP> from validated.json
curl -sS -o /dev/null -w "no-auth: %{http_code}\n" "https://<HOST><EP>"
```

Trust-assumption battery:
```bash
EP="<EP>"
for h in "Authorization: Bearer null" "Authorization: Bearer undefined" "Authorization: Bearer x" "Authorization: null"; do
  printf "%s -> " "$h"
  curl -sS -o /dev/null -w "%{http_code}\n" -H "$h" "https://<HOST>${EP}"
done
# custom header variant (adjust name/value from auth_schemes.txt):
curl -sS -o /dev/null -w "no-custom-header: %{http_code}\n" "https://<HOST>${EP}"
curl -sS -o /dev/null -w "bundle-key-value: %{http_code}\n" -H "X-Api-Key: <KEY_FROM_BUNDLE>" "https://<HOST>${EP}"
```

Refresh endpoint unauthenticated probe:
```bash
curl -sS -X POST "https://<HOST><REFRESH_EP>" -H "Content-Type: application/json" \
  -d '{}' -w "\nempty: %{http_code}\n"
curl -sS -X POST "https://<HOST><REFRESH_EP>" -H "Content-Type: application/json" \
  -d '{"refresh_token":"garbage"}' -w "\ngarbage: %{http_code}\n"
```

Cookie-vs-header auth comparison (which does the server actually check?):
```bash
EP="<EP>"
printf "cookie-only (no header): "
curl -sS -o /dev/null -w "%{http_code}\n" -H "Cookie: session=<SESSION_COOKIE>" "https://<HOST>${EP}"
printf "header-only (no cookie): "
curl -sS -o /dev/null -w "%{http_code}\n" -H "Authorization: Bearer <TOKEN>" "https://<HOST>${EP}"
printf "both:                    "
curl -sS -o /dev/null -w "%{http_code}\n" -H "Cookie: session=<SESSION_COOKIE>" -H "Authorization: Bearer <TOKEN>" "https://<HOST>${EP}"
# If cookie-only 200s but the client always sends the header, the header is theater — note it.
```

Token expiry / refresh race test:
```bash
# if refresh logic observed: request refresh twice in parallel — does the server rotate or reuse?
curl -sS -X POST "https://<HOST><REFRESH_EP>" -H "Content-Type: application/json" \
  -d '{"refresh_token":"<RT>"}' -o /tmp/r1 & 
curl -sS -X POST "https://<HOST><REFRESH_EP>" -H "Content-Type: application/json" \
  -d '{"refresh_token":"<RT>"}' -o /tmp/r2 &
wait; diff /tmp/r1 /tmp/r2 && echo "SAME TOKEN REUSED (no rotation)" || echo "ROTATED"
```

## Completion-bias defenses

- [ ] Client construction sites extracted (client_hits.txt non-trivial)
- [ ] All base URLs listed with absolute/relative classification
- [ ] Auth scheme captured verbatim (not paraphrased)
- [ ] Request interceptor injections listed (every header/param)
- [ ] Response interceptor 401/refresh flow mapped; refresh endpoint identified
- [ ] Token storage locations recorded per token type
- [ ] Signing scheme analyzed (inputs listed; bundle-contained secret flagged)
- [ ] CSRF model documented (token source identified)
- [ ] Every trust assumption tested live with baseline comparison
- [ ] Refresh endpoint probed unauthenticated (empty + garbage body)
- [ ] Client-side-only auth checks listed
- [ ] client_model.json written; 3 key tests reproduced 2x
- [ ] findings/api_client_reverse_confirmed.md exists
- **Review step:** agent10_review must verify: (a) the auth scheme is quoted verbatim from the bundle, not summarized; (b) every "trust assumption" row has a baseline (no-auth) result to compare against; (c) no claim of bypass without a changed-status differential.
- **Nudge prompts:**
  - "Keep going until every header the interceptor injects has been tested with and without — untested headers are unfinished work."
  - "Do not report done before findings/api_client_reverse_confirmed.md exists on disk."
  - "Client-side `if (!isAdmin)` is not authorization — list every one, they point at server endpoints nobody linked."
- **Finished artifact definition:** `findings/api_client_reverse_confirmed.md` containing client_model.json's full content plus the trust-assumption test table with baselines and verdicts.

## Evidence standard

- Baseline: no-auth request to the same endpoint before every header-manipulation test.
- Reproduction: 3 most interesting assumption tests run twice.
- Raw evidence: full request/response pairs for any differential (status changed vs baseline) in `js/apiclient/differential_pairs.txt`.
- Verdicts: CONFIRMED (differential proves trust assumption breakable) / INCONCLUSIVE (ambiguous, needs second model) / NEGATIVE (assumptions hold, auth enforced).

## Handoffs

- **dead_code_endpoints:** consumes client-side-only auth checks → hidden server endpoints to probe.
- **minified_logic_review:** consumes signing/refresh logic for deep logic review.
- **endpoint_regex_mining:** consumes newly found refresh/special endpoints for validation.
- **agent10_review:** consumes findings/api_client_reverse_confirmed.md.
