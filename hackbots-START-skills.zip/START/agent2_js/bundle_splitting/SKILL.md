---
name: bundle_splitting
agent: agent2_js
description: Enumerate webpack/rollup/Vite chunk files and analyze chunk manifests for hidden modules.
---

# Bundle Splitting

## Purpose

Modern apps don't ship one JS file — they ship a manifest bundle plus dozens of lazily-loaded chunks (`4523.a1b2c3.js`). The chunk manifest is a goldmine: it lists chunk IDs, async route boundaries, and often vendor chunks named after internal features (`admin-panel`, `billing-flow`). Developers routinely deploy chunks for features that are disabled in the UI but fully functional. This skill enumerates every chunk, maps chunk ID to feature name, and flags chunks whose names suggest hidden or privileged functionality.

## Division of labor

- **Consumes:** `js/raw/bundle_list.txt` (entry bundles); page HTML containing webpack runtime hints.
- **Produces:** `findings/bundle_splitting_confirmed.md` — chunk inventory: chunk URL, size, inferred feature, and flags for suspicious names; plus `js/chunks/chunk_manifest.json`.

## When to use / when NOT to use

- **Use when:** the main bundle contains `webpackChunk`, `__vite`, `_next/static/chunks`, or `import(` dynamic-import syntax; the HTML references `/static/js/main.` or `/_next/static/`.
- **Skip when (time-pass filter):** single-file SPA with no dynamic imports (one bundle, no chunks); chunks are all third-party vendor code from a public CDN (react-dom, lodash — time-pass, their content is public).

## Methodology

1. Identify the bundler: search the main bundle for `webpackChunk` (webpack), `System.register` (SystemJS), `vite` preload helpers, `__next` (Next.js), `parcelRequire` (Parcel). Record in `js/chunks/bundler.txt`.
2. Extract the chunk manifest: for webpack, find `webpackChunk<name> = {...}` push calls and the runtime's chunk-loading map (`u.<chunkId> => "<hash>.js"`). For Next.js, parse `/_next/static/<buildId>/_buildManifest.js` and `_ssgManifest.js`. Save raw to `js/chunks/manifest_raw.txt`.
3. Build `js/chunks/chunk_manifest.json`: `{chunk_id, url, size_hint, feature_name}`. Feature names come from chunk filenames (webpack `namedChunks` often leak real names like `admin-dashboard.chunk.js`).
4. Enumerate ALL chunks: fetch the build manifest / runtime map, resolve every chunk URL against the host, and download each to `js/chunks/files/`. Record 404s separately — those feed webpack_chunk_gap.
5. Baseline: request a known-dead chunk URL (`/_next/static/chunks/0000.deadbeef.js` or `/static/js/9999.dead.js`) and record the status/body. Chunk "found" claims must differ from baseline.
6. For each downloaded chunk, extract its module map: webpack chunks contain `/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {` blocks with module IDs. List module IDs and any `/* WEBPACK VAR INJECTION */` or comment hints at original paths.
7. Flag chunks by filename semantics: `admin`, `internal`, `staff`, `debug`, `test`, `dev`, `staging`, `payment`, `billing`, `auth`, `sso`, `partner`, `vendor-portal`, `superuser`. These get priority mining in endpoint_regex_mining.
8. Check chunk loading logic for path traversal or controllable chunk IDs: some runtimes do `script.src = publicPath + chunkId + ".js"` where chunkId comes from route data — test if a crafted route param changes the requested chunk URL (404 vs 200 differential).
9. Look for `webpack.config` devtool leftovers: chunks referencing `eval-source-map` or `localhost:3000` in comments — evidence of dev builds in production.
10. Measure chunk staleness: compare chunk hashes in the current HTML vs a re-fetch 10 minutes later — drifting hashes mean active deploys; stable hashes mean you can safely cache.
11. Re-fetch 3 flagged chunks a second time and byte-compare (2x reproduction).
12. Write `findings/bundle_splitting_confirmed.md`: total chunks, bundler type, flagged chunks with rationale, 404 list (→ webpack_chunk_gap), and module-count stats.

## Exact commands

Baseline (known-dead chunk):
```bash
curl -sS -o /dev/null -w "%{http_code} %{size_download}\n" \
  "https://<HOST>/static/js/9999.deadbeef.js"
```

Detect bundler and extract chunk map:
```bash
mkdir -p js/chunks/files
grep -o 'webpackChunk[a-zA-Z_$]*' js/raw/main.*.js | sort -u | tee js/chunks/bundler.txt
grep -oE '"[0-9]+":"[a-f0-9]{8,}\.js"' js/raw/main.*.js | head -50 | tee js/chunks/manifest_raw.txt
# Next.js build manifests:
curl -sS "https://<HOST>/_next/static/<BUILDID>/_buildManifest.js" -o js/chunks/_buildManifest.js
curl -sS "https://<HOST>/_next/static/<BUILDID>/_ssgManifest.js" -o js/chunks/_ssgManifest.js
```

Download every chunk and log 404s:
```bash
python3 - <<'EOF'
import json, re, urllib.request, os
os.makedirs("js/chunks/files", exist_ok=True)
raw = open("js/chunks/manifest_raw.txt").read()
pairs = re.findall(r'"(\d+)":"([a-f0-9]{8,}\.js)"', raw)
manifest = []
missed = []
for cid, fn in pairs:
    url = f"https://<HOST>/static/js/{fn}"   # adjust path prefix to observed publicPath
    try:
        data = urllib.request.urlopen(url, timeout=30).read()
        open(f"js/chunks/files/{cid}_{fn}", "wb").write(data)
        manifest.append({"id": cid, "file": fn, "bytes": len(data)})
    except Exception as e:
        missed.append(f"{cid} {fn} {e}")
json.dump(manifest, open("js/chunks/chunk_manifest.json", "w"), indent=2)
open("js/chunks/chunk_404s.txt", "w").write("\n".join(missed))
print("downloaded", len(manifest), "missed", len(missed))
EOF
```

Extract module IDs from a chunk:
```bash
grep -oE '/\*\*\*/ "[^"]+"' js/chunks/files/4523_*.js | head -30
# or webpack numeric module ids:
grep -oE '"./src/[^"]+\.(js|ts|tsx)":' js/chunks/files/*.js | sort -u | head -40
```

Flag suspicious chunk names:
```bash
ls js/chunks/files/ | grep -iE "admin|internal|staff|debug|test|dev|staging|payment|billing|auth|sso|partner|portal|superuser|employee" | tee js/chunks/flagged_chunks.txt
```

Chunk-ID control test (route-param differential):
```bash
# baseline: normal route chunk load
curl -sS -o /dev/null -w "normal: %{http_code}\n" "https://<HOST>/static/js/4523.a1b2c3.js"
# crafted: try to influence chunk id via route param (adjust to observed pattern)
curl -sS -o /dev/null -w "crafted: %{http_code} %{size_download}\n" "https://<HOST>/static/js/..%2f4523.a1b2c3.js"
```

Service worker + import map analysis (extra chunk sources):
```bash
# service workers import their own scripts — often unlisted elsewhere:
grep -oE 'navigator\.serviceWorker\.register\(["'\''][^"'\'']+' js/endpoints/corpus.txt | sort -u | tee js/chunks/sw_registrations.txt
curl -sS "https://<HOST>/sw.js" -o /tmp/sw.js -w "sw.js: %{http_code} %{size_download}\n"
grep -oE 'importScripts\(["'\''][^"'\'']+["'\'']' /tmp/sw.js 2>/dev/null | sort -u | tee js/chunks/sw_imports.txt
# import maps reveal bare-specifier -> URL mappings (hidden module URLs):
python3 - <<'EOF'
import re, json
html = open("/tmp/idx.html", encoding="utf-8", errors="replace").read()
for m in re.finditer(r'<script type="importmap">(.*?)</script>', html, re.S):
    im = json.loads(m.group(1))
    print(json.dumps(im.get("imports", {}), indent=2)[:1500])
EOF
```

Preload/prefetch hint harvest (chunks the app plans to load):
```bash
grep -oE '<link[^>]+rel="(preload|prefetch|modulepreload)"[^>]+>' /tmp/idx.html | \
  grep -oE 'href="[^"]+\.js"' | sort -u | tee js/chunks/preload_hints.txt
# every preloaded chunk not in chunk_manifest.json is a gap — investigate why
```

## Completion-bias defenses

- [ ] Bundler identified and recorded in js/chunks/bundler.txt
- [ ] Chunk manifest extracted (manifest_raw.txt) and structured (chunk_manifest.json)
- [ ] Every chunk URL downloaded OR logged in chunk_404s.txt — zero unaccounted
- [ ] Baseline dead-chunk fetched before any "found" claim
- [ ] Module IDs extracted from at least the 5 largest chunks
- [ ] Suspicious-name flag pass completed (flagged_chunks.txt)
- [ ] Chunk-ID control differential tested (path traversal attempt logged)
- [ ] 3 flagged chunks re-fetched and byte-compared
- [ ] findings/bundle_splitting_confirmed.md exists
- **Review step:** agent10_review must verify: (a) chunk_manifest.json count matches manifest_raw.txt entries; (b) every flagged chunk name is quoted with its URL; (c) 404s were passed to webpack_chunk_gap, not silently dropped.
- **Nudge prompts:**
  - "Keep going until every chunk in the manifest has a downloaded file or a 404 entry — unaccounted chunks are unfinished work."
  - "Do not report done before findings/bundle_splitting_confirmed.md exists on disk."
  - "Vendor chunks are noise; admin/debug/internal chunks are the hunt. Flag names, don't just count files."
- **Finished artifact definition:** `findings/bundle_splitting_confirmed.md` with total chunk count, bundler, flagged-chunk table (name → URL → rationale), and the 404 list handed to webpack_chunk_gap.

## Evidence standard

- Baseline: known-dead chunk URL fetched; status/size recorded at the top of chunk_probe_log.
- Reproduction: 3 flagged chunks fetched twice, byte-compared.
- Raw evidence: manifest_raw.txt excerpt + first 40 lines of one flagged chunk's module list in the findings file.
- Verdicts: CONFIRMED (flagged chunk with sensitive feature name, real file) / INCONCLUSIVE (chunk exists but content unclear, needs second model) / NEGATIVE (all chunks vendor/public, no flags).

## Handoffs

- **sourcemap_recovery:** receives js/chunks/files/ — every chunk also gets a map-probe pass.
- **endpoint_regex_mining:** receives flagged_chunks.txt as priority mining targets.
- **webpack_chunk_gap:** receives js/chunks/chunk_404s.txt for dead-surface analysis.
- **dead_code_endpoints:** receives chunk_manifest.json + module lists to find unreachable modules.
- **agent10_review:** consumes findings/bundle_splitting_confirmed.md.
