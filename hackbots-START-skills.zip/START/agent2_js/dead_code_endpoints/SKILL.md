---
name: dead_code_endpoints
agent: agent2_js
description: Find endpoints present in code but unreachable in the UI — the hidden attack surface.
---

# Dead Code Endpoints

## Purpose

Bundles contain endpoints the UI never links to: admin panels behind removed nav items, debug routes from development, API versions the frontend migrated away from, feature-flagged flows, and entire modules loaded but never rendered. This "dead code" is live on the server far more often than developers believe — the UI was cleaned up, the backend wasn't. This skill finds code-present-but-UI-unreachable endpoints and tests each one live, because dead UI + live API = the classic hidden-surface finding.

## Division of labor

- **Consumes:** `js/endpoints/candidates_raw.txt` + `js/endpoints/validated.json` (endpoint_regex_mining); `js/chunks/chunk_manifest.json` + module lists (bundle_splitting); `js/routes/route_table.json` (framework_route_audit); client-side-only checks (api_client_reverse, minified_logic_review).
- **Produces:** `findings/dead_code_endpoints_confirmed.md` — dead-code endpoint inventory with live-test verdicts; plus `js/deadcode/dead_list.json`.

## When to use / when NOT to use

- **Use when:** endpoint candidates exist that 404'd or were never linked in UI; chunks/modules exist with no route pointing at them; route manifests list routes with no nav links.
- **Skip when (time-pass filter):** every candidate endpoint is linked from the UI or sitemap (verify with a link crawl first — don't assume deadness).

## Methodology

1. Build the UI-reachable set: crawl the app's nav (header/footer/sitemap links) + SPA route table from framework_route_audit. Normalize to path set `U` in `js/deadcode/ui_reachable.txt`.
2. Build the code-present set: all endpoint candidates from endpoint_regex_mining + all routes from route_table.json + all chunk-module paths suggesting pages. Normalize to set `C` in `js/deadcode/code_present.txt`.
3. Compute the dead set: `D = C − U` — endpoints in code but not reachable from UI. Save to `js/deadcode/dead_candidates.txt`. This is the hunt list.
4. Sub-classify each dead candidate:
   - **D1 — Admin/internal naming** (`/admin/*`, `/internal/*`, `/staff/*`): highest priority.
   - **D2 — Old API versions** (`/v1/*` when UI uses `/v2/*`): old versions often lack newer auth checks.
   - **D3 — Debug/test/dev** (`/debug/*`, `/test/*`, `*.test.*`): dev endpoints in prod.
   - **D4 — Unreferenced chunks' routes**: chunk modules with page-like names but no route entry.
   - **D5 — Commented-out code**: `// fetch("/api/old-export")`, `{/* <AdminPanel/> */}` — the developer's own notes about hidden surface.
5. Hunt commented-out code explicitly: regex `//.*fetch\(|/\*.*?(api|admin|endpoint)|<!--.*?(api|admin)` across reconstructed source (comments survive in sourcemaps even when stripped from bundles).
6. For each D1–D3 candidate: test live with the observed method (default GET), unauthenticated. Record status + body type. Baseline: the dead-path fingerprints from endpoint_regex_mining (SPA fallback vs API 404).
7. Decision branch on results:
   - 200 + data → CONFIRMED hidden surface; assess sensitivity (admin data? PII? actions?) and escalate.
   - 401/403 → auth-gated hidden endpoint: log for the access-ladder (bypass battery is another agent's job, but note the exact WWW-Authenticate / error body — it reveals the auth scheme).
   - 404 → verify it's the REAL 404 shape, not a soft-404 hiding a live endpoint (compare body size to baseline ±5%).
   - 405 → method-confusion battery (all 6 methods + Allow header).
8. For D4 unreferenced chunks: check if the chunk is actually loaded by any route — search route_table.json and the runtime manifest for the chunk ID. If truly unloaded, the code is dead weight BUT its endpoints may still be live server-side — test the top 5 endpoints found inside.
9. For old API versions (D2): diff behavior — does `/v1/users/me` enforce the same auth as `/v2/users/me`? Test both with identical requests; any differential (v1 200s where v2 401s) is a CONFIRMED finding.
10. Check robots.txt / sitemap.xml for dead candidates the crawler missed — sometimes "dead" endpoints are linked there but nowhere in the UI.
11. Re-test every CONFIRMED dead-code endpoint a second time (2x reproduction).
12. Write `findings/dead_code_endpoints_confirmed.md`: the dead set, subclass table, per-endpoint live results, v1-vs-v2 differentials, and commented-code finds.

## Exact commands

Build UI-reachable vs code-present sets:
```bash
mkdir -p js/deadcode
# U: from nav crawl + route table (adjust to observed nav)
grep -oE 'href="/[^"]*"' /tmp/idx.html | grep -oE '"/[^"]*"' | tr -d '"' | sort -u > js/deadcode/ui_reachable.txt
# C: candidates + routes
cut -d' ' -f2 js/endpoints/candidates_raw.txt 2>/dev/null | sort -u > /tmp/c1.txt
python3 -c "import json; print('\n'.join(json.load(open('js/routes/route_table.json'))))" 2>/dev/null | sort -u > /tmp/c2.txt
cat /tmp/c1.txt /tmp/c2.txt | sort -u > js/deadcode/code_present.txt
comm -23 js/deadcode/code_present.txt js/deadcode/ui_reachable.txt | tee js/deadcode/dead_candidates.txt | wc -l
```

Commented-out code hunt:
```bash
grep -rn -oE '//.{0,80}(fetch\(|/api/|/admin/|endpoint).{0,60}' js/reconstructed/ 2>/dev/null | head -30 | tee js/deadcode/commented_api.txt
grep -rn -oE '/\*[^*]{0,200}(api|admin|internal|debug)[^*]{0,100}\*/' js/reconstructed/ 2>/dev/null | head -20 | tee js/deadcode/commented_blocks.txt
grep -oE '<!--.{0,100}(api|admin)[^-]{0,60}-->' /tmp/idx.html | tee js/deadcode/commented_html.txt
```

Sub-classify dead candidates:
```bash
D=js/deadcode/dead_candidates.txt
grep -iE '/(admin|internal|staff|superuser|employee)' $D | tee js/deadcode/D1_admin.txt
grep -E '/v[0-9]+/' $D | tee js/deadcode/D2_oldapi.txt
grep -iE '/(debug|test|dev|staging|qa)/|\.test\.|_test' $D | tee js/deadcode/D3_debug.txt
```

Live-test dead candidates:
```bash
while read -r p; do
  [ -z "$p" ] && continue
  code=$(curl -sS -o /tmp/dc -w "%{http_code}" --max-time 20 "https://<HOST>${p}")
  size=$(wc -c < /tmp/dc); ct=$(file -b --mime-type /tmp/dc)
  echo "$code $size $ct $p"
done < js/deadcode/dead_candidates.txt | tee js/deadcode/dead_live_results.txt
```

Old-API-version differential (v1 vs v2):
```bash
for v in v1 v2; do
  printf "%s: " "$v"
  curl -sS -o /tmp/dv -w "%{http_code} %{size_download}\n" --max-time 20 "https://<HOST>/${v}/<RESOURCE>"
done
# also unauthenticated vs baseline dead-path for each:
curl -sS -o /dev/null -w "v1-dead-shape: %{http_code} %{size_download}\n" "https://<HOST>/v1/zzz-dead-xyz"
```

Sitemap/robots cross-check (dead endpoints linked outside the UI):
```bash
curl -sS "https://<HOST>/sitemap.xml" -o /tmp/sitemap.xml -w "sitemap: %{http_code}\n"
grep -oE '<loc>[^<]+' /tmp/sitemap.xml 2>/dev/null | sed 's/<loc>//' | sort -u > js/deadcode/sitemap_urls.txt
curl -sS "https://<HOST>/robots.txt" | grep -iE "disallow" | awk '{print $2}' | tee js/deadcode/robots_disallow.txt
# any sitemap/robots URL missing from ui_reachable.txt is dead-by-definition — add to dead set:
while read -r u; do
  p=$(echo "$u" | sed -E 's|https?://[^/]+||')
  grep -qxF "$p" js/deadcode/ui_reachable.txt || echo "$p" >> js/deadcode/dead_candidates.txt
done < js/deadcode/sitemap_urls.txt
sort -u js/deadcode/dead_candidates.txt -o js/deadcode/dead_candidates.txt
```

Direct-navigation guard bypass (SPA route guards vs real enforcement):
```bash
# for a UI-unreachable route <R> that the router guards: compare direct load vs in-app nav expectation
curl -sS -o /tmp/nav -w "direct-nav: %{http_code} %{size_download}\n" --max-time 20 "https://<HOST><R>"
grep -oiE '.{0,40}(redirect|login|unauthorized|forbidden).{0,40}' /tmp/nav | head -5
```

405 follow-up on dead candidates:
```bash
grep '^405' js/deadcode/dead_live_results.txt | awk '{print $4}' | while read -r p; do
  echo "== $p"; curl -sSI --max-time 20 "https://<HOST>${p}" | grep -i "^allow:"
done
```

## Completion-bias defenses

- [ ] UI-reachable set built from actual nav crawl (not assumed)
- [ ] Code-present set built from candidates + route table
- [ ] Dead set computed as set difference; count recorded
- [ ] Dead candidates sub-classified D1–D5
- [ ] Commented-out code hunt run (JS + HTML comments)
- [ ] Every D1–D3 candidate tested live with baseline comparison
- [ ] 404s verified against real 404 shape (±5% body size check)
- [ ] 405s run through method-confusion battery
- [ ] D4 unreferenced chunks checked against route table; top endpoints tested
- [ ] D2 old-version differentials tested (v1 vs v2 identical requests)
- [ ] robots.txt/sitemap.xml cross-checked
- [ ] Every CONFIRMED reproduced 2x
- [ ] findings/dead_code_endpoints_confirmed.md exists
- **Review step:** agent10_review must verify: (a) the dead set is a real computed difference, not a hand-picked list; (b) every CONFIRMED has the UI-unreachable evidence (not in ui_reachable.txt) AND the live 200 evidence; (c) v1-vs-v2 claims show both responses.
- **Nudge prompts:**
  - "Keep going until every dead candidate has a live-test row — the dead list is a hypothesis until tested."
  - "Do not report done before findings/dead_code_endpoints_confirmed.md exists on disk."
  - "Dead in the UI does not mean dead on the server. The server never got the memo — test it."
- **Finished artifact definition:** `findings/dead_code_endpoints_confirmed.md` with the dead-set computation, D1–D5 tables, live-test results, version differentials, commented-code finds, and verdicts.

## Evidence standard

- Baseline: dead-path fingerprints from endpoint_regex_mining reused; 404 body-size ±5% check per candidate.
- Reproduction: every CONFIRMED dead-code endpoint fetched twice.
- Raw evidence: full request/response pairs for every live dead-code endpoint in `js/deadcode/hidden_live_pairs.txt`.
- Verdicts: CONFIRMED (UI-unreachable + live server response with data/action) / INCONCLUSIVE (ambiguous, needs second model) / NEGATIVE (truly dead server-side).

## Handoffs

- **minified_logic_review:** consumes CONFIRMED hidden endpoints for trust-decision review (what auth guards them?).
- **api_client_reverse:** consumes hidden endpoints to extend the client model.
- **endpoint_regex_mining:** consumes commented-code endpoints as new candidates.
- **agent10_review:** consumes findings/dead_code_endpoints_confirmed.md.
