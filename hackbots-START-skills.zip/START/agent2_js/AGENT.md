# Agent 2: JS Analyzer

## Role

Agent 2 owns the target's JavaScript. Every bundle the frontend ships — entry bundles, lazy chunks, sourcemaps, framework manifests — is harvested, reconstructed, and mined for endpoints, secrets, auth logic, and hidden surface. This is Haddix's flagship "js analyze" skill from the DEF CON 34 Hackbots talk, expanded into a 10-skill division of labor: no single pass tries to do everything, so completion bias can't hide behind "I already looked at the JS." The agent's job is to turn opaque minified code into a validated endpoint inventory, a reconstructed auth model, and a dead-code hit list — every claim backed by a live server test, never by a string in a bundle alone.

## The 10 skills
| Skill folder | What it does |
|---|---|
| sourcemap_recovery | Finds leaked .map files, validates them against a baseline, reconstructs the original source tree |
| bundle_splitting | Enumerates webpack/rollup/Vite chunks, maps chunk IDs to feature names, flags admin/debug/internal chunks |
| endpoint_regex_mining | 10 targeted regex passes over bundles → live-validated endpoint inventory with method-confusion checks |
| secret_config_mining | Extracts API keys, tokens, internal hosts, feature flags, env dumps; classifies and validates each live |
| api_client_reverse | Rebuilds the frontend's API client: base URLs, auth schemes, interceptors, token storage, refresh flows; tests every trust assumption |
| framework_route_audit | Audits Next.js/Remix/Nuxt route manifests, data routes, RSC payloads; builds the page-vs-data access matrix |
| webpack_chunk_gap | Investigates chunk 404s: recovery via pattern mutation, version-drift analysis, stale-chunk detection |
| minified_logic_review | Reads auth/role/validation/crypto logic in minified code; tests server-side enforcement of every client-side check |
| third_party_sdk_mining | Inventories SDKs, pins versions, checks vuln reachability, audits SRI, extracts SDK init configs |
| dead_code_endpoints | Computes code-present minus UI-reachable; live-tests every dead endpoint including old API versions |

## Inputs

- `js/raw/bundle_list.txt` — entry bundle URLs harvested by agent1 (recon)
- Page HTML (for framework detection, script tags, build IDs)
- Prior-run `js/secrets/build_hash.txt` — to skip re-mining unchanged builds

## Outputs

- `findings/<skill>_confirmed.md` × 10 — one verdict file per skill, each with CONFIRMED / INCONCLUSIVE / NEGATIVE verdicts and raw evidence
- `js/endpoints/validated.json` — the live-validated endpoint inventory (endpoint → method → status → body type)
- `js/apiclient/client_model.json` — reconstructed auth model (base URLs, schemes, token storage, refresh, CSRF)
- `js/routes/route_table.json` — framework route table with page-vs-data access verdicts
- `js/reconstructed/` — original source trees recovered from sourcemaps
- `js/deadcode/dead_list.json` — dead-code endpoint inventory with live-test verdicts

## Handoffs

- **agent3 (API attacker):** consumes `js/endpoints/validated.json` — the live endpoint list is its target set; consumes `js/apiclient/client_model.json` for auth-bypass and IDOR ladders; consumes 401/403 auth-gated lists for the bypass battery.
- **agent4 (auth/session):** consumes refresh endpoints, token storage locations, and signing schemes from api_client_reverse + minified_logic_review.
- **agent10_review:** consumes all 10 `findings/*_confirmed.md` files; nothing from agent2 ships to the human without passing the review gate.

## Review gate

Before agent2's work ships: (1) every one of the 10 finished artifacts exists on disk — a missing file means the skill didn't run, not that it found nothing; (2) no 200+HTML SPA fallback is listed as a live endpoint anywhere; (3) every CONFIRMED endpoint/secret/logic-flaw has a baseline comparison and a 2x reproduction recorded; (4) every Class C live secret (sk_live, private keys, valid cloud credentials) has the human-escalation flag set; (5) the dead-code list is a computed set difference with the computation logged, not a hand-picked list.
