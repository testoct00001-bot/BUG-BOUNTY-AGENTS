---
name: sourcemap_recovery
agent: agent2_js
description: Recover and reconstruct original source code from leaked JavaScript sourcemaps.
---

# Sourcemap Recovery

## Purpose

Production JavaScript is minified, but a shocking number of sites ship `.js.map` files — either linked from the bundle via `//# sourceMappingURL=` or directly retrievable by guessing the map URL. A leaked sourcemap hands you the original pre-minification source: full filenames, original variable names, comments, dead code, internal API paths, auth logic, and secrets that were never meant to be public. This skill finds every sourcemap on the target, reconstructs the original source tree, and turns it into a finding when the map leaks internal paths, credentials, or logic the UI hides.

## Division of labor

- **Consumes:** `js/raw/bundle_list.txt` — list of JS bundle URLs already harvested (from agent1 recon / bundle_splitting). Each line: one full bundle URL.
- **Produces:** `findings/sourcemap_recovery_confirmed.md` — for each recovered map: map URL, reconstruction status, list of reconstructed files, and any internal paths/secrets found with raw evidence. Empty with a `NEGATIVE` verdict line if no maps exist.

## When to use / when NOT to use

- **Use when:** the target ships any JS bundle; when response headers or HTML comments hint at a build pipeline (webpack, Vite, esbuild); when bundle names contain hashes (strong sourcemap-build signal).
- **Skip when (time-pass filter):** all bundles are inline `<script>` blocks with no external files; CDN-hosted third-party libraries only (maps would come from the CDN vendor, not the target — checking those is time-pass).

## Methodology

1. Download every bundle in `js/raw/bundle_list.txt` to `js/raw/`. Keep the exact filename from the URL.
2. Inspect the last 300 bytes of each bundle for `//# sourceMappingURL=` or `/*# sourceMappingURL=` comments. Record matches in `js/maps/map_hints.txt` as `<bundle_url> <map_url_hint>`.
3. For every bundle WITHOUT an inline hint, probe the guessed map URLs: `<bundle_url>.map` and `<bundle_basename_without_hash>.map`. Record HTTP status + content-type in `js/maps/map_probe_log.txt`.
4. Baseline: fetch a known-dead path on the same host (e.g. `https://<HOST>/definitely-not-a-map-xyz123.js.map`) and record its status/body fingerprint. Any "found" map must differ from this baseline — some CDNs return 200 with an error page for everything.
5. For each map URL that returns 200 with JSON content: validate it's a real sourcemap by checking for `version: 3` and a `sources` array. Discard fakes.
6. Parse the map with a script: list all `sources[]` entries, `sourcesContent[]` presence, and the `file` field. Save to `js/maps/<bundle>_sources.json`.
7. If `sourcesContent` is present: reconstruct the original tree — write each source to `js/reconstructed/<bundlename>/<path>`. This is the gold: original filenames, comments, unminified logic.
8. If `sourcesContent` is ABSENT: the `sources[]` array alone is still a finding lead — it reveals the full original directory layout, internal project names, and paths that likely exist as endpoints or static files. Extract and list them.
9. Grep the reconstructed tree (and raw map JSON) for: `api_key`, `secret`, `token`, `password`, `internal`, `staging`, `admin`, `.env`, `aws`, `firebase`, `supabase`, `stripe`, GraphQL schema strings, and internal hostnames (regex: `[a-z0-9-]+\.internal`, `10\.\d+\.\d+\.\d+`).
10. Cross-check every internal path found in `sources[]` that looks like a file route (e.g. `src/pages/admin/users.tsx`) against the live site — framework route manifests often confirm these are real URLs. Feed confirmed patterns to framework_route_audit.
11. Check for `//# debugId` or Sentry `debug_id` markers — if the app uses Sentry, map URLs may be fetchable from Sentry's CDN even when removed from the origin.
12. Re-fetch each confirmed map URL a second time (independent reproduction) and byte-compare with the first fetch.
13. Assign verdict per map: CONFIRMED (map real + contains original source or sensitive material) / INCONCLUSIVE (map real but only minified sources, needs second model run) / NEGATIVE (no maps after full probe).
14. Write `findings/sourcemap_recovery_confirmed.md` with every map URL, reconstruction status, file counts, and all extracted secrets/internal paths with evidence.

## Exact commands

Baseline (known-dead map on the same host):
```bash
curl -sS -o /dev/null -w "%{http_code} %{size_download} %{content_type}\n" \
  "https://<HOST>/no-such-map-xyz987.js.map"
```

Download bundles and check tail hints:
```bash
mkdir -p js/raw js/maps js/reconstructed
while read -r u; do
  f="js/raw/$(basename "$u" | cut -d'?' -f1)"
  curl -sS -L --max-time 60 -o "$f" "$u"
done < js/raw/bundle_list.txt
for f in js/raw/*.js; do
  echo "== $f"; tail -c 300 "$f" | grep -o 'sourceMappingURL=[^ *]*' || echo "no hint"
done | tee js/maps/map_hints.txt
```

Probe guessed map URLs (differentiate from baseline):
```bash
baseline_code=$(curl -sS -o /dev/null -w "%{http_code}" "https://<HOST>/no-such-map-xyz987.js.map")
while read -r u; do
  b=$(basename "$u" | cut -d'?' -f1)
  for m in "${u}.map" "https://<HOST>/${b}.map"; do
    code=$(curl -sS -L --max-time 30 -o /tmp/mapcheck -w "%{http_code}" "$m")
    if [ "$code" = "200" ]; then
      if grep -q '"version":[ ]*3' /tmp/mapcheck && grep -q '"sources"' /tmp/mapcheck; then
        echo "REAL $m"; cp /tmp/mapcheck "js/maps/${b}.map"
      else
        echo "FAKE200 $m (baseline-like)"
      fi
    else
      echo "MISS $code $m"
    fi
  done
done < js/raw/bundle_list.txt | tee js/maps/map_probe_log.txt
```

Reconstruct source tree from a map (python3):
```bash
python3 - <<'EOF'
import json, os, sys
mp = sys.argv[1]                      # js/maps/<name>.map
out = sys.argv[2]                     # js/reconstructed/<name>/
m = json.load(open(mp))
srcs = m.get("sources", [])
contents = m.get("sourcesContent", [])
print("version:", m.get("version"), "| sources:", len(srcs), "| contents:", len([c for c in contents if c]))
os.makedirs(out, exist_ok=True)
manifest = []
for i, s in enumerate(srcs):
    safe = s.replace("../", "__up__/").lstrip("/")
    p = os.path.join(out, safe)
    manifest.append(s)
    if i < len(contents) and contents[i]:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "w", encoding="utf-8", errors="replace").write(contents[i])
open(os.path.join(out, "MANIFEST.txt"), "w").write("\n".join(manifest))
print("reconstructed", sum(1 for c in contents if c), "files")
EOF
```

Grep reconstructed tree for secrets/internal material:
```bash
grep -rniE "api[_-]?key|secret|passwd|password|token|internal|staging|admin|firebase|supabase|\.env|aws_access|sk_live|x-api-key" \
  js/reconstructed/ --include="*.js" --include="*.ts" --include="*.tsx" --include="*.json" -l | tee js/maps/secret_hits.txt
grep -rhoE "[a-zA-Z0-9.-]+\.(internal|corp|local|lan|svc|cluster\.local)" js/reconstructed/ | sort -u | tee js/maps/internal_hosts.txt
```

Second independent re-fetch (reproduction):
```bash
curl -sS -L --max-time 60 -o /tmp/map_recheck "https://<HOST>/<path-to-map>"  # placeholder: real confirmed map URL
sha256sum /tmp/map_recheck js/maps/<bundle>.map
# maps must be byte-identical across fetches — drift means active deploys; note it
```

Sentry debug_id map recovery (when origin hides maps):
```bash
grep -oE 'debugId["'\'']? *: *["'\''][a-f0-9-]{36}' js/endpoints/corpus.txt | sort -u | tee js/maps/debug_ids.txt
# Sentry serves maps at https://browser.sentry-cdn.com/... only with auth; a debug_id in the
# bundle + public Sentry project = map fetchable. Check the project's public DSN first.
```

## Completion-bias defenses

- [ ] All bundles downloaded to js/raw/ (count matches bundle_list.txt line count)
- [ ] Tail-hint check run on every bundle; map_hints.txt written
- [ ] Guessed-map probes run for every bundle without a hint; map_probe_log.txt written
- [ ] Baseline dead-map fetched and fingerprinted BEFORE verdicts assigned
- [ ] Every 200 map response validated as real sourcemap JSON (version 3 + sources)
- [ ] sources[] extracted to _sources.json for every real map
- [ ] Reconstruction script run; MANIFEST.txt exists per map
- [ ] Secret/internal grep run over the reconstructed tree
- [ ] Each confirmed map re-fetched and byte-compared (2x reproduction)
- [ ] findings/sourcemap_recovery_confirmed.md exists with verdicts
- **Review step:** agent10_review must verify: (a) baseline dead-map fingerprint is recorded and every "real" map differs from it; (b) at least one reconstructed file sample is quoted in the findings; (c) every secret/internal path claim has the exact file + line cited.
- **Nudge prompts:**
  - "Keep going until EVERY bundle has a map verdict — the one you skip is the one that ships the map."
  - "Do not report done before findings/sourcemap_recovery_confirmed.md exists on disk with CONFIRMED/INCONCLUSIVE/NEGATIVE verdicts."
  - "A 200 status is not a finding — byte-compare against the baseline before you claim anything."
- **Finished artifact definition:** `findings/sourcemap_recovery_confirmed.md` exists and contains one verdict line per bundle in bundle_list.txt plus raw evidence (map URL + quoted excerpt) for every CONFIRMED map.

## Evidence standard

- Baseline: known-dead map URL on the same host fetched first; its status/body recorded in map_probe_log.txt header.
- Reproduction: every confirmed map fetched twice, 60+ seconds apart, byte-compared with sha256sum.
- Raw evidence: first 2000 bytes of each confirmed map + 3 reconstructed-file excerpts saved in the findings file.
- Verdicts: CONFIRMED (real map with original source or sensitive material) / INCONCLUSIVE (real map, minified-only, needs second model run) / NEGATIVE (all bundles probed, no maps).

## Handoffs

- **bundle_splitting:** consumes bundle_list.txt refinement (chunk URLs found here feed back into the map probe loop).
- **endpoint_regex_mining:** consumes js/reconstructed/ as its primary input — original source mines 10x better than minified bundles.
- **secret_config_mining:** consumes js/maps/secret_hits.txt and js/maps/internal_hosts.txt as its seed list.
- **framework_route_audit:** consumes internal page paths found in sources[] (e.g. src/pages/admin/*).
- **agent10_review:** consumes findings/sourcemap_recovery_confirmed.md for the review gate.
