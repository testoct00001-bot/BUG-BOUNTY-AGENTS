---
name: webpack_chunk_gap
agent: agent2_js
description: Analyze chunks the app requests but 404 — dead surface and version-drift signals.
---

# Webpack Chunk Gap Analysis

## Purpose

When a deployed app requests a chunk URL and gets a 404, that gap is information: it reveals the deploy pipeline (stale HTML cached at CDN referencing rotated chunk hashes), chunk naming/versioning schemes you can predict, and — critically — sometimes the 404 is a lie and the chunk exists at a slightly different path. Version drift between the HTML's chunk hashes and the actually-deployed chunks also tells you when deploys happen and whether old vulnerable chunks are still served. This skill turns every chunk 404 into either a recovered file or a documented pipeline signal.

## Division of labor

- **Consumes:** `js/chunks/chunk_404s.txt` (from bundle_splitting); the live HTML's current chunk references.
- **Produces:** `findings/webpack_chunk_gap_confirmed.md` — per-404 verdict: recovered, predictable-pattern, stale-deploy, or true-dead; plus `js/chunkgap/recovered/` for any resurrected chunks.

## When to use / when NOT to use

- **Use when:** chunk_404s.txt is non-empty; or the live page's chunk hashes differ from a cached/older copy of the page.
- **Skip when (time-pass filter):** zero chunk 404s AND chunk hashes stable across two fetches 10 minutes apart (no drift, no gaps — document and move on).

## Methodology

1. For each 404'd chunk URL, classify the 404: real 404 status? 200-with-error-page (baseline lie)? 403 (exists but gated)? Record exact status + body size in `js/chunkgap/gap_classification.txt`.
2. Baseline: fetch the known-dead chunk from bundle_splitting AND fetch one KNOWN-GOOD chunk — you need both fingerprints to classify gaps (good=200+JS, dead=404 shape, lie=200+HTML).
3. Pattern extraction: take 10 known-good chunk URLs and derive the naming scheme — is it `<id>.<hash>.js`? Is the hash full or truncated? Is `<id>` numeric or named? Write the regex in `js/chunkgap/naming_scheme.txt`.
4. For each 404'd chunk, attempt recovery via pattern mutation:
   - Strip query strings / add missing `.js`
   - Try the chunk ID with the CURRENT deploy's hash (from fresh HTML) — stale-HTML 404s often resolve with the new hash
   - Try `/_next/static/chunks/` vs `/static/js/` prefix swaps
   - Try unhashed name (`4523.js`) and named variant (`4523.admin.js`)
5. Version-drift analysis: fetch the page HTML now and again in 15 minutes. Diff the chunk hash lists. If hashes rotated: record deploy cadence signal; check whether OLD hashes still serve (stale chunk = possibly old vulnerable code still live).
6. If old hashes still serve: download the old chunk and diff against the new chunk (`diff` or hash compare). Changed modules = what the deploy fixed/added — new endpoints in the new chunk go to endpoint_regex_mining; removed code may reveal retired-but-still-live endpoints.
7. Check CDN cache headers on 404s vs 200s: `age`, `x-cache: HIT/MISS`, `cache-control`. A 404 with `x-cache: HIT` from long ago + a fresh-HTML hash = stale edge cache, not a dead chunk — retry with cache-buster `?v=<random>`.
8. Probe for chunk directory listing / predictable siblings: if chunks live at `/static/js/4523.abc.js`, test `/static/js/` listing behavior and sequential IDs (`4524.`, `4525.`) — some pipelines deploy numbered chunks predictably.
9. For each recovered chunk: run it through the endpoint_regex_mining passes (at least P1/P9) — recovered chunks are often admin/debug bundles.
10. Re-verify every "recovered" chunk with a second fetch + byte compare; re-verify every "true dead" with a cache-busted fetch.
11. Write `findings/webpack_chunk_gap_confirmed.md`: table of every 404 (URL → classification → recovery attempts → final verdict), drift analysis results, and any recovered-chunk findings.

## Exact commands

Classify every gap (need good + dead baselines first):
```bash
mkdir -p js/chunkgap/recovered
GOOD="https://<HOST>/static/js/<known-good-chunk>.js"   # from chunk_manifest.json
DEAD="https://<HOST>/static/js/9999.deadbeef.js"
for u in "$GOOD" "$DEAD"; do
  printf "%s -> " "$u"
  curl -sS -o /tmp/g -w "%{http_code} %{size_download} %{content_type}\n" --max-time 20 "$u"
done
while read -r line; do
  u=$(echo "$line" | awk '{print $2}')
  printf "%s -> " "$u"
  curl -sS -o /tmp/g -w "%{http_code} %{size_download} %{content_type}\n" --max-time 20 "$u"
done < js/chunks/chunk_404s.txt | tee js/chunkgap/gap_classification.txt
```

Derive naming scheme from good chunks:
```bash
python3 - <<'EOF'
import json, re
man = json.load(open("js/chunks/chunk_manifest.json"))
fns = [c["file"] for c in man]
print("\n".join(fns[:10]))
pats = {}
for f in fns:
    key = re.sub(r'[a-f0-9]{8,}', '<HASH>', f)
    key = re.sub(r'^\d+', '<ID>', key)
    pats[key] = pats.get(key, 0) + 1
open("js/chunkgap/naming_scheme.txt", "w").write("\n".join(f"{k} x{v}" for k, v in pats.items()))
print(pats)
EOF
```

Recovery attempts per 404'd chunk:
```bash
# <CHUNK404> = full 404'd URL, <FRESHASH> = current hash for same chunk id from fresh HTML
u="<CHUNK404>"
for v in "$u" "${u%.js}.js" "${u%%.*}.<FRESHASH>.js" "https://<HOST>/_next/static/chunks/$(basename $u)"; do
  printf "%-80s -> " "$v"
  curl -sS -o /tmp/rec -w "%{http_code} %{size_download}\n" --max-time 20 "$v" \
    && [ "$(wc -c < /tmp/rec)" -gt 1000 ] && cp /tmp/rec "js/chunkgap/recovered/$(basename $v).recovered"
done
# cache-buster retry for stale-edge 404s:
curl -sS -o /tmp/cb -w "cache-busted: %{http_code} %{size_download}\n" --max-time 20 "${u}?v=$(date +%s)"
```

Version-drift check:
```bash
curl -sS "https://<HOST>/" -o /tmp/html1.html
sleep 900
curl -sS "https://<HOST>/" -o /tmp/html2.html
grep -oE '[a-f0-9]{8,}\.js' /tmp/html1.html | sort -u > /tmp/h1.txt
grep -oE '[a-f0-9]{8,}\.js' /tmp/html2.html | sort -u > /tmp/h2.txt
diff /tmp/h1.txt /tmp/h2.txt && echo "NO DRIFT" || echo "DRIFT DETECTED"
# do old hashes still serve?
while read -r old; do
  grep -q "$old" /tmp/h2.txt || {
    printf "old chunk %s -> " "$old"
    curl -sS -o /dev/null -w "%{http_code} %{size_download}\n" --max-time 20 "https://<HOST>/static/js/${old}"
  }
done < /tmp/h1.txt | tee js/chunkgap/stale_chunk_check.txt
```

CDN cache header inspection:
```bash
curl -sSI --max-time 20 "<CHUNK404>" | grep -iE "^(HTTP|age|x-cache|cache-control|cf-cache-status):"
```

Sequential-ID probing (predictable numeric chunk schemes):
```bash
# if naming scheme is <ID>.<HASH>.js with numeric IDs: probe neighbors of known IDs
for id in 4520 4521 4522 4526 4527 4528; do
  printf "chunk %s -> " "$id"
  curl -sS -o /dev/null -w "%{http_code} %{size_download}\n" --max-time 15 \
    "https://<HOST>/static/js/${id}.<FRESHASH>.js"
done | tee js/chunkgap/sequential_probe.txt
# any 200 here is an unlisted chunk — download and mine it
```

## Completion-bias defenses

- [ ] Every 404 classified against good+dead baselines (gap_classification.txt)
- [ ] Naming scheme derived from ≥10 good chunks
- [ ] Recovery mutations attempted for every 404 (log shows each variant tried)
- [ ] Cache-busted retry done for stale-edge-suspect 404s
- [ ] Version-drift check completed (two HTML fetches 15 min apart, diffed)
- [ ] Old-hash liveness checked where drift detected; old-vs-new diffed
- [ ] CDN cache headers inspected for 404s
- [ ] Sequential/predictable sibling IDs probed where scheme allows
- [ ] Recovered chunks mined with endpoint regex passes
- [ ] All recoveries + true-deads verified 2x
- [ ] findings/webpack_chunk_gap_confirmed.md exists
- **Review step:** agent10_review must verify: (a) every 404 in chunk_404s.txt has a classification row; (b) "true dead" verdicts show the cache-busted retry; (c) any recovered chunk's mining results are attached.
- **Nudge prompts:**
  - "Keep going until every 404 has a classification AND a recovery log — an unclassified 404 is unfinished work."
  - "Do not report done before findings/webpack_chunk_gap_confirmed.md exists on disk."
  - "A 404 with an old hash is a stale deploy, not a dead file. Swap in the fresh hash before you give up."
- **Finished artifact definition:** `findings/webpack_chunk_gap_confirmed.md` with the per-404 table, drift analysis, stale-chunk results, and recovered-chunk mining notes.

## Evidence standard

- Baseline: known-good chunk + known-dead chunk fingerprints captured first.
- Reproduction: every recovery and every true-dead verified twice (second fetch cache-busted).
- Raw evidence: gap_classification.txt + drift diff + one recovered chunk's first 50 lines in the findings file.
- Verdicts: CONFIRMED (recovered chunk with sensitive content) / INCONCLUSIVE (pattern unclear, needs second model) / NEGATIVE (true dead after all mutations + cache-bust).

## Handoffs

- **endpoint_regex_mining:** consumes js/chunkgap/recovered/ chunks + new endpoints from old-vs-new diffs.
- **sourcemap_recovery:** consumes recovered chunk URLs for map probing.
- **dead_code_endpoints:** consumes retired-but-still-live endpoints found in old chunks.
- **agent10_review:** consumes findings/webpack_chunk_gap_confirmed.md.
