---
name: third_party_sdk_mining
agent: agent2_js
description: Identify third-party SDKs in bundles, check versions for known vulns, mine SDK-internal endpoints.
---

# Third-Party SDK Mining

## Purpose

Apps bundle dozens of third-party SDKs: analytics, chat widgets, payment processors, auth providers (Auth0, Okta, Firebase Auth), error trackers, A/B testing. Each SDK is versioned code with a public changelog — old versions have known CVEs and known misconfigurations. SDKs also phone home to their own endpoints, and their init configs often leak tenant IDs and keys. This skill inventories every SDK, pins its version, checks it against known vulnerability data, and extracts SDK-internal endpoints the app exposes.

## Division of labor

- **Consumes:** `js/raw/*.js`, `js/chunks/files/*.js` (vendor chunks especially); `js/secrets/*` SDK init configs.
- **Produces:** `findings/third_party_sdk_mining_confirmed.md` — SDK inventory: name → version → vuln status → exposed endpoints; plus `js/sdks/inventory.json`.

## When to use / when NOT to use

- **Use when:** vendor chunks exist; HTML loads third-party scripts; SDK init calls found in secret mining.
- **Skip when (time-pass filter):** the app is fully self-hosted with zero third-party scripts AND zero SDK imports (verify with a script-src + import audit first).

## Methodology

1. Enumerate external script sources: parse all `<script src>` from HTML + dynamic `import(` URLs + `document.createElement('script')` injections in bundles. Record vendor domains in `js/sdks/external_scripts.txt`.
2. Identify SDKs in bundles: regex for known SDK markers — `auth0`, `firebase`, `okta`, `stripe`, `intercom`, `segment`, `amplitude`, `sentry`, `datadog`, `launchdarkly`, `algolia`, `cloudinary`, `braintree`, `paypal`, `zendesk`, `drift`, `hubspot`, `onetrust`. Also generic: `VERSION\s*=\s*["']\d+\.\d+` near SDK names.
3. Pin versions: SDKs usually expose `SDK_VERSION`, `version: "x.y.z"`, or a banner comment (`/*! auth0-spa-js v2.1.3 */`). Extract exact version per SDK into `js/sdks/inventory.json`. If no version found, record `version: unknown` and note the file hash for later diffing.
4. Vulnerability check per SDK (offline knowledge + live check):
   - Search local knowledge: known CVE patterns per SDK (e.g. old `auth0-spa-js` token leakage, `firebase` <v9 open rules, `lodash` prototype pollution if bundled, `moment` ReDoS, `jquery` <3.5 XSS).
   - For each SDK with a pinned version, record the check: `SDK name, version, known-issue-query, result`. Do NOT claim a CVE without verifying the vulnerable code path is actually reachable in this app's usage.
5. Extract SDK init configs: `auth0.createAuth0Client({domain, clientId})`, `firebase.initializeApp({...})`, `oktaAuth({issuer, clientId})`, `stripe = Stripe("pk_...")`, `intercomSettings = {app_id}`. Tenant IDs + domains are recon gold (Auth0 tenant → try the tenant's `/authorize` directly; Firebase project → database check).
6. Mine SDK-internal endpoints: SDKs call their own APIs — extract every `https://<sdk-domain>/...` URL from the bundle. Some are app-configurable (webhook URLs, callback URLs) — those may point at internal app endpoints.
7. Check SDK script integrity: does the HTML use `integrity=` (SRI) on third-party scripts? Missing SRI on a third-party script = compromise-of-vendor → XSS-on-target chain. List every external script without SRI.
8. Check for SDK debug/test modes: `debug: true`, `testMode`, `__DEV__`, staging SDK endpoints (`*.sandbox.*`, `*-test.*`) — test-mode SDKs often have relaxed validation.
9. Decision branch: if an SDK version has a known vuln AND the vulnerable function is called in the app's code (not just present in the bundle), escalate: demonstrate reachability with a minimal PoC request. If the vulnerable code is present but never called, mark INCONCLUSIVE with the call-graph note.
10. Re-verify version pins by re-extracting from a fresh bundle fetch (2x reproduction of inventory).
11. Write `findings/third_party_sdk_mining_confirmed.md`: inventory table, vuln check results, init-config findings, missing-SRI list, SDK endpoint list.

## Exact commands

Enumerate external scripts + SDK markers:
```bash
mkdir -p js/sdks
curl -sS "https://<HOST>/" -o /tmp/idx.html
grep -oE '<script[^>]+src="[^"]+"' /tmp/idx.html | grep -oE 'src="[^"]+"' | sort -u | tee js/sdks/external_scripts.txt
grep -oiE '(auth0|firebase|okta|stripe|intercom|segment|amplitude|sentry|datadog|launchdarkly|algolia|cloudinary|braintree|paypal|zendesk|drift|hubspot|mixpanel|posthog)[^"'"'"' ]{0,30}' \
  js/endpoints/corpus.txt | sort | uniq -c | sort -rn | tee js/sdks/sdk_markers.txt
```

Pin versions:
```bash
python3 - <<'EOF'
import re, json, glob
inv = {}
corpus = open("js/endpoints/corpus.txt", encoding="utf-8", errors="replace").read()
patterns = {
    "auth0-spa-js": r'auth0-spa-js[^0-9]*v?(\d+\.\d+\.\d+)',
    "firebase": r'firebase[^0-9]*?(\d+\.\d+\.\d+)',
    "stripe-js": r'stripe\.js[^0-9]*v?(\d+)',
    "sentry": r'@sentry\/[^0-9]*?(\d+\.\d+\.\d+)',
    "lodash": r'lodash[^0-9]*?(\d+\.\d+\.\d+)',
    "jquery": r'jQuery v?(\d+\.\d+\.\d+)',
    "moment": r'moment[^0-9]*?(\d+\.\d+\.\d+)',
}
for name, pat in patterns.items():
    ms = sorted(set(re.findall(pat, corpus, re.I)))
    if ms:
        inv[name] = {"versions_found": ms}
json.dump(inv, open("js/sdks/inventory.json", "w"), indent=2)
print(json.dumps(inv, indent=2))
# banner comments often carry versions:
EOF
grep -oE '/\*! *[a-zA-Z0-9_@/-]+ v?[0-9]+\.[0-9]+\.[0-9]+' js/raw/*.js js/chunks/files/*.js 2>/dev/null | sort -u | tee js/sdks/banner_versions.txt
```

Extract SDK init configs:
```bash
grep -oE '.{0,40}(createAuth0Client|initializeApp|OktaAuth|Stripe\(|intercomSettings|algoliasearch).{0,200}' \
  js/endpoints/corpus.txt | sort -u | tee js/sdks/init_configs.txt | head -30
```

SDK-internal endpoints:
```bash
grep -oE 'https://[a-zA-Z0-9.-]*(auth0|firebaseio|okta|stripe|intercom|segment|amplitude|sentry|algolia)[a-zA-Z0-9.-]*/[^"'"'"' ]*' \
  js/endpoints/corpus.txt | sort -u | tee js/sdks/sdk_endpoints.txt
```

Missing-SRI audit:
```bash
python3 - <<'EOF'
import re
html = open("/tmp/idx.html").read()
for m in re.finditer(r'<script[^>]+>', html):
    tag = m.group(0)
    src = re.search(r'src="([^"]+)"', tag)
    if src and ("http" in src.group(1) or src.group(1).startswith("//")):
        sri = "integrity=" in tag
        print(("OK  " if sri else "MISS"), src.group(1)[:100])
EOF
```

Test-mode detection:
```bash
grep -oiE '.{0,30}(debug *: *true|testMode *: *true|sandbox|__DEV__).{0,30}' \
  js/endpoints/corpus.txt | sort -u | tee js/sdks/testmode_hits.txt
```

SDK callback/redirect URL hijack check:
```bash
# auth SDKs take redirect_uri / callbackURL — extract and check if attacker-controllable:
grep -oE '.{0,40}(redirect_uri|redirectUri|callbackURL|returnTo|postLogoutRedirect).{0,120}' \
  js/endpoints/corpus.txt | sort -u | tee js/sdks/redirect_configs.txt | head -20
# if the value is built from location.* or a query param, test with an evil domain (record only — open redirect needs live test by agent3)
grep -oE 'redirect_uri.{0,60}(location|search|query|param)' js/sdks/redirect_configs.txt | tee js/sdks/redirect_dynamic.txt
```

Offline vuln cross-reference (no network needed):
```bash
# for each pinned version, record the check query for the human/agent10 — never claim from memory alone:
python3 - <<'EOF'
import json
inv = json.load(open("js/sdks/inventory.json"))
for name, d in inv.items():
    for v in d["versions_found"]:
        print(f"{name}@{v} -> check: CVE database / osv.dev query '{name} {v} vulnerability'")
EOF
```

## Completion-bias defenses

- [ ] External script sources enumerated (external_scripts.txt)
- [ ] SDK markers swept; inventory.json built with version pins (or explicit "unknown")
- [ ] Banner-comment version pass run
- [ ] Per-SDK vuln check recorded with reachable-code-path analysis (not just presence)
- [ ] SDK init configs extracted (tenant IDs/domains listed)
- [ ] SDK-internal endpoints extracted
- [ ] SRI audit completed for every external script
- [ ] Test/debug mode sweep run
- [ ] Version pins re-verified from fresh fetch (2x)
- [ ] findings/third_party_sdk_mining_confirmed.md exists
- **Review step:** agent10_review must verify: (a) no CVE claimed without a reachable code path in the app's own usage; (b) every version pin cites the file + pattern that produced it; (c) missing-SRI entries quote the actual script tag.
- **Nudge prompts:**
  - "Keep going until every SDK has a version pin or an explicit 'unknown' — unversioned SDKs are unfinished work."
  - "Do not report done before findings/third_party_sdk_mining_confirmed.md exists on disk."
  - "Presence is not vulnerability. Show the app CALLS the vulnerable function before you claim anything."
- **Finished artifact definition:** `findings/third_party_sdk_mining_confirmed.md` with the inventory table, per-SDK vuln verdicts with reachability notes, init configs, SRI audit, and SDK endpoint list.

## Evidence standard

- Baseline: version strings extracted from two independent fetches and compared.
- Reproduction: version pins re-verified 2x; any reachability PoC run twice.
- Raw evidence: init config excerpts + script tags (for SRI) quoted verbatim in the findings file.
- Verdicts: CONFIRMED (vuln version + reachable path, or live misconfigured SDK) / INCONCLUSIVE (version unknown or path unclear, needs second model) / NEGATIVE (current versions, SRI present, no misconfig).

## Handoffs

- **secret_config_mining:** consumes SDK init configs (tenant IDs, keys) for validation.
- **endpoint_regex_mining:** consumes SDK-internal app-configurable endpoints (webhooks, callbacks).
- **dead_code_endpoints:** consumes SDK-gated features (chat widget admin panels, etc.).
- **agent10_review:** consumes findings/third_party_sdk_mining_confirmed.md.
