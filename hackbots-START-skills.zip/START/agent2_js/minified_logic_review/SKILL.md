---
name: minified_logic_review
agent: agent2_js
description: Read auth, validation, and role logic in minified code for client-side trust flaws.
---

# Minified Logic Review

## Purpose

Minified code is unreadable at a glance — which is exactly why developers hide trust decisions in it: `isAdmin` flags from JWT claims, role checks that never hit the server, input validation that exists only in the UI, price/quantity logic computed client-side, "encrypted" tokens that are just base64. This skill teaches the agent to read minified auth/validation/role logic systematically: beautify, locate the trust decisions, trace their inputs, and test whether the server actually enforces what the client claims.

## Division of labor

- **Consumes:** `js/reconstructed/**` (preferred — original source) or beautified minified bundles; `js/apiclient/client_model.json` (client-side checks list); template-literal endpoints with `:param` placeholders.
- **Produces:** `findings/minified_logic_review_confirmed.md` — trust-decision inventory: each client-side check → what it gates → server-enforcement test result; plus `js/logic/trust_decisions.json`.

## When to use / when NOT to use

- **Use when:** reconstructed source or bundles contain role/auth/validation keywords; client_model.json lists client-side checks; the app has roles (admin/user) or sensitive actions (payment, export, delete).
- **Skip when (time-pass filter):** no auth concepts in the app at all (pure marketing site — verify with a keyword count first, don't assume).

## Methodology

1. Keyword sweep: count occurrences of `isAdmin|is_admin|role|roles|permission|hasPermission|can[A-Z]|authorize|guard|validate|sanitize|encrypt|decrypt|token|jwt|claim` in the corpus. If total < 5, document NEGATIVE and stop (don't review noise).
2. Beautify the top 3 files by keyword density: use python3 `jsbeautifier` if available, else a newline-insertion pass (`;` → `;\n`, `{` → `{\n`). Save to `js/logic/beautified/`. (Never rely on memory of the minified text — always work from the beautified copy.)
3. Extract every trust decision with 300 chars of context into `js/logic/trust_decisions.json`: `{id, file, line, code_excerpt, gates_what, inputs[], server_check_observed?}`.
4. Classify each decision:
   - **T1 — Role from token claims:** `user.role === 'admin'`, `jwt.decode(...).isAdmin` — the server must re-verify; test by calling the gated endpoint with a non-admin session / no session.
   - **T2 — UI-only gating:** `if (isAdmin) showButton` / route guards — find the underlying API endpoint and test it directly unauthenticated.
   - **T3 — Client-side validation:** `if (amount > 0)`, regex email checks, `maxLength` — test the API with invalid values (negative amounts, overlong strings, type confusion).
   - **T4 — Client-side crypto:** `CryptoJS.AES.encrypt(data, "hardcoded")`, `btoa(password)`, `md5(...)` — extract the key/algorithm; if the key is in the bundle, the "encryption" is obfuscation.
   - **T5 — Feature/flag gating:** `if (flags.newBilling)` — find what the flag unlocks and test the endpoint directly.
5. For T1/T2: build the server-enforcement test matrix. For each gated endpoint: request it (a) unauthenticated, (b) with a low-privilege context if available, (c) with tampered role indicators if the client sends any (`X-Role: admin`, `?role=admin`, cookie `role=admin`). Record the matrix in `js/logic/enforcement_matrix.txt`.
6. For T3: pick the 3 highest-impact validations (payment amounts, quantities, IDs) and send boundary violations: negative, zero, oversized, wrong-type (string where number expected), and array-where-scalar. Record server responses — 200 with acceptance = validation missing server-side.
7. For T4: if a hardcoded key is found, demonstrate decryptability offline (decrypt a sample ciphertext from the bundle with the extracted key) — do NOT decrypt live user data. Record as CONFIRMED obfuscation.
8. Trace data flow for the top 5 decisions: where does the input come from? (JWT claim → who sets it? localStorage → who writes it? URL param → user-controlled?) User-controlled inputs feeding trust decisions are the highest priority.
9. Decision branch: if reconstructed source exists, prefer it — minified review is the fallback. If BOTH are thin (< 5 decisions total), pivot: the app's trust logic is server-side; note it and hand enforcement testing to the API-focused agents.
10. Re-run the 3 highest-impact enforcement tests a second time (2x reproduction).
11. Write `findings/minified_logic_review_confirmed.md`: decision inventory table, enforcement matrix results, validation-bypass results, crypto findings, data-flow notes.

## Exact commands

Keyword density sweep:
```bash
mkdir -p js/logic/beautified
grep -oE 'isAdmin|is_admin|["'\'']role["'\'']|hasPermission|can[A-Z][a-z]+|authorize|jwt|claim' \
  js/endpoints/corpus.txt | sort | uniq -c | sort -rn | tee js/logic/keyword_counts.txt
```

Beautify top files (python3, no external deps):
```bash
python3 - <<'EOF'
import re, glob, os
cands = []
for f in glob.glob("js/chunks/files/*.js") + glob.glob("js/raw/*.js"):
    t = open(f, encoding="utf-8", errors="replace").read()
    hits = len(re.findall(r'isAdmin|role|permission|authorize|jwt|validate|encrypt', t))
    cands.append((hits, f))
cands.sort(reverse=True)
os.makedirs("js/logic/beautified", exist_ok=True)
for hits, f in cands[:3]:
    t = open(f, encoding="utf-8", errors="replace").read()
    b = t.replace(";", ";\n").replace("{", "{\n").replace("}", "\n}\n")
    b = re.sub(r'\n{3,}', '\n\n', b)
    out = "js/logic/beautified/" + os.path.basename(f) + ".beautified.js"
    open(out, "w").write(b)
    print(hits, f, "->", out, len(b), "chars")
EOF
```

Extract trust decisions with context:
```bash
grep -n -oE '.{0,150}(isAdmin|user\.role|hasPermission|can[A-Z][a-zA-Z]+|role *===? *["'\''][^"'\'']+["'\'']).{0,150}' \
  js/logic/beautified/*.js | head -60 | tee js/logic/trust_decisions_raw.txt
grep -n -oE '.{0,120}(CryptoJS\.(AES|SHA|MD5|Hmac)|btoa\(|atob\(|encrypt\().{0,120}' \
  js/logic/beautified/*.js | head -30 | tee js/logic/crypto_raw.txt
```

T1/T2 enforcement matrix (example for one gated endpoint <EP>):
```bash
EP="<GATED_EP>"
printf "unauthenticated: "; curl -sS -o /dev/null -w "%{http_code}\n" "https://<HOST>${EP}"
printf "X-Role admin:    "; curl -sS -o /dev/null -w "%{http_code}\n" -H "X-Role: admin" "https://<HOST>${EP}"
printf "?role=admin:     "; curl -sS -o /dev/null -w "%{http_code}\n" "https://<HOST>${EP}?role=admin"
printf "cookie role:     "; curl -sS -o /dev/null -w "%{http_code}\n" -H "Cookie: role=admin" "https://<HOST>${EP}"
```

T3 validation bypass probes:
```bash
# adjust <EP> and field names to the observed API; examples:
curl -sS -X POST "https://<HOST><EP>" -H "Content-Type: application/json" \
  -d '{"amount":-100}' -w "\nnegative-amount: %{http_code}\n"
curl -sS -X POST "https://<HOST><EP>" -H "Content-Type: application/json" \
  -d '{"quantity":"ten"}' -w "\ntype-confusion: %{http_code}\n"
curl -sS -X POST "https://<HOST><EP>" -H "Content-Type: application/json" \
  -d '{"id":["1","2"]}' -w "\narray-for-scalar: %{http_code}\n"
```

T4 offline decryptability demo (sample ciphertext FROM the bundle only):
```bash
python3 - <<'EOF'
# <KEY> and <CIPHERTEXT> extracted verbatim from the bundle — never live user data
from Crypto.Cipher import AES  # or pure-python fallback
import base64
key = b"<KEY_FROM_BUNDLE>"
ct = base64.b64decode("<CIPHERTEXT_FROM_BUNDLE>")
print("decrypts to:", AES.new(key, AES.MODE_ECB).decrypt(ct)[:64])
EOF
```

Dangerous-sink sweep (eval / innerHTML / prototype pollution near trust decisions):
```bash
grep -n -oE '.{0,80}(eval\(|new Function\(|innerHTML *=[^=]|document\.write\(|__proto__|constructor\.prototype).{0,80}' \
  js/logic/beautified/*.js | head -30 | tee js/logic/dangerous_sinks.txt
# any sink within 500 chars of a trust decision = review priority:
python3 - <<'EOF'
import re
trust = open("js/logic/trust_decisions_raw.txt").read()
sinks = open("js/logic/dangerous_sinks.txt").read()
print("trust decisions:", len(trust.splitlines()), "| dangerous sinks:", len(sinks.splitlines()))
print("if sinks > 0 near auth code, trace data flow before claiming anything")
EOF
```

## Completion-bias defenses

- [ ] Keyword sweep run; density counts recorded; <5 → documented NEGATIVE stop
- [ ] Top 3 files beautified to js/logic/beautified/
- [ ] Trust decisions extracted with context (trust_decisions_raw.txt)
- [ ] Every decision classified T1–T5
- [ ] T1/T2: enforcement matrix tested per gated endpoint (unauth + tampered-role variants)
- [ ] T3: top 3 validations probed with boundary violations
- [ ] T4: hardcoded keys demonstrated decryptable offline (bundle samples only)
- [ ] Data flow traced for top 5 decisions (input origin identified)
- [ ] 3 highest-impact tests reproduced 2x
- [ ] findings/minified_logic_review_confirmed.md exists
- **Review step:** agent10_review must verify: (a) every T1/T2 claim has the enforcement matrix row with baseline; (b) no "client-side check" is claimed as a vulnerability without a server-side test; (c) T4 demos used bundle samples only, never live data.
- **Nudge prompts:**
  - "Keep going until every trust decision has a classification AND a server-side test — an untested decision is a guess."
  - "Do not report done before findings/minified_logic_review_confirmed.md exists on disk."
  - "The client is the attacker. If the check lives in JavaScript, assume it's bypassable until the server proves otherwise."
- **Finished artifact definition:** `findings/minified_logic_review_confirmed.md` with the decision inventory, enforcement matrix, validation-bypass results, crypto findings, and verdicts per decision.

## Evidence standard

- Baseline: unauthenticated request to each gated endpoint before tampered-role variants.
- Reproduction: 3 highest-impact enforcement tests run twice.
- Raw evidence: full request/response pairs for every enforcement differential in `js/logic/enforcement_pairs.txt`.
- Verdicts: CONFIRMED (server fails to enforce — differential vs baseline) / INCONCLUSIVE (needs authenticated low-priv session, second model) / NEGATIVE (server enforces correctly).

## Handoffs

- **dead_code_endpoints:** consumes T2 UI-gated endpoints that the server actually serves.
- **api_client_reverse:** consumes T4 crypto findings for the client auth model.
- **endpoint_regex_mining:** consumes T3 validation-bypass endpoints for deeper parameter testing.
- **agent10_review:** consumes findings/minified_logic_review_confirmed.md.
