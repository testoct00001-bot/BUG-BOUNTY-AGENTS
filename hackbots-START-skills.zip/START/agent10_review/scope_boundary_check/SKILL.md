---
name: scope_boundary_check
agent: agent10_review
description: Verifies every tested asset is in scope before testing starts — the scope-drift guard that runs before any probe fires and re-checks every newly discovered host.
---

# Scope Boundary Check

## Purpose

Out-of-scope testing is the fastest way to get banned from a program and the slowest way to waste a hunt. This skill is the gate that runs before any probe fires: it pulls the program's declared scope, normalizes it into a machine-checkable allowlist, and verifies every planned target against it. It also guards against scope drift mid-hunt — every newly discovered subdomain, IP, or API host is re-checked before a single probe touches it. Scope is not a document you read once; it is a check that runs on every target, every time.

## Division of labor

- **Consumes:** the program's scope definition (HackerOne policy page, Bugcrowd brief, or program page text saved to `scope/program_scope_raw.md`), and the list of planned/discovered targets
- **Produces:** the finished artifact — `review/scope_manifest.md` containing the normalized allowlist, the exclusion list, the unclear list, and a per-target verdict table; recon and testing agents consume it as their allowlist

## When to use / when NOT to use

- **Use when:** a hunt starts against a new program; before any testing agent's first probe; whenever recon discovers a new subdomain, IP, CIDR, or API host mid-hunt; when the program updates its scope (re-pull and re-verify)
- **Skip when (time-pass filter):** never skipped at hunt start. The only "skip" is per-target: assets already verified in the current manifest are not re-checked — but any asset NOT in the manifest is blocked until checked. There is no default-allow.

## Methodology

1. Pull the program's scope: fetch the policy/brief page and save the raw text to `scope/program_scope_raw.md` with the retrieval date. Scope from memory or from an aggregator is not scope — only the program's own page counts.
2. Extract in-scope assets into three lists: domains (with wildcard semantics noted), IP ranges/CIDRs, and special assets (mobile apps, APIs, specific URLs). Preserve the program's exact wording next to each normalized entry.
3. Extract exclusions into their own list: out-of-scope domains, "do not test" notes, rate-limit and social-engineering prohibitions, and any "testing of X is forbidden" clauses. Exclusions are as important as inclusions.
4. Normalize every entry: lowercase domains, strip schemes/paths/ports, expand `*.example.com` to "all subdomains of example.com, any depth" (unless the program says otherwise), convert CIDRs to ranges. Ambiguous entries (`example.com and related properties`) go to the UNCLEAR list, not the allowlist.
5. Build the verdict table: for each planned target, check membership and write ALLOW / DENY / UNCLEAR with the matching scope rule quoted. A target matching no rule is DENY by default — scope is allowlist-only.
6. Handle the hard cases explicitly:
   - **CDN/WAF IPs:** testing the IP directly when the domain is in scope — allowed only if the program's scope includes IPs or says "any asset serving the domain." Otherwise UNCLEAR.
   - **Third-party services:** the target loads scripts/APIs from a third party (analytics, auth providers) — the third party is out of scope unless explicitly listed. Probing the integration point on the in-scope host is fine; attacking the third party is not.
   - **Acquired/partner domains:** discovered via cert logs but not in the program's list → UNCLEAR, never assumed in.
   - **Wildcard scope:** `*.example.com` covers `a.b.example.com` at any depth unless the program limits depth — note the interpretation in the manifest.
7. Scope-drift guard (mid-hunt): recon agents must submit every newly discovered host to this check before probing. Maintain `review/scope_drift_log.md` — every new host, its verdict, timestamp. A host probed before its verdict is logged is a scope violation; flag it in the audit trail.
8. Re-verification triggers: program scope page changes (re-pull monthly or when the program announces), new asset classes appear (mobile app added), or the hunt pivots to a new target set. Each re-verification appends a dated section to the manifest; old verdicts are never silently edited.
9. UNCLEAR handling: list the exact ambiguity, propose the conservative interpretation, and route to the human for a yes/no before any testing. Testing an UNCLEAR asset without human approval is a scope violation, full stop.
10. Write the manifest: program name, scope-source URL + retrieval date, normalized allowlist, exclusions, unclear list, per-target verdict table, drift log pointer, and the re-verification schedule.
11. Dangling-DNS marking: for every in-scope subdomain, check for dangling CNAMEs (pointing at unclaimed third-party services). The domain is still in scope, but any takeover-shaped test affects a third party → mark TAKEOVER-SENSITIVE in the manifest and require human approval before any claim-shaped request.
12. IPv6 coverage: if the program lists IPv4 CIDRs, check whether the scope text mentions IPv6. Silent on v6 → every IPv6 target is UNCLEAR until the human or the program clarifies. Do not assume v4 scope covers v6.
13. Enumeration is not exemption: recon-discovered subdomains under a wildcard ARE covered by the wildcard rule, but each one still gets a drift-log entry before probing (step 7). Coverage by a rule never skips the logging step — the log is the proof.

**Decision branches:** if the program has no published scope page → the entire hunt is UNCLEAR: do not test anything, escalate to human. If scope says "all subdomains" but excludes a named subdomain → the exclusion wins, list it in DENY. If a target is an IP that reverse-resolves to an in-scope domain → still DENY unless IPs are in scope; note the reasoning.

## Exact commands

Pull and freeze the scope source:

```bash
mkdir -p scope
curl -s --max-time 30 "<program-policy-url>" -o scope/program_scope_raw.md
wc -l scope/program_scope_raw.md && date -u >> scope/program_scope_raw.md
```

Normalize and check a target against the allowlist (domains):

```bash
TARGET="<target-host>"
# allowlist lives in review/scope_manifest.md as bare domains, one per line under "## Allowlist"
grep -qxF "$TARGET" scope/allowlist.txt && echo ALLOW_EXACT && exit 0
# wildcard match: strip leftmost labels and test parent domains
h="$TARGET"; while [[ "$h" == *.* ]]; do h="${h#*.}";
  grep -qxF "*.$h" scope/allowlist.txt && { echo "ALLOW_WILDCARD via *.$h"; exit 0; }; done
echo DENY_NO_MATCH
```

CIDR membership check for IP targets:

```bash
python3 -c "
import ipaddress, sys
ip = ipaddress.ip_address('<target-ip>')
nets = [l.strip() for l in open('scope/cidr_allowlist.txt') if l.strip()]
print('ALLOW_CIDR' if any(ip in ipaddress.ip_network(n) for n in nets) else 'DENY_NO_CIDR_MATCH')
"
```

Resolved-IP verification (the IP behind the host must also be in scope):

```bash
python3 -c "
import ipaddress, socket
ip = ipaddress.ip_address(socket.gethostbyname('<target-host>'))
nets = [l.strip() for l in open('scope/cidr_allowlist.txt') if l.strip()]
print('IP', ip, '->', 'ALLOW_CIDR' if any(ip in ipaddress.ip_network(n) for n in nets) else 'DENY_NO_CIDR_MATCH')
"
# dangling-CNAME check for takeover-sensitive marking
dig +short "<subdomain>" CNAME
```

Scope-drift log entry (every newly discovered host, before probing):

```bash
echo "$(date -u +%FT%TZ) <new-host> <ALLOW|DENY|UNCLEAR> <matching-rule>" >> review/scope_drift_log.md
```

Detect probes that fired before their scope verdict (audit cross-check):

```bash
# every host in run logs must appear in the drift log with an earlier-or-equal timestamp
comm -23 <(grep -oE 'https?://[a-zA-Z0-9.-]+' <run-log> | cut -d/ -f3 | sort -u) \
         <(awk '{print $2}' review/scope_drift_log.md | sort -u)
# any output above = host probed without a scope verdict -> violation
```

Drift-log backfill check (run before the hunt's first probe wave):

```bash
# every host in the recon target list must already have a drift-log line
comm -23 <(sort -u scope/targets.txt) <(awk '{print $2}' review/scope_drift_log.md | sort -u)
# any output above = target with no verdict yet -> do not probe until logged
```

## Completion-bias defenses

- [ ] Scope pulled from the program's own page and frozen with retrieval date — not from memory
- [ ] Allowlist, exclusions, and unclear lists built as three separate lists
- [ ] Every entry normalized (lowercase, no scheme/path, wildcard semantics noted)
- [ ] Per-target verdict table complete: every planned target has ALLOW/DENY/UNCLEAR with the matching rule quoted
- [ ] Default-deny applied: no rule match = DENY, never assumed in
- [ ] Hard cases adjudicated explicitly (CDN IPs, third parties, partner domains, wildcard depth)
- [ ] Scope-drift log created and every mid-hunt discovery logged BEFORE probing
- [ ] Cross-check run: no host in run logs without a prior drift-log verdict
- [ ] UNCLEAR items routed to human with the conservative interpretation proposed — none tested without approval
- [ ] Re-verification schedule written into the manifest
- [ ] Dangling-CNAME check done on in-scope subdomains; takeover-sensitive ones flagged for human approval
- [ ] IPv6 coverage determined (in scope, or silent → UNCLEAR)
- [ ] IP targets verified against CIDR allowlist via live DNS resolution
- [ ] Every recon-discovered host has a drift-log entry — none probed on wildcard-coverage alone
- **Review step:** the human reviews the manifest before the hunt's first probe wave. The manifest is the hunt's license to test — no manifest, no probes.
- **Nudge prompts:**
  - "Keep going until every planned target has a verdict row. A target with no row is a target you plan to test out of scope."
  - "Do not put an ambiguous asset in ALLOW because testing it would be convenient. Ambiguous is UNCLEAR, and UNCLEAR waits for the human."
  - "Re-check the scope page before every new hunt round. Programs change scope silently; last month's manifest is not this month's permission."
  - "A subdomain covered by a wildcard still gets a drift-log line. The log is the proof you checked; the wildcard is just the answer."
- **Finished artifact definition:** `review/scope_manifest.md` with program name, scope-source URL + retrieval date, normalized allowlist, exclusions, unclear list, per-target verdict table (ALLOW/DENY/UNCLEAR + matching rule quoted), drift-log pointer, and re-verification schedule. Every planned target verdict-ed = done.

## Evidence standard

- Baseline: the frozen `scope/program_scope_raw.md` is the baseline — every verdict quotes the rule it matched, so the reasoning is auditable.
- Reproduction: any agent can re-run the membership checks above and must get the same verdicts; the manifest records the exact normalized lists used.
- Raw evidence: the raw scope page text is kept verbatim; verdicts never rest on paraphrase.
- Verdicts: ALLOW (rule matched, quoted) / DENY (no match, or exclusion matched) / UNCLEAR (ambiguous — human decides). No "probably fine."

## Handoffs

- **All recon and testing agents** consume the manifest as their allowlist: no probe fires at a host without an ALLOW verdict in the manifest or drift log.
- **completion_checklist_audit** consumes the drift log: the "no probe before verdict" cross-check is an audit item for every testing skill.
- **The human** consumes the manifest (pre-hunt approval) and the UNCLEAR list (yes/no decisions).
- **hunt_debrief** consumes the drift log and any violations: scope discipline is a debrief metric.
