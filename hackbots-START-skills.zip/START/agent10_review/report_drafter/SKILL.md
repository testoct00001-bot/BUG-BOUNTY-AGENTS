---
name: report_drafter
agent: agent10_review
description: Drafts bug-bounty writeups that get triaged fast — title, summary, exact steps, quantified impact, remediation; structured for busy triagers.
---

# Report Drafter

## Purpose

The best finding in the world earns $0 if the triager can't understand it in 90 seconds. This skill drafts bug-bounty reports engineered for fast triage: a title that says class + asset + impact in one line, a summary a non-specialist can follow, steps to reproduce copied verbatim from the evidence package (never rewritten), impact quantified in attacker-terms, and a remediation section specific enough to act on. It writes for the busiest reader in the pipeline and preempts the five standard triage objections. The draft always ends at the human — agents draft, humans submit.

## Division of labor

- **Consumes:** the evidence package (`evidence/<finding-id>/` — repro.sh, raw pairs, README), the severity file (`review/severity_<finding-id>.md`), and the chain file if the finding is a chain
- **Produces:** the finished artifact — `reports/draft_<finding-id>.md`, a complete submission-ready report the human reviews and submits

## When to use / when NOT to use

- **Use when:** a finding is CONFIRMED, packaged (PACKAGE-VERIFIED), and severity-calibrated; when a chain is CHAIN-CONFIRMED; when a REOPENED retest needs a fix-bypass report
- **Skip when (time-pass filter):** the evidence package failed fresh replay — the drafter replays repro.sh once more, and a failed replay rejects the draft back to evidence_packager. Never write around broken evidence. Skip when severity is Informative-only and the program doesn't accept info reports — log it, don't draft it.

## Methodology

1. Replay check: run the evidence package's `repro.sh` once more, fresh. If it fails → reject back to evidence_packager with the failure output. The drafter never drafts from unreproducible evidence.
2. Assemble inputs: read the severity file (severity, why-not-higher/lower, payout context — internal only, never in the report), the validation file (steps, auth context), and the chain file if present (the narrative follows the chain rung by rung).
3. Write the title: `<Class> on <asset> allows <concrete impact>`. Examples: "IDOR on /api/users/{id} exposes any user's PII including email and phone"; "SSRF in invoice webhook reaches AWS metadata and leaks IAM credentials". Never: "Security issue found" / "Vulnerability in API" / the class alone.
4. Write the summary: 2–3 sentences. Sentence 1: what the bug is and where. Sentence 2: what an attacker gets, quantified. Sentence 3 (if chain): the escalation path in one clause. A triager who reads only the title + summary must understand the report.
5. Write steps to reproduce: numbered, exact, copied from repro.sh — do not paraphrase commands into prose. Each step: the command (code block), then the expected observable result in one line, including the exact marker string to look for (e.g. `expect: response contains "email":"` for N records). Include the baseline step first ("observe the normal behavior") so the contrast is visible. Number every step; triagers follow numbers. If a step needs a session, state exactly how to obtain one ("log in as any test user" vs "use the attached session").
6. Write the impact section: attacker-terms, quantified. "An unauthenticated attacker can read X records containing Y fields for Z users" — not "sensitive data exposure." Include: who is affected (count/scope), what data or capability, whether it's unauthenticated (say it explicitly — it's the highest-value word in the section), and the worst realistic case in one sentence. No hype words ("devastating," "critical infrastructure") unless the evidence earns them.
7. Write remediation: specific to the root cause. "Add authorization check comparing session user id to requested id on GET /api/users/{id}" — not "implement proper access controls." If there are two valid fixes (e.g. WAF rule vs code fix), name the durable one and note the stopgap.
8. Attach evidence: reference the raw pairs (attach the core three: baseline, probe, verification), note the full package is available. Never paste 500-line responses into the report body — attach, don't inline.
9. Preempt the five standard triage objections — check each before finishing:
   - "Can't reproduce" → steps are numbered exact commands from a passing repro.sh. Covered.
   - "Not impactful" → impact section quantifies affected users/data/capability. Covered.
   - "Duplicate" → state what you checked (program's disclosed reports for this class/asset) and why this differs.
   - "Out of scope" → name the scope rule from scope_manifest.md that allows this asset.
   - "Needs auth / self-only" → auth-context classification stated explicitly; if auth is needed, say whose and why it still matters.
10. Self-review pass: read the draft as a hostile triager. Every claim must trace to a numbered step. Every number must trace to evidence. Then read the steps section as literal commands in a fresh terminal: if any step assumes state from an unlisted prior action (a login, a created resource, an env var), add the missing step — the triager's shell has none of your history. Cut any sentence you'd flag as hype. If the draft is longer than 2 pages, the summary and steps carry it — trim the rest.
11. Severity-field honesty: the report's severity is copied from `review/severity_<finding-id>.md`, never inflated. If the human upgrades or downgrades it during review, the draft's changelog line records who changed it and why — the agent never silently bumps severity.
12. Attachment manifest: list every file attached to the report (the core three raw pairs minimum) with a one-line description each, and name the full evidence package path for the triager who wants everything. An attachment referenced but not attached is a broken promise — verify each file exists before finishing.
13. Write the file to `reports/draft_<finding-id>.md` with the sections: Title, Summary, Severity, Affected asset(s), Steps to reproduce, Impact, Remediation, Evidence, Scope basis, Duplicate check. The human reviews and submits — the draft file gets a `STATUS: DRAFT-AWAITING-HUMAN` header until submitted.
14. Title QA — rewrite until the title names class + asset + concrete impact. Reference transformations:
    - "Vulnerability in API" → "IDOR on /api/users/{id} exposes any user's email and phone"
    - "SSRF found" → "SSRF in invoice webhook reaches AWS metadata and leaks IAM credentials"
    - "XSS" → "Stored XSS in support-ticket notes executes in admin sessions"
15. Tone scan: the draft speaks in neutral evidence language. Banned: first-person heroics ("I was able to"), hype adjectives (devastating, trivially, shocking, massive), and certainty beyond the evidence ("all users" when you tested three). Replace with measured claims tied to steps.
16. Length check (the 90-second test): if the draft exceeds 2 pages, verify the title + summary + steps alone convey the finding to a fresh reader. If they do, trim the rest; if they don't, the summary is wrong — fix the summary, not the length.
17. FORM-FIELDS appendix: if the program's submission form has mandatory structured fields (asset type, weakness category, CVSS input), add an appendix mapping each field to the draft's content so the human can paste without thinking.
18. Changelog: every draft ends with a CHANGELOG section (date, author, what changed relative to the severity/validation inputs). When the human edits the draft before submitting, they append their line. The changelog is how a future retest knows what was actually submitted versus what was drafted.

**Decision branches:** if the finding is a chain → the steps section follows the chain narrative rung by rung, each rung numbered, with the terminal impact as the final step's result. If it's a REOPENED fix-bypass → the report opens with "This is a bypass of the fix for <original-id>", includes the original finding-id, and the steps show the variant that defeats the patch. If the program's report form has mandatory fields (asset type dropdowns, etc.) → add a `FORM-FIELDS` appendix mapping each field to the draft's content.

## Exact commands

Drafter's replay gate (run before drafting anything):

```bash
bash "evidence/<finding-id>/repro.sh" > /tmp/draft_replay.txt 2>&1
grep -q REPRODUCED /tmp/draft_replay.txt && echo DRAFT_OK || echo REJECT_TO_PACKAGER
```

Pull the exact steps from repro.sh (copy, never rewrite):

```bash
sed -n '1,200p' "evidence/<finding-id>/repro.sh"
# steps in the report = these commands, numbered, each followed by its expected output line
```

Duplicate check against the program's disclosed history:

```bash
# search H1 Hacktivity / program disclosed reports for class+asset; record what you checked
grep -ri "<class>.*<asset-keyword>" ~/workspace/skills/writeup-intel/ 2>/dev/null | head -5
echo "checked: <source>, <date>; nearest: <report-id or 'none found'>"
```

Scope-basis line (quote the manifest):

```bash
grep -A2 "<target-host>" review/scope_manifest.md | head -5
```

Draft completeness check:

```bash
for s in Title Summary Severity Steps Impact Remediation Evidence; do
  grep -qi "^## $s" "reports/draft_<finding-id>.md" && echo "$s OK" || echo "$s MISSING"
done
grep -c '^```' "reports/draft_<finding-id>.md"   # code blocks = exact commands present
```

Tone / hype scan:

```bash
grep -niE 'devastating|trivially|shocking|massive|easily hacked|i was able to' "reports/draft_<finding-id>.md" && echo HYPE_FOUND || echo TONE_OK
```

Attachment verification (every referenced file must exist):

```bash
grep -oE 'evidence/[^ )`]+' "reports/draft_<finding-id>.md" | sort -u | while read -r f; do
  [ -e "$f" ] && echo "OK $f" || echo "MISSING $f"
done
```

## Completion-bias defenses

- [ ] repro.sh replayed fresh by the drafter — passed before any writing
- [ ] Title follows the class + asset + concrete-impact formula
- [ ] Summary is 2–3 sentences; title + summary alone convey the report
- [ ] Steps are numbered exact commands copied from repro.sh, baseline first
- [ ] Every step has its expected observable result in one line
- [ ] Impact is quantified (who/how many/what/unauth-or-not), hype-free
- [ ] Remediation names the root-cause fix, not a platitude
- [ ] Evidence attached (core three pairs), not inlined as walls of text
- [ ] All five triage objections preempted with explicit lines
- [ ] Duplicate check performed and documented; scope basis quoted from the manifest
- [ ] Hostile-triager self-review done; every claim traces to a numbered step
- [ ] File written with all sections; STATUS header set to DRAFT-AWAITING-HUMAN
- [ ] Title QA passed: class + asset + concrete impact named
- [ ] Tone scan run; hype words and first-person heroics removed
- [ ] 90-second test passed (title + summary + steps convey the finding)
- [ ] FORM-FIELDS appendix added when the program's form needs it
- [ ] Severity copied from the severity file, never inflated; changelog line present for any human change
- [ ] Attachment manifest complete; every referenced file verified to exist
- [ ] Steps re-read as literal fresh-terminal commands; hidden state assumptions fixed
- [ ] CHANGELOG section present at the end of the draft
- [ ] Severity-field honesty verified: report severity matches the severity file exactly
- **Review step:** the human reads every draft before submission — for accuracy, tone, and the final severity call. The agent never submits, never edits after human review without re-review.
- **Nudge prompts:**
  - "Keep going until every sentence in Impact traces to a numbered step. An impact claim without a step is a wish."
  - "Do not rewrite repro.sh commands into prose. Triagers copy-paste; prose doesn't paste."
  - "If the draft doesn't preempt all five objections, it's not done — it's a draft of a rejection."
  - "The changelog is not optional paperwork. The retest six months from now needs to know what the triager actually saw."
- **Finished artifact definition:** `reports/draft_<finding-id>.md` with Title, Summary, Severity, Affected asset(s), Steps to reproduce (numbered exact commands), Impact (quantified), Remediation (root-cause specific), Evidence (attachments noted), Scope basis (manifest quote), Duplicate check (documented), and the `STATUS: DRAFT-AWAITING-HUMAN` header. All sections non-empty = done.

## Evidence standard

- Baseline: the report's step 1 is the baseline behavior — the triager sees normal before they see broken.
- Reproduction: every step is a command from a passing repro.sh; the drafter's own fresh replay is the reproduction leg.
- Raw evidence: core three raw pairs attached; full package referenced by path.
- Verdicts: DRAFT-AWAITING-HUMAN (ready for human review) / REJECTED-TO-PACKAGER (replay failed — not a draft problem, an evidence problem). The human's verdict after review is SUBMITTED or REVISED.

## Handoffs

- **The human** consumes every draft: review, final severity call, submission. This is the hard human-in-the-loop gate — no report leaves without it.
- **evidence_packager** consumes REJECTED-TO-PACKAGER drafts: the replay failure output tells it what broke.
- **hunt_debrief** consumes submitted drafts (once the human reports the outcome): triage result (accepted/duplicate/N/A + payout) feeds calibration accuracy.
- **retest_regression** consumes submitted findings later: the draft's steps become the retest's baseline expectation.
