#!/usr/bin/env python3
"""Mechanical half of the completion_checklist_audit skill.

Parses a skill's SKILL.md (checklist items + finished-artifact definition),
then checks the run directory for the mechanical evidence:
  - finished artifact exists and is non-trivial (no placeholders)
  - evidence files are newer than run_started.txt (no recycled output)
  - load-bearing command counts in run.log match claims
  - completion-bias signatures: uniform-timestamp bursts, byte-identical "independent" runs

Writes a markdown audit skeleton. Items the script cannot verify mechanically
are marked NEEDS-HUMAN-REVIEW -- the agent completes those by reading logs.

Usage:
  python3 audit.py --skill-dir <skill-folder> --run-dir <run-output-dir> --out <audit-md>
"""
import argparse, os, re, sys, hashlib
from datetime import datetime, timezone

PLACEHOLDER_RE = re.compile(r'TODO|N/A|pending|^\{\}\s*$|^done\s*$', re.I | re.M)
CHECKBOX_RE = re.compile(r'^\s*-\s*\[( |x|X)\]\s*(.+)$')


def parse_skill_md(path):
    text = open(path, encoding='utf-8', errors='replace').read()
    # checklist items under the Completion-bias defenses section
    m = re.search(r'## Completion-bias defenses(.*?)(?=\n## |\Z)', text, re.S)
    items = []
    if m:
        for line in m.group(1).splitlines():
            cm = CHECKBOX_RE.match(line)
            if cm:
                items.append({'ticked': cm.group(1).lower() == 'x', 'text': cm.group(2).strip()})
    # finished artifact definition
    fa = re.search(r'\*\*Finished artifact definition:\*\*\s*(.+)', text)
    fa_text = fa.group(1).strip() if fa else ''
    fa_paths = re.findall(r'`([^`]+)`', fa_text)
    return items, fa_text, fa_paths


def walk(run_dir):
    out = []
    for root, _, files in os.walk(run_dir):
        for f in files:
            p = os.path.join(root, f)
            try:
                st = os.stat(p)
                out.append({'path': p, 'size': st.st_size, 'mtime': st.st_mtime})
            except OSError:
                pass
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--skill-dir', required=True)
    ap.add_argument('--run-dir', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    skill_md = os.path.join(a.skill_dir, 'SKILL.md')
    if not os.path.isfile(skill_md):
        sys.exit(f'no SKILL.md in {a.skill_dir}')
    items, fa_text, fa_paths = parse_skill_md(skill_md)
    files = walk(a.run_dir)

    # run start marker
    start_ts = None
    marker = os.path.join(a.run_dir, 'run_started.txt')
    if os.path.isfile(marker):
        try:
            start_ts = os.stat(marker).st_mtime
        except OSError:
            pass

    lines = []
    lines.append(f'# Audit (mechanical pass) — {os.path.basename(a.skill_dir.rstrip("/"))}')
    lines.append(f'_generated {datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")} by audit.py_')
    lines.append('')
    lines.append(f'Checklist items found in SKILL.md: **{len(items)}**')
    lines.append(f'Finished-artifact definition: {fa_text or "(not found)"}')
    lines.append('')

    # 1. finished artifact check
    lines.append('## 1. Finished artifact')
    if not fa_paths:
        lines.append('- FAIL: no backticked artifact path in the Finished artifact definition.')
    for pat in fa_paths:
        # resolve simple patterns: literal path, or <slug> placeholders
        hits = [f for f in files if pat.split('/')[-1].replace('<finding-id>', '').replace('<skill-slug>', '') in f['path']]
        if not hits:
            lines.append(f'- FAIL: `{pat}` — no matching file in run dir.')
            continue
        for h in hits:
            body = open(h['path'], encoding='utf-8', errors='replace').read() if h['size'] < 5_000_000 else ''
            verdict = 'PASS'
            if h['size'] < 200:
                verdict = 'FAIL (file < 200 bytes)'
            elif body and PLACEHOLDER_RE.search(body):
                verdict = 'FAIL (placeholder text detected)'
            lines.append(f'- {verdict}: `{h["path"]}` ({h["size"]} bytes)')
    lines.append('')

    # 2. timestamp / recycled-output check
    lines.append('## 2. Evidence freshness (mtime vs run start)')
    if start_ts is None:
        lines.append('- INCONCLUSIVE: no run_started.txt — cannot verify evidence is from this run.')
    else:
        stale = [f for f in files if f['mtime'] < start_ts and not f['path'].endswith('run_started.txt')]
        if stale:
            lines.append(f'- FAIL: {len(stale)} file(s) older than run start (recycled output):')
            for f in stale[:20]:
                lines.append(f'  - `{f["path"]}`')
        else:
            lines.append(f'- PASS: all {len(files)} files newer than run start.')
    lines.append('')

    # 3. uniform-timestamp burst detection
    lines.append('## 3. Completion-bias signatures')
    buckets = {}
    for f in files:
        minute = datetime.fromtimestamp(f['mtime'], timezone.utc).strftime('%Y-%m-%d %H:%M')
        buckets[minute] = buckets.get(minute, 0) + 1
    if buckets:
        top_min, top_n = max(buckets.items(), key=lambda kv: kv[1])
        if top_n > len(files) / 2 and len(files) >= 4:
            lines.append(f'- SUSPECT burst-write: {top_n}/{len(files)} files share mtime minute {top_min}.')
        else:
            lines.append(f'- OK: no burst-write (max {top_n}/{len(files)} in one minute).')
    # byte-identical "independent" runs
    hashes = {}
    for f in files:
        if re.search(r'run\d|probe1|probe2|_r1|_r2', os.path.basename(f['path'])):
            try:
                h = hashlib.sha256(open(f['path'], 'rb').read()).hexdigest()
                hashes.setdefault(h, []).append(f['path'])
            except OSError:
                pass
    dupes = [v for v in hashes.values() if len(v) > 1]
    if dupes:
        lines.append('- SUSPECT copy-paste: byte-identical files across supposedly independent runs:')
        for v in dupes:
            lines.append('  - ' + ', '.join(f'`{p}`' for p in v))
    else:
        lines.append('- OK: no byte-identical duplicates among run-labeled files.')
    lines.append('')

    # 4. per-item table (mechanical status; agent completes judgment)
    lines.append('## 4. Checklist items (agent: verify each, replace NEEDS-HUMAN-REVIEW)')
    lines.append('| # | Ticked | Item | Mechanical status |')
    lines.append('|---|--------|------|-------------------|')
    for i, it in enumerate(items, 1):
        lines.append(f'| A{i} | {"yes" if it["ticked"] else "NO"} | {it["text"][:90]} | NEEDS-HUMAN-REVIEW |')
    lines.append('')
    lines.append('## Verdict (agent: set after completing section 4)')
    lines.append('`PASS` / `CONDITIONAL-PASS` / `FAIL` — with coverage % and re-do list.')

    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    open(a.out, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print(f'wrote {a.out} ({len(items)} checklist items, {len(files)} run files)')


if __name__ == '__main__':
    main()
