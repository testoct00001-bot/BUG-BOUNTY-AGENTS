---
name: completion_checklist_audit
agent: agent10_review
description: Verifies every methodology step of a skill actually ran (not just claimed) — the anti-completion-bias audit that gates every skill's output before it ships.
---

# Completion Checklist Audit

## Purpose

Completion bias is the #1 enemy of an AI hackbot: an agent does 3 steps of a 20-step methodology and reports "done." This skill is Haddix's mandatory review step made executable. It takes a skill's declared completion checklist and its finished-artifact definition, then verifies — against the filesystem, logs, and content quality — that every step actually ran. A skill's output is not "done" when the agent says so; it is done when this audit says PASS. It finds the quiet skips: the baseline never run, the second model never tried, the wordlist truncated at 200 entries.

## Division of labor

- **Consumes:** the executing agent's skill folder (its `SKILL.md`, including the Completion-bias defenses checklist and Finished artifact definition), the run's output directory (artifacts, logs, raw captures), and the claimed finished artifact path
- **Produces:** the finished artifact — `review/audit_<skill-slug>_<YYYYMMDD-HHMM>.md` containing per-item PASS/FAIL, a coverage percentage, and an explicit re-do list when not PASS; plus `review/audit_<skill-slug>_verdict.txt` containing exactly one word: `PASS`, `CONDITIONAL-PASS`, or `FAIL`

## When to use / when NOT to use

- **Use when:** any skill claims completion and hands off its finished artifact; when a skill's output will feed another agent (chains, validators, report drafters); when a hunt round ends and every agent's checklist must be audited before the debrief
- **Skip when (time-pass filter):** this skill is itself a gate — it never gets skipped. The only exception is a human explicitly waving a CONDITIONAL-PASS through with a written reason, and even that gets logged in the audit file

## Methodology

1. Locate the skill folder for the run being audited. Read its full `SKILL.md`. Do not trust the executing agent's summary of it — read the source of truth.
2. Extract every checkbox line under the "Completion-bias defenses" section (lines starting `- [ ]` or `- [x]`). Number them A1..An. These are the claimed steps.
3. Extract the "Finished artifact definition" — the exact file path or path pattern that proves done. Also extract the "Produces" line from Division of labor for the canonical artifact format.
4. Inventory the run's actual output directory: full recursive listing with sizes and mtimes. Save it to the audit file as the evidence baseline.
5. Check the finished artifact first, before anything else. If the exact file does not exist → stop, write verdict `FAIL`, reason `missing-finished-artifact`. No artifact, no further reading. This is the fastest kill and the most common failure.
6. If the artifact exists, verify it is non-trivial: minimum size (reject files under 200 bytes unless the format legitimately allows it), no placeholder text ("TODO", "N/A", "pending", empty JSON `{}`), no single-line "done" content. A 1-line file claiming a 20-step methodology ran is a FAIL.
7. For each checklist item A1..An, demand exactly one piece of evidence: a file on disk, a log line with a timestamp, or a captured command output. A ticked box with no evidence is FAIL for that item. An unticked box is FAIL for that item. There is no partial credit for intent.
8. Verify timestamps: every evidence file's mtime must be at or after the run-start marker (the harness writes `run_started.txt` when the skill begins). Evidence older than the run start means the agent recycled old output and claimed it as new → FAIL.
9. Cross-check command execution: pull the "Exact commands" section of the skill. For the 3–5 load-bearing commands (baseline probe, main probe, verification probe), grep the run log for their echo or output signature. A methodology that says "ran 1000 probes" must show ~1000 result lines, not 12. Count lines; do the arithmetic.
10. Detect completion-bias signatures explicitly — check all four:
    - **Early-done:** the word "done"/"complete" appears in the log before 80% of the planned probes/steps executed
    - **Uniform timestamps:** >50% of evidence files share the same mtime minute (written in a burst at the end, not during the run)
    - **Truncated loops:** a loop over N items stopped at M < N with no error recorded (e.g. wordlist of 1000, only 214 probed)
    - **Identical outputs:** two "independent" runs produced byte-identical output (copy-paste, not re-execution)
11. For skills whose methodology has decision branches ("if X, do Y"), verify the branch was actually taken: if the run log shows the X condition, the Y evidence must exist. A claimed branch with no evidence is an unaudited claim → mark INCONCLUSIVE for that item.
12. Verify the baseline ran: the skill's baseline command (known-dead path) must have a captured response in the log. No baseline → the skill's hits are unaudited noise → FAIL the "Evidence standard" items.
13. Compute coverage: `verified_items / total_items * 100`. Record it. PASS requires 100% on all items marked critical (baseline, artifact, reproduction) and ≥95% overall. 80–94% → CONDITIONAL-PASS only with a human-written waiver. Below 80% → FAIL.
14. Build the re-do list: for every FAIL item, write the exact step to re-run, with the full command copied from the skill's "Exact commands" section. The re-do list is not advice ("re-run the baseline") — it is copy-paste commands ("run `curl -s -i ...` and append to ...").
15. Write the audit file: skill name, run id, timestamp, per-item table (item / claimed / evidence found / verdict), completion-bias signature findings, coverage %, verdict, and the re-do list.
16. Write the one-word verdict file. Route the result: `PASS` → the skill's output proceeds to its normal handoff (usually finding_validator or the next agent). `CONDITIONAL-PASS` → proceeds only after a human appends a waiver line to the audit file. `FAIL` → the executing agent is re-dispatched with the re-do list; nothing downstream consumes this output.
17. If the same skill FAILs audit twice in a row, escalate to the human with both audit files attached and a note: the skill's methodology or the harness's enforcement needs fixing, not just a re-run.
18. Archive: keep every audit file. The hunt debrief (hunt_debrief skill) consumes the audit trail to find systemic completion-bias patterns.
19. Spot-check the artifact's own claims: pick 3 factual claims inside the finished artifact (a count, a path, a status code, a finding-id) and verify each against the raw evidence files. An artifact whose own claims don't match its evidence is FAIL even if every checklist box is ticked — ticks verify the process, this verifies the product.
20. Cross-skill consistency: if this skill's output was already consumed downstream (a validation file or chain file cites the artifact), verify the citation matches — same finding-id, same target, same counts. A mismatch means the downstream agent worked from a different version of the output → flag both artifacts for re-audit and halt the downstream chain until resolved.

**Decision branches:** if the finished artifact is missing → fail fast at step 5, skip the deep work. If there is no run log at all → every ticked box is unverified: mark the whole run INCONCLUSIVE, verdict FAIL, re-do = re-run with logging enabled. If coverage is 95–99% with only non-critical items failing → CONDITIONAL-PASS is allowed but the waiver must name a human. If the skill has no checklist section at all (legacy skill) → FAIL with reason `no-checklist-defined` and require the skill author to add one before re-audit.

## Exact commands

Baseline pattern — inventory the run directory before judging anything:

```bash
SKILL_RUN_DIR="<run-output-dir>"
find "$SKILL_RUN_DIR" -type f | sort
find "$SKILL_RUN_DIR" -type f -printf '%T+ %s %p\n' | sort   # mtimes + sizes
```

Finished-artifact existence and non-triviality:

```bash
ARTIFACT="review/js_analysis_confirmed.md"   # from the skill's Finished artifact definition
test -f "$ARTIFACT" && echo ARTIFACT_PRESENT || echo ARTIFACT_MISSING
wc -c "$ARTIFACT"
grep -Ei 'TODO|N/A|pending|^\{\}$|^done$' "$ARTIFACT" && echo PLACEHOLDER_DETECTED || echo CONTENT_OK
```

Timestamp check against run start (harness writes `run_started.txt` at dispatch):

```bash
RUN_START=$(cat "$SKILL_RUN_DIR/run_started.txt")
find "$SKILL_RUN_DIR" -type f -newermt "$RUN_START" | wc -l    # evidence newer than start
find "$SKILL_RUN_DIR" -type f ! -newermt "$RUN_START"          # recycled files = suspect
```

Command-execution cross-check (did the load-bearing commands actually run?):

```bash
grep -c 'curl -s -i' "$SKILL_RUN_DIR/run.log"          # probe echo count vs claimed count
grep -c '200\|404\|403' "$SKILL_RUN_DIR/results.txt"  # result lines vs claimed probe count
```

Uniform-timestamp burst detection (completion-bias signature):

```bash
find "$SKILL_RUN_DIR" -type f -printf '%TY-%Tm-%Td %TH:%TM\n' | sort | uniq -c | sort -rn | head
# if one minute owns >50% of files -> burst-written, suspect
```

Identical-output detection (two "independent" runs copy-pasted):

```bash
sha256sum "$SKILL_RUN_DIR"/run1_out.txt "$SKILL_RUN_DIR"/run2_out.txt
```

JSON/YAML artifact structural check:

```bash
python3 -c "import json,sys; d=json.load(open('$ARTIFACT')); assert d, 'empty JSON'; print('top-level keys:', list(d)[:10])"
```

Artifact claim spot-check (pull claimed counts, verify against raw files):

```bash
grep -oE '[0-9]+ (probes|paths|endpoints|hits|parameters)' "$ARTIFACT" | head -3
wc -l "$SKILL_RUN_DIR"/results*.txt 2>/dev/null   # do the claimed counts match reality?
```

Run the helper auditor (parses SKILL.md checklist + checks artifacts automatically):

```bash
python3 audit.py --skill-dir ~/workspace/hackbot-skills/START/<agent>/<skill>/ \
                 --run-dir "$SKILL_RUN_DIR" \
                 --out review/audit_<skill-slug>_20261004-1415.md
```

## Completion-bias defenses

- [ ] Read the skill's SKILL.md directly — never audited from the agent's summary alone
- [ ] Finished artifact existence checked before any per-item work (fail fast)
- [ ] Every checklist item mapped to exactly one concrete evidence file/log line
- [ ] All evidence mtimes verified at/after run start; recycled files flagged
- [ ] Load-bearing commands cross-checked in run log by count, not by claim
- [ ] All four completion-bias signatures tested (early-done, uniform timestamps, truncated loops, identical outputs)
- [ ] Baseline execution verified in the log, not assumed
- [ ] Coverage % computed and recorded; verdict follows the numeric rule, not a feeling
- [ ] Re-do list written as copy-paste commands, not advice
- [ ] Verdict file written as exactly one word; routing followed (FAIL re-dispatches, never proceeds)
- [ ] Second consecutive FAIL escalated to human with both audit files
- [ ] Artifact spot-check: 3 claims inside the artifact verified against raw evidence
- [ ] Cross-skill consistency: downstream citations match this artifact's ids/counts/targets
- [ ] Structured artifacts (JSON/YAML) parse and are non-empty
- **Review step:** the human reviews every FAIL audit and every CONDITIONAL-PASS waiver. The audit skill itself is reviewed by the human, never by another agent — the reviewer cannot be reviewed by the reviewed.
- **Nudge prompts:**
  - "Do not write PASS because the agent sounded confident. PASS requires 100% of critical items with filesystem evidence."
  - "Keep going until every checklist item has a verdict row in the audit file. An item with no row is an item you skipped — the exact failure you exist to catch."
  - "If the re-do list would take you longer to write than to just re-run the skill, write the re-do list anyway. The executing agent needs commands, not commentary."
  - "A ticked checklist with a lying artifact is still a lie. Verify the product (spot-check 3 claims), not just the process."
- **Finished artifact definition:** `review/audit_<skill-slug>_<YYYYMMDD-HHMM>.md` (per-item table, bias-signature findings, coverage %, verdict, re-do list) AND `review/audit_<skill-slug>_verdict.txt` (exactly one of `PASS`, `CONDITIONAL-PASS`, `FAIL`). Both files existing with non-trivial content = done.

## Evidence standard

- Baseline: the audit itself has no baseline — it IS the baseline for everything else. Its evidence is the filesystem: `find` listings, `wc -c` output, and `grep` counts quoted verbatim in the audit file.
- Reproduction: a FAIL verdict must be reproducible — re-running `audit.py` on the same run-dir must produce the same verdict. If the verdict flips between runs, the audit is INCONCLUSIVE and the human investigates the harness.
- Raw evidence: quote the actual `find`/`wc`/`grep` outputs in the audit file. Never paraphrase a count.
- Verdicts: PASS (100% critical items, ≥95% overall, artifact valid) / CONDITIONAL-PASS (80–94%, human waiver appended) / FAIL (anything below, or missing artifact, or bias signatures found). No fourth option.

## Handoffs

- **finding_validator** consumes PASS audits: it only validates findings from skills whose audit passed. A finding arriving without a PASS audit is rejected at intake.
- **The executing agent** (whichever agent ran the audited skill) consumes FAIL audits: the re-do list is its next dispatch, with the exact commands.
- **hunt_debrief** consumes the full audit trail: consecutive FAILs and bias-signature patterns become skill-improvement entries and pattern-library updates.
- **The human** consumes CONDITIONAL-PASS audits (waiver decision) and double-FAIL escalations.
