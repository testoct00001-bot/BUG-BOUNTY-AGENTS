---
name: severity_calibrator
agent: agent10_review
description: Sets the final severity — honest CVSS plus real-world bounty-market calibration; what the finding actually earns, not what the scanner says.
---

# Severity Calibrator

## Purpose

Scanners say Critical; triagers say Low. This skill sets the severity a finding actually deserves: an honest CVSS 3.1 vector computed from first principles, then calibrated against the real bounty market — what this class pays on this kind of program, adjusted for unauthenticated reachability, data sensitivity, scale, and chainability. It produces a severity the human can defend in a report and a payout expectation grounded in disclosed-report reality, not wishful thinking. Under-severitied findings leave money on the table; over-severitied ones burn credibility. This skill gets it right.

## Division of labor

- **Consumes:** CONFIRMED verdict files, chain files (terminal impact statements), and evidence packages (auth context, README summaries)
- **Produces:** the finished artifact — `review/severity_<finding-id>.md` containing the CVSS vector with per-metric justification, the market calibration, comparable disclosed reports, the final severity, and the payout expectation range

## When to use / when NOT to use

- **Use when:** a finding or chain is CONFIRMED/CHAIN-CONFIRMED and packaged; when a chain's terminal impact changes what the finding is worth; when the human asks "what is this actually worth?"
- **Skip when (time-pass filter):** the finding is INCONCLUSIVE or NEGATIVE — unproven findings get no severity. Calibrating noise is how "Critical" findings die in triage and take your reputation with them.

## Methodology

1. Read the validation file and evidence package. Extract: attack vector (network/adjacent/local), authentication required (none/low/high), user interaction (none/required), what the attacker gains (read/write/execute, whose data), and blast radius (one user / many users / all tenants / the platform).
2. Compute the CVSS 3.1 base vector metric by metric — honestly:
   - **AV:** N unless the attack needs adjacent-network or physical presence. SSRF, IDOR, XSS (reflected, link-delivered) are N.
   - **AC:** L unless it needs a race window, a specific non-default config, or MITM positioning.
   - **PR:** N if it works with no session (verify from the auth-context classification — don't guess); L if any authenticated session works; H if it needs admin/high-priv.
   - **UI:** N unless the victim must click/visit/submit something. Stored XSS viewed by an admin is still UI:N for the attacker if no victim action beyond normal use is needed — be careful and justify.
   - **S:** C if the exploit crosses a security authority boundary (browser → server, tenant → tenant, user → admin, SSRF → internal network). This is the most under-applied metric — check it twice.
   - **C/I/A:** H only for what is actually demonstrated. Reading one user's own profile is C:L, not C:H. Exfiltrating the user table is C:H. A write primitive you didn't demonstrate is I:N with a note, not I:H on vibes.
3. Write the vector string (e.g. `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N`) and the base score. Show the metric-by-metric justification in a table — every letter must have a one-line reason citing evidence.
4. Apply the bounty-market calibration — CVSS is the start, not the answer. Score each factor:
   - **Unauthenticated reachability:** ×1.5 weight. Unauth + sensitive = the thing programs pay for. Auth-required findings lose a full severity tier unless the impact is exceptional.
   - **Data sensitivity class:** PII/financial/auth-tokens > internal-config > non-sensitive-metadata. Map the actual leaked fields to a class; quote them.
   - **Scale:** single-user < multi-user < tenant-wide < platform-wide. Count or estimate from the evidence (pagination? total records?).
   - **Chainability:** does this finding unlock a chain (per impact_chain_builder)? A low that is rung 1 of a Critical chain is reported at chain severity with the chain as context — never reported alone as a low.
   - **Exploit reliability:** works every time vs race-condition vs one-observed. Flaky findings get downgraded a tier with the flakiness documented.
   - **Program history:** what has this program (or this program class — fintech, SaaS, infra) historically paid for this vuln class? Cite 2–3 disclosed HackerOne reports with IDs and bounty amounts.
   - **Data recency:** is the exposed data fresh (active sessions, current PII, live tokens) or stale (2019 dump, expired tokens, test accounts)? Stale data downgrades a full tier — a leak of expired tokens is not the same finding as a leak of live ones. Quote the freshest timestamp you can find in the evidence.
5. Set the final severity: Critical / High / Medium / Low / Informative. Then write the "why not higher / why not lower" paragraph — the two sentences that preempt the triager's downgrade. If you can't argue both sides, you haven't calibrated.
6. Set the payout expectation: a range (e.g. $500–$1,500), anchored to the comparable reports, adjusted for this program's known generosity and the finding's tier. Never a single number — ranges are honest.
7. Check the credibility traps: severity inflation (calling it Critical because you worked hard), duplicate-class discount (the program's 5th IDOR pays less than its 1st — check the program's disclosed history), and scope-adjacent discount (finding on a less-critical asset in scope pays less).
8. Second-reader check: close the file, re-derive the CVSS vector from the raw evidence alone without looking at your first derivation, then compare. If the two vectors differ on any metric, reconcile the difference in writing before proceeding — the discrepancy is telling you which metric was judgment, not evidence.
9. Peer-review swap: hand the severity file (without the final severity line) to a second model run with only the evidence package as input, and ask it to set severity independently. If the two severities differ by more than one tier, reconcile in writing — the disagreement marks the exact judgment call the human must make.
10. Write the severity file: CVSS table, vector, base score, the seven calibration factors with weights, comparables (report IDs + bounties + why comparable), final severity, payout range, the why-not-higher/lower paragraph, credibility-trap checks, and the peer-review reconciliation note.

**Decision branches:** if the finding is a chain → severity comes from terminal impact; the file must state the chain-id and quote the terminal impact statement. If CVSS says 9.8 but the market calibration says Medium (e.g. self-XSS with no delivery) → the market wins for the report's severity field, CVSS stays as the technical score; document the split explicitly. If no comparable disclosed reports exist for the class → say so, widen to adjacent classes, and mark the payout range low-confidence.

## Exact commands

CVSS base-score computation (verify by hand, then cross-check):

```bash
# vector assembled from the metric table, e.g.:
VECTOR="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N"
# cross-check the score with a local calculator — never trust mental arithmetic
python3 - <<'EOF'
# minimal CVSS 3.1 base calculator (round-up per spec)
import math
def r(x): return math.ceil(x*10)/10
AV={'N':0.85,'A':0.62,'L':0.55,'P':0.2}; AC={'L':0.77,'H':0.44}
PR={'N':0.85,'L':0.62,'H':0.27}; PRC={'N':0.85,'L':0.68,'H':0.5}
UI={'N':0.85,'R':0.62}
C={'H':0.56,'L':0.22,'N':0}; I={'H':0.56,'L':0.22,'N':0}; A={'H':0.56,'L':0.22,'N':0}
m=dict(p.split(':') for p in "AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:N/A:N".split('/'))
iss=1-(1-C[m['C']])*(1-I[m['I']])*(1-A[m['A']])
pr=PRC[m['PR']] if m['S']=='C' else PR[m['PR']]
esc=8.22*AV[m['AV']]*AC[m['AC']]*pr*UI[m['UI']]
imp=7.52*(iss-0.029)-3.25*((iss-0.029)**15) if m['S']=='C' else 6.42*iss
score=r(min(1.08*(imp+esc),10)) if (m['S']=='C' and imp>0) else r(min(imp+esc,10))
print("base score:", score)
EOF
```

Evidence extraction for calibration inputs:

```bash
grep -E '^(Class|Target|VERDICT)' "review/validated_<finding-id>.md"
grep -A3 'Auth classification' "review/validated_<finding-id>.md"
grep -iE 'email|token|key|ssn|password|pii' "evidence/<finding-id>/02_probe1.resp" | head -10
```

Comparable-report lookup (disclosed H1 reports for the class — record IDs + bounties):

```bash
# search writeup-intel mirrors / H1 Hacktivity for the class; record:
# report id, class, bounty, why comparable (same vector? same data class? same program tier?)
grep -ri "<class>" ~/workspace/skills/writeup-intel/ 2>/dev/null | head -10
```

Worked-example sanity anchor (unauth IDOR reading any user's email+phone):

```
CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N  -> base 7.5 (High)
Market: unauth x1.5, PII class, multi-user scale, no chain -> final: High
Payout anchor: comparable IDOR reports $500-$2,000 depending on program tier.
Use this as the yardstick: if your finding scores above it, the calibration
factors must say exactly why.
```

Program-tier payout adjustment (apply after the comparable anchor):

```
tier A (top-paying: broad scope, history of $5k+ bounties)  -> anchor x 1.5
tier B (standard managed program)                            -> anchor x 1.0
tier C (new / narrow / historically low-paying)              -> anchor x 0.5
Record the tier and the multiplier in the severity file; never silently
use tier A math on a tier C program.
```

## Completion-bias defenses

- [ ] Validation file and evidence package read — severity never set from a summary
- [ ] CVSS metric table written with one-line evidence-cited justification per metric
- [ ] Vector string and base score computed; score cross-checked with the calculator
- [ ] Scope-changed (S:C) evaluated deliberately, not defaulted
- [ ] CIA rated on demonstrated impact only — no credit for unproven writes
- [ ] All six market calibration factors scored with evidence quotes
- [ ] 2–3 comparable disclosed reports cited (IDs + bounties + comparability reason)
- [ ] Final severity set; "why not higher / why not lower" paragraph written
- [ ] Payout expectation as a range, anchored to comparables, confidence noted
- [ ] Credibility traps checked (inflation, duplicate-class discount, scope-adjacent discount)
- [ ] Chain findings severitied from terminal impact with chain-id quoted
- [ ] Factor 7 (data recency) scored with the freshest timestamp quoted
- [ ] Second-reader vector re-derivation done; divergences reconciled in writing
- [ ] Worked-example sanity: severity justified against the IDOR yardstick
- [ ] Program tier recorded with its payout multiplier applied to the range
- [ ] Peer-review swap done; >1-tier disagreements reconciled in writing
- **Review step:** the human reviews every Critical and High calibration before the report ships. A severity the human can't defend to a triager doesn't ship — downgrade until it's defensible.
- **Nudge prompts:**
  - "Keep going until every CVSS metric has a cited reason. A vector with unjustified metrics is a guess with formatting."
  - "Do not set severity from effort. A week of work on a self-XSS is still a Low — write the why-not-higher paragraph until you believe it."
  - "If the payout range feels exciting, re-check the comparables. Excitement is not a calibration factor."
- **Finished artifact definition:** `review/severity_<finding-id>.md` with the CVSS metric table + vector + score, the six calibration factors with evidence, comparable reports (IDs, bounties, comparability), final severity, payout range with confidence, the why-not-higher/lower paragraph, and credibility-trap checks. All sections non-empty = done.

## Evidence standard

- Baseline: the CVSS metric table is the baseline — every severity claim traces to a metric with cited evidence, re-derivable by anyone reading the file.
- Reproduction: re-running the calculator on the recorded vector must reproduce the score; the calibration factors are re-scorable from the quoted evidence.
- Raw evidence: the leaked-field quotes and auth-classification lines are copied verbatim into the file.
- Verdicts: a single final severity (Critical/High/Medium/Low/Informative) plus a payout range with a confidence tag (high/medium/low). No "Critical-ish."

## Handoffs

- **report_drafter** consumes the severity file: the writeup's severity section is copied from here, including the why-not-higher/lower reasoning condensed.
- **impact_chain_builder** consumes the severity file for chains: the terminal-impact severity argument is checked against this calibration.
- **hunt_debrief** consumes all severity files: calibration accuracy (predicted range vs actual bounty, when known) becomes a pattern-library entry.
- **The human** consumes Critical/High calibrations for pre-submission review.
