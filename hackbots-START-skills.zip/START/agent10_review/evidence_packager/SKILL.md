---
name: evidence_packager
agent: agent10_review
description: Builds Burp-style raw request/response evidence packages — clean, reproducible proof bundles that make every finding re-playable by anyone.
---

# Evidence Packager

## Purpose

A finding without packaged evidence is a story; a finding with packaged evidence is a report. This skill turns validated findings and chains into self-contained proof bundles: Burp-style raw request/response pairs, exact reproduction commands, a manifest with hashes, and a README that lets a stranger reproduce the finding in minutes. It enforces the reproducibility rule — the packager replays every reproduction script fresh, and only evidence that reproduces from a clean run ships. Triagers trust reports they can replay; this skill manufactures that trust.

## Division of labor

- **Consumes:** CONFIRMED verdict files (`review/validated_<finding-id>.md`), chain files (`review/chain_<chain-id>.md`), and their referenced raw captures
- **Produces:** the finished artifact — `evidence/<finding-id>/` directory containing `MANIFEST.md`, `README.md`, `repro.sh`, numbered raw pairs (`01_baseline.req/.resp`, `02_probe1.req/.resp`, `03_probe2.req/.resp`, …), and `sha256sums.txt`

## When to use / when NOT to use

- **Use when:** a finding is CONFIRMED and headed for severity calibration and report drafting; when a chain is CHAIN-CONFIRMED and its transitions need packaging; when the human asks for "the raw pairs" for any finding
- **Skip when (time-pass filter):** the finding is INCONCLUSIVE or NEGATIVE — package only what survived validation. Packaging noise wastes the report drafter's time and the triager's. If the raw pairs contain another user's live data (not a canary), stop and escalate to the human before packaging anything.

## Methodology

1. Create the package directory: `evidence/<finding-id>/`. For chains: `evidence/<chain-id>/` with a `links/` subdirectory per rung.
2. Copy the baseline pair in first: `01_baseline.req`, `01_baseline.resp`, plus a one-line note of what the baseline proves ("this is what 'nothing here' looks like on this host").
3. Copy probe pairs in execution order: `02_probe1.*`, `03_probe2.*`, then negative controls as `04_negctrl_wrongparam.*`, `05_negctrl_truncated.*`. Numbering tells the story without words.
4. Format every pair Burp-style in the MANIFEST: request block (method, path, headers, body), then response block (status line, headers, body), then a 1–2 line annotation of what the pair proves. Truncate bodies over 50KB with a `[truncated at 50KB — full body in <file>]` marker; never silently cut.
5. Write `repro.sh`: the exact commands to reproduce the finding from a clean shell, using variables at the top (`HOST=`, `SESSION=` if needed) and `set -euo pipefail`. Every command must be copy-paste runnable. Include the baseline command first so the replayer sees the contrast.
6. Redaction pass: scan all packaged files for third-party PII or secrets that are NOT the researcher's own session material — other users' emails, tokens, keys incidentally captured. Redact with `[REDACTED-<class>]` and log each redaction in the MANIFEST. The researcher's own session cookie stays (it's the proof of auth context) but is flagged `RESEARCHER-OWNED`.
7. Hash everything: `sha256sum` over all package files into `sha256sums.txt`. This is the chain of custody — if a file changes later, the hash tells.
8. Fresh-replay verification: run `repro.sh` in a clean environment (fresh shell, no leftover state), capture its outputs to `replay_check/`, and diff the key assertions (status codes, presence of the leaked marker). If the fresh replay diverges from the packaged pairs → the evidence is stale or environment-dependent → do NOT ship; return to finding_validator with the divergence noted.
9. Write `README.md`: finding-id, one-paragraph summary, auth context, the three commands that matter most (baseline, probe, verify), expected outputs, and the redaction log pointer.
10. Write `MANIFEST.md`: file inventory with hashes, pair annotations, redaction log, replay-check result, and the verdict line copied from the validation file.
11. Final completeness check: every file referenced by the validation file's evidence section exists in the package; every package file is hashed; repro.sh is executable and passed fresh replay. Only then is the package done.
12. Naming-convention enforcement: every file in the package matches the fixed set — `NN_<role>.req/.resp` pairs, `MANIFEST.md`, `README.md`, `repro.sh`, `sha256sums.txt`, `replay_check/`. Anything else is a stowaway; remove it or justify it in the MANIFEST.
13. Local-path leak scan: grep repro.sh, README.md, and MANIFEST.md for `/home/`, `/tmp/`, `C:\`, and the operator's username. Packages must not leak the hunter's filesystem layout — parameterize or remove every hit.
14. Chain packages: for `evidence/<chain-id>/`, create `links/rungN/` subdirectories holding that rung's raw pairs, plus a `CHAINMAP.md` mapping each rung to its finding-id and transition evidence. The chain package replays rung by rung via the chain replay script, not a single repro.sh.
15. Execution-trace hygiene: repro.sh must never `set -x` — an xtrace would echo the session cookie and any tokens into whoever's terminal replays it. Verify with grep; if xtrace is needed for debugging, it stays out of the shipped script.
16. Date-stamp the package: write the packaging date (UTC) and the validation date into MANIFEST.md. A package without dates can't answer "is this still fresh?" — and retest_regression needs the validation date to measure the patch window.

**Decision branches:** if fresh replay fails because the target changed (fixed, WAF rule added) → mark the package `STALE-<date>`, keep it (it's historical proof), and dispatch retest_regression to determine FIXED vs REOPENED. If the package would exceed 25MB (huge responses) → keep full raw pairs for the 3 core pairs, truncate the rest with markers, note it in the MANIFEST. If repro.sh needs a secret that can't be shared (researcher's private session) → parameterize it as `$SESSION` with instructions, and note that replay requires a valid session.

## Exact commands

Package skeleton:

```bash
FID="<finding-id>"
mkdir -p "evidence/$FID/replay_check"
cp "review/validation/$FID/baseline.req"  "evidence/$FID/01_baseline.req"
cp "review/validation/$FID/baseline.resp" "evidence/$FID/01_baseline.resp"
cp "review/validation/$FID/probe1.req"    "evidence/$FID/02_probe1.req"
cp "review/validation/$FID/probe1.resp"   "evidence/$FID/02_probe1.resp"
cp "review/validation/$FID/probe2.req"    "evidence/$FID/03_probe2.req"
cp "review/validation/$FID/probe2.resp"   "evidence/$FID/03_probe2.resp"
```

repro.sh template (write this per finding — variables at top, baseline first):

```bash
#!/usr/bin/env bash
set -euo pipefail
HOST="<HOST>"                 # target host, no scheme
OUT="evidence/<finding-id>/replay_check"
mkdir -p "$OUT"
# 1. baseline: known-dead path — expect 404-shaped response
curl -s -i --max-time 20 "https://$HOST/__validator_dead_9f3a2b7c1d4e5f6a/" -o "$OUT/baseline.resp" -w 'baseline_http=%{http_code}\n'
# 2. probe: the finding — expect <expected-status> with <marker>
curl -s -i --max-time 20 -X <METHOD> "https://$HOST/<path>" \
  -H "Content-Type: application/json" \
  ${SESSION:+-H "Cookie: $SESSION"} \
  --data-raw '<body>' -o "$OUT/probe.resp" -w 'probe_http=%{http_code}\n'
grep -q "<marker-string>" "$OUT/probe.resp" && echo REPRODUCED || { echo NOT_REPRODUCED; exit 1; }
```

Redaction scan (third-party PII / secrets that are not researcher-owned):

```bash
grep -rEn '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "evidence/$FID/" --include='*.resp' | grep -v RESEARCHER-OWNED
grep -rEn '(AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{16,}|xox[bap]-[0-9A-Za-z-]{10,})' "evidence/$FID/" --include='*.resp'
# redact each hit as [REDACTED-<class>] and log it in MANIFEST.md
```

Hashing and fresh-replay check:

```bash
cd "evidence/$FID" && sha256sum 0*.req 0*.resp repro.sh README.md MANIFEST.md > sha256sums.txt && cd -
chmod +x "evidence/$FID/repro.sh"
bash "evidence/$FID/repro.sh"   # must exit 0 and print REPRODUCED
```

Naming-convention and local-path checks:

```bash
ls "evidence/$FID" | grep -Ev '^(0[1-9][^/]*\.(req|resp)|MANIFEST\.md|README\.md|repro\.sh|sha256sums\.txt|replay_check)$' && echo NAMING_VIOLATION || echo NAMING_OK
grep -rEn '/home/|/tmp/|C:\\' "evidence/$FID/repro.sh" "evidence/$FID/README.md" "evidence/$FID/MANIFEST.md" && echo LOCAL_PATH_LEAK || echo PATHS_CLEAN
# redaction re-scan: second pass over the finished package
grep -rEn '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}' "evidence/$FID/" --include='*.resp' | grep -v RESEARCHER-OWNED | grep -v '\[REDACTED' && echo UNREDACTED_PII || echo REDACTION_OK
```

Trace-hygiene and date-stamp:

```bash
grep -q 'set -x' "evidence/$FID/repro.sh" && echo TRACE_LEAK_RISK || echo TRACE_OK
printf 'packaged: %s\nvalidated: %s\n' "$(date -u +%FT%TZ)" "$(grep -oE '20[0-9]{2}-[0-9]{2}-[0-9]{2}' review/validated_<finding-id>.md | head -1)" >> "evidence/$FID/MANIFEST.md"
```

Truncation marker for oversized bodies (apply in MANIFEST annotation, keep full file):

```bash
wc -c "evidence/$FID/"*.resp | sort -n | tail -3
# any body > 51200 bytes: annotation gets "[truncated at 50KB in display — full body in <file>]"
```

## Completion-bias defenses

- [ ] Package directory created with the exact finding-id/chain-id naming
- [ ] Baseline pair copied first and annotated (what "nothing here" looks like)
- [ ] All probe pairs copied in execution order with story-telling numbering
- [ ] Every pair annotated Burp-style in MANIFEST.md (request / response / what it proves)
- [ ] Bodies over 50KB marked truncated in display, full file retained
- [ ] repro.sh written: variables at top, `set -euo pipefail`, baseline first, copy-paste runnable
- [ ] Redaction pass completed; every redaction logged in MANIFEST.md with class
- [ ] sha256sums.txt generated covering every package file
- [ ] Fresh replay of repro.sh run in a clean shell — exit 0 and REPRODUCED required
- [ ] README.md written (summary, auth context, the 3 key commands, expected outputs)
- [ ] MANIFEST.md complete (inventory, hashes, annotations, redaction log, replay result, verdict line)
- [ ] Completeness check: every validation-file evidence reference resolves to a packaged file
- [ ] File naming convention verified (numbered pairs + fixed names only, no stowaways)
- [ ] No local filesystem paths in repro.sh / README.md / MANIFEST.md
- [ ] Redaction re-scan run on the finished package (second pass)
- [ ] Chain packages: links/rungN/ layout + CHAINMAP.md present
- [ ] No `set -x` in repro.sh (trace-hygiene verified)
- [ ] Packaging date + validation date stamped in MANIFEST.md
- **Review step:** the report_drafter replays repro.sh once more during drafting. If it fails there, the package is rejected back to this skill — the drafter never writes around broken evidence.
- **Nudge prompts:**
  - "Keep going until repro.sh passes from a clean shell. A package that only reproduces from your shell history is not evidence."
  - "Do not skip the redaction pass because 'it's probably fine.' Scan, redact, log — every package, every time."
  - "If the MANIFEST's pair annotations are longer than two lines each, you're editorializing. One to two lines: what the pair proves."
- **Finished artifact definition:** `evidence/<finding-id>/` containing `MANIFEST.md`, `README.md`, executable `repro.sh` (fresh-replay passing), numbered raw pairs `01_*` through `0N_*`, and `sha256sums.txt`. All six elements present with non-trivial content = done.

## Evidence standard

- Baseline: the package always opens with the baseline pair — the contrast is part of the proof.
- Reproduction: fresh-replay verification is the reproduction leg; the packaged pairs are the historical record.
- Raw evidence: untruncated raw pairs for the core three (baseline, probe1, probe2); truncation only in display annotations, never in files.
- Verdicts: PACKAGE-VERIFIED (fresh replay passed) / PACKAGE-STALE (target changed since validation — kept as historical proof, retest_regression dispatched). There is no "probably fine."

## Handoffs

- **report_drafter** consumes the package: steps-to-reproduce are copied from repro.sh; raw pairs are attached/linked from the writeup.
- **severity_calibrator** consumes the package: the README's auth context and the MANIFEST's annotations feed the calibration.
- **retest_regression** consumes the package: repro.sh is the exact script re-run against the patched target.
- **The human** consumes the package on request: "show me the raw pairs" is answered with the evidence directory, never with a paraphrase.
