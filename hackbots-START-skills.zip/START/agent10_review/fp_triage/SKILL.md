---
name: fp_triage
agent: agent10_review
description: Kills false positives fast — quick-kill discriminators that separate real bugs from noise before expensive validation burns time.
---

# FP Triage

## Purpose

Validation is expensive: baselines, double reproductions, raw pairs. Triage is cheap: a few fast discriminators that kill obvious non-findings in seconds. This skill sits in front of finding_validator and decides KILL or ESCALATE for every candidate that hasn't been validated yet. It kills the classics — framework defaults, WAF deny pages, login redirects dressed as 200s, reflections of your own input, timestamp noise mistaken for data leaks — and it does it fast, with a documented reason for every kill. Every kill goes into the dead-end registry so the pattern is recognized instantly next time. Speed here is what makes depth affordable elsewhere.

## Division of labor

- **Consumes:** unvalidated candidate findings (claimed class, target, the raw response that triggered the claim)
- **Produces:** the finished artifact — a triage verdict per candidate appended to `review/fp_triage_log.md`, plus new entries in `review/fp_registry.md` for every KILL; survivors are dispatched to finding_validator with a triage note

## When to use / when NOT to use

- **Use when:** any skill produces a candidate finding that has not yet been validated; when a recon sweep returns a pile of "interesting" responses that need sorting; when the same signature keeps reappearing across targets
- **Skip when (time-pass filter):** the candidate already has a CONFIRMED verdict — triage never second-guesses validation. Skip when the candidate is already in fp_registry.md with a KILL signature — it's dead, don't re-triage it, log the duplicate and move on.

## Methodology

1. Intake: for each candidate, capture the exact raw response that triggered the claim. Triage judges responses, not descriptions. No raw response → cannot triage → send back for the raw capture.
2. Registry check first: compute the candidate's signature (host + path pattern + status + body hash of the normalized response) and grep fp_registry.md. Hit → KILL-DUPLICATE, log it, done in seconds. This is the cheapest kill.
3. Run the quick-kill discriminators in order. Stop at the first kill — no need to run the rest:
   - **D1 — Framework default:** response matches a known stock page (default nginx/Apache/IIS welcome, Spring Whitelabel error, Django debug page signature, WordPress readme). Compare against the defaults library in `review/fp_defaults/`.
   - **D2 — WAF/edge deny:** body matches the host's known deny-page shape (compare against the baseline deny captured during recon — Akamai/Cloudflare reference IDs, `Access Denied` boilerplate). A WAF block is not a vulnerability.
   - **D3 — Login redirect in disguise:** status 200 but body is a login form, or 302 to `/login` — the "interesting 200" is just the auth wall. Check for `password` input fields.
   - **D4 — Self-reflection only:** the "leak" is the candidate's own request echoed back (search box reflecting the query, error message quoting the input). If removing your input from the request removes the "finding," it's not a finding.
   - **D5 — Timestamp/nonce noise:** the "difference" between baseline and probe is only timestamps, CSRF tokens, or request IDs. Normalize and re-diff — if the diff empties, kill it.
   - **D6 — Empty 200 / generic error:** 200 with empty or boilerplate body, or a generic 500 with no stack trace, no path disclosure, no data. A status code alone is not a finding.
   - **D7 — Requires creds you don't have:** the response is a login gate and the claim needs an authenticated session the hunt doesn't legitimately have. Not a finding for this hunt — log as `GATED`, not as a bug.
   - **D8 — Third-party asset:** the response comes from a third-party domain (CDN, analytics, auth provider) that is out of scope. Kill with reason `out-of-scope-asset`.
   - **D9 — Rate-limit page:** a 429 with retry messaging mistaken for information disclosure ("the endpoint reveals rate-limit logic"). Rate limiting is a control, not a bug — kill unless the candidate demonstrates a limiter bypass, which is a different finding.
   - **D10 — Public by design:** health checks (`/health`, `/status`, `/ping`), `robots.txt`, `/.well-known/` — intentionally public. Kill unless the content is sensitive beyond its purpose (e.g. `/status` leaking internal IPs or a version with a known RCE → escalate with that note).
4. For candidates surviving all discriminators, run the 60-second smell test: fetch the same path with a trivially different input (change one character). If the response is byte-identical including the "vulnerable" part → the response is static and the claim's mechanism is wrong → KILL with reason `static-response`.
5. Survivors get the reachability check: strip all auth material and re-request. Record whether the behavior is reachable unauthenticated. This doesn't kill — it routes (unauth survivors go to validation first; auth-required survivors are queued behind them).
6. Write the triage log entry per candidate: candidate id, discriminators run, kill reason or ESCALATE, registry signature, reachability note, time spent. Triage must be fast — if a candidate takes more than 5 minutes, you're validating, not triaging: ESCALATE it to finding_validator and move on.
7. Kill-confidence grading: mark every KILL as CERTAIN (discriminator matched a known reference — framework default hash, host deny shape) or LIKELY (heuristic match — keyword hit, size threshold). LIKELY kills go in a separate registry section and get priority in the human spot-check sample. A LIKELY kill is a hypothesis with a fast test, not a verdict carved in stone.
8. For every KILL, append to fp_registry.md: signature (method + path pattern + normalized body hash prefix), the discriminator that killed it, the confidence grade, the raw evidence pointer, date. The registry is append-only — never delete entries. Quote the 1-line evidence that triggered the discriminator (the matched string) — a kill without quoted evidence is not reviewable.
9. Batch-rule creation: when the same signature kills 3+ times in one hunt, stop triaging them individually — write a regex batch rule into fp_registry.md and notify the producing skill to stop emitting that pattern, naming the pattern and citing the three kills. Batch rules are only written for CERTAIN kills — never automate a heuristic.
10. Batch summary: at the end of a triage run, report counts (triaged / killed-by-discriminator / escalated / duplicates, CERTAIN vs LIKELY split). If one discriminator kills >50% of a batch, flag it to hunt_debrief — the producing skill is generating a systematic false-positive pattern and needs its methodology fixed.
11. Registry hygiene (monthly): re-validate the fp_defaults/ reference library against current framework stock pages — defaults change with new releases, and a stale library either misses kills or, worse, starts killing real pages. Log the refresh date in the registry header.

**Decision branches:** if a candidate's raw response is huge (>1MB) → triage on headers + first 10KB; note the truncation. If discriminators disagree (D4 says self-reflection but the reflection includes another user's data) → the disagreement itself is signal: ESCALATE with the conflict noted. If the same kill signature appears 3+ times in one hunt → stop triaging them individually, add a batch rule to the registry, and tell the producing skill to stop emitting that pattern.

## Exact commands

Registry check (cheapest kill first):

```bash
SIG="$(printf '%s' '<METHOD> <path-pattern>' | sha256sum | cut -c1-16)"
grep -q "$SIG" review/fp_registry.md && echo KILL_DUPLICATE || echo NOT_IN_REGISTRY
```

Quick-kill discriminators (run in order, stop at first kill):

```bash
RESP="review/triage/<candidate-id>.resp"
# D1: framework default — diff against known stock pages
for d in review/fp_defaults/*.html; do diff -q <(sed -E 's/[0-9a-f-]{36}/UUID/g' "$RESP") <(sed -E 's/[0-9a-f-]{36}/UUID/g' "$d") >/dev/null && { echo "KILL D1 framework-default ($d)"; break; }; done
# D2: WAF/edge deny — compare against the host's captured deny shape
grep -qiE 'access denied|request blocked|reference #[0-9]|attention required' "$RESP" && echo "KILL D2 waf-deny"
# D3: login redirect in disguise
grep -qiE '<input[^>]*type="password"|/login|sso' "$RESP" && echo "KILL D3 login-wall"
# D4: self-reflection only — does the "finding" vanish without your input?
# (re-request with the input parameter removed; compare)
# D5: timestamp/nonce noise — normalize and re-diff vs baseline
diff <(sed -E -e 's/[0-9]{10,13}/EPOCH/g' -e 's/[0-9a-f-]{36}/UUID/g' "$RESP") \
     <(sed -E -e 's/[0-9]{10,13}/EPOCH/g' -e 's/[0-9a-f-]{36}/UUID/g' review/triage/<candidate-id>.baseline) >/dev/null && echo "KILL D5 noise-only"
# D6: empty 200 / generic error
{ [ "$(wc -c < "$RESP")" -lt 300 ] && echo "KILL D6 empty-or-boilerplate"; }
# D9: rate-limit page mistaken for a finding
grep -qiE 'rate.?limit|too many requests|retry-after' "$RESP" && echo "KILL D9 rate-limit-page"
# D10: intentionally public endpoint
printf '%s' "<path>" | grep -qiE '^/(health|status|ping|robots\.txt|\.well-known/)' && echo "KILL D10 public-by-design (escalate only if content is sensitive)"
```

60-second smell test (is the response static regardless of input?):

```bash
curl -s "https://<HOST>/<path>?<param>=AAAA" -o /tmp/t1.resp
curl -s "https://<HOST>/<path>?<param>=BBBB" -o /tmp/t2.resp
cmp -s /tmp/t1.resp /tmp/t2.resp && echo "KILL static-response" || echo "dynamic — continue"
```

Reachability check (strip auth, re-request):

```bash
curl -s -o /tmp/noauth.resp -w '%{http_code}\n' "https://<HOST>/<path>"
# compare with the authed response: same behavior -> unauth-reachable
```

Worked kill example (full triage of one candidate):

```bash
# candidate: "SQLi on /api/search?q=" — raw response saved
RESP=review/triage/sqli-api-search-01.resp
# registry first
SIG="$(printf '%s' 'GET /api/search' | sha256sum | cut -c1-16)"
grep -q "$SIG" review/fp_registry.md && echo KILL_DUPLICATE
# D4 check: remove the input, re-request
curl -s "https://<HOST>/api/search" -o /tmp/noinput.resp
grep -qi 'sql syntax' /tmp/noinput.resp && echo "error without input -> not self-triggered" || echo "no error without input -> self-triggered input"
# reachability: strip auth, re-request with the payload
curl -s "https://<HOST>/api/search?q=%27" -o /tmp/noauth.resp -w 'http=%{http_code}\n'
# verdict goes in the triage log with the discriminator cited
```

Registry append for a kill:

```bash
printf '%s | %s | %s | %s | %s | %s\n' "$SIG" "<candidate-id>" "<discriminator>" "<CERTAIN|LIKELY>" "<one-line-reason>" "$(date -u +%F)" >> review/fp_registry.md
```

## Completion-bias defenses

- [ ] Raw response captured for every candidate before triage begins
- [ ] Registry checked first for every candidate (duplicate kills logged, not re-triaged)
- [ ] Discriminators D1–D8 run in order; first kill stops the sequence
- [ ] 60-second smell test run on all discriminator survivors
- [ ] Reachability check done on survivors (unauth vs auth-required recorded)
- [ ] Triage log entry written per candidate with discriminators run and verdict
- [ ] Every KILL appended to fp_registry.md with signature + discriminator + date
- [ ] 5-minute rule enforced: slow candidates escalated, not triaged-to-death
- [ ] D9 (rate-limit page) and D10 (public-by-design) in the discriminator sequence
- [ ] Every KILL quotes its 1-line trigger evidence in the registry entry
- [ ] Batch rule written + producing skill notified at 3+ repeat kills
- [ ] Every KILL graded CERTAIN or LIKELY; LIKELY kills in the separate registry section
- [ ] Batch rules only from CERTAIN kills — no automated heuristics
- [ ] Registry hygiene: fp_defaults/ refreshed against current framework stock pages (monthly)
- [ ] Batch summary written; systematic-FP patterns flagged to hunt_debrief
- **Review step:** the human spot-checks 1 in 10 KILLs per batch by re-running the cited discriminator. A wrongly killed candidate is restored, the discriminator is refined, and the registry entry is corrected — killing a real bug is the worst error this skill can make.
- **Nudge prompts:**
  - "Keep going until every candidate in the batch has a log entry. An untriaged candidate is a candidate you'll pay validation-cost for later."
  - "Do not ESCALATE because a response 'feels interesting.' Interesting is not a discriminator result — run D1–D10, then decide."
  - "D9 and D10 exist because hunters keep reporting rate limiters and health checks. If the response is a control working as designed, it is not a finding."
  - "Grade every kill. A CERTAIN kill you can defend; a LIKELY kill you must be able to un-kill. If you cannot tell which it is, it is LIKELY."
  - "If you're writing more than three sentences of justification for a KILL, you're overthinking it. One discriminator, one line, next candidate."
- **Finished artifact definition:** `review/fp_triage_log.md` entries for every candidate in the batch (id, discriminators run, verdict KILL/ESCALATE, registry signature, reachability note) plus new `review/fp_registry.md` entries for every KILL. Every candidate accounted for = done.

## Evidence standard

- Baseline: each discriminator compares against a known reference (framework defaults library, host deny shape, the candidate's own baseline) — the reference is cited in the log entry.
- Reproduction: triage kills must be re-producible: re-running the cited discriminator command on the saved raw response must produce the same kill. The raw response is kept for this.
- Raw evidence: the triggering raw response is saved under `review/triage/<candidate-id>.resp` for every candidate, killed or escalated.
- Verdicts: KILL (discriminator cited, registry updated) / KILL-DUPLICATE (registry hit) / ESCALATE (survived triage → finding_validator) / GATED (needs creds the hunt doesn't have — not a bug, not a kill).

## Handoffs

- **finding_validator** consumes ESCALATE candidates with the triage note (which discriminators it survived, reachability classification).
- **hunt_debrief** consumes the batch summary: systematic-FP patterns become skill-methodology fixes and pattern-library negative entries.
- **The human** consumes the spot-check sample and any GATED candidates (the credential decision is theirs).
- **fp_registry.md** is consumed by every future triage run and by completion_checklist_audit (NEGATIVE findings must be registered — an audit item).
