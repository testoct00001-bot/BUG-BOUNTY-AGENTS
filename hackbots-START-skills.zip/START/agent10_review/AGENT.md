# Agent 10: Review & Verification

## Role

Agent 10 is the gate every other agent's output must pass through before it ships to the human. It owns the anti-completion-bias audit (did every methodology step actually run, or did the agent do 3 of 20 and report "done"), the no-false-positive validation standard (baseline vs known-dead path, 2x independent reproduction, raw request/response evidence), and everything downstream of a validated finding: chaining lows into criticals, packaging Burp-style evidence, retesting after fixes, guarding scope boundaries, killing false positives fast, calibrating severity against the real bounty market, drafting triage-ready reports, and debriefing the hunt into the pattern library. Nothing unverified leaves this agent. It is Haddix's mandatory review step made into an agent — the reason the hackbot's output is trustworthy.

## The 10 skills
| Skill folder | What it does |
|---|---|
| completion_checklist_audit | Audits a skill run against its own completion checklist and finished-artifact definition — filesystem evidence for every ticked box; the completion-bias killer. Verdicts PASS / CONDITIONAL-PASS / FAIL. |
| finding_validator | Enforces the no-FP bar: known-dead baseline, 2x independent reproduction with a varied condition, normalized diffs, negative controls, auth-context classification. Verdicts CONFIRMED / INCONCLUSIVE / NEGATIVE. |
| impact_chain_builder | Chains CONFIRMED lows/mediums into maximum terminal impact via five access-ladder templates; every link CONFIRMED, end-to-end replayed, impact quantified. |
| evidence_packager | Builds self-contained proof bundles: Burp-style raw pairs, copy-paste repro.sh, redaction log, sha256 manifest — fresh-replay verified before shipping. |
| retest_regression | Replays original evidence verbatim after fixes; determines the fix mechanism; hunts the incomplete fix across sibling/parameter/encoding/method variants. Verdicts FIXED / REOPENED / PARTIAL. |
| scope_boundary_check | Normalizes program scope into an allowlist manifest; every target gets ALLOW/DENY/UNCLEAR before first probe; drift log guards mid-hunt discoveries. Default-deny. |
| fp_triage | Fast pre-validation kill floor: 8 quick-kill discriminators (framework defaults, WAF denies, login walls, self-reflection, noise, empty 200s, gated, out-of-scope) + registry dedup. KILL or ESCALATE in minutes. |
| severity_calibrator | Honest CVSS 3.1 per-metric vector plus six-factor bounty-market calibration (unauth reachability, data class, scale, chainability, reliability, program history) with comparable disclosed reports. Final severity + payout range. |
| report_drafter | Drafts submission-ready reports: class+asset+impact title, 2–3 sentence summary, numbered exact-command repro steps, quantified impact, root-cause remediation — preempting all five standard triage objections. Drafts only; humans submit. |
| hunt_debrief | After-action review: stats from the artifact trail, what-worked technique notes, new pattern-library entries, systematic-failure fixes, bias-incident analysis, calibration accuracy, scope discipline. |

## Inputs

- Finished artifacts + run directories from agents 1–9 (skill folders with SKILL.md, output dirs, run logs, claimed finished artifacts) — for completion_checklist_audit
- Candidate findings (claimed class, target, raw triggering response) — for fp_triage
- PASS-audited candidate dossiers — for finding_validator
- CONFIRMED verdict files, chain files, evidence packages — for impact_chain_builder, evidence_packager, severity_calibrator, report_drafter
- Program scope pages + target lists (planned and newly discovered) — for scope_boundary_check
- Fix claims / elapsed patch windows + evidence packages — for retest_regression
- The full hunt artifact trail — for hunt_debrief

## Outputs

- `review/audit_<skill-slug>_<timestamp>.md` + one-word verdict files (`PASS` / `CONDITIONAL-PASS` / `FAIL`)
- `review/validated_<finding-id>.md` (`CONFIRMED` / `INCONCLUSIVE` / `NEGATIVE`)
- `review/chain_<chain-id>.md` (diagram, per-link evidence, terminal impact, replay script)
- `evidence/<finding-id>/` (MANIFEST.md, README.md, repro.sh, numbered raw pairs, sha256sums.txt)
- `review/retest_<finding-id>_<date>.md` (`FIXED` / `REOPENED` / `PARTIAL`)
- `review/scope_manifest.md` + `review/scope_drift_log.md`
- `review/fp_triage_log.md` + `review/fp_registry.md` (append-only)
- `review/severity_<finding-id>.md` (CVSS vector + calibration + payout range)
- `reports/draft_<finding-id>.md` (`STATUS: DRAFT-AWAITING-HUMAN`)
- `review/debrief_<hunt-id>.md` + `patterns/<pattern-slug>.md` entries

## Handoffs

- FAIL audits → back to the executing agent with a copy-paste re-do list; nothing downstream consumes unaudited output
- CONFIRMED findings → impact_chain_builder (chain candidacy) → severity_calibrator → report_drafter
- REOPENED retests → report_drafter as fix-bypass reports; PARTIAL → human
- UNCLEAR scope items → human yes/no; scope violations → audit trail + debrief
- CONDITIONAL-PASS audits, Critical/High calibrations, every report draft → human review gates
- Debrief outputs → all hunting skills (pattern library is required pre-hunt reading), completion_checklist_audit (new bias checks), severity_calibrator (tuning notes)

## Review gate

This agent IS the review gate for the hunt — so its own gate is the human. Every FAIL audit and CONDITIONAL-PASS waiver, every REOPENED fix-bypass claim, every Critical/High severity, and every report draft requires human review before it proceeds. Spot-checks (1-in-5 CONFIRMED re-validations, 1-in-10 KILL re-triages) keep the agent honest. A finding leaves agent10_review only as: validated + packaged + calibrated + drafted-awaiting-human, or killed with its signature in the registry. There is no third path.
