---
name: hunt_debrief
agent: agent10_review
description: After-action review of the hunt — what worked, new patterns discovered, dead ends retired, and pattern-library updates for the next hunt.
---

# Hunt Debrief

## Purpose

A hunt that ends without a debrief teaches nothing; the next hunt repeats the same mistakes at the same cost. This skill is the after-action review: it reads the entire artifact trail — audits, validations, chains, packages, retests, triage logs, severity files, drafts — and extracts what actually worked, what systematically failed, and what new patterns were discovered. Its output is twofold: a debrief report for the human, and pattern-library entries that make the next hunt smarter. Haddix's war stories exist because someone debriefed; this skill manufactures the next ones.

## Division of labor

- **Consumes:** the full hunt artifact trail — `review/audit_*.md`, `review/validated_*.md`, `review/chain_*.md`, `evidence/*/`, `review/retest_*.md`, `review/fp_triage_log.md`, `review/fp_registry.md`, `review/severity_*.md`, `reports/draft_*.md`, `review/scope_drift_log.md`
- **Produces:** the finished artifact — `review/debrief_<hunt-id>.md` (stats, what worked, what failed, new patterns, skill-improvement notes) AND new/updated files under `patterns/<pattern-slug>.md`

## When to use / when NOT to use

- **Use when:** a hunt round ends (all agents' checklists audited); on a schedule for long-running hunts (weekly); after a major finding ships (capture the pattern while it's hot)
- **Skip when (time-pass filter):** the hunt produced no artifacts beyond recon — debrief needs a trail; an empty trail gets a one-paragraph "nothing to debrief" note, not a ceremony. Never skip after a hunt with CONFIRMED findings — that's exactly when the patterns are freshest.

## Methodology

1. Inventory the trail: count artifacts by type. Record the hunt-id, target set, date range, and participating agents/skills. If the trail is missing expected artifacts (e.g. validations exist but no audits), note the gap — the debrief audits the hunt's own discipline too.
2. Compute the stats table: targets tested, skills run, audits PASS/FAIL/CONDITIONAL-PASS, candidates triaged, killed by discriminator (with the top-3 killing discriminators), validated CONFIRMED/INCONCLUSIVE/NEGATIVE, chains built, reports drafted/submitted, retests FIXED/REOPENED. Record which model ran which skill — retune notes for the next model depend on knowing what ran where. Numbers first — narrative second.
3. What worked: for every CONFIRMED finding and CHAIN-CONFIRMED chain, trace back to the technique that produced it — which skill, which methodology step, which observation triggered it. Write each as a reusable technique note: "technique → trigger → result." These are the hunt's proven weapons.
4. New patterns: for each novel observation (a response shape, a framework quirk, a bypass that worked, a chain template that fired), write a pattern-library entry:
   - `patterns/<pattern-slug>.md` with: Pattern name, Trigger (what you see that suggests it), Technique (exact steps/commands), Example (finding-id + one-line result), Program class (where it applies), Confidence (seen once / repeated / systematic)
5. What failed systematically: find the repeats — the discriminator that killed 40% of candidates (the producing skill needs a methodology fix), the skill that failed audit twice (checklist or harness problem), the chain template that never fired (retire or re-scope it). Each gets a skill-improvement note with the evidence cited.
6. Completion-bias incidents: pull every audit FAIL and CONDITIONAL-PASS. What was skipped, and why? If the same step gets skipped across skills (e.g. "second model run" never happens), that's a harness-level problem — recommend the enforcement fix (block handoff until the artifact exists).
7. Calibration accuracy: for submitted findings with known triage outcomes, compare predicted severity/payout range vs actual. Record the delta. Systematic over/under-calibration becomes a severity_calibrator tuning note.
8. Dead-end registry review: scan fp_registry.md for entries added this hunt. Promote repeated signatures to batch rules; retire entries that were later proven wrong (with the correction noted — the registry must stay trustworthy).
9. Scope discipline: review scope_drift_log.md and any violations flagged by audit. Report the violation count; zero is the target and is worth stating.
10. Write the debrief: stats, what worked (technique notes), new patterns (with pattern-file links), systematic failures (with improvement notes), bias incidents, calibration accuracy, registry changes, scope discipline, and the top-3 recommendations for the next hunt — concrete, assigned ("fix X in skill Y before next round"), not vague.
11. Negative patterns: for techniques that consumed significant effort and produced only NEGATIVEs on this target class, write negative pattern entries (`patterns/negative_<slug>.md`): what was tried, why it failed here, and the signal that would make it worth trying again. Future hunts skip these unless the signal appears.
12. Technique-diffusion check: for each what-worked technique, check whether other agents/skills adopted it mid-hunt (grep the skill folders for the technique keyword). If a winning technique stayed siloed in one agent, log the diffusion gap and assign the spread — which skills should adopt it next round.
13. Open-questions log (interim debriefs): list every unresolved item — INCONCLUSIVE findings awaiting a second model run, gated chains awaiting credentials, UNCLEAR scope items awaiting the human. Each with owner and next action. An interim debrief with no open-questions log is pretending the hunt is over.
14. Artifact retention decision: after the debrief, decide what stays hot (evidence packages for open findings, the pattern library, the fp registry) and what gets archived (per-run raw captures older than the retention window, superseded drafts). Record the decision in the debrief — disk is cheap, but a workspace full of stale captures is how the next hunt re-tests dead ends.
15. Human review: the debrief goes to the human. Pattern-library entries marked `seen-once` need human confirmation before being promoted to `repeated` — one observation is a note, not a pattern.

**Decision branches:** if the hunt is ongoing (scheduled debrief) → write it as an interim debrief, mark open questions explicitly, don't close patterns prematurely. If a "new pattern" is actually a known technique from writeup-intel → link it instead of duplicating; the entry becomes a confirmation data point, not a new pattern. If the trail shows an agent worked without audit coverage → flag as a process violation in the debrief, regardless of its results.

## Exact commands

Trail inventory:

```bash
HUNT="<hunt-id>"
echo "audits: $(ls review/audit_*.md 2>/dev/null | wc -l)"
echo "validated: $(ls review/validated_*.md 2>/dev/null | wc -l)"
grep -h '^VERDICT:' review/validated_*.md 2>/dev/null | sort | uniq -c
echo "chains: $(ls review/chain_*.md 2>/dev/null | wc -l)"
echo "drafts: $(ls reports/draft_*.md 2>/dev/null | wc -l)"
echo "retests: $(ls review/retest_*.md 2>/dev/null | wc -l)"
```

Top killing discriminators (what's generating the noise?):

```bash
grep -oE 'D[1-8]' review/fp_triage_log.md | sort | uniq -c | sort -rn | head -5
grep -c 'KILL' review/fp_triage_log.md; grep -c 'ESCALATE' review/fp_triage_log.md
```

Audit health (completion-bias pressure gauge):

```bash
grep -h 'verdict' review/audit_*_verdict.txt 2>/dev/null | sort | uniq -c
grep -l 'uniform-timestamps\|truncated-loops\|early-done' review/audit_*.md 2>/dev/null
```

What-worked trace (technique behind each CONFIRMED):

```bash
for f in review/validated_*.md; do
  grep -q '^VERDICT: CONFIRMED' "$f" || continue
  echo "== $f =="; grep -E '^(Class|Target)' "$f" | head -2
done
```

Pattern entry creation:

```bash
mkdir -p patterns
# write patterns/<pattern-slug>.md per the format in step 4
ls patterns/ | wc -l
```

Technique-diffusion check (did the winning technique spread?):

```bash
grep -rl "<technique-keyword>" ~/workspace/hackbot-skills/START/agent*/ --include=SKILL.md
# adopted by >1 agent = diffused; only the originator = diffusion gap -> assign the spread
```

Pattern-entry format (follow verbatim):

```markdown
# Pattern: <name>
Trigger: <what you see that suggests trying this>
Technique: <exact steps or commands>
Example: <finding-id> — <one-line result>
Program class: <where it applies>
Confidence: seen-once | repeated | systematic
```

Retention sizing (what's actually on disk):

```bash
du -sh review/ evidence/ reports/ patterns/ 2>/dev/null
find review/validation -maxdepth 1 -type d -mtime +30 | head   # stale captures: archive candidates
```

## Completion-bias defenses

- [ ] Full trail inventoried; missing-artifact gaps noted explicitly
- [ ] Stats table computed from files, not from memory
- [ ] Every CONFIRMED finding traced to its producing technique (technique → trigger → result)
- [ ] New patterns written as patterns/<pattern-slug>.md with all six fields
- [ ] Systematic failures identified with evidence and skill-improvement notes assigned
- [ ] Completion-bias incidents pulled from audits; harness-level repeats flagged with enforcement recommendations
- [ ] Calibration accuracy checked against known triage outcomes
- [ ] fp_registry.md reviewed: batch rules promoted, wrong entries corrected
- [ ] Scope discipline reported (drift log + violation count)
- [ ] Top-3 concrete next-hunt recommendations written, each assigned to a skill
- [ ] Debrief routed to human; seen-once patterns marked pending human confirmation
- [ ] Negative patterns written for effort-heavy techniques that produced only NEGATIVEs
- [ ] Technique-diffusion check done; diffusion gaps assigned to specific skills
- [ ] Open-questions log written with owner + next action per item (interim debriefs)
- [ ] Pattern entries follow the six-field format verbatim
- [ ] Artifact retention decision recorded (hot vs archive)
- **Review step:** the human reviews the debrief and approves pattern promotions. The debrief is the one artifact where the human's judgment outranks the files — if they disagree with a "what worked" note, their version stands.
- **Nudge prompts:**
  - "Keep going until every CONFIRMED finding has a technique note. An unexplained win is luck, and luck doesn't replicate."
  - "Do not write 'test more' as a recommendation. Name the skill, the step, and the exact change — or don't write it."
  - "If the debrief has no systematic failures listed, you didn't look hard enough. Re-read the triage log's top discriminator."
  - "A pattern entry without a Trigger is a diary entry, not a pattern. If you can't say what to look for next time, you didn't learn anything."
- **Finished artifact definition:** `review/debrief_<hunt-id>.md` (stats, what-worked technique notes, new-pattern links, systematic failures with improvement notes, bias incidents, calibration accuracy, registry changes, scope discipline, top-3 assigned recommendations) AND all new `patterns/<pattern-slug>.md` entries created this round. Debrief complete with human routing noted = done.

## Evidence standard

- Baseline: the stats table is the baseline — every narrative claim in the debrief must be traceable to a counted artifact.
- Reproduction: re-running the inventory commands must reproduce the stats; technique notes cite finding-ids so anyone can re-derive them.
- Raw evidence: the debrief quotes artifact paths, not conclusions — `review/validated_x.md` says CONFIRMED, not "we found an IDOR."
- Verdicts: no single verdict — the debrief's "verdicts" are the pattern confidence tags (seen-once / repeated / systematic) and the calibration accuracy deltas.

## Handoffs

- **All hunting skills** consume the pattern library: `patterns/` is required reading before the next hunt round — new triggers go into wordlists, new techniques into methodologies.
- **completion_checklist_audit** consumes the bias-incident section: repeated skip patterns become new audit checks.
- **severity_calibrator** consumes the calibration-accuracy section: systematic drift becomes tuning notes.
- **The human** consumes the debrief: approves pattern promotions, assigns the top-3 recommendations, and decides the next hunt's focus.
