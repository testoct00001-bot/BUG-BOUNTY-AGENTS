---
name: finding_validator
agent: agent10_review
description: Validates candidate findings against the no-FP bar — baseline vs known-dead path, 2x independent reproduction, raw request/response evidence; verdicts CONFIRMED / INCONCLUSIVE / NEGATIVE.
---

# Finding Validator

## Purpose

A candidate finding is not a finding until it survives this skill. It enforces the standing no-false-positive bar: every claimed hit is compared against a known-dead baseline on the same host, reproduced twice independently (different time, varied conditions), and documented with full raw request/response pairs. Only then does it earn CONFIRMED. Anything that cannot be reproduced is NEGATIVE and goes into the dead-end registry so nobody wastes a run re-testing it. This is what keeps the hunt's output trustworthy when findings feed chains, severity ratings, and reports.

## Division of labor

- **Consumes:** a candidate finding dossier — claimed vulnerability class, target URL/endpoint, the original probe request, and the PASS audit file of the skill that produced it (findings without a PASS audit are rejected at intake)
- **Produces:** the finished artifact — `review/validated_<finding-id>.md` containing the baseline pair, both reproduction pairs, normalized diffs, and exactly one verdict: `CONFIRMED`, `INCONCLUSIVE`, or `NEGATIVE`

## When to use / when NOT to use

- **Use when:** any skill hands off a candidate finding; when fp_triage escalates a survivor; when a chain builder needs a missing link tested; when a program reopens a ticket and you must re-prove the original claim
- **Skip when (time-pass filter):** the candidate only exists on a login-walled page you cannot reach — validate reachability first, don't burn reproductions on gated surface. Skip when the "finding" is a framework default page or a generic error — send it to fp_triage for a fast kill instead. Ask: does it leak? Is it sensitive? Is it reachable unauthenticated? If all three are no, it never reaches this skill.

## Methodology

1. Intake: read the candidate dossier. Reject immediately if there is no PASS audit from the producing skill — log the rejection and return. The audit gate is not optional.
2. Write the finding-id: `<class>-<host>-<NN>` (e.g. `ssrf-api-example-com-01`). All artifacts for this finding live under `review/validation/<finding-id>/`.
3. Define the known-dead baseline: pick a path on the SAME host that must not exist — `/__validator_dead_<16-hex-chars>/`. The hex suffix guarantees it is not a real route. Request it and save the full raw pair as `baseline.req` / `baseline.resp`. This is the shape of "nothing here" on this host.
4. Capture the probe exactly as the candidate describes it: same method, path, headers, body. Save raw pair as `probe1.req` / `probe1.resp`. Do not "improve" the probe — reproduce what was claimed, verbatim.
5. Wait at least 60 seconds, then run reproduction 2: identical probe, saved as `probe2.req` / `probe2.resp`. The delay breaks cache-coincidence and proves the behavior is stable, not a one-off.
6. Vary one condition on reproduction 2 if the environment allows: different source egress, or strip the session cookie, or change the User-Agent. Record exactly what varied. If the finding only reproduces with one exact cookie, that fact goes in the report — it changes the severity.
7. Normalize all three responses: strip dynamic tokens before any comparison — timestamps (ISO and epoch), UUIDs, CSRF tokens, nonces, session ids, `Date`/`Set-Cookie` headers. Diff normalized bodies: baseline-vs-probe1 and probe1-vs-probe2.
8. Apply the divergence rules:
   - probe1 ≈ probe2 (normalized) but probe1 ≠ baseline (normalized) → behavior is real and stable → proceed
   - probe1 ≠ probe2 (normalized) → flaky, cache artifact, or time-dependent → INCONCLUSIVE, note the variance
   - probe1 ≈ baseline (normalized) → the "hit" was noise → NEGATIVE
   - All three identical → the probe never diverged from dead → NEGATIVE
9. Run negative controls: 2–3 mutated probes that SHOULD fail — wrong parameter name, truncated token, off-by-one id. If a mutation that should fail still "succeeds," the endpoint is not actually validating input and the original finding's mechanism is misunderstood → INCONCLUSIVE, mechanism needs re-derivation.
10. Prove the data is real, not placeholder: inspect the leaked/reflected content for synthetic markers — `lorem`, `example.com`, `faker`, `test_`, all-zeros, sequential `12345` ids, stock framework text. Real data has entropy and internal consistency (ids referenced elsewhere resolve, emails have real domains, timestamps are recent). Placeholder data → NEGATIVE with reason `synthetic-data`.
11. Auth-context classification: run the probe with no cookies/headers, then with the researcher's session. Classify: `unauth` (works with nothing), `auth` (needs session — note whose), `session-dependent` (works only with the exact original session — fragile, downgrade severity).
12. Check the framework-default trap: fetch the same path pattern on a stock install signature if known (e.g. default Spring/WordPress/Django responses). If the response matches a framework default byte-for-byte → NEGATIVE, `framework-default`.
13. If CONFIRMED: write the verdict file with the full evidence chain — baseline pair, both reproduction pairs, normalized diffs, negative-control results, auth classification, and the exact reproduction commands. This file is what evidence_packager consumes.
14. If INCONCLUSIVE: state exactly what is missing (second model run? a different egress? human with credentials?) and what was already ruled out. INCONCLUSIVE is not a soft CONFIRMED — nothing downstream may treat it as confirmed.
15. If NEGATIVE: append a one-line signature to `review/fp_registry.md` (finding-id, signature of the dead response, reason) so no future run re-tests it. Write the verdict file with the killing evidence.
16. Sanity-check your own verdict: re-read the three normalized diffs once more before writing the file. The most expensive error in this skill is a CONFIRMED that was actually a cached 200.
17. HTTP-version differential: run the probe over HTTP/1.1 and HTTP/2 (`curl --http1.1` / `curl --http2`). If the finding reproduces on only one version, record it — version-dependent behavior changes the repro steps, and the report must state the working version explicitly.
18. Response-size stability: record the normalized Content-Length of probe1 vs probe2. The leak marker must be stable; if the payload size swings wildly between runs, the finding may be pulling from a changing dataset — CONFIRMED can still hold, but the report must disclose the variance.

**Decision branches:** if the target rate-limits or WAF-blocks mid-validation → pause, wait 5 minutes, retry once; if still blocked → INCONCLUSIVE with reason `waf-interference`, do not force through. If the probe mutates state (POST that writes) → run reproductions against a canary resource you created, never against another user's data; if no safe canary exists → INCONCLUSIVE with reason `state-mutating-no-canary`. If baseline and probe both return 403 with identical bodies → the host denies everything uniformly; the finding is untestable from this vantage → INCONCLUSIVE, `uniform-deny`.

## Exact commands

Baseline capture (known-dead path on the same host):

```bash
FID="ssrf-api-example-com-01"
mkdir -p "review/validation/$FID"
BASE="https://<HOST>/__validator_dead_9f3a2b7c1d4e5f6a/"
curl -s -i --max-time 20 "$BASE" -o "review/validation/$FID/baseline.resp" -D "review/validation/$FID/baseline.headers"
printf 'GET %s HTTP/1.1\nHost: <HOST>\n\n' "$BASE" > "review/validation/$FID/baseline.req"
```

Probe capture, verbatim reproduction (run twice, ≥60s apart):

```bash
# Save the EXACT request the candidate claimed — method, headers, body, all of it
curl -s -i --max-time 20 -X POST "https://<HOST>/<path>" \
  -H "Content-Type: application/json" \
  -H "Cookie: <session-if-any>" \
  --data-raw '{"<param>":"<value>"}' \
  -o "review/validation/$FID/probe1.resp" -D "review/validation/$FID/probe1.headers"
sleep 65
curl -s -i --max-time 20 -X POST "https://<HOST>/<path>" \
  -H "Content-Type: application/json" \
  --data-raw '{"<param>":"<value>"}' \
  -o "review/validation/$FID/probe2.resp" -D "review/validation/$FID/probe2.headers"
# note: probe2 above intentionally drops the session cookie -> auth-context classification
```

Normalized diff (strip dynamic tokens before comparing):

```bash
norm() { sed -E -e 's/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/UUID/g' \
                -e 's/[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9:.]+Z?/TS/g' \
                -e 's/[0-9]{10,13}/EPOCH/g' \
                -e '/^Date:/d' -e '/^Set-Cookie:/d' "$1"; }
diff <(norm "review/validation/$FID/baseline.resp") <(norm "review/validation/$FID/probe1.resp") > /dev/null && echo SAME_AS_BASELINE || echo DIVERGES_FROM_BASELINE
diff <(norm "review/validation/$FID/probe1.resp") <(norm "review/validation/$FID/probe2.resp") > /dev/null && echo STABLE || echo FLAKY
```

Negative controls (mutations that should fail):

```bash
# wrong param name -> should NOT reproduce the finding
curl -s -o /dev/null -w '%{http_code}\n' -X POST "https://<HOST>/<path>" \
  -H "Content-Type: application/json" --data-raw '{"<wrong_param>":"<value>"}'
# truncated token -> should NOT reproduce
curl -s -o /dev/null -w '%{http_code}\n' "https://<HOST>/<path>?token=abc"
# swapped values -> should NOT reproduce the same leak
curl -s --max-time 20 -X POST "https://<HOST>/<path>" -H "Content-Type: application/json" \
  --data-raw '{"<param_a>":"<value_b>","<param_b>":"<value_a>"}' -o /tmp/swap.resp -w '%{http_code}\n'
```

HTTP-version differential:

```bash
curl -s --http1.1 -o /tmp/h1.resp -w 'h1=%{http_code}\n' -X POST "https://<HOST>/<path>" -H "Content-Type: application/json" --data-raw '{"<param>":"<value>"}'
curl -s --http2 -o /tmp/h2.resp -w 'h2=%{http_code}\n' -X POST "https://<HOST>/<path>" -H "Content-Type: application/json" --data-raw '{"<param>":"<value>"}'
grep -c "<marker-string>" /tmp/h1.resp /tmp/h2.resp
```

Synthetic-data check on leaked content:

```bash
grep -Ei 'lorem|example\.com|faker|test_|000000|12345' "review/validation/$FID/probe1.resp" && echo SYNTHETIC_MARKERS || echo NO_MARKERS
```

Or run the helper (does baseline + 2 probes + normalization + verdict recommendation):

```bash
python3 replay.py --spec "review/validation/$FID/spec.json" --out "review/validation/$FID/"
```

## Completion-bias defenses

- [ ] PASS audit of the producing skill verified at intake — no audit, no validation
- [ ] Baseline captured on the SAME host with a guaranteed-dead path before any verdict
- [ ] Probe reproduced verbatim (no "improvements") for probe1
- [ ] Reproduction 2 run ≥60s after probe1, with one varied condition recorded
- [ ] All three responses normalized (timestamps, UUIDs, cookies stripped) before diffing
- [ ] Divergence rules applied mechanically: probe1≈probe2≠baseline required for CONFIRMED
- [ ] 2–3 negative controls run; results recorded
- [ ] Synthetic/placeholder data check run on any leaked content
- [ ] Auth-context classification done (unauth / auth / session-dependent)
- [ ] Framework-default trap checked where a stock signature exists
- [ ] Verdict file written with full evidence chain; NEGATIVE appended to fp_registry.md
- [ ] Final re-read of normalized diffs before writing the verdict
- [ ] HTTP/1.1 vs HTTP/2 differential run; version-dependence recorded
- [ ] Response-size stability checked across probe1/probe2
- [ ] Swapped-value negative control run and recorded
- **Review step:** agent10_review's own lead (or the human) spot-checks 1 in 5 CONFIRMED verdicts by re-running the reproduction commands from the verdict file. A spot-check failure demotes the finding to INCONCLUSIVE and triggers a re-validation of the batch.
- **Nudge prompts:**
  - "Keep going until you have three raw pairs on disk: baseline, probe1, probe2. Two pairs is not validation."
  - "Do not write CONFIRMED because the response 'looks vulnerable.' CONFIRMED requires probe1≈probe2≠baseline on normalized bodies plus passing negative controls."
  - "When in doubt between INCONCLUSIVE and NEGATIVE, pick the harsher one and document why. A wrong CONFIRMED costs the hunt's credibility."
- **Finished artifact definition:** `review/validated_<finding-id>.md` containing the finding-id, class, target, baseline raw pair, probe1 and probe2 raw pairs, normalized diff results, negative-control results, auth classification, reproduction commands, and exactly one verdict line `VERDICT: CONFIRMED|INCONCLUSIVE|NEGATIVE`. The file existing with all sections non-empty = done.

## Evidence standard

- Baseline: the known-dead path pair, captured on the same host in the same run, quoted in full in the verdict file.
- Reproduction: 2x independent (≥60s apart, one varied condition). Both raw pairs saved.
- Raw evidence: full request/response pairs, untruncated, for baseline + probe1 + probe2 + negative controls.
- Verdicts: CONFIRMED (all three evidence legs hold) / INCONCLUSIVE (needs a second model run, different vantage, or human — state exactly what) / NEGATIVE (dead end, signature logged in fp_registry.md so nobody re-tests it).

## Handoffs

- **impact_chain_builder** consumes CONFIRMED verdict files: only CONFIRMED findings enter chains. INCONCLUSIVE may enter as explicitly-marked speculative links, never as load-bearing ones.
- **evidence_packager** consumes CONFIRMED verdict files: the raw pairs here become the evidence package.
- **fp_triage** consumes NEGATIVE verdicts: the killing reason enriches the dead-end registry discriminators.
- **report_drafter** consumes CONFIRMED verdict files for the steps-to-reproduce section — the exact commands are copied from here, never rewritten.
