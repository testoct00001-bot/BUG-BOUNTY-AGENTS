#!/usr/bin/env python3
"""Mechanical half of the finding_validator skill.

Takes a JSON spec describing a baseline request and a probe request,
runs baseline + probe twice (>=delay apart), saves raw request/response
pairs, normalizes dynamic tokens, diffs, and prints a verdict recommendation.

The recommendation is MECHANICAL ONLY (DIVERGES/STABLE/FLAKY/SAME-AS-BASELINE).
The agent applies the skill's divergence rules + negative controls + auth
classification before writing the final CONFIRMED/INCONCLUSIVE/NEGATIVE.

Spec format (spec.json):
{
  "label": "ssrf-api-example-com-01",
  "delay_seconds": 65,
  "baseline": {"method": "GET", "url": "https://host/__validator_dead_<hex>/",
               "headers": {}, "body": null},
  "probe": {"method": "POST", "url": "https://host/path",
            "headers": {"Content-Type": "application/json"},
            "body": "{\"k\":\"v\"}"},
  "probe_variant": {"drop_headers": ["Cookie"]}
}

Usage:
  python3 replay.py --spec review/validation/<fid>/spec.json --out review/validation/<fid>/
"""
import argparse, json, os, re, subprocess, sys, time

NORM_RES = [
    (re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I), 'UUID'),
    (re.compile(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[\d.:]*Z?'), 'TS'),
    (re.compile(r'(?<!\d)\d{10,13}(?!\d)'), 'EPOCH'),
]
DROP_HEADERS = re.compile(r'^(date|set-cookie|cf-ray|x-request-id|etag):', re.I | re.M)


def run_curl(name, spec, outdir):
    req_path = os.path.join(outdir, f'{name}.req')
    resp_path = os.path.join(outdir, f'{name}.resp')
    cmd = ['curl', '-s', '-i', '--max-time', '20', '-X', spec.get('method', 'GET'), spec['url']]
    for k, v in spec.get('headers', {}).items():
        cmd += ['-H', f'{k}: {v}']
    if spec.get('body') is not None:
        cmd += ['--data-raw', spec['body']]
    cmd += ['-o', resp_path]
    # save a readable request record
    with open(req_path, 'w') as f:
        f.write(f"{spec.get('method', 'GET')} {spec['url']} HTTP/1.1\n")
        for k, v in spec.get('headers', {}).items():
            f.write(f'{k}: {v}\n')
        f.write('\n' + (spec.get('body') or ''))
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=40)
    return r.returncode, resp_path


def normalize(path):
    body = open(path, encoding='utf-8', errors='replace').read()
    body = DROP_HEADERS.sub('', body)
    for rx, rep in NORM_RES:
        body = rx.sub(rep, body)
    return body


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--spec', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    spec = json.load(open(a.spec))

    delay = int(spec.get('delay_seconds', 65))
    probe2 = json.loads(json.dumps(spec['probe']))  # deep copy
    for h in spec.get('probe_variant', {}).get('drop_headers', []):
        probe2.get('headers', {}).pop(h, None)

    print(f'[{spec.get("label")}] baseline ...')
    run_curl('baseline', spec['baseline'], a.out)
    print('probe1 ...')
    run_curl('probe1', spec['probe'], a.out)
    print(f'sleeping {delay}s ...')
    time.sleep(delay)
    print('probe2 (varied) ...')
    run_curl('probe2', probe2, a.out)

    b, p1, p2 = (normalize(os.path.join(a.out, f'{n}.resp')) for n in ('baseline', 'probe1', 'probe2'))
    p1_vs_base = 'DIVERGES' if p1 != b else 'SAME-AS-BASELINE'
    p1_vs_p2 = 'STABLE' if p1 == p2 else 'FLAKY'
    print(f'probe1 vs baseline : {p1_vs_base}')
    print(f'probe1 vs probe2   : {p1_vs_p2}')
    if p1_vs_base == 'DIVERGES' and p1_vs_p2 == 'STABLE':
        print('RECOMMENDATION: candidate for CONFIRMED (agent: run negative controls + auth classification)')
    elif p1_vs_base == 'SAME-AS-BASELINE':
        print('RECOMMENDATION: candidate for NEGATIVE (no divergence from dead baseline)')
    else:
        print('RECOMMENDATION: candidate for INCONCLUSIVE (flaky — agent: investigate variance)')


if __name__ == '__main__':
    main()
