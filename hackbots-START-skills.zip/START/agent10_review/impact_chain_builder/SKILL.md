---
name: impact_chain_builder
agent: agent10_review
description: Chains validated lows into criticals — takes CONFIRMED findings and builds the full attack chain to maximum terminal impact, Haddix-style.
---

# Impact Chain Builder

## Purpose

Single bugs get low bounties; chains get criticals. This skill takes CONFIRMED low and medium findings and builds the full attack chain to maximum terminal impact — the difference between "reflected XSS, self-only" and "XSS → session theft → admin panel → SSRF → cloud metadata → tenant keys," the exact shape of Haddix's Kubernetes war story. It models every finding as a rung on an access ladder, finds the missing links, tests them, and proves the terminal impact with the same no-FP evidence standard as a single finding. A chain is only as strong as its weakest link: every link must be CONFIRMED before the chain ships.

## Division of labor

- **Consumes:** CONFIRMED verdict files from finding_validator (`review/validated_<finding-id>.md`), plus INCONCLUSIVE files explicitly marked as speculative candidates
- **Produces:** the finished artifact — `review/chain_<chain-id>.md` containing the link-by-link chain diagram, per-link evidence references, missing-link test results, the terminal impact statement, and the chain severity recommendation

## When to use / when NOT to use

- **Use when:** two or more CONFIRMED findings exist on the same target and at least one touches authentication, session handling, internal network access, or data access; when a single CONFIRMED finding's impact statement feels understated ("what could an attacker do NEXT with this?"); when the hunt has several lows that individually would not be worth reporting
- **Skip when (time-pass filter):** there is only one CONFIRMED finding and no plausible next rung — do not invent links to make a chain. Skip when the "chain" would require chaining through a third party's infrastructure (another tenant, another user) without their data — chains stay within the tested program's assets. Ask: does each link leak something, escalate something, or reach something new? If a link adds nothing, cut it.

## Methodology

1. Inventory: list every CONFIRMED finding on the target with its class, what it exposes (data / session / endpoint / internal host), and its auth context (unauth / auth / session-dependent). Build a table: finding-id → capability gained.
2. Draw the capability map: for each finding, write the single sentence "with this, an attacker can ___." Be concrete: "read any user's profile JSON," not "access data."
3. Apply the chain templates — test each against your inventory:
   - **Ladder A (auth escalation):** unauth data leak → canary value (a token/id you control) → IDOR / parameter ladder → other users' data → privilege escalation → admin
   - **Ladder B (network pivot):** SSRF / open redirect / XXE → internal endpoints → cloud metadata (169.254.169.254 / instance metadata) → credentials → internal admin panels → tenant data
   - **Ladder C (session theft):** reflected/stored XSS → session token exfiltration → session hijack → account takeover → chained into A or B
   - **Ladder D (auth confusion):** 401/403 on endpoint → bypass battery (path confusion, method override, header tricks) → authenticated-as-nobody access → verb smuggling → state-changing actions
   - **Ladder E (trust escalation):** info leak (stack trace, config, JS bundle) → credentials/endpoints → authenticated access → ladders A–D
   - **Ladder F (business-logic escalation):** logic flaw (price/quantity/coupon manipulation) → balance/credit mutation → spendable value → financial impact (canary-only testing)
4. For each template, map your findings onto rungs. Mark each rung: HAVE (CONFIRMED finding) / NEED (must be tested) / SPECULATIVE (INCONCLUSIVE candidate only).
5. For every NEED rung, derive the exact test from the previous rung's output. Example: SSRF CONFIRMED → NEED: "can it reach metadata?" Test: SSRF the metadata URL through the same vector, look for the credential JSON shape. Each NEED test is dispatched as a mini-validation: baseline + 2x reproduction, same as finding_validator.
6. Test NEED rungs one at a time, in chain order. Stop the moment a rung fails twice (different conditions): the chain ends at the last HAVE rung. Document the failed rung and why — a documented dead end is valuable, a skipped one is a lie.
7. When a rung succeeds, immediately ask "what does this new capability unlock?" before celebrating. The chain only ends when a rung's answer is "nothing further on this target" — terminal impact.
8. Define terminal impact precisely and quantitatively: "read/write access to N tenant records," "admin panel with user-management," "RCE as <user> on <host>," "exfiltration of <data class> for <scope>." Vague terminal impact ("full compromise") is rejected — quantify or it didn't happen.
9. Re-verify the full chain end-to-end: replay rung 1 → rung 2 → … → terminal in one session, capturing raw pairs for each transition. The chain report must read as a single reproducible narrative, not a pile of separate findings.
10. Check for chain-breaking mitigations between rungs: WAF rules that fire only on the second request, rate limits, step-up auth on sensitive actions, short token TTLs. A chain that works in theory but trips a mitigation in practice is INCONCLUSIVE until the mitigation is bypassed or documented.
11. Severity recalibration: the chain's severity is set by terminal impact, not by the highest single link. A chain of three lows ending in tenant data exfiltration is a Critical. Write the explicit argument: "link severities L/L/M, terminal impact = ___, therefore chain severity = ___."
12. Write the chain file: ASCII chain diagram (rung → rung with the capability gained at each arrow), per-link table (finding-id, verdict, evidence file), NEED-rung test results, failed-rung documentation, terminal impact statement, severity recommendation, and the end-to-end replay commands.
13. Cross-check against the war-story standard: would this chain, written up, sit credibly next to "SSRF → open Kubernetes admin → tenant API keys"? If the terminal impact is weaker than the weakest link's promise, say so and downgrade — chains must earn their severity.
14. Business-logic rung check (Ladder F): where the target has transactions, credits, coupons, or priced actions, test the logic ladder — manipulate quantity/price/coupon on a canary transaction, observe balance mutation, trace whether the mutated value is spendable. Canary amounts only; never complete a real purchase, transfer, or payout. A logic flaw that mints spendable value is a chain terminal on its own.
15. Blast-radius pre-check: before testing any NEED rung that writes state (POST/PUT/DELETE, balance changes, config writes), confirm a canary resource exists (test account, canary record id, sandbox tenant) and name it in the chain file. No canary → the rung is not tested → mark CHAIN-GATED at that rung, never improvise on live data.
16. Hand off: chain file → severity_calibrator (final rating) and report_drafter (the writeup's steps-to-reproduce follows the chain narrative).

**Decision branches:** if a NEED rung needs credentials you don't have → mark the chain "gated at rung N," document exactly which credential would unblock it, hand to the human — do not attempt credential theft or phishing to continue a chain. If a rung would touch another user's live data (not a canary) → stop, mark INCONCLUSIVE with reason `cross-user-impact`, escalate to human. If two different chains share rungs → merge them into one chain file with branches, don't maintain parallel chains over the same links.

## Exact commands

Inventory CONFIRMED findings on the target:

```bash
ls review/validated_*.md
grep -H '^VERDICT: CONFIRMED' review/validated_*.md
grep -H -A2 'Auth classification' review/validated_*.md | head -50
```

Capability map extraction (one concrete sentence per finding):

```bash
for f in review/validated_<finding-id>.md; do
  echo "== $f =="
  grep -E '^(Class|Target|VERDICT)' "$f"
  sed -n '/Impact statement/,/^$/p' "$f" | head -5
done
```

NEED-rung test via the SSRF→metadata template (example — adapt the vector to the CONFIRMED SSRF):

```bash
# rung HAVE: SSRF to arbitrary URL confirmed in review/validated_ssrf-*.md
# rung NEED: can it reach instance metadata?
curl -s --max-time 20 -X POST "https://<HOST>/<ssrf-endpoint>" \
  -H "Content-Type: application/json" \
  --data-raw '{"url":"http://169.254.169.254/latest/meta-data/iam/security-credentials/"}' \
  -o review/chainwork/meta_probe1.resp -D review/chainwork/meta_probe1.headers -w '%{http_code}\n'
sleep 65
curl -s --max-time 20 -X POST "https://<HOST>/<ssrf-endpoint>" \
  -H "Content-Type: application/json" \
  --data-raw '{"url":"http://169.254.169.254/latest/meta-data/iam/security-credentials/"}' \
  -o review/chainwork/meta_probe2.resp -w '%{http_code}\n'
grep -Ei 'AccessKeyId|SecretAccessKey|Token' review/chainwork/meta_probe1.resp && echo CREDENTIALS_LEAKED || echo NO_CREDS
```

NEED-rung test via the IDOR ladder template (canary → other users):

```bash
# rung HAVE: unauth read of own record at /api/users/<my-id>
# rung NEED: does /api/users/<other-id> return someone else's record?
# use a canary id you control or a sequential neighbor; NEVER a real other user's id you guessed
curl -s "https://<HOST>/api/users/<canary-or-neighbor-id>" -H "Cookie: <session>" | head -c 2000
```

Rung-to-rung transition test (does the artifact from rung N work at rung N+1?):

```bash
# e.g. token leaked at rung 2, used against the rung-3 endpoint
curl -s --max-time 20 "https://<HOST>/<rung3-path>" \
  -H "Authorization: Bearer <token-from-rung2>" \
  -o review/chainwork/transition_r2_r3.resp -w 'http=%{http_code}\n'
grep -q "<rung3-marker>" review/chainwork/transition_r2_r3.resp && echo LINK_WORKS || echo LINK_BROKEN
```

End-to-end chain replay (capture every transition in one session):

```bash
# rung1 -> rung2 -> terminal, one script, raw pairs per transition
bash review/chainwork/<chain-id>_replay.sh   # generated from the chain file's replay section
ls -la review/chainwork/<chain-id>_step*.resp
```

Chain diagram template (ASCII, goes in the chain file):

```
[rung1: unauth profile leak] --(yields user ids)--> [rung2: IDOR on /api/users/{id}]
    --(yields session tokens in profile JSON)--> [rung3: session hijack as victim]
    --(victim is admin)--> [TERMINAL: admin panel, user management, data export]
```

## Completion-bias defenses

- [ ] Every CONFIRMED finding on the target inventoried — none left out of the capability map
- [ ] Each finding reduced to one concrete "attacker can ___" sentence
- [ ] All five chain templates tested against the inventory, not just the obvious one
- [ ] Every NEED rung has a named test with baseline + 2x reproduction evidence
- [ ] NEED rungs tested in chain order; chain stops at the first rung that fails twice
- [ ] Failed rungs documented with reason — no silent skips
- [ ] Terminal impact quantified (what, how much, whose) — no vague "full compromise"
- [ ] Full chain replayed end-to-end in one session with raw pairs per transition
- [ ] Chain-breaking mitigations between rungs checked (WAF, rate limits, step-up auth, TTLs)
- [ ] Chain severity argued from terminal impact with the explicit link-severity vs terminal-impact reasoning
- [ ] War-story standard applied: the chain earns its severity or gets downgraded
- [ ] Chain file written with diagram, per-link table, NEED results, replay commands
- [ ] Ladder F (business-logic) tested where the target has transactions — canary-only, no real purchases
- [ ] Blast-radius pre-check done before every state-changing NEED rung; canary named
- [ ] Every rung-to-rung transition tested with the actual artifact (token/id) from the previous rung
- **Review step:** a second agent (or the human) replays the chain's end-to-end script from the chain file on a fresh session. If any transition fails, the chain is demoted to its last replayable rung and re-severitied.
- **Nudge prompts:**
  - "Keep going until the answer to 'what can the attacker do NEXT?' is 'nothing further.' A chain that stops at the first interesting rung is a single finding wearing a costume."
  - "Do not report a chain whose middle rung is INCONCLUSIVE. Speculative links are marked speculative; the chain's claimed severity rests only on CONFIRMED rungs."
  - "If the terminal impact statement contains the words 'full,' 'complete,' or 'total' without numbers, rewrite it with numbers."
- **Finished artifact definition:** `review/chain_<chain-id>.md` with ASCII chain diagram, per-link table (finding-id → verdict → evidence file), NEED-rung test results, failed-rung documentation, quantified terminal impact statement, severity recommendation, and the end-to-end replay script/commands. All sections non-empty = done.

## Evidence standard

- Baseline: each NEED rung tested with the same baseline discipline as finding_validator (known-dead comparison where applicable; otherwise the pre-rung state as baseline).
- Reproduction: every link in the final chain is CONFIRMED (2x reproduced). The end-to-end replay is itself run twice.
- Raw evidence: per-transition raw pairs saved under `review/chainwork/<chain-id>_step<N>.{req,resp}`.
- Verdicts: CHAIN-CONFIRMED (every link CONFIRMED + end-to-end replayed) / CHAIN-GATED (blocked at rung N by missing credential — human decision) / CHAIN-BROKEN (a rung failed twice — report ends at last good rung).

## Handoffs

- **severity_calibrator** consumes the chain file: final severity is set from terminal impact, with the chain's severity argument as input.
- **report_drafter** consumes the chain file: the writeup's steps-to-reproduce follow the chain narrative rung by rung.
- **evidence_packager** consumes the chain file: per-transition raw pairs are packaged alongside the single-finding evidence.
- **The human** consumes CHAIN-GATED chains: the decision to pursue the gated rung (with legitimate credentials) is theirs.
