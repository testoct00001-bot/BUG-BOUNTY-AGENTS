---
name: retest_regression
agent: agent10_review
description: Re-verifies findings after fixes — replays the original evidence verbatim, confirms the patch, and hunts the incomplete fix and its bypassable variants.
---

# Retest Regression

## Purpose

Programs fix things — sometimes. This skill re-verifies every CONFIRMED finding after a fix is claimed or a patch window passes: it replays the original evidence package verbatim, determines whether the patch actually holds, and — the part most hunters skip — hunts the incomplete fix. Patches routinely cover only the exact reported shape while sibling endpoints, encoded variants, and alternate methods still work. A retest that only replays the original probe and calls it fixed is how bypassable patches ship. This skill proves FIXED or proves REOPENED, with the same raw-pair evidence as the original validation.

## Division of labor

- **Consumes:** the evidence package (`evidence/<finding-id>/` with its `repro.sh`), the original validation file, and the fix claim (program message, changelog, or elapsed patch window)
- **Produces:** the finished artifact — `review/retest_<finding-id>_<YYYYMMDD>.md` with per-probe replay results, the incomplete-fix hunt results, and exactly one verdict: `FIXED`, `REOPENED`, or `PARTIAL`

## When to use / when NOT to use

- **Use when:** a program marks a finding fixed; a patch window the program communicated has passed; a fix was deployed and the finding needs confirmation before closure; periodically (per the hunt's retest schedule) for high-value findings
- **Skip when (time-pass filter):** the finding was NEGATIVE — there is nothing to retest. Skip when the asset is out of scope for retesting (program ended) — log it as `RETEST-DEFERRED`, don't probe a dead program. Ask: is there a live, in-scope target to replay against? If no, stop.

## Methodology

1. Retrieve the evidence package for the finding-id. Verify `repro.sh` exists and `sha256sums.txt` matches — you are replaying the exact original proof, not a reconstruction.
2. Replay the original reproduction verbatim: run `repro.sh` exactly as packaged, twice, ≥60s apart. Save outputs to `review/retest/<finding-id>_<date>/replay1/` and `replay2/`.
3. Classify the replay outcome:
   - Original probe now fails (blocked/404/patched behavior) on both replays → candidate FIXED
   - Original probe still succeeds on both replays → REOPENED, stop here and document
   - Mixed results (one succeeds, one fails) → flaky fix or race → PARTIAL, investigate
4. If candidate FIXED, determine the fix mechanism — it matters for the variant hunt: is it a WAF rule (test with encoding variants), a code fix (test logic variants), an endpoint removal (test for the endpoint under other paths), or an auth gate added (test the bypass battery)? Record your determination with evidence.
5. Hunt the incomplete fix — this is the core of the skill. For the exact vulnerability class, run the variant battery:
   - **Sibling endpoints:** same functionality under different paths (`/api/v2/`, `/internal/`, legacy versions, mobile API hosts)
   - **Parameter variants:** renamed, duplicated, case-changed, nested (`user[id]` vs `userId`), JSON vs form-encoded
   - **Encoding variants:** URL-encoding, double-encoding, Unicode normalization, HTML entities — especially if the fix smells like a WAF rule
   - **Method variants:** GET/PUT/PATCH/DELETE on the same route; `X-HTTP-Method-Override`; verb smuggling if the fix was method-scoped
   - **Auth-context variants:** the fix may have added auth to the reported path but not to the equivalent unauth path
   - **Header variants:** `X-Original-URL`, `X-Rewrite-URL`, `X-Forwarded-Path` pointing at the patched path — reverse-proxy routing differentials survive many code fixes
   - **Content-type variants:** the same probe body sent as `application/xml`, `application/x-www-form-urlencoded`, `text/plain` — parsers differ, and fixes often cover only the reported content type
6. For each variant that reproduces the original impact: capture raw pairs (baseline + 2x probe, same as finding_validator), and mark it as a NEW finding linked to the original (`<finding-id>-bypass1`, etc.). A bypassed fix is a new finding, not a footnote.
7. If all variants fail: probe for the fix's blast radius — did the fix break legitimate functionality? (e.g. the endpoint now 500s on valid input, or the WAF blocks benign traffic). Record as an observation for the report; it is not a vulnerability, but programs appreciate it and it proves you tested honestly.
8. Check for fix-regression on related findings: if the same patch window touched shared code, re-run repro.sh for sibling findings on the same asset. One patch can fix three findings or break two others.
9. Document the fix timeline: the program's stated fix date, the date you first observed the changed behavior, and any partial-fix window in between (original blocked but a variant worked for N days). Timelines matter — a fix that took three iterations tells you about the program's patch process.
10. Write the retest file: fix claim source, replay results (both runs, raw pairs), fix-mechanism determination, variant battery table (variant → result → evidence), fix timeline, blast-radius observations, related-finding regression results, and the verdict.
11. Route: `FIXED` → close the finding (update its status file, keep the evidence package as historical proof). `REOPENED` → package the new evidence and hand to report_drafter as a fix-bypass report. `PARTIAL` → escalate to human with both replay outputs; do not guess.

**Decision branches:** if the target is unreachable during retest (DNS gone, host down) → `RETEST-BLOCKED`, retry once after 24h, then log and stop — do not hammer a dead host. If the program's fix message describes a different root cause than your finding → verify you are retesting the right thing; if the finding and the fix don't match, say so explicitly. If replay needs a session that has expired and you cannot legitimately obtain a new one → `RETEST-BLOCKED`, `session-expired`, hand to human.

## Exact commands

Verify package integrity, then replay verbatim (twice, ≥60s apart):

```bash
FID="<finding-id>"
RDATE="20261004"
mkdir -p "review/retest/${FID}_${RDATE}/replay1" "review/retest/${FID}_${RDATE}/replay2"
cd "evidence/$FID" && sha256sum -c sha256sums.txt && cd -
bash "evidence/$FID/repro.sh" > "review/retest/${FID}_${RDATE}/replay1/out.txt" 2>&1; echo "exit=$?"
sleep 65
bash "evidence/$FID/repro.sh" > "review/retest/${FID}_${RDATE}/replay2/out.txt" 2>&1; echo "exit=$?"
grep -E 'REPRODUCED|NOT_REPRODUCED' "review/retest/${FID}_${RDATE}"/replay*/out.txt
```

Fix-mechanism determination (what kind of fix is it?):

```bash
# WAF smell test: encoded variant of the original payload
curl -s -o /dev/null -w '%{http_code}\n' -X POST "https://<HOST>/<path>" \
  -H "Content-Type: application/json" --data-raw '{"<param>":"<url-encoded-payload>"}'
# endpoint-removal test: same path under versioned/sibling prefixes
for p in /api/v2/<path> /internal/<path> /api/v1/<path>; do
  printf '%s -> ' "$p"; curl -s -o /dev/null -w '%{http_code}\n' "https://<HOST>$p";
done
```

Incomplete-fix variant battery (adapt per class; every hit gets baseline + 2x probe):

```bash
# parameter variants
for par in "<param>" "<PARAM>" "<param>2" "data[<param>]"; do
  printf '%s -> ' "$par"
  curl -s --max-time 20 -X POST "https://<HOST>/<path>" -H "Content-Type: application/json" \
    --data-raw "{\"$par\":\"<value>\"}" -o "review/retest/${FID}_${RDATE}/var_param_$par.resp" -w '%{http_code}\n'
done
# method variants
for m in GET PUT PATCH DELETE; do
  printf '%s -> ' "$m"
  curl -s --max-time 20 -X "$m" "https://<HOST>/<path>" -o "review/retest/${FID}_${RDATE}/var_method_$m.resp" -w '%{http_code}\n'
done
grep -l "<marker-string>" "review/retest/${FID}_${RDATE}"/var_*.resp 2>/dev/null && echo BYPASS_FOUND || echo NO_BYPASS
```

Header-variant battery (reverse-proxy routing differentials):

```bash
for h in "X-Original-URL: /<path>" "X-Rewrite-URL: /<path>" "X-Forwarded-Path: /<path>"; do
  k="${h%%:*}"; printf '%s -> ' "$k"
  curl -s --max-time 20 -H "$h" "https://<HOST>/" \
    -o "review/retest/${FID}_${RDATE}/var_hdr_$k.resp" -w '%{http_code}\n'
done
# content-type variants of the original probe body
for ct in "application/xml" "application/x-www-form-urlencoded" "text/plain"; do
  tag="$(printf '%s' "$ct" | tr '/.' '__')"; printf '%s -> ' "$ct"
  curl -s --max-time 20 -X POST "https://<HOST>/<path>" -H "Content-Type: $ct" \
    --data-raw '<body-equivalent>' -o "review/retest/${FID}_${RDATE}/var_ct_$tag.resp" -w '%{http_code}\n'
done
grep -l "<marker-string>" "review/retest/${FID}_${RDATE}"/var_*.resp 2>/dev/null && echo BYPASS_FOUND || echo NO_BYPASS
```

Blast-radius check (did the fix break legitimate use?):

```bash
curl -s --max-time 20 -X POST "https://<HOST>/<path>" -H "Content-Type: application/json" \
  --data-raw '{"<param>":"<benign-valid-value>"}' -w '\nhttp=%{http_code}\n' | head -c 1500
```

## Completion-bias defenses

- [ ] Evidence package integrity verified (sha256sums) before replay — no reconstructed probes
- [ ] Original repro.sh replayed verbatim, twice, ≥60s apart, outputs saved per run
- [ ] Replay outcome classified (FIXED-candidate / REOPENED / PARTIAL) from both runs, not one
- [ ] Fix mechanism determined with evidence (WAF vs code vs removal vs auth gate)
- [ ] Incomplete-fix variant battery run: siblings, parameters, encodings, methods, auth-contexts
- [ ] Every variant hit captured with baseline + 2x probe and filed as a linked new finding
- [ ] Blast-radius observation recorded (legitimate functionality check)
- [ ] Related findings on the same asset regression-checked against the same patch window
- [ ] Retest file written with verdict; routing followed (FIXED closes, REOPENED → report_drafter, PARTIAL → human)
- [ ] Header-variant battery run (X-Original-URL / X-Rewrite-URL / X-Forwarded-Path)
- [ ] Content-type variant battery run (xml / form / text equivalents)
- [ ] Fix timeline documented (program's stated date vs observed date, partial-fix windows)
- **Review step:** the human reviews every REOPENED before it becomes a fix-bypass report — claiming a program's fix failed is a credibility event, and the evidence must be airtight.
- **Nudge prompts:**
  - "Keep going until the variant battery is exhausted, not until the original probe fails. The original probe failing is the START of the retest, not the end."
  - "Do not write FIXED because the exact reported shape is blocked. FIXED means the vulnerability class is dead on this asset across siblings, encodings, and methods."
  - "If you found a bypass, it is a new finding with its own finding-id. Do not bury it as a footnote in the retest file."
- **Finished artifact definition:** `review/retest_<finding-id>_<YYYYMMDD>.md` with fix-claim source, both replay outputs, fix-mechanism determination, variant battery table with evidence, blast-radius observation, related-finding regression results, and exactly one verdict line `RETEST-VERDICT: FIXED|REOPENED|PARTIAL`. All sections non-empty = done.

## Evidence standard

- Baseline: the retest replays the original package's baseline first — the "nothing here" contrast must still hold, or the host itself changed.
- Reproduction: 2x verbatim replays of the original repro.sh; variant hits each get baseline + 2x probe.
- Raw evidence: per-run outputs and per-variant raw pairs saved under `review/retest/<finding-id>_<date>/`.
- Verdicts: FIXED (original dead + full variant battery dead) / REOPENED (original still works, or a variant reproduces the impact) / PARTIAL (mixed/flaky — human decides). RETEST-BLOCKED and RETEST-DEFERRED are logged states, not verdicts.

## Handoffs

- **report_drafter** consumes REOPENED retests: the fix-bypass report is drafted from the new variant evidence, referencing the original finding-id.
- **finding_validator** consumes variant hits: each bypass is validated as a new finding before it ships.
- **hunt_debrief** consumes the retest trail: fix quality (how often patches hold vs get bypassed) becomes a pattern-library entry about the program.
- **The human** consumes PARTIAL retests and reviews every REOPENED before submission.
