#!/usr/bin/env python3
"""classify_context.py — locate a canary in a saved HTTP response and classify
the output context of every occurrence.

Usage:
    python3 classify_context.py --file resp.html --canary rxmA7k9q [--window 200]

Prints one line per occurrence:
    offset | context | attribute | break_out_hint | snippet
Contexts: html_body, attr_double, attr_single, attr_unquoted, attr_event,
js_string_single, js_string_double, js_template, js_comment, js_code,
url_href, url_src, url_action, url_other, css, html_comment,
json_body, textarea, title, unknown
"""
import argparse
import re
import sys

EVENT_ATTRS = {
    "onabort", "onblur", "onchange", "onclick", "ondblclick", "onerror",
    "onfocus", "onkeydown", "onkeypress", "onkeyup", "onload", "onmousedown",
    "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onreset",
    "onresize", "onscroll", "onselect", "onsubmit", "onunload",
    "oninput", "onanimationstart", "onpointerdown", "ontoggle",
}
URL_ATTRS = {"href": "url_href", "src": "url_src", "action": "url_action",
             "formaction": "url_action", "xlink:href": "url_href",
             "data": "url_other", "poster": "url_other", "cite": "url_other"}
SPECIAL_TAGS = {"textarea": "textarea", "title": "title", "style": "css",
                "script": None}  # script handled separately


def classify(html: str, pos: int):
    before = html[:pos]
    after = html[pos:]

    # --- inside HTML comment? ---
    last_open = before.rfind("<!--")
    last_close = before.rfind("-->")
    if last_open > last_close:
        return "html_comment", None, "break out of comment first: -->"

    # --- inside <script> ? ---
    opens = [m.start() for m in re.finditer(r"<script\b", before, re.I)]
    closes = [m.start() for m in re.finditer(r"</script\s*>", before, re.I)]
    in_script = len(opens) > len(closes)
    if in_script:
        seg = before[opens[-1]:]
        # strip JS comments to see real code
        if re.search(r"//[^\n]*$", seg.split("\n")[-1]):
            return "js_comment", None, "close line comment: \\n"
        if re.search(r"/\*[^*]*$", seg):
            return "js_comment", None, "close block comment: */"
        # count quotes to determine string context
        sq = seg.count("'") - seg.count("\\'")
        dq = seg.count('"') - seg.count('\\"')
        bt = seg.count("`") - seg.count("\\`")
        if bt % 2 == 1:
            return "js_template", None, "${...} executes directly; or break out with `"
        if sq % 2 == 1:
            return "js_string_single", None, "break out: ';...;//"
        if dq % 2 == 1:
            return "js_string_double", None, 'break out: ";...;//'
        return "js_code", None, "direct code execution context"

    # --- inside <style> ? ---
    opens = [m.start() for m in re.finditer(r"<style\b", before, re.I)]
    closes = [m.start() for m in re.finditer(r"</style\s*>", before, re.I)]
    if len(opens) > len(closes):
        return "css", None, "CSS context: url() / expression only in old IE"

    # --- inside <textarea>/<title> ? ---
    for tag, ctx in (("textarea", "textarea"), ("title", "title")):
        opens = [m.start() for m in re.finditer(r"<%s\b" % tag, before, re.I)]
        closes = [m.start() for m in re.finditer(r"</%s\s*>" % tag, before, re.I)]
        if len(opens) > len(closes):
            return ctx, None, "close the tag first: </%s>" % tag

    # --- inside a tag (attribute) ? ---
    last_lt = before.rfind("<")
    last_gt = before.rfind(">")
    if last_lt > last_gt:
        tag_seg = before[last_lt:]
        m = re.match(r"<([a-zA-Z][a-zA-Z0-9-]*)", tag_seg)
        tag = m.group(1).lower() if m else "?"
        # find the attribute being written
        attrs = re.findall(
            r'([a-zA-Z_:][a-zA-Z0-9_:.\-]*)\s*=\s*("[^"]*|\'[^\']*|[^\s>]+)?',
            tag_seg)
        attr_name = attrs[-1][0].lower() if attrs else None
        # is the canary inside a quoted value?
        tail = tag_seg[tag_seg.rfind("=") + 1:] if "=" in tag_seg else ""
        if tail.startswith('"'):
            ctx = "attr_double"
        elif tail.startswith("'"):
            ctx = "attr_single"
        else:
            ctx = "attr_unquoted"
        if attr_name in EVENT_ATTRS:
            return "attr_event", attr_name, "direct JS execution"
        if attr_name in URL_ATTRS:
            return URL_ATTRS[attr_name], attr_name, "try javascript: / data: URLs"
        if attr_name == "srcdoc":
            return "attr_double", attr_name, "srcdoc = full HTML injection"
        hint = {"attr_double": 'break out: "><svg onload=...>',
                "attr_single": "break out: '><svg onload=...>",
                "attr_unquoted": "break out: ><svg onload=...> or space-separated event"}[ctx]
        return ctx, attr_name, hint

    # --- JSON body? ---
    stripped = html.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        return "json_body", None, "JSON context: break string, inject key/HTML"

    # --- plain HTML body ---
    return "html_body", None, "direct HTML injection: <svg onload=...>"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--canary", required=True)
    ap.add_argument("--window", type=int, default=120)
    args = ap.parse_args()

    try:
        html = open(args.file, encoding="utf-8", errors="replace").read()
    except OSError as e:
        print("cannot read file: %s" % e, file=sys.stderr)
        sys.exit(2)

    hits = [m.start() for m in re.finditer(re.escape(args.canary), html)]
    if not hits:
        print("NO_HITS for canary %r in %s" % (args.canary, args.file))
        sys.exit(1)

    for pos in hits:
        ctx, attr, hint = classify(html, pos)
        lo = max(0, pos - args.window)
        hi = min(len(html), pos + len(args.canary) + args.window)
        snippet = html[lo:hi].replace("\n", "\\n")
        print("%d | %s | attr=%s | %s" % (pos, ctx, attr, hint))
        print("    ...%s..." % snippet)


if __name__ == "__main__":
    main()
