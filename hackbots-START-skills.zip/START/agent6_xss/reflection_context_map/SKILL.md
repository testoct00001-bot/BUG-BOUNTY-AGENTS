---
name: reflection_context_map
agent: agent6_xss
description: Map every reflection point to its exact output context (HTML, attribute, JS string, URL, CSS, comment).
---

# Reflection Context Map

## Purpose

Most XSS hunting dies at step one: the hunter fires `<script>alert(1)</script>` at a parameter, sees it filtered or encoded, and moves on — never learning that the same input reflects raw inside an unquoted attribute, a JS string, or a URL. This skill maps EVERY input vector on the target to its exact reflection context before any payload is ever crafted. Context decides the payload, never the reverse. A parameter that reflects raw in HTML body needs `<svg onload>`, one inside a single-quoted JS string needs `'-alert(1)-'`, and one in an `href` needs `javascript:`. Wrong context guesses are the #1 source of false negatives. This skill kills them.

## Division of labor

- **Consumes:** `findings/surface_inputs.txt` from agent1_recon / hidden_endpoint_discovery — the full list of forms, parameters, path segments, headers, and AJAX endpoints. If no such file exists, this skill's step 1 produces its own.
- **Produces:** the finished artifact — `findings/reflection_context_map.json` — one object per (vector, parameter) pair with: input location, canary, every reflection location in the response, exact context classification per location, encoding applied, and a priority score. Plus raw evidence under `evidence/reflection_context_map/`.

## When to use / when NOT to use

- **Use when:** any parameter, form field, header, path segment, or AJAX body field accepts attacker-controlled input and its value (or a recognizable transform of it) appears anywhere in a response.
- **Use when:** a new endpoint, new form, or new JS-driven feature is found — every new input surface gets mapped before payload work starts.
- **Use when:** a reflected value appears in a second context you did not test (e.g. you mapped the HTML body reflection, but the same param also lands in a JS block) — re-run for the full map.
- **Skip when (time-pass filter):** the input is fully absorbed server-side with zero reflection of any kind after the full battery (no canary, no transformed canary, no error echo) — document as NEGATIVE and move on. Don't keep hammering a dead parameter hoping for magic.

## Methodology

1. **Enumerate input vectors.** List every place attacker input can enter: GET query params, POST form fields, JSON body keys, URL path segments, cookies, headers the app echoes (Referer, User-Agent, X-Forwarded-For), and fragment/query values consumed by client JS. One line per vector: `vector_id | location | name`.
2. **Capture the baseline.** Request the same page/endpoint with a known-dead parameter value and save it: this is what "no reflection" looks like. Every later judgment compares against this file.
3. **Generate unique canaries.** One unique alphanumeric canary per (vector, parameter) — e.g. `rxmA7k9q`, `rxmB3t2w`. Never reuse a canary across parameters; reuse makes reflections unattributable. Canary format: letters + digits only, no special characters (so the filter has nothing to strip and you test context, not filtering).
4. **Inject one canary at a time.** Send the request with exactly one canary set. If you inject into 10 params at once and the response contains one, you learn nothing. Slow is fast here.
5. **Save the raw response** to `evidence/reflection_context_map/<vector_id>.html` with the request line prepended in a comment.
6. **Locate the canary.** Search the raw response for the exact canary string. Record: found (yes/no), count, and the byte offset(s) of every occurrence.
7. **If not found, search for transforms.** Look for: URL-encoded form, HTML-entity-encoded form, uppercased, lowercased, truncated, or partial matches (first/last 4 chars). A transformed reflection is still a reflection — record the transform exactly.
8. **Classify each occurrence's context.** For every occurrence, read the surrounding 200 characters and classify:
   - `html_body` — between tags, plain text node
   - `attr_double` — inside a double-quoted attribute value
   - `attr_single` — inside a single-quoted attribute value
   - `attr_unquoted` — inside an unquoted attribute value
   - `attr_event` — inside an event-handler attribute (`onclick`, `onload`, …)
   - `js_string_single` / `js_string_double` / `js_template` — inside a JS string literal
   - `js_comment` / `js_code` — inside a JS comment, or directly as executable code
   - `url_href` / `url_src` / `url_action` — inside href/src/action/formaction
   - `css` — inside a `<style>` block or style attribute
   - `html_comment` — inside `<!-- -->`
   - `json_body` / `json_embedded` — inside a JSON response or JSON embedded in HTML
   - `textarea` / `title` / `noscript` — special containers that change parsing
   If ambiguous (e.g. looks like attribute but tag is broken), record BOTH candidates and mark `ambiguous: true`.
9. **For JS contexts, determine break-out cost.** Read the characters before and after the canary: can you break out with `'` or `"` or a backtick? Is the string inside an event handler already? Is there a `.` after the string (template literal chain)? Record the exact break-out sequence needed, e.g. `';alert(1);//`.
10. **For attribute contexts, name the attribute.** `href` and `src` are URL contexts (test `javascript:`); `srcdoc` is an HTML-injection context; event handlers are direct code execution. Unquoted attributes are the cheapest break-outs.
11. **Check reflection multiplicity.** One parameter reflecting in 3 contexts = 3 attack surfaces = priority 1. Record every occurrence, even the boring-looking ones — the 3rd reflection is often the exploitable one.
12. **Score each vector.** Priority 1: raw reflection in `js_code`, `attr_event`, `html_body`, `srcdoc`, `url_href` with no encoding. Priority 2: encoded-but-decodable, single/double-quoted attributes, JS strings. Priority 3: fully entity-encoded, HTML comments, textareas. Priority 0/NEGATIVE: no reflection after full battery.
13. **Decision branches.**
    - If reflection exists in ANY active context → hand the exact context entry to `filter_behavior_analysis` (which will build payloads for that context).
    - If reflection exists only in dead contexts (comments, fully-encoded) → record and deprioritize, but do NOT delete — a code change can resurrect it.
    - If a reflection appears in the DOM but not in raw HTML → flag for `dom_sink_audit` (client-side reflection).
14. **Write the artifact.** `findings/reflection_context_map.json`: array of `{vector_id, location, param, canary, baseline_file, reflections: [{offset, context, attribute?, transform, break_out, priority}], verdict}`. No JSON entry = the work did not happen.

## Exact commands

Baseline (known-dead parameter — must return 200 with no reflection):

```bash
curl -sS -D headers_base.txt -o evidence/reflection_context_map/baseline.html \
  "https://<TARGET>/search?q=zzdeadparam999" \
  -H "User-Agent: Mozilla/5.0" --compressed
```

Single-canary probe per parameter (repeat for each — script it):

```bash
curl -sS -o evidence/reflection_context_map/vec_search_q.html \
  "https://<TARGET>/search?q=rxmA7k9q" \
  -H "User-Agent: Mozilla/5.0" --compressed
grep -o -b 'rxmA7k9q' evidence/reflection_context_map/vec_search_q.html | head -20
```

POST form field probe:

```bash
curl -sS -o evidence/reflection_context_map/vec_contact_name.html \
  -X POST "https://<TARGET>/contact" \
  -d "name=rxmB3t2w&email=t@t.t&msg=hello" \
  -H "Content-Type: application/x-www-form-urlencoded"
grep -o -b 'rxmB3t2w' evidence/reflection_context_map/vec_contact_name.html | head -20
```

Header-echo probe (Referer / User-Agent reflections):

```bash
curl -sS -o evidence/reflection_context_map/vec_header_ua.html \
  "https://<TARGET>/" -H "User-Agent: rxmC9x1z" --compressed
grep -o -b 'rxmC9x1z' evidence/reflection_context_map/vec_header_ua.html | head
```

Transform hunt (when the raw canary is absent):

```bash
f=evidence/reflection_context_map/vec_search_q.html
for t in 'rxmA7k9q' 'rxmA7K9Q' 'rxma7k9q' 'rxmA7k9' 'A7k9q'; do
  echo "== $t =="; grep -o -b "$t" "$f" | head -5
done
```

Context classification (the helper script reads a saved response and reports the context around every canary hit):

```bash
python3 reflection_context_map/classify_context.py \
  --file evidence/reflection_context_map/vec_search_q.html \
  --canary rxmA7k9q
```

Verification: re-request with the SAME canary twice and confirm identical reflection positions (rules out one-off template noise), then with a DIFFERENT canary to confirm the vector is stable:

```bash
curl -sS "https://<TARGET>/search?q=rxmA7k9q" | grep -c 'rxmA7k9q'
curl -sS "https://<TARGET>/search?q=rxmZ4p8v" | grep -c 'rxmZ4p8v'
```

## Completion-bias defenses

- [ ] Every input vector from the surface list has a unique canary assigned (no reuse)
- [ ] Baseline (known-dead) response captured and saved before any probing
- [ ] Each vector probed with exactly one canary at a time (no batch injection)
- [ ] Raw response saved per vector under `evidence/reflection_context_map/`
- [ ] Every canary occurrence located with byte offsets (or documented absent)
- [ ] Transform hunt run for every absent canary (encoded/upper/truncated/partial)
- [ ] Context classified for every occurrence using the classifier script
- [ ] JS contexts have an explicit break-out sequence recorded
- [ ] Attribute contexts have the attribute name recorded
- [ ] Multiplicity checked: every occurrence recorded, not just the first
- [ ] Each vector scored P1/P2/P3/NEGATIVE with the reason written down
- [ ] `findings/reflection_context_map.json` exists and is valid JSON
- [ ] **Review step:** agent10_review must verify: (a) no canary was reused across vectors, (b) every P1/P2 entry has a saved raw response on disk, (c) at least one full re-probe (different canary) confirmed vector stability, (d) the JSON parses and every entry has `context` and `verdict`.
- [ ] **Nudge prompts:**
  - "Keep going until every parameter has its own canary and its own raw response file — not just the first parameter that reflected."
  - "Do not report done before findings/reflection_context_map.json exists on disk with a verdict for every vector you enumerated."
  - "If a canary is absent, you have not finished that vector — run the transform hunt before marking it NEGATIVE."
- [ ] **Finished artifact definition:** `findings/reflection_context_map.json` — valid JSON, one entry per enumerated (vector, parameter), each with `reflections[]` (possibly empty), `context` per reflection, and `verdict`. The file's existence and completeness IS done.

## Evidence standard

- Baseline: `evidence/reflection_context_map/baseline.html` — every "reflection found" claim is diffed against this; identical structure minus the canary = clean baseline.
- Reproduction: each P1/P2 reflection reproduced 2x with different canaries on the same vector.
- Raw evidence: full request + response saved per vector; byte offsets recorded.
- Verdicts: CONFIRMED (canary reflected 2x, context classified, raw saved) / INCONCLUSIVE (reflection seen once or only as an ambiguous transform — needs a second model run) / NEGATIVE (full battery incl. transform hunt, no reflection — documented so nobody re-tests).

## Handoffs

- `filter_behavior_analysis`: consumes the P1/P2 entries — needs `vector_id`, `param`, exact `context`, `attribute` name, and the observed `transform`/encoding, so it can build the evasion alphabet for that exact context.
- `dom_sink_audit`: consumes any reflection flagged as DOM-only (present in rendered DOM, absent in raw HTML).
- `stored_xss_chain`: consumes any vector whose reflection persists across requests/sessions (profile fields, comments).
- agent10_review: consumes `findings/reflection_context_map.json` plus the raw evidence directory.
