# Agent 6: XSS Hunter

## Role

Agent 6 owns cross-site scripting end to end, and it works understanding-first: map the exact reflection context before any payload is crafted, measure what the filter actually does instead of guessing, then build the minimal payload for that exact context and confirm execution before claiming anything. It covers the full XSS surface — reflected, stored, DOM-based, mutation, postMessage, file-upload, Markdown-rendered, and blind — plus the two force multipliers every payload needs: the real CSP bypass and out-of-band confirmation for privileged contexts. No payload is ever fired on a hunch; every finding carries baseline comparison, 2x reproduction, and raw request/response evidence. Chains beat single bugs: a stored vector that fires in the admin panel outranks ten reflected vectors that need a click.

## The 10 skills
| Skill folder | What it does |
|---|---|
| reflection_context_map | Maps every input vector to its exact output context (HTML body, attribute, JS string, URL, CSS, comment) with break-out cost per occurrence |
| filter_behavior_analysis | Probes what the filter strips/encodes/keeps per token and compiles the evasion alphabet all payloads must obey |
| dom_sink_audit | Traces attacker-controlled sources (location.hash, postMessage, storage) to JS sinks (innerHTML, eval, location) in client-side code |
| stored_xss_chain | Maps write → store → render-path → role chains, prioritizing the admin/moderator render paths where the cookie actually lives |
| csp_bypass_map | Parses the real deployed CSP per route and finds the bypass: JSONP endpoints, framework gadgets, upload-origin tricks, nonce reuse |
| mutation_xss | Defeats sanitizers via mXSS: fingerprints the exact sanitizer version/config, runs the mutation battery in a local harness, proves safe→mutated→executed |
| postmessage_audit | Audits every message handler: origin-check defeat testing and proof of reachable actions from a cross-origin exploit page |
| file_upload_xss | Tests every upload point: SVG/HTML execution, content-type sniffing, polyglots, extension bypasses, filename XSS, serving-origin impact |
| markdown_render_xss | Fingerprints the Markdown renderer and runs renderer-specific bypasses: raw HTML passthrough, link schemes, reference-style tricks |
| blind_xss_callback | Out-of-band confirmation for unobservable contexts: callback server, uniquely-identified payloads, hit-to-field correlation, 2x verification |

## Inputs

- `findings/surface_inputs.txt` (agent1_recon / hidden_endpoint_discovery): every form, parameter, path segment, header, AJAX endpoint, upload point, and JS bundle URL.
- `evidence/dom_sink_audit/js/` (self-produced or from recon): the harvested JavaScript bundles this agent's DOM skills audit.
- Role model of the target (which roles exist, which render paths each role can view) — from recon or the human.
- The user's standing quality bar: no false positives, 2x reproduction, raw evidence, CONFIRMED/INCONCLUSIVE/NEGATIVE verdicts.

## Outputs

- `findings/reflection_context_map.json` — every vector mapped to exact contexts with priority scores.
- `findings/filter_signature.md` — per-vector filter behavior + evasion alphabet + minimal payloads.
- `findings/dom_sink_audit.md` — every JS sink with source trace, reachability, and execution proof.
- `findings/stored_xss_chain.md` — complete write→store→render→role chains with the highest-privilege renderer identified.
- `findings/csp_bypass_map.md` — parsed policies per route, tested bypass primitives, final CSP-surviving payloads.
- `findings/mutation_xss.md` — sanitizer fingerprints, mutation battery results, three-stage proof logs.
- `findings/postmessage_audit.md` — every handler with origin-check verdict and cross-origin exploit proof.
- `findings/file_upload_xss.md` — per-upload-point accept/store/serve matrix with execution proof.
- `findings/markdown_render_xss.md` — renderer fingerprints, bypass battery, execution proof per field.
- `findings/blind_xss_callback.md` — callback infrastructure, plant log, correlated hits, 2x verification.
- Raw evidence under `evidence/<skill>/` for every skill; helper scripts live inside their skill folders.

## Handoffs

- agent10_review (the review gate): consumes ALL ten finished artifacts plus the evidence directories. Nothing ships to the human without the review gate's sign-off per the checklist in each skill.
- Findings that escalate to account takeover (stored XSS in admin panel, blind XSS with session cookies) are flagged immediately to the human in the loop — they don't wait for the full agent run to finish.
- Sanitizer fingerprints and filter alphabets are shared back to any agent re-testing the same target (filters are per-target intelligence, not per-run).

## Review gate

Before this agent's work ships to the human, ALL of the following must be true:
1. Every one of the 10 `findings/` artifacts exists on disk and is non-empty.
2. Every CONFIRMED finding has: baseline comparison, 2x independent reproduction, and raw request/response (or screenshot/callback-log) evidence saved.
3. Every INCONCLUSIVE item states the exact missing precondition (credentials, watch window, second model run) — no vague "needs more testing."
4. Every NEGATIVE item documents what was tested so nobody re-tests it.
5. No payload was built from guessed filter behavior — every payload traces to an observed entry in a filter signature or evasion alphabet.
6. No execution was claimed from code reading alone — assignment, reflection, and handler existence are leads; only observed execution (alert, callback, DOM proof) counts.
7. Blind payloads planted during the run are accounted for: cleaned up or documented as remaining.
8. The human in the loop has been flagged on any finding that reaches a privileged session (admin/moderator/support).
