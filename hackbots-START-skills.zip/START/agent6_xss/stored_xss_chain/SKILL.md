---
name: stored_xss_chain
agent: agent6_xss
description: Stored entry points plus the admin/reviewer paths that render them — where the cookie actually lives.
---

# Stored XSS Chain

## Purpose

Reflected XSS needs a victim to click. Stored XSS waits for the victim — and the highest-value victim is usually the admin. This skill maps the full chain: WHERE attacker input gets stored (profile fields, comments, tickets, filenames, order notes), WHO renders it (admin panel, support dashboard, moderation queue, email templates), and WHAT executes there (session cookies, CSRF tokens, admin-only actions). A stored XSS in a field only an admin views is not a medium — it is an account takeover of the most privileged user on the platform. This skill finds where the cookie actually lives and proves the chain end to end.

## Division of labor

- **Consumes:** `findings/reflection_context_map.json` (any vector whose reflection persists across requests), `findings/surface_inputs.txt` (forms that write data: profiles, comments, tickets, uploads), and the app's role model (which roles exist, which views exist per role).
- **Produces:** the finished artifact — `findings/stored_xss_chain.md` — every stored entry point, its storage location, every render path per role, the highest-privilege renderer, and execution proof. Raw evidence under `evidence/stored_xss_chain/`.

## When to use / when NOT to use

- **Use when:** any form, API endpoint, or file upload persists attacker input (profile name, bio, comments, reviews, tickets, chat messages, filenames, CSV imports).
- **Use when:** the app has a privileged viewer role (admin panel, moderator queue, support dashboard, seller portal) — stored XSS there is the top target.
- **Use when:** user content is rendered in emails, PDFs, or exports — those are render paths too, often with weaker escaping.
- **Skip when (time-pass filter):** the stored value is only ever rendered back to the same user in a properly escaped context AND no other role ever sees it — verify the escaping once, document, move on. Also skip when you cannot reach any render path without credentials you don't have — document the chain as INCONCLUSIVE (needs creds), don't burn hours.

## Methodology

1. **Inventory every write primitive.** List every place the app stores attacker-controlled data: registration fields, profile fields, comments, reviews, support tickets, chat, file uploads (filename + content), CSV/bulk imports, webhook URLs, company names, address fields. For each: the exact request that writes it (method, endpoint, field name) and the storage identifier returned.
2. **Plant benign canaries first.** Submit a unique canary per field (`stA1b2c3`) — never a payload yet. Canaries are safe, deniable, and tell you exactly which render paths touch the data without tripping WAFs or alerting admins.
3. **Enumerate every render path.** For each stored canary, check where it appears: your own profile page, public profile, comment threads, search results, admin user list, admin ticket view, moderation queue, notification emails, exports/CSVs, API responses consumed by the mobile app or admin SPA. One canary, many render paths — check them all.
4. **Map render paths to roles.** For each render path, record which role can view it: unauthenticated visitor, the author, other users, moderator, support agent, admin. The highest-privilege role that renders your input raw is the target.
5. **Classify the render context per path.** For each (field, render path) pair, determine the output context exactly as in `reflection_context_map`: HTML body, attribute, JS string, etc. Admin panels are frequently old, unmaintained code with no escaping — check them with extra care.
6. **Check the admin panel specifically.** Find the admin login/page (often `/admin`, `/wp-admin`, `/dashboard`, or a separate subdomain). Even without credentials, map: does it list users? does it preview ticket content? does it render profile fields? Every "yes" is a render path. If you have a low-priv test account, submit canaries and view them from the admin side if possible.
7. **Determine what the admin session holds.** The value of admin XSS = what the admin cookie/session can do. From the outside: does the admin panel have user management, settings, plugin install, or export functions? A stored XSS firing in an admin browser with session cookies = full admin takeover via cookie theft or forced actions.
8. **Upgrade canary to minimal payload.** Only after the full chain is mapped (write → store → render path → role → context), craft the minimal payload for that exact context using the `filter_behavior_analysis` alphabet (filters often differ between public and admin render paths — re-probe if needed).
9. **Prove execution in the highest-privilege context you can reach.** If you can only reach the self-render path, prove execution there and document the admin path as the escalation (with evidence the admin renders the same field). If you have two test accounts, prove user-to-user execution. Execution proof: alert/callback in the victim context, 2x reproduced.
10. **Check secondary render paths.** The same stored value often renders in: email notifications (HTML emails — test with your own inbox), PDF exports, CSV exports (formula injection is a bonus, not the goal), mobile API JSON (then to `dom_sink_audit` for client-side rendering), webhooks to third parties.
11. **Check stored-via-upload paths.** Filenames are stored and rendered in file lists and admin panels — test `"><svg onload=...>.png` as a filename. SVG file content rendered inline = stored XSS. Hand upload-content cases to `file_upload_xss` but keep the chain mapping here.
12. **Check persistence and cache.** Does the stored value survive edits? Does a CDN or app cache serve the injected version to others? Cached stored XSS multiplies impact — verify with a fresh session.
13. **Check API-only and mobile surfaces.** Some stored fields never render in the web UI but do render in the mobile app or a partner API response. Fetch the raw API object for your planted canary and check for unescaped output; hand client-rendered cases to `dom_sink_audit`.
14. **Decision branches.**
    - If the payload executes in an admin/moderator render path → this is the crown jewel; document the full chain with screenshots and escalate immediately.
    - If it executes only for the author → still a finding if the context is dangerous (self-XSS is weak alone, but chain it: does the profile page have a "share" feature? can another user trigger the render?).
    - If the admin path exists but you can't reach it → INCONCLUSIVE with the exact missing precondition (e.g. "needs admin session; render path confirmed via canary in admin user-list HTML").
    - If every render path properly escapes → NEGATIVE per path, documented.

## Exact commands

Plant benign canaries in stored fields (one unique canary per field):

```bash
mkdir -p evidence/stored_xss_chain
curl -sS -X POST "https://<TARGET>/api/profile" \
  -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
  -d '{"display_name":"stA1b2c3","bio":"stD4e5f6"}' \
  -o evidence/stored_xss_chain/plant_profile.json
cat evidence/stored_xss_chain/plant_profile.json
```

Submit a ticket/comment canary:

```bash
curl -sS -X POST "https://<TARGET>/api/tickets" \
  -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
  -d '{"subject":"help stG7h8i9","body":"details here"}' \
  -o evidence/stored_xss_chain/plant_ticket.json
```

Hunt every render path for the canary (public page, profile, search):

```bash
for p in "/" "/profile/me" "/users/me" "/search?q=stA1b2c3" "/tickets"; do
  echo "== $p"
  curl -sS "https://<TARGET>$p" -H "Cookie: session=<YOUR_SESSION>" --compressed \
    | grep -o '.\{40\}stA1b2c3.\{40\}' | head -3
done
```

Check the admin-side render (even unauthenticated, look for the panel's existence and structure):

```bash
for p in "/admin" "/admin/users" "/dashboard" "/moderate" "/support/tickets"; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" "https://<TARGET>$p" --compressed)
  echo "$p -> $code"
done
```

Filename-as-vector probe:

```bash
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/pixel.png;filename="stJ1k2l3\"><svg onload=alert(1)>.png"' \
  -o evidence/stored_xss_chain/upload_filename.json
curl -sS "https://<TARGET>/files" -H "Cookie: session=<YOUR_SESSION>" --compressed \
  | grep -o '.\{40\}stJ1k2l3.\{40\}' | head -3
```

Upgrade to minimal payload in the confirmed context (example: HTML-body context in ticket view):

```bash
curl -sS -X POST "https://<TARGET>/api/tickets" \
  -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
  -d '{"subject":"xss px1","body":"<svg onload=alert(document.domain)>"}' \
  -o evidence/stored_xss_chain/payload_ticket.json
# Then load the ticket render path in a clean browser profile and screenshot the alert.
```

Persistence check (fresh session, no cookies):

```bash
curl -sS "https://<TARGET>/tickets/<TICKET_ID>" --compressed \
  | grep -c 'onload=alert(document.domain)'
```

## Completion-bias defenses

- [ ] Every write primitive inventoried with the exact write request saved
- [ ] Benign canary planted per field (unique canary per field, no payloads yet)
- [ ] Every render path checked for every canary (public, self, other-user, admin, email, export)
- [ ] Each render path mapped to the roles that can view it
- [ ] Render context classified per (field, path) pair
- [ ] Admin panel render paths specifically investigated
- [ ] Admin session value assessed (what the admin cookie can do)
- [ ] Minimal payload crafted for the exact context and tested
- [ ] Execution proved in the highest-privilege reachable context, 2x
- [ ] Secondary render paths checked (email, PDF, CSV, mobile API)
- [ ] Upload/filename vector tested
- [ ] Persistence and caching verified with a fresh session
- [ ] `findings/stored_xss_chain.md` exists with the full chain per finding
- [ ] **Review step:** agent10_review must verify: (a) every claimed render path has a saved response showing the canary/payload, (b) the role for each render path is evidenced not assumed, (c) execution proof exists for CONFIRMED items (screenshot/callback), (d) unreachable-but-mapped admin paths are marked INCONCLUSIVE with the exact missing precondition.
- [ ] **Nudge prompts:**
  - "Keep going until every canary has been checked in every render path — the admin panel view is the one that matters most."
  - "Do not report done before findings/stored_xss_chain.md maps the complete write → store → render → role chain for every field."
  - "A payload firing in your own profile is a lead. Find who else renders that field before you call it a finding."
- [ ] **Finished artifact definition:** `findings/stored_xss_chain.md` — per field: write request, storage ID, every render path with role + context, highest-privilege renderer, execution proof or INCONCLUSIVE reason. Existence + complete chains IS done.

## Evidence standard

- Baseline: the same render path loaded before planting the canary (proves the content is yours and the path renders stored data).
- Reproduction: execution proved 2x in clean browser profiles; canary presence re-verified after 24h for persistence claims.
- Raw evidence: write requests/responses, every render-path response showing the canary, screenshots of execution, admin panel structure captures.
- Verdicts: CONFIRMED (execution in a victim context, 2x, full chain documented) / INCONCLUSIVE (chain mapped but execution blocked by missing precondition — exact precondition stated) / NEGATIVE (all render paths escape properly — per-path evidence).

## Handoffs

- `filter_behavior_analysis`: if the admin render path filters differently than the public path, request a separate filter signature for it.
- `file_upload_xss`: consumes upload-content stored vectors (SVG/HTML file bodies rendered inline).
- `blind_xss_callback`: consumes admin-only render paths you can't observe — out-of-band proof of execution.
- `dom_sink_audit`: consumes stored values rendered into JS-driven admin SPAs (client-side rendering of stored data).
- agent10_review: consumes `findings/stored_xss_chain.md` plus execution screenshots.
