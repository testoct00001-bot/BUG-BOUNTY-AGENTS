---
name: postmessage_audit
agent: agent6_xss
description: Audit postMessage handlers — origin checks (or missing ones), and sensitive actions reachable via messages.
---

# postMessage Audit

## Purpose

`postMessage` is the front door apps leave open for their own iframes, embeds, and partner integrations — and attackers can knock on it from any origin. A `message` handler that doesn't validate `event.origin`, or validates it with `indexOf` instead of equality, lets any website send commands to the target: navigate the victim, inject HTML, steal tokens, or trigger state-changing actions. This skill finds every message handler in the app's JavaScript, tests the origin validation for real (not by reading code and assuming), and proves what an attacker origin can make the handler do. Missing origin checks are among the highest-signal, lowest-effort XSS-adjacent findings in modern apps.

## Division of labor

- **Consumes:** `findings/dom_sink_audit.md` (any trace whose source is `postMessage`/`onmessage`), the app's JS bundles under `evidence/dom_sink_audit/js/`, and the list of iframe/embed relationships (which origins the app legitimately talks to).
- **Produces:** the finished artifact — `findings/postmessage_audit.md` — every handler found, its origin validation verdict, every reachable action, and proof-of-exploit from a cross-origin test page. Test pages saved under `evidence/postmessage_audit/`.

## When to use / when NOT to use

- **Use when:** any `addEventListener('message')`, `onmessage`, or `postMessage` call exists in the app's JS — each handler is a potential unauthenticated command channel.
- **Use when:** the app embeds third-party iframes, uses OAuth popups, payment widgets, chat widgets, or cross-origin embeds — these are the features that create message handlers.
- **Use when:** `dom_sink_audit` flagged a postMessage source reaching a sink — this skill owns the origin-check analysis.
- **Skip when (time-pass filter):** the only message handlers are in third-party library code (analytics, ads) that never touch app state or DOM — verify once with a grep for what the handler does, then stop. Also skip when the handler provably only receives messages from a hardcoded trusted origin AND validates it with strict equality (document and move on).

## Methodology

1. **Find every handler.** Grep all JS bundles for `addEventListener('message'`, `addEventListener("message"`, `onmessage =`, `window.onmessage`. For each hit, record file:line and extract the full handler function (read at least 60 lines around it — handlers often delegate to sub-functions).
2. **Find every sender.** Grep for `.postMessage(` calls — who sends messages, to which `targetOrigin`? `postMessage(data, '*')` on the sender side leaks data to any listening origin (reverse direction, still a finding if the data is sensitive). Record sender → data → targetOrigin triples.
3. **Read what the handler does with `event.data`.** Classify the handler's actions:
   - Navigation: `location.href = data.url`, `location.replace(...)` → open redirect / javascript: URL → XSS.
   - DOM: `innerHTML = data.html`, `document.write(data.x)` → direct XSS.
   - Code: `eval(data.code)`, `new Function(data.fn)` → direct code execution.
   - State: `localStorage.setItem`, cookie writes, `fetch` with attacker URL (SSRF-ish), form auto-submit.
   - Auth: token receipt (`data.token` stored and used), login-state changes.
   - Benign: analytics pings, resize messages (`data.height` → iframe resize). Low value — but verify, don't assume.
4. **Test the origin validation for real.** Read the check, then defeat-test it:
   - No check at all → fully exploitable from any origin.
   - `if (event.origin === 'https://app.example.com')` → strict; test that a subdomain (`https://evilapp.example.com`) and sibling don't pass (they shouldn't).
   - `event.origin.indexOf('app.example.com') !== -1` → bypass with `https://app.example.com.evil.com`.
   - `event.origin.endsWith('example.com')` → bypass with `https://evil-example.com`... no wait, that ends with `example.com`? `evilexample.com` ends with `example.com` — yes, bypass.
   - Regex checks → test for missing anchors (`/example.com/` matches `evil-example.com`), unescaped dots, `.*` greediness.
   - `event.source` checks without origin → bypass by opening the target as a popup and posting from the opener.
   - Checks on `data.origin` (attacker-controlled field) instead of `event.origin` → completely bypassable; send `data: {origin: 'https://trusted.com'}`.
5. **Build the cross-origin exploit page.** Host a test page on an origin you control (localhost with a tunnel, or any https origin). The page opens/iframes the target and `postMessage`s the malicious payload. This is the proof — code review alone is not a finding.
6. **Prove each reachable action.** For navigation handlers: send `{url: 'javascript:alert(document.domain)'}` (or `data:text/html,...` if javascript: is filtered) and screenshot the execution. For DOM handlers: send `{html: '<img src=x onerror=alert(1)>'} `. For token handlers: demonstrate token theft or session riding. Each proof runs 2x.
7. **Check handler reachability.** Does the handler live on a page the victim visits while logged in? Is the listener registered on page load or only after an interaction? An exploitable handler on the login page (pre-auth) vs the dashboard (post-auth) changes the attack story — record the exact page and trigger conditions.
8. **Check `window.name` and `location.hash` as message-adjacent vectors.** Some "postMessage integrations" actually pass data via `window.name` (persists across navigations, attacker-settable) or the fragment. If the handler reads `window.name` instead of `event.data`, any site can set it by navigating the frame — test this.
9. **Check for message-based CSRF.** Handlers that perform state changes (delete account, change email, transfer) on message receipt = CSRF without cookies being the issue — the victim just needs to visit the attacker's page. Map every state-changing action reachable by message.
10. **Check nested/forwarded messages.** Some handlers re-post received data to another frame (`otherFrame.postMessage(event.data, '*')`) — a confused-deputy chain. Trace where received data goes after the first handler.
11. **Decision branches.**
    - If no origin check + dangerous action → immediate exploit page + proof; this is a high/critical finding.
    - If weak check (indexOf/endsWith/unanchored regex) → craft the bypass origin, prove the check passes with the evil origin, then prove the action.
    - If strict check + dangerous action → the handler is correctly gated; document as a positive control and move on (don't burn time).
    - If the handler only does benign things (resize, ping) → NEGATIVE, documented.

## Exact commands

Find every handler and sender:

```bash
mkdir -p evidence/postmessage_audit
grep -rn "addEventListener(['\"]message['\"]" evidence/dom_sink_audit/js/bundle_*.js 2>/dev/null \
  | head -20 > evidence/postmessage_audit/handlers.txt
grep -rn "\.postMessage(" evidence/dom_sink_audit/js/bundle_*.js 2>/dev/null \
  | head -20 > evidence/postmessage_audit/senders.txt
cat evidence/postmessage_audit/handlers.txt
```

Extract the full handler (read 60 lines around each hit):

```bash
# for a hit at bundle_3.js:4821
sed -n '4790,4880p' evidence/dom_sink_audit/js/bundle_3.js > evidence/postmessage_audit/handler_1_ctx.txt
cat evidence/postmessage_audit/handler_1_ctx.txt
```

Cross-origin exploit page (save as evidence/postmessage_audit/exploit.html, serve via https):

```html
<!DOCTYPE html><html><body>
<iframe id="t" src="https://<TARGET>/vulnerable/page"></iframe>
<script>
const f = document.getElementById('t');
f.onload = () => {
  // navigation-sink handler test
  f.contentWindow.postMessage({url: 'javascript:alert(document.domain)'}, '*');
  // DOM-sink handler test (uncomment per handler shape)
  // f.contentWindow.postMessage({html: '<img src=x onerror=alert(document.domain)>'}, '*');
};
</script></body></html>
```

```bash
cd evidence/postmessage_audit && python3 -m http.server 8902 &
# expose via a tunnel for a real cross-origin test, then open the exploit page
# in a clean browser profile and screenshot the result
```

Origin-validation bypass probes (test the check logic directly):

```bash
# if the check is indexOf('target.com'): verify evil origin passes the same logic
python3 -c "
origins = ['https://target.com.evil.com', 'https://eviltarget.com', 'https://target.com%2e.evil.com']
for o in origins:
    print(o, '-> indexOf passes:', o.indexOf('target.com') if hasattr(o,'indexOf') else ('target.com' in o))
"
```

`window.name` vector test (when the handler reads window.name):

```html
<!-- attacker page: set window.name, then navigate the frame to the target -->
<script>
var w = window.open('about:blank');
w.name = JSON.stringify({html: '<img src=x onerror=alert(document.domain)>'});
w.location = 'https://<TARGET>/vulnerable/page';
</script>
```

## Completion-bias defenses

- [ ] Every message handler found via grep, with file:line logged
- [ ] Full handler body extracted (60+ lines) for each handler
- [ ] Every `.postMessage(` sender recorded with targetOrigin
- [ ] Each handler's actions classified (navigation/DOM/code/state/auth/benign)
- [ ] Origin validation read AND defeat-tested (not just read)
- [ ] Weak checks bypassed with a concrete evil origin (indexOf/endsWith/regex cases)
- [ ] Cross-origin exploit page built and served over https
- [ ] Each dangerous action proved 2x from the attacker origin with screenshots
- [ ] Handler reachability recorded (which page, logged-in or not, trigger conditions)
- [ ] window.name / fragment adjacent vectors tested where applicable
- [ ] Message-based CSRF (state-changing actions) mapped
- [ ] Nested/forwarded message chains traced
- [ ] `findings/postmessage_audit.md` exists with every handler + verdict + proof
- [ ] **Review step:** agent10_review must verify: (a) every "missing origin check" claim has the handler source saved, (b) every exploit claim has a screenshot from the cross-origin test page, (c) strict-equality handlers are documented as positive controls, not findings, (d) the evil origin used in bypass proofs is recorded exactly.
- [ ] **Nudge prompts:**
  - "Keep going until every handler in handlers.txt has an action classification and an origin-check verdict — not just the first one."
  - "Do not report done before findings/postmessage_audit.md exists with a 2x screenshot proof for every CONFIRMED handler."
  - "Reading the origin check is not testing it. Send the bypass origin and watch what happens."
- [ ] **Finished artifact definition:** `findings/postmessage_audit.md` — every handler (file:line), its actions, origin-check verdict with the exact check code, bypass origin where applicable, and 2x screenshot proof per CONFIRMED handler. Existence + proofs IS done.

## Evidence standard

- Baseline: the exploit page posting a benign message (proves the channel works); the same payload from the legitimate origin (proves the handler processes it at all).
- Reproduction: each CONFIRMED exploit reproduced 2x from the attacker origin in clean profiles.
- Raw evidence: handler source extracts, exploit page, screenshots, console logs.
- Verdicts: CONFIRMED (cross-origin action proved 2x) / INCONCLUSIVE (handler found, action unclear — needs deeper code read or second model run) / NEGATIVE (strict origin check or benign-only actions — documented).

## Handoffs

- `dom_sink_audit`: postMessage-sourced traces get their origin-check verdict written back here.
- `stored_xss_chain`: if a message handler stores data that later renders (e.g. chat widget), the stored chain starts here.
- `csp_bypass_map`: `javascript:` URLs via message handlers must survive the CSP — combine payloads before proof.
- agent10_review: consumes `findings/postmessage_audit.md` plus exploit screenshots.
