#!/usr/bin/env python3
"""trace_sinks.py — first-pass source-to-sink pairing inside JS bundles.

For each bundle_*.js in --jsdir: finds sink assignments (var X = ...; sink(X)),
collects variable names flowing into known sinks, then checks whether any
attacker-controlled source assigns to the same variable name in the same file.

This is a LEAD GENERATOR, not proof. Every candidate trace must be verified
by reading the actual code — variable shadowing and scoping defeat naive grep.

Usage:
    python3 trace_sinks.py --jsdir evidence/dom_sink_audit/js --out evidence/dom_sink_audit/traces/
"""
import argparse
import os
import re

SINKS = [
    (r"\.innerHTML\s*=", "innerHTML"),
    (r"\.outerHTML\s*=", "outerHTML"),
    (r"insertAdjacentHTML\s*\(", "insertAdjacentHTML"),
    (r"document\.write(ln)?\s*\(", "document.write"),
    (r"(?<![\w$])eval\s*\(", "eval"),
    (r"Function\s*\(", "Function"),
    (r"location\.href\s*=", "location.href"),
    (r"location\.replace\s*\(", "location.replace"),
    (r"dangerouslySetInnerHTML", "dangerouslySetInnerHTML"),
    (r"bypassSecurityTrustHtml\s*\(", "bypassSecurityTrustHtml"),
]
SOURCES = [
    (r"location\.hash", "location.hash"),
    (r"location\.search", "location.search"),
    (r"document\.URL", "document.URL"),
    (r"document\.referrer", "document.referrer"),
    (r"window\.name", "window.name"),
    (r"localStorage\.getItem\s*\(", "localStorage"),
    (r"sessionStorage\.getItem\s*\(", "sessionStorage"),
    (r"document\.cookie", "document.cookie"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsdir", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    report = []
    for fn in sorted(os.listdir(args.jsdir)):
        if not fn.startswith("bundle_") or not fn.endswith(".js"):
            continue
        path = os.path.join(args.jsdir, fn)
        try:
            src = open(path, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        lines = src.split("\n")

        # map variable -> source (simple assignment scan)
        var_source = {}
        for i, line in enumerate(lines):
            for pat, sname in SOURCES:
                if re.search(pat, line):
                    m = re.match(r"\s*(?:var|let|const)?\s*([\w$]+)\s*=", line)
                    if m:
                        var_source[m.group(1)] = (sname, i + 1)

        # sinks: what identifier flows in?
        for i, line in enumerate(lines):
            for pat, skname in SINKS:
                if not re.search(pat, line):
                    continue
                m = re.search(
                    r"(?:innerHTML|outerHTML)\s*=\s*([\w$.()\[\]'\" ]+)",
                    line)
                ident = None
                if m:
                    ident = re.findall(r"[\w$]+", m.group(1))
                    ident = ident[0] if ident else None
                else:
                    m2 = re.search(pat + r"\s*([\w$]+)", line)
                    if m2:
                        ident = m2.group(1)
                verdict = "MANUAL_REVIEW"
                detail = ""
                if ident and ident in var_source:
                    sname, sline = var_source[ident]
                    verdict = "CANDIDATE_TRACE"
                    detail = "var %s <- %s (line %d)" % (ident, sname, sline)
                report.append("%s:%d | sink=%s | var=%s | %s %s"
                             % (fn, i + 1, skname, ident, verdict, detail))

    out_path = os.path.join(args.out, "candidate_traces.txt")
    with open(out_path, "w") as f:
        f.write("# CANDIDATE traces — verify each by reading the code.\n"
                "# variable shadowing defeats this scan; it is a lead list only.\n")
        f.write("\n".join(report) + "\n")
    print("wrote %s (%d candidates)" % (out_path, len(report)))
    for r in report:
        print(r)


if __name__ == "__main__":
    main()
