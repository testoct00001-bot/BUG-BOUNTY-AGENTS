---
name: dom_sink_audit
agent: agent6_xss
description: Trace attacker-controlled sources to JS sinks (innerHTML, eval, location) in client-side code.
---

# DOM Sink Audit

## Purpose

Server-side filters are irrelevant when the vulnerability lives in the browser. Modern apps take `location.hash`, `location.search`, `postMessage` data, or `localStorage` values and feed them straight into `innerHTML`, `eval`, `document.write`, or `location`. These DOM XSS sinks are invisible to server-side reflection mapping — the raw HTML contains no canary, but the rendered DOM executes it. This skill harvests every JavaScript file the app ships, finds every sink, traces every source that can reach it, and proves execution with fragment-driven canaries. DOM XSS is where the unauthenticated, filter-free wins live.

## Division of labor

- **Consumes:** `findings/surface_inputs.txt` (JS file URLs — or harvest your own in step 1), `findings/reflection_context_map.json` (any vector flagged DOM-only), `evidence/reflection_context_map/` raw pages.
- **Produces:** the finished artifact — `findings/dom_sink_audit.md` — every sink found, its source trace, reachability verdict, and proof-of-execution evidence. Raw JS saved under `evidence/dom_sink_audit/js/`, traces under `evidence/dom_sink_audit/traces/`.

## When to use / when NOT to use

- **Use when:** the app is a SPA or heavy-JS app (React, Vue, Angular, or large custom bundles) — DOM XSS probability scales with client-side rendering.
- **Use when:** a canary appears in the rendered DOM but not in raw HTML (reflection map flagged it), or URL fragments visibly change page content.
- **Use when:** you see `location.hash` / `location.search` / `postMessage` / `localStorage` reads anywhere in the JS — each is a source worth tracing.
- **Skip when (time-pass filter):** the page ships trivial JS (a few lines of analytics) with no sinks and no dynamic DOM writes — grep proves it in 2 minutes, then stop. Also skip auditing third-party library internals (jQuery, lodash) unless the app passes attacker data into a known-dangerous library API.

## Methodology

1. **Harvest every JS file.** From the homepage and 3–5 key pages: save the HTML, extract all `<script src>`, fetch each JS file. Also fetch `*.js.map` source maps when present (they contain original source with comments — a goldmine). Record the full list in `evidence/dom_sink_audit/js/urls.txt`.
2. **Baseline the bundle inventory.** Note framework (React/Vue/Angular/vanilla), bundler fingerprints (webpack chunk names), and total JS size. Huge bundles = more sinks = worth the time.
3. **Grep for sinks.** Search all JS for the dangerous sink list. Every hit gets a file:line entry:
   - HTML sinks: `innerHTML`, `outerHTML`, `insertAdjacentHTML`, `document.write`, `document.writeln`, `DOMParser` + `parseFromString` with `text/html`
   - Code sinks: `eval(`, `Function(`, `setTimeout(` / `setInterval(` with string arg, `execScript`
   - Navigation sinks: `location.href=`, `location.replace(`, `location.assign(`, `window.open(`
   - jQuery sinks: `.html(`, `.append(`, `.prepend(`, `.before(`, `.after(` (check the jQuery version — old versions are sink-rich)
   - Framework sinks: `v-html` (Vue), `dangerouslySetInnerHTML` (React), `[innerHTML]` / `bypassSecurityTrustHtml` (Angular), `{@html}` (Svelte)
4. **Grep for sources.** In the same files, find every attacker-reachable source: `location.hash`, `location.search`, `location.href`, `document.URL`, `document.referrer`, `window.name`, `localStorage.getItem`, `sessionStorage.getItem`, `document.cookie`, `postMessage` / `onmessage` handlers, `WebSocket` `onmessage`.
5. **Build source→sink traces.** For each sink, walk backwards: what variable flows into it? Where is that variable assigned? Does any assignment chain reach a source from step 4? Use the helper script for the first pass, then verify each candidate trace by reading the actual code — automated taint is a lead generator, not proof.
6. **Classify each trace.**
   - `direct` — source flows into sink with no sanitization (e.g. `el.innerHTML = location.hash.slice(1)`). Priority 1.
   - `gated` — a condition or transform sits between (e.g. only runs when `?debug=1`, or passes through a sanitizer). Record the gate exactly — it may be bypassable.
   - `sanitized` — flows through DOMPurify, a strict allowlist, or text-only assignment (`textContent`, `innerText`). Verify the sanitizer version/config; misconfigured DOMPurify is still a sink (hand to `mutation_xss`).
   - `dead` — sink exists but no attacker source reaches it. Document and stop.
7. **Test each Priority-1 trace with a fragment canary.** DOM XSS sources are usually URL-driven, so test by loading the page with a canary in the fragment: `https://<TARGET>/page#dx7k2`. Then check: does the canary appear in the DOM? Does an `<img src=x onerror=...>`-style probe execute? Use a benign canary first (`dx7k2`), then a minimal execution probe.
8. **Prove execution, don't assume it.** Execution proof = one of: (a) `alert(document.domain)`-equivalent firing in a controlled browser, (b) a network callback to your `blind_xss_callback` server with the canary ID, (c) `console.log` marker visible in devtools with a screenshot. `innerHTML =` assignment alone is NOT proof — the sink may be in dead code.
9. **Check sink reachability conditions.** Does the vulnerable code path require: login? a specific route? a feature flag? user interaction (click)? Record the exact preconditions — an unauthenticated, no-click DOM XSS is a critical; one needing admin login is a different report.
10. **Check for jQuery/legacy sinks.** If the app ships jQuery < 3.x, test `$(location.hash)` selector XSS and `$.parseHTML` behaviors. If AngularJS 1.x is present, test `ng-app` expression injection via `{{constructor.constructor('alert(1)')()}}` in hash-driven templates.
11. **Decision branches.**
    - If a sink is `direct` and source is `location.hash` → immediate execution test; this is the classic unauthenticated DOM XSS.
    - If the trace passes through a sanitizer → extract the sanitizer name/version/config and hand to `mutation_xss`.
    - If the source is `postMessage` → hand to `postmessage_audit` (it owns origin-check analysis).
    - If no source reaches any sink → NEGATIVE for this bundle, but re-run when new JS ships (note the bundle hash so changes are detectable).

## Exact commands

Harvest JS files from the homepage:

```bash
mkdir -p evidence/dom_sink_audit/js
curl -sS "https://<TARGET>/" --compressed -o evidence/dom_sink_audit/js/home.html
grep -oE 'src="[^"]+\.js[^"]*"' evidence/dom_sink_audit/js/home.html | \
  sed 's/src="//;s/"//' | sort -u > evidence/dom_sink_audit/js/urls.txt
i=0; while read u; do
  case "$u" in http*) full="$u";; /*) full="https://<TARGET>$u";; *) full="https://<TARGET>/$u";; esac
  i=$((i+1)); curl -sS --max-time 30 "$full" --compressed -o "evidence/dom_sink_audit/js/bundle_$i.js" && echo "saved $full"
done < evidence/dom_sink_audit/js/urls.txt
```

Fetch source maps (append .map to each bundle URL — many servers expose them):

```bash
while read u; do
  case "$u" in http*) full="$u";; /*) full="https://<TARGET>$u";; *) full="https://<TARGET>/$u";; esac
  curl -sS --max-time 20 "${full}.map" --compressed -o /tmp/sourcemap_test.json
  head -c 100 /tmp/sourcemap_test.json | grep -q '"sources"' && echo "SOURCEMAP EXPOSED: ${full}.map"
done < evidence/dom_sink_audit/js/urls.txt
```

Sink grep (every hit = file:line to investigate):

```bash
cd evidence/dom_sink_audit/js
grep -rnoE '(innerHTML|outerHTML|insertAdjacentHTML|document\.write(ln)?|eval\(|Function\(|setTimeout\(|setInterval\(|location\.(href|replace|assign)|window\.open\(|dangerouslySetInnerHTML|v-html|bypassSecurityTrustHtml|\.html\(|\.append\()' \
  --include='bundle_*.js' . | head -100 > ../sink_hits.txt
wc -l ../sink_hits.txt
```

Source grep:

```bash
grep -rnoE '(location\.(hash|search|href)|document\.(URL|referrer|cookie)|window\.name|localStorage\.getItem|sessionStorage\.getItem|addEventListener\(.(message).|onmessage)' \
  --include='bundle_*.js' . | head -100 > ../source_hits.txt
wc -l ../source_hits.txt
```

Automated first-pass trace (pairs sinks and sources sharing a variable name within the same file):

```bash
python3 dom_sink_audit/trace_sinks.py \
  --jsdir evidence/dom_sink_audit/js \
  --out evidence/dom_sink_audit/traces/
```

Fragment-canary reachability test (benign canary first):

```bash
curl -sS "https://<TARGET>/app#dx7k2" --compressed -o /tmp/fragtest.html
# NOTE: curl does not execute JS — the fragment test MUST run in a real browser.
# In the browser console on https://<TARGET>/app#dx7k2, run:
#   document.documentElement.innerHTML.includes('dx7k2')
```

Execution proof probe (only after the benign canary is confirmed in the DOM):

```bash
# Load in browser: https://<TARGET>/app#<img src=x onerror=alert(document.domain)>
# Or for hash-to-innerHTML sinks: https://<TARGET>/app#<svg onload=alert(document.domain)>
# Record: screenshot of the alert + the exact URL that triggered it.
```

jQuery version check (old jQuery = extra sink surface):

```bash
grep -rhoE 'jQuery JavaScript Library v[0-9.]+' evidence/dom_sink_audit/js/ | sort -u
```

## Completion-bias defenses

- [ ] Every `<script src>` from homepage + 3 key pages harvested and saved
- [ ] Source-map exposure tested for every bundle
- [ ] Full sink grep run — every hit logged with file:line in `sink_hits.txt`
- [ ] Full source grep run — every hit logged in `source_hits.txt`
- [ ] Automated trace script run; every candidate trace manually verified by reading the code
- [ ] Each trace classified direct / gated / sanitized / dead with the reasoning written down
- [ ] Every Priority-1 (direct) trace tested with a benign fragment canary
- [ ] Execution proved (alert/callback/console marker) — assignment alone never counts
- [ ] Reachability preconditions recorded (auth? route? click? flag?)
- [ ] jQuery/AngularJS legacy sink check completed
- [ ] `findings/dom_sink_audit.md` exists with every sink, trace, verdict, and proof
- [ ] **Review step:** agent10_review must verify: (a) every claimed execution has a screenshot or callback log, (b) no trace was marked direct without reading the surrounding code, (c) sanitizer-gated traces include the sanitizer name/version, (d) dead-code sinks are documented as NEGATIVE, not silently dropped.
- [ ] **Nudge prompts:**
  - "Keep going until every sink hit in sink_hits.txt has a trace verdict — not just the first innerHTML you found."
  - "Do not report done before findings/dom_sink_audit.md exists with execution proof for every CONFIRMED sink."
  - "An innerHTML assignment is a lead, not a finding. Prove execution or mark it INCONCLUSIVE."
- [ ] **Finished artifact definition:** `findings/dom_sink_audit.md` — lists every sink (file:line), its source trace, reachability preconditions, and for CONFIRMED items the execution proof (screenshot path or callback ID). Existence + per-sink verdicts IS done.

## Evidence standard

- Baseline: the known-dead baseline page (no fragment) vs the fragment-loaded page — DOM diff proves the sink consumed the input.
- Reproduction: each CONFIRMED DOM XSS reproduced 2x in a clean browser profile (rules out extension/caching artifacts).
- Raw evidence: saved JS bundles, grep hit lists, trace files, screenshots of execution, callback logs.
- Verdicts: CONFIRMED (execution proved 2x, preconditions recorded) / INCONCLUSIVE (sink+source connected but execution not yet observed — needs browser run or second model) / NEGATIVE (sink unreachable or properly sanitized — documented).

## Handoffs

- `mutation_xss`: consumes sanitizer-gated traces — needs sanitizer name, version, and config.
- `postmessage_audit`: consumes any trace whose source is `postMessage`/`onmessage`.
- `filter_behavior_analysis`: if the DOM sink reads from a server-reflected value (e.g. `location.search` populated by a redirect), the server-side filter signature applies.
- `blind_xss_callback`: consumes CONFIRMED-but-hard-to-observe sinks — execution proof via callback.
- agent10_review: consumes `findings/dom_sink_audit.md` plus screenshots/callback logs.
