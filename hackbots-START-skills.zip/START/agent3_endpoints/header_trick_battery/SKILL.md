---
name: header_trick_battery
agent: agent3_endpoints
description: 401/403 bypass battery — method-override headers, URL-rewrite headers, IP-spoof headers, encoding variants; a bypass counts only when denied flips to non-error.
---

# Header Trick Battery

## Purpose

A 401 or 403 is not a dead end — it is proof the endpoint exists and that something valuable sits behind the gate. Servers, proxies, and frameworks disagree about what a request IS: the WAF sees the raw path, the app sees the rewritten one; the ACL checks the URL, the framework checks a header. This skill fires a full battery of header tricks at every gated path and claims a bypass ONLY when the response flips from denied (401/403) to non-error (200/302/500-with-content) — never on a status wobble, never without a dead-path control proving the trick doesn't just rewrite everything.

## Division of labor

- **Consumes:** gated-path list — every AUTH-GATE (401) and FORBIDDEN-GATE (403) path from `recursive_fuzz_loop`, plus any 403s from `method_verb_matrix` differentials; one path per line in `endpoints/gated_paths.txt`.
- **Produces:** the finished artifact — `findings/header_trick_battery.md` with one section per path: baseline denied response, every trick tried with its response, and a verdict per trick. Verdicts are the deliverable.

## When to use / when NOT to use

- **Use when:** any path returns 401/403; a verb-matrix differential shows a live method behind an ACL; you suspect proxy/app disagreement (CDN in front, `X-Forwarded-*` headers echoed anywhere).
- **Skip when (time-pass filter):** the 403 body is a WAF block page identical across all paths including dead ones (the gate is the edge, not the app — tricks won't reach application logic; document once); the endpoint requires a session cookie you don't have AND every trick returns the identical login redirect (that's an auth wall, not a bypassable gate — move to session-gated testing).

## Methodology

1. **Record the denied baseline.** For each gated path, capture: status, full headers, body length, body hash, and the first 500 bytes of the body. Do this twice. This is the "before" picture — every trick is judged against it.
2. **Run the dead-path control first.** Pick a known-dead path. Fire the entire battery at it. If ANY trick turns the dead path into a 200, that trick is a global rewrite on this host (e.g. the CDN strips the header and serves the homepage) — mark the trick INVALID for this host and never claim a bypass with it. This control is what separates bypasses from false positives.
3. **Fire the URL-rewrite header group.** These target proxy/app disagreement about the path:
   - `X-Original-URL: /<gated-path>` with request to `/` (or `/404`)
   - `X-Rewrite-URL: /<gated-path>` with request to `/`
   - `X-Original-URL: /<gated-path>` with request to `/<gated-path>` (double-declaration confuses some parsers)
   - `Referer: https://<HOST>/<gated-path>` (weak, but some legacy ACLs check it)
4. **Fire the method-override header group.** `X-HTTP-Method-Override: GET` (or POST) on the gated path; `X-Method-Override: GET`; `X-HTTP-Method: GET`. Some stacks route on the header while the ACL checked the raw verb.
5. **Fire the IP-spoof header group.** ACLs that allowlist "internal" callers often trust headers: `X-Forwarded-For: 127.0.0.1`, `X-Originating-IP: 127.0.0.1`, `X-Remote-IP: 127.0.0.1`, `X-Remote-Addr: 127.0.0.1`, `X-Client-IP: 127.0.0.1`, `True-Client-IP: 127.0.0.1`, `X-Real-IP: 127.0.0.1`. Also try the appended-IP form `X-Forwarded-For: 127.0.0.1, <your-ip>` (some parsers take the first IP, some the last) and `10.0.0.1`/`192.168.1.1` variants. One header at a time — combining them masks which one worked. Record response-time deltas too: an ACL consulting an external auth service may answer slower on 127.0.0.1 (fail-open timing), which is intel by itself.
6. **Fire the host-confusion group.** `X-Forwarded-Host: localhost`, `X-Forwarded-Host: 127.0.0.1`, `Forwarded: for=127.0.0.1;host=localhost`. Virtual-host-routed ACLs sometimes grant on the forwarded host.
7. **Fire the encoding-variant group on the path itself.** `%2e` for `.`, `%252e` (double-encoded), `%c0%ae` (overlong UTF-8 dot), trailing `%20`, `%09` (tab), `%00` (null — mostly dead on modern stacks, one quick test). Compare each against the denied baseline: a 404 on the encoded variant means the trick changed routing (the WAF no longer matches the ACL rule) — then check whether the 404 body differs from the baseline 404 (a distinct 404 can still be an app-level 404 = bypassed the gate, reached the app).
8. **Fire the trailing-junk group.** `/<path>/`, `/<path>/.`, `/<path>..;/`, `/<path>?`, `/<path>#`, `/<path>;.js` (some ACLs regex-match `\.js$` and skip). Each is one request; record all.
9. **Judge every trick against the bypass bar.** BYPASS = response is non-error AND different from denied baseline: 200 with distinct body, 302 to an authenticated destination (not back to login), 500 with application content (reached code). NOT a bypass: 403→404 (still denied, different costume), 403→403 with different body (WAF vs app block — note it, not a bypass), any trick that also flips the dead-path control.
10. **Re-verify claimed bypasses 2x.** Re-fire the exact winning trick twice, 30s apart, plus once with headers in different order (some bypasses are parser-order-dependent — if reordering kills it, note the fragility, still counts if 2/3 stable).
11. **Chain immediately.** A bypassed 403 that returns 200 is not the end — feed the now-open path to `recursive_fuzz_loop` (fuzz beneath it), `param_mining` (mine its params), and `method_verb_matrix` (the gate may be verb-specific). A bypass is a door; walk through it.
12. **Combine on stubborn gates.** When every single trick returns the denied baseline, combine: the closest near-miss header (e.g. a 403→404 on `X-Original-URL`) with one `path_confusion` variant (trailing `/;`, encoded dot). Layered disagreements — proxy vs app vs framework — fall to layered tricks. Judge combinations with the same bar and the same dead-path control.
13. **Write the report.** One section per path: denied baseline (status/headers/hash), table of trick → response, dead-path control result, verdict per trick, and for bypasses the full raw pair + chain targets.

Decision branches: trick flips dead-path control too → trick INVALID host-wide, discard · 403→404 on encoded variant → check if the 404 is app-level (diff bodies) · bypass returns 200 → chain to fuzz/param/verb skills immediately · all tricks return identical denied baseline → document NEGATIVE per path, move on.

## Exact commands

Denied baseline (twice):
```bash
for i in 1 2; do
  curl -sS -D /tmp/deny_hdr -o /tmp/deny_body -w 'HTTP %{http_code} len=%{size_download}\n' \
    --max-time 15 "https://<HOST><GATED_PATH>"
  sha256sum /tmp/deny_body; head -c 500 /tmp/deny_body; echo
done
```

Dead-path control (run the whole battery here FIRST):
```bash
R=$(openssl rand -hex 6); DEAD="/$R"
curl -sS -o /dev/null -w 'rewrite-to-root: %{http_code}\n' --max-time 15 \
  -H "X-Original-URL: <GATED_PATH>" "https://<HOST>/"
curl -sS -o /dev/null -w 'xff-localhost: %{http_code}\n' --max-time 15 \
  -H "X-Forwarded-For: 127.0.0.1" "https://<HOST>$DEAD"
# any trick returning 200 on $DEAD is INVALID host-wide
```

URL-rewrite header group:
```bash
P="<GATED_PATH>"
curl -sS -D - -o /dev/null -w '%{http_code}\n' --max-time 15 -H "X-Original-URL: $P" "https://<HOST>/"
curl -sS -D - -o /dev/null -w '%{http_code}\n' --max-time 15 -H "X-Rewrite-URL: $P" "https://<HOST>/"
curl -sS -D - -o /dev/null -w '%{http_code}\n' --max-time 15 -H "X-Original-URL: $P" "https://<HOST>$P"
```

IP-spoof header group (one header per request — never combine):
```bash
P="<GATED_PATH>"
for h in "X-Forwarded-For" "X-Originating-IP" "X-Remote-IP" "X-Remote-Addr" "X-Client-IP" "True-Client-IP" "X-Real-IP"; do
  for ip in 127.0.0.1 10.0.0.1 192.168.1.1; do
    code=$(curl -sS -o /tmp/spoof_body -w '%{http_code} %{size_download}' --max-time 15 \
      -H "$h: $ip" "https://<HOST>$P")
    echo "$h=$ip -> $code"
  done
done
```

Encoding + trailing-junk variants:
```bash
P="<GATED_PATH>"
for v in "${P}/" "${P}/." "${P}..;/" "${P}?" "${P}#" "${P};.js" "${P}%20" "${P}%09"; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>$v")
  echo "$code  $v"
done
# dot encodings (path segments with dots only; skip if path has no dots)
for enc in "%2e" "%252e" "%c0%ae"; do
  echo "$enc -> $(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>${P//$enc}")"
done
```

Bypass re-verification (exact winning trick, 2x + header reorder):
```bash
for i in 1 2; do
  curl -sS -D /tmp/bp_hdr -o /tmp/bp_body -w 'HTTP %{http_code} len=%{size_download}\n' \
    --max-time 15 -H "<WINNING_HEADER>" "https://<HOST><GATED_PATH>"
  sha256sum /tmp/bp_body
  sleep 30
done
```

## Completion-bias defenses

- [ ] Denied baseline captured twice per gated path (status/headers/hash/body sample)
- [ ] Dead-path control run with the FULL battery before judging any trick
- [ ] Tricks that flip the dead path marked INVALID host-wide and excluded
- [ ] URL-rewrite group fired (X-Original-URL, X-Rewrite-URL, double-declaration)
- [ ] Method-override header group fired
- [ ] IP-spoof group fired one-header-at-a-time (7 headers × 3 IPs)
- [ ] Host-confusion group fired (X-Forwarded-Host, Forwarded)
- [ ] Encoding-variant group fired and judged by body-diff, not status alone
- [ ] Trailing-junk group fired
- [ ] Every trick judged against the bypass bar (denied → non-error + differs from baseline)
- [ ] Claimed bypasses re-verified 2x + header-reorder test
- [ ] Combination tricks attempted on stubborn gates (near-miss header + path variant)
- [ ] Bypassed paths chained to fuzz / param / verb skills
- [ ] `findings/header_trick_battery.md` written with per-path sections and per-trick verdicts

- **Review step:** agent10_review must verify: (1) the dead-path control exists and any host-wide-invalid trick is excluded from bypass claims; (2) each claimed bypass shows the denied baseline AND the flipped response with raw pairs; (3) no 403→404 is labeled a bypass; (4) bypasses were re-verified.
- **Nudge prompts:**
  - "A bypass is denied-flips-to-non-error. 403 to 404 is still denied wearing a different costume — do not claim it."
  - "Run the dead-path control first. A trick that opens every door including fake ones opens nothing."
  - "A bypassed gate is a door, not a trophy — chain it into fuzzing, parameter mining, and verb matrixing before you report done."
- **Finished artifact definition:** `findings/header_trick_battery.md` on disk with one section per gated path: denied baseline, trick→response table, dead-path control result, per-trick verdicts, and raw request/response pairs for every claimed bypass.

## Evidence standard

- Baseline: denied response captured twice per path; dead-path control for the whole battery on the same host.
- Reproduction: winning trick re-fired 2x, 30s apart, + header-reorder run — 2/3 stable to CONFIRMED.
- Raw evidence: full request (headers verbatim) + response headers + first 2KB of body for the baseline and for every claimed bypass.
- Verdicts: CONFIRMED (denied→non-error, control-clean, 2/3 stable) / INCONCLUSIVE (flips once, unstable, or control ambiguous — second model run) / NEGATIVE (all tricks return the denied baseline — documented per path).

## Handoffs

- `recursive_fuzz_loop`: every bypassed path — fuzz beneath the now-open gate (new depth root).
- `param_mining`: every bypassed path returning dynamic content — mine its parameters.
- `method_verb_matrix`: every bypassed path — the gate may be verb-specific; matrix it.
- `path_confusion`: every path where encoding variants changed routing but didn't bypass — deeper confusion testing.
- `agent10_review`: the battery report for the review gate above.
