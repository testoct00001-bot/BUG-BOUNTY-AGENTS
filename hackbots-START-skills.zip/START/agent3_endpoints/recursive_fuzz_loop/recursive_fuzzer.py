#!/usr/bin/env python3
"""
recursive_fuzzer.py — baseline-aware recursive endpoint prober.
Core tool of the recursive_fuzz_loop skill.

Only HTTP answers count as live. Every response is classified with the
skill's response-intelligence table. VALID hits are re-requested twice
(30s apart) before being marked CONFIRMED.

Usage:
  python3 recursive_fuzzer.py --host https://example.com \
      --wordlist wordlists/target_derived.txt \
      --prefixes endpoints/seed_prefixes.txt \
      --max-depth 6 --budget 20000 --delay 0.2 \
      --out-valid endpoints/recursive_fuzz_loop_valid.txt \
      --out-hits findings/recursive_fuzz_loop_hits.json
"""
import argparse, hashlib, json, random, string, sys, time
import urllib.request, urllib.error

UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) bugbounty-research"}

def fetch(host, path, method="GET", timeout=15):
    req = urllib.request.Request(host.rstrip("/") + path, method=method, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(), None
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read(), None
    except Exception as e:  # timeout / reset -> UNSTABLE, never dead
        return None, {}, b"", str(e)

def bhash(b):
    return hashlib.sha256(b).hexdigest()[:16]

def randpath():
    seg = lambda: "".join(random.choice(string.ascii_lowercase) for _ in range(12))
    return "/" + seg() + "/" + seg()

def capture_baseline(host):
    """Two provably-dead paths; they must agree or the host is unstable."""
    s = []
    for _ in range(2):
        st, _, body, _ = fetch(host, randpath())
        s.append((st, len(body), bhash(body)))
        time.sleep(1)
    (s1, l1, h1), (s2, l2, h2) = s
    stable = (s1 == s2) and (abs(l1 - l2) / max(l1, 1) < 0.05)
    return {"status": s1, "length": l1, "hash": h1, "stable": stable}

def classify(status, headers, body, base, fallback):
    h = bhash(body)
    if status is None:
        return "UNSTABLE"
    if status == 429:
        return "BACKOFF"
    if status in (301, 302, 307, 308):
        return "VALID-REDIRECT" if headers.get("Location") else "DEAD"
    if status == 401:
        return "AUTH-GATE"
    if status == 403:
        return "FORBIDDEN-GATE"
    if status == 405:
        return "METHOD-GATE"
    if status == 400:
        return "CANDIDATE"
    if status >= 500:
        return "ERROR-GATE" if h != base["hash"] else "DEAD"
    if status == 200:
        if fallback:
            return "VALID" if h != base["hash"] else "DEAD"
        return "VALID" if (status != base["status"] or h != base["hash"]) else "DEAD"
    if status == 404:
        return "DEAD"
    return "CANDIDATE"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", required=True)
    ap.add_argument("--wordlist", required=True)
    ap.add_argument("--prefixes", required=True)
    ap.add_argument("--max-depth", type=int, default=6)
    ap.add_argument("--budget", type=int, default=20000)
    ap.add_argument("--delay", type=float, default=0.2)
    ap.add_argument("--out-valid", required=True)
    ap.add_argument("--out-hits", required=True)
    a = ap.parse_args()

    words = [w.strip() for w in open(a.wordlist) if w.strip()]
    prefixes = [p.strip() or "/" for p in open(a.prefixes) if p.strip() != ""]
    if not prefixes:
        prefixes = ["/"]
    probed, hits, valid_paths = set(), [], []
    new_prefixes = list(prefixes)
    budget_left = a.budget
    dead_rounds = 0

    base = capture_baseline(a.host)
    if not base["stable"]:
        print("BASELINE UNSTABLE — aborting. Wait 60s and re-run.", file=sys.stderr)
        sys.exit(2)
    # fallback detection: is / identical to the dead baseline?
    st, _, body, _ = fetch(a.host, "/")
    fallback = (st == 200 and bhash(body) == base["hash"])
    print(f"baseline={base} fallback_mode={fallback}", flush=True)
    json.dump({"baseline": base, "fallback_mode": fallback, "host": a.host},
              open("evidence/baseline.json", "w"), indent=2)

    depth = 1
    while new_prefixes and depth <= a.max_depth and budget_left > 0:
        round_new = []
        for prefix in new_prefixes:
            for w in words:
                for cand in (prefix.rstrip("/") + "/" + w, prefix.rstrip("/") + "/" + w + "/"):
                    if cand in probed or budget_left <= 0:
                        continue
                    probed.add(cand)
                    budget_left -= 1
                    st, hd, body, err = fetch(a.host, cand)
                    cls = classify(st, hd, body, base, fallback)
                    if cls == "BACKOFF":
                        print("429 — backing off 60s", flush=True)
                        time.sleep(60)
                        continue
                    if cls in ("VALID", "VALID-REDIRECT", "ERROR-GATE", "CANDIDATE",
                               "AUTH-GATE", "FORBIDDEN-GATE", "METHOD-GATE"):
                        loc = hd.get("Location", "")
                        hits.append({"depth": depth, "path": cand, "status": st,
                                     "class": cls, "location": loc,
                                     "body_hash": bhash(body), "len": len(body),
                                     "content_type": hd.get("Content-Type", "")})
                        if cls in ("VALID", "VALID-REDIRECT") and cand not in valid_paths:
                            valid_paths.append(cand)
                            # child prefixes for next depth
                            for p in (cand.rstrip("/") + "/", cand if cand.endswith("/") else cand + "/"):
                                if p not in probed:
                                    round_new.append(p)
                        print(f"[{cls}] d={depth} {st} {cand}", flush=True)
                    time.sleep(a.delay)
        # dedupe new prefixes, stop if two dead rounds
        round_new = [p for p in dict.fromkeys(round_new) if p not in probed]
        if not round_new:
            dead_rounds += 1
        else:
            dead_rounds = 0
        new_prefixes = round_new
        depth += 1
        if dead_rounds >= 2:
            print("two consecutive rounds with zero new prefixes — stopping", flush=True)
            break

    # 2x re-verification of VALID hits, 30s apart
    confirmed = []
    for h in hits:
        if h["class"] not in ("VALID", "VALID-REDIRECT"):
            continue
        oks = 0
        for _ in range(2):
            time.sleep(30)
            st2, _, body2, _ = fetch(a.host, h["path"])
            if st2 == h["status"] and bhash(body2) == h["body_hash"]:
                oks += 1
        h["reverified"] = oks
        h["verdict"] = "CONFIRMED" if oks == 2 else "INCONCLUSIVE"
        confirmed.append(h)

    with open(a.out_valid, "w") as f:
        for h in sorted(confirmed, key=lambda x: x["depth"]):
            f.write(f"{h['depth']} {h['status']} {h['path']}\n")
    json.dump({"host": a.host, "baseline": base, "fallback_mode": fallback,
               "depth_reached": depth - 1, "probed": len(probed),
               "budget_left": budget_left, "hits": hits}, open(a.out_hits, "w"), indent=2)
    print(f"done: probed={len(probed)} hits={len(hits)} confirmed_valid={len(confirmed)}")

if __name__ == "__main__":
    main()
