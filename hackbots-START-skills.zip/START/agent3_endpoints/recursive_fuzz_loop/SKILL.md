---
name: recursive_fuzz_loop
agent: agent3_endpoints
description: Never-stop recursive fuzzing — find one valid prefix and dig deeper with target-specific wordlists to depth 6, classifying every response with the response-intelligence table.
---

# Recursive Fuzz Loop

## Purpose

Public surface is where bugs go to die. The real attack surface lives below paths nobody links to — `/api/v2/admin/export`, `/internal/debug/heapdump` — and the only reliable way to find it is recursion: one valid prefix becomes the parent of the next depth level. This skill runs the understand → wordlist → probe → understand loop to depth 6, classifying every single response with the response-intelligence table below. It never reports "done" until a documented stop condition fires. Every valid path it emits is an HTTP-verified fact — never a DNS-only claim, never an unprobed guess.

## Division of labor

- **Consumes:** `wordlists/target_derived.txt` from `wordlist_target_derived` (one token per line); `endpoints/seed_prefixes.txt` (known-good prefixes; may start as just `/`); `evidence/baseline.json` captured on this exact host in this exact run.
- **Produces:** the finished artifacts — `endpoints/recursive_fuzz_loop_valid.txt` (one line per valid path: `<depth> <status> <path>`) and `findings/recursive_fuzz_loop_hits.json` (per-hit classification + raw request/response). Both files existing on disk, with every hit evidenced, is "done".

## When to use / when NOT to use

- **Use when:** you have ≥1 live host answering HTTP; a JS bundle, robots.txt, sitemap, or error page revealed a candidate prefix; a 403/401/405 proved an endpoint exists behind a gate; `docs_swagger_probe` handed you documented routes to verify live.
- **Skip when (time-pass filter):** the host is a pure static SPA where the baseline check shows 5 random dead paths all returning the identical 200 fallback page (document NEGATIVE, move on); a wildcard/CDN host where every response is the same edge error page with zero variance; you have no seed words AND the stack fingerprint is unknown — go run `wordlist_target_derived` first. Fuzzing a live program with a generic 100k-word list is noise, not signal.

## Methodology

1. **Capture the 404 baseline — twice.** Request two provably-dead random paths (`/<rand12>` and `/<rand12>/<rand12>`). Record status, body length, SHA-256. Both runs must agree: same status, lengths within ±5%. If they disagree, the host is unstable or rate-limiting — wait 60s and re-capture.
2. **Decide dead-vs-fallback.** Request `/` and compare to the baseline. If `/` and the dead paths return identical bodies, the host serves a universal fallback: every "200" is fake. Set `FALLBACK_MODE=true` and switch all hit-detection to body-hash divergence from the fallback hash, never status codes.
3. **Load seeds.** Seed prefixes = `/` + robots.txt Disallow entries + JS strings ending in `/` + sitemap paths + every documented route from `docs_swagger_probe` (a spec is a verified prefix list — never fuzz blind when a machine-readable map exists). Load the target-derived wordlist. Record starting counts (prefixes, words) in the run log.
4. **Probe depth 1.** For each word W, request `/W` and `/W/` (trailing-slash twin). Classify each response with the table in step 5. Append every non-DEAD classification to the hits file immediately — never batch in memory where a crash loses the round.
5. **Classify with the response-intelligence table:**
   - `200` + body hash == baseline hash → DEAD (fallback page, ignore)
   - `200` + body hash != baseline hash → VALID (understand it: title? JSON keys? forms? — record the understanding)
   - `301/302/307/308` → follow Location once; if the destination differs from baseline → VALID, record source + destination
   - `400` → CANDIDATE (server parsed and rejected — a real code path; probe with well-formed payloads next)
   - `401` → AUTH-GATE (real endpoint; hand the exact path to `header_trick_battery`, note it in hits)
   - `403` → FORBIDDEN-GATE (real endpoint behind ACL; hand to `header_trick_battery` AND `path_confusion`; never mark dead)
   - `405` → METHOD-GATE (endpoint exists, wrong verb; hand the exact path to `method_verb_matrix`)
   - `429` → BACKOFF (sleep 60s, halve concurrency, resume — never mark dead)
   - `5xx` → ERROR-GATE (record the error signature; a 500 page that differs from the baseline error page is a valid hit — diff the bodies)
   - timeout / connection reset → RETRY-ONCE, then UNSTABLE — never dead on a single network failure
6. **Extract new prefixes from VALID hits.** `/api` at depth 1 becomes a depth-2 prefix. `/api/v2/users` yields `/api/v2/` and `/api/v2/users/`. Also harvest: `<a href>` targets, script srcs, Location headers, JSON keys shaped like path segments.
7. **Build the depth N+1 wordlist.** Combine: (a) the base target-derived wordlist, (b) words harvested from the parent path's response body, (c) segment mutations of the parent (`-admin`, `_internal`, plural/singular, version numbers). Deduplicate against every path already probed — never re-probe.
8. **Probe depth N+1 under each new prefix.** Request `<prefix><word>` and `<prefix><word>/`. Re-classify everything with the table.
9. **Understand every VALID hit before recursing deeper.** Record per hit: page title or JSON top-level keys, forms present, `Content-Type`, `Server`/`X-Powered-By` headers. This understanding feeds step 7 — the loop is understand → wordlist → probe → understand, not blind fuzzing.
10. **Stop conditions — check all four, in order:** (a) depth 6 reached — finish classifying the current round, then stop; (b) two consecutive rounds with zero new VALID prefixes — stop; (c) probe budget exhausted (default 20,000 requests/host) — stop; (d) uniform 429s for >5 minutes — stop and document. Whichever fires first wins. **"I found a few things" is never a stop condition.**
11. **Alias-twin check.** For every VALID hit, request `/path` vs `/path/` vs `//path` vs `/./path`. If twins diverge (one 200, one 404, or different bodies), record both — the divergence itself is a finding and a `path_confusion` lead.
12. **Re-verify every VALID hit 2x.** Re-request each hit twice, 30s apart. Only hits stable across all three observations graduate to CONFIRMED.
13. **Write the finished artifacts.** `endpoints/recursive_fuzz_loop_valid.txt` (sorted by depth, then path) and `findings/recursive_fuzz_loop_hits.json` (hit objects with classification, understanding notes, raw request/response). Also write `endpoints/recursive_fuzz_loop_prefixes.txt` (valid directory-like prefixes only, one per line) — the canonical input for the next depth round and for `old_api_version`/`docs_swagger_probe`.
14. **NEGATIVE documentation.** Zero valid paths beyond `/` after budget exhaustion → write both artifacts anyway with an empty valid list and a `verdict: NEGATIVE` entry: baseline fingerprint, wordlist size, depths reached, stop condition fired — so no other agent re-fuzzes this host blindly.
15. **Politeness and resume.** Write `findings/recursive_fuzz_loop_state.json` after every round (depth, probed count, valid prefixes, budget left). If the run crashes or is killed, resume from the state file — but re-capture the baseline first (baselines expire; a stale baseline poisons every classification). Default 0.2s delay between requests, max 5 concurrent; on 429, sleep 60s and halve concurrency before resuming. Never exceed 20,000 requests/host without human approval.
16. **Content-type-aware understanding.** In step 9's understanding pass, branch on `Content-Type`: `application/json` → top-level keys + pagination markers (`next`, `links`, `cursor`); `text/html` → title + forms + script srcs; `application/xml` → root element + namespaces (SOAP/WSDL leads); `text/plain` → first 3 lines (often version/debug banners); `application/octet-stream` → magic bytes (file-type leads for `backup_file_hunt`).

Decision branches, compressed: 200≠baseline → understand + recurse · 301/302 → follow once · 400 → well-formed payloads · 401/403 → bypass skills · 405 → verb matrix · 429 → backoff · 5xx → diff bodies · timeout → retry once, never dead.

## Worked example — one recursion trace

```
Depth 1:  /api            → 200, JSON {"version":"v2"}          → VALID, new prefix /api/
Depth 2:  /api/admin      → 403                                 → FORBIDDEN-GATE → header_trick_battery
          /api/v2         → 200                                 → VALID, new prefix /api/v2/
Depth 3:  /api/v2/export  → 405                                 → METHOD-GATE → method_verb_matrix
          /api/v2/users   → 200, JSON list                       → VALID, new prefix /api/v2/users/
Depth 4:  /api/v2/users/debug → 200, stack trace in body        → VALID, harvest: debug, trace, profiler
Depth 5:  /api/v2/users/debug/profiler → 401                    → AUTH-GATE → header_trick_battery
Depth 6:  budget/depth reached → stop.
Result: 5 VALID paths, 3 gates handed to bypass skills, 0 rounds wasted on dead prefixes.
```

## Exact commands

Baseline capture (run twice, compare hashes):
```bash
R1=$(openssl rand -hex 6); R2=$(openssl rand -hex 6)
for p in "/$R1" "/$R2/$R1"; do
  curl -sS -D /tmp/base_hdr -o /tmp/base_body -w 'HTTP %{http_code} len=%{size_download}\n' \
    --max-time 15 "https://<HOST>$p"
  sha256sum /tmp/base_body; head -5 /tmp/base_hdr
done
```

Depth probing via the helper (baseline-aware, table-driven classification):
```bash
python3 recursive_fuzzer.py \
  --host "https://<HOST>" \
  --wordlist wordlists/target_derived.txt \
  --prefixes endpoints/seed_prefixes.txt \
  --max-depth 6 --budget 20000 --delay 0.2 \
  --out-valid endpoints/recursive_fuzz_loop_valid.txt \
  --out-hits findings/recursive_fuzz_loop_hits.json
```

Manual 2x reproduction of one hit (30s apart, 3/3 must agree):
```bash
for i in 1 2 3; do
  curl -sS -D - -o /tmp/hit_$i.body -w 'HTTP %{http_code} len=%{size_download}\n' \
    --max-time 15 "https://<HOST><PATH>"
  sha256sum /tmp/hit_$i.body
  [ $i -lt 3 ] && sleep 30
done
```

Alias-twin divergence check:
```bash
for v in "<PATH>" "<PATH>/" "//<PATH>l" "/./<PATH>"; do
  code=$(curl -sS -o /dev/null -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$v")
  echo "$code  $v"
done
```

## Completion-bias defenses

- [ ] 404 baseline captured twice and both runs agree (saved to `evidence/baseline.json`)
- [ ] Dead-vs-fallback determination made and recorded (FALLBACK_MODE true/false)
- [ ] Seed wordlist + seed prefixes loaded; starting counts recorded
- [ ] Every depth level probed with both `/W` and `/W/` twins
- [ ] Every response classified with the response-intelligence table — zero "unclassified" rows
- [ ] Every VALID hit has understanding notes (title / JSON keys / forms / headers)
- [ ] New prefixes extracted; depth N+1 wordlist built from harvested + mutated words
- [ ] A documented stop condition fired (depth 6 / two dead rounds / budget / sustained 429s)
- [ ] Alias-twin check run on every VALID hit; divergences recorded
- [ ] Every VALID hit re-verified 2x, 30s apart, stable across all observations
- [ ] State file written per round; resume re-captures the baseline first
- [ ] Understanding pass branched on Content-Type per hit
- [ ] Finished artifacts exist on disk: `endpoints/recursive_fuzz_loop_valid.txt` + `findings/recursive_fuzz_loop_hits.json`
- [ ] NEGATIVE documented (baseline + budget + stop condition) if zero hits

- **Review step:** agent10_review must verify: (1) the baseline is from this host and this run; (2) every line in the valid file has a matching hits-JSON entry with raw evidence; (3) the stop condition is one of the four allowed ones; (4) no response was marked DEAD on a single 429/timeout.
- **Nudge prompts:**
  - "Keep going until a documented stop condition fires — depth 6, two consecutive rounds with zero new prefixes, budget exhausted, or sustained 429s. 'I found a few paths' is not done."
  - "Every response gets a classification from the response-intelligence table. An unclassified response is a skipped step, not a dead end."
  - "Do not report done before both finished artifacts exist on disk with raw evidence for every hit."
- **Finished artifact definition:** `endpoints/recursive_fuzz_loop_valid.txt` (sorted `<depth> <status> <path>` lines) AND `findings/recursive_fuzz_loop_hits.json` (hit objects with classification, understanding, raw request/response pairs), both on disk; non-empty valid list OR a `verdict: NEGATIVE` entry.

## Evidence standard

- Baseline: every hit compared against `evidence/baseline.json` captured twice on this host; FALLBACK_MODE hosts use body-hash divergence, never status alone.
- Reproduction: each VALID hit re-requested 2x, 30s apart — 3/3 stable observations required for CONFIRMED.
- Raw evidence: full request line + response headers + first 2KB of body stored per hit in the hits JSON.
- Verdicts: CONFIRMED (baseline-divergent + 3/3 stable + raw evidence) / INCONCLUSIVE (divergent once, unstable on re-run — flag for a second model run) / NEGATIVE (host exhausted per stop conditions, artifacts written anyway).

## Handoffs

- `old_api_version`: every valid `/api*` prefix — test version siblings (`/v1`, `/v2`, `/v0`) of each.
- `docs_swagger_probe`: every valid prefix — probe `<prefix>/openapi.json`, `<prefix>/docs`, `<prefix>/swagger` beneath each.
- `backup_file_hunt`: every valid file-like hit (`*.js`, `*.json`, `*.xml`) — test backup/editor variants of each.
- `method_verb_matrix`: every METHOD-GATE (405) path from the classification table.
- `header_trick_battery` + `path_confusion`: every AUTH-GATE (401) and FORBIDDEN-GATE (403) path.
- `param_mining`: every VALID hit returning dynamic content (forms, filterable JSON) — mine for hidden parameters.
- `agent10_review`: both finished artifacts for the review gate above.
