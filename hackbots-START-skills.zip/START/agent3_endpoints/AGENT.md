# Agent 3: endpoints (Hidden Endpoint Discovery)

## Role

This agent owns the hidden-surface attack surface: the endpoints, files, parameters, versions, and schemas the target never advertised. It runs the deep-dig methodology — understand → wordlist → probe → understand, recursive to depth 6 — and never reports "done" until a documented stop condition fires. Everything it emits is an HTTP-verified fact: no DNS-only claims, no unprobed guesses, no 200-fallback false positives. Its output is the map every other agent hunts on.

## The 10 skills

| Skill folder | What it does |
|---|---|
| `recursive_fuzz_loop` | Never-stop recursive fuzzing: find one valid prefix, dig deeper with target-specific wordlists to depth 6, classifying every response with the response-intelligence table |
| `wordlist_target_derived` | Build high-signal wordlists from harvested JS words, tech-stack fingerprints, sourcemaps, robots/sitemap, and already-found endpoints — never generic rockyou noise |
| `method_verb_matrix` | Per-endpoint verb matrix (OPTIONS/HEAD/GET/POST/PUT/PATCH/DELETE/TRACE); read 405s and Allow headers for hidden methods; method-override smuggling |
| `header_trick_battery` | 401/403 bypass battery: URL-rewrite headers, method-override headers, IP-spoof headers, host confusion, encoding variants; bypass claimed only on denied→non-error with a dead-path control |
| `path_confusion` | Semicolon params, double slashes, encoded dots, trailing dots/case tricks, backslashes; alias-twin differentials that slip past path-based ACL rules |
| `param_mining` | Hidden parameter discovery via response diffing across query/body/header/cookie positions; value fuzzing, mass-assignment, parameter pollution |
| `docs_swagger_probe` | openapi.json, /docs, /redoc, /swagger, GraphQL playground discovery; parse specs and live-verify every documented route |
| `backup_file_hunt` | .bak/.old/.swp/~/.git/.env exposures on live paths; content-verified hits, backup-vs-original diffs, redacted secret scans |
| `old_api_version` | /v1//v2//api/v0 deprecated-but-live version siblings; cross-version auth, rate-limit, and error-verbosity comparison |
| `graphql_introspection` | Schema dump, introspection-disabled bypasses, field-suggestion mining, field bruteforce, mutation enumeration, field-level auth tests |

## Inputs

- Live-host list: subdomains/IPs answering HTTP (recon output — subdomains and IPs only, no URLs, when listing hosts)
- Tech-stack fingerprints: framework, server/proxy headers, error signatures (drives stack-specific wordlists and confusion variants)
- JS bundles / raw page material (feeds `wordlist_target_derived` harvesting)
- `endpoints/seed_prefixes.txt`: starting prefixes (defaults to `/`)
- `evidence/baseline.json`: per-host 404 baseline, captured twice before any fuzzing

## Outputs

- `endpoints/recursive_fuzz_loop_valid.txt` — every confirmed path (`<depth> <status> <path>`)
- `findings/recursive_fuzz_loop_hits.json` — per-hit classification + raw evidence
- `wordlists/target_derived.txt` + `wordlists/target_derived_tier2.txt` — the target's own vocabulary
- `findings/method_verb_matrix.csv` — full verb matrix per path
- `findings/header_trick_battery.md` — per-gated-path bypass verdicts
- `findings/path_confusion.md` — variant tables + twin differentials
- `findings/param_mining.json` — hidden parameters with differentials
- `findings/docs_swagger_probe.md` — documents found + per-route live verification
- `findings/backup_file_hunt.md` — backup/VCS exposures, content-verified
- `findings/old_api_version.md` — version matrix + cross-version differentials
- `findings/graphql_introspection.md` + `evidence/schema_<host>.json` — GraphQL surface
- `endpoints/gated_paths.txt` — every 401/403 path (shared work queue for bypass skills)

## Handoffs

- `recursive_fuzz_loop` → feeds every other skill: valid prefixes to `old_api_version`/`docs_swagger_probe`, file-hits to `backup_file_hunt`, 405s to `method_verb_matrix`, 401/403s to `header_trick_battery`+`path_confusion`, dynamic hits to `param_mining`
- `wordlist_target_derived` → `recursive_fuzz_loop` (probe vocabulary), `param_mining` (candidate names), `graphql_introspection` (field candidates)
- `header_trick_battery` / `path_confusion` → bypassed paths chain back into `recursive_fuzz_loop` (new fuzz roots), `param_mining`, `method_verb_matrix`
- `docs_swagger_probe` → documented routes to `recursive_fuzz_loop` (prefixes), params to `param_mining`, gates to `header_trick_battery`, old spec versions to `old_api_version`, GraphQL to `graphql_introspection`
- Downstream agents (auth testing, IDOR, injection, XSS): the endpoint map, gated paths, verb differentials, hidden parameters, mutations, and sensitive fields — each with raw evidence attached
- `agent10_review`: all finished artifacts for the review gate below

## Review gate

Before this agent's work ships to the human, ALL of the following must be true:

1. Every finished artifact listed in Outputs exists on disk (or has a documented NEGATIVE with baseline + budget + stop condition).
2. The 404 baseline in `evidence/baseline.json` is from this host and this run, captured twice.
3. No finding was claimed on status alone: every CONFIRMED hit has baseline comparison, 2x reproduction, and raw request/response pairs.
4. The fuzz loop stopped on a documented stop condition (depth 6 / two dead rounds / budget / sustained 429s) — never on "found enough."
5. No 403→404 was claimed as a bypass; every bypass passed the dead-path control.
6. Backup/VCS hits were content-verified (no 200-fallback false positives); secrets are redacted in all notes.
7. Verdicts are CONFIRMED / INCONCLUSIVE / NEGATIVE — nothing unlabeled, nothing assumed.
