---
name: param_mining
agent: agent3_endpoints
description: Hidden parameter discovery via response diffing — find the debug, admin, and filter params the app accepts but never documents.
---

# Param Mining

## Purpose

Endpoints are only half the surface; the other half is parameters. Apps accept dozens of undocumented query, body, and header parameters — `debug=true` that dumps stack traces, `admin=1` that skips checks, `filter`/`sort`/`include` that reach unprotected ORM fields, `callback` that enables JSONP. This skill discovers them by response diffing: send the baseline request, then the same request plus one candidate parameter, and flag every response that differs in status, length, hash, or timing. A parameter that changes the response exists — and an existing undocumented parameter is a lead.

## Division of labor

- **Consumes:** dynamic endpoints — VALID hits from `recursive_fuzz_loop` that return forms, filterable JSON, search, or any 400/405 on POST/PUT (reached application code); candidate param-name list (tier-1 words from `wordlist_target_derived` + the built-in list below).
- **Produces:** the finished artifact — `findings/param_mining.json`: per endpoint, the baseline fingerprint and every parameter that produced a differential, with the differential type and raw evidence.

## When to use / when NOT to use

- **Use when:** an endpoint returns dynamic content (JSON lists, search results, forms); POST/PUT returned 400/405 (parameter parsing reached); JS shows `params.`/`query.`/`req.body` references; the endpoint name suggests filtering (`/search`, `/list`, `/users`, `/report`).
- **Skip when (time-pass filter):** the endpoint returns byte-identical static content (verified across 3 requests — nothing to diff against); the endpoint is a static asset; every candidate returns the identical response AND identical timing across 50+ params (document the uniformity once, move on).

## Methodology

1. **Fingerprint the baseline.** Request the endpoint 3x with no added parameters. Record status, body length, body hash, and response time for each. All three must agree within ±3% length and ±50% time — if the endpoint is naturally unstable (timestamps, random ordering), you must normalize before diffing (strip timestamps/nonces from the body before hashing) or every parameter will "differ."
2. **Normalize dynamic noise.** Identify the unstable substrings (timestamps, CSRF tokens, request IDs) by diffing the 3 baseline bodies. Build a normalization function (regex strip) and apply it to ALL subsequent bodies before hashing. Document the normalization — a reviewer must be able to reproduce your hashes.
3. **Build the candidate list.** Combine: (a) tier-1 words from `wordlist_target_derived` (apps reuse vocabulary), (b) the built-in high-signal list below, (c) parameter names harvested from JS (`?` strings, `params:` objects, `new URLSearchParams`), (d) names seen in forms on the page. Dedupe.
4. **Probe query parameters, one at a time.** `?candidate=1` — also try `=true`, `=test`, and empty (`?candidate`). One parameter per request: combining masks which one caused the differential. Record status/len/hash/time per candidate.
5. **Probe body parameters.** For endpoints accepting POST/PUT: send JSON `{"candidate": "test"}`, form `candidate=test`, and (if JSON API) nested `{"filter": {"candidate": "test"}}`. Frameworks parse body params the query string never sees.
6. **Probe header parameters.** `X-candidate: test` — some APIs (and WAF-bypassed gates) read custom headers as parameters. Also try the candidate as a cookie (`candidate=test`).
7. **Classify differentials:**
   - status change (200→500, 200→400, 200→302) → STRONG — the parameter reached application logic
   - body hash change with same status → MEDIUM — reached logic, changed output
   - length-only change <1% → WEAK — likely noise; re-test 3x before noting
   - timing change >2x consistently → TIMING — possible backend query involvement (note, don't claim injection)
   - reflection of the value in the body → REFLECTION — XSS/context lead, hand to XSS skills downstream
   - no change → dead, move on
8. **Value-fuzz the hits.** For each STRONG/MEDIUM hit, try values: `true`, `1`, `0`, `false`, `admin`, `*`, `%`, `../`, `'`, `"`, `null`, huge string (10k chars), negative number. Watch for: boolean flips (debug output appears), wildcard expansion (more records returned), errors leaking SQL/ORM details, type-confusion 500s.
9. **Test for mass-assignment.** On POST/PUT endpoints, send `{"role": "admin"}`, `{"isAdmin": true}`, `{"admin": 1}`, `{"user_id": 1}` alongside a legitimate action. A 200 that changes the created object's role = mass assignment. Verify by reading the object back — claim only what the re-read proves.
10. **Test parameter pollution.** Send `?id=1&id=2`, `?id[]=1`, `?id=1,2`. Frameworks differ (first wins, last wins, array) — a differential between `?id=1` and `?id=1&id=2` reveals parser behavior useful for filter bypasses.
11. **Re-verify every STRONG/MEDIUM differential 2x** with normalization applied. 3/3 stable to CONFIRMED.
12. **Write the artifact**: per endpoint — baseline fingerprint + normalization rules, candidate count, and every differential parameter with type, values tested, and raw evidence.

Built-in high-signal parameter names (add target-derived words to these):
```
debug test admin administrator mode verbose trace
filter sort order by limit offset page per_page size
include exclude fields select expand with relations
callback jsonp _ method format output pretty
id user_id uid account_id org_id tenant_id
role isAdmin is_admin admin_flag permissions
search q query keyword term name email
token api_token access_token key secret
redirect url next return_to continue
file path filename dir folder
lang locale country currency
version v api_version
preview draft unpublished internal
```

Decision branches: STRONG differential → value-fuzz immediately · reflection → note XSS lead, keep mining · timing differential → 3x re-test before noting · mass-assignment 200 → re-read the object to prove it · all candidates dead → try header/cookie positions before declaring negative.

## Exact commands

Baseline fingerprint (3x, with normalization check):
```bash
for i in 1 2 3; do
  curl -sS -o /tmp/pm_base_$i.body -w 'HTTP %{http_code} len=%{size_download} time=%{time_total}\n' \
    --max-time 15 "https://<HOST><PATH>"
  sha256sum /tmp/pm_base_$i.body
done
diff /tmp/pm_base_1.body /tmp/pm_base_2.body | head -20  # identify noise to normalize
```

Query-parameter diff loop:
```bash
while read -r p; do
  code=$(curl -sS -o /tmp/pm.body -w '%{http_code} %{size_download} %{time_total}' \
    --max-time 15 "https://<HOST><PATH>?${p}=test")
  h=$(sha256sum /tmp/pm.body | cut -c1-12)
  echo "$p -> $code h=$h"
done < wordlists/param_candidates.txt > findings/pm_query_diff.txt
# compare each line against the baseline fingerprint; flag non-matching
```

Body-parameter probes (JSON + form):
```bash
P="<PATH>"
curl -sS -o /dev/null -w 'json: %{http_code} %{size_download}\n' --max-time 15 \
  -X POST -H 'Content-Type: application/json' -d '{"debug":true}' "https://<HOST>$P"
curl -sS -o /dev/null -w 'form: %{http_code} %{size_download}\n' --max-time 15 \
  -X POST -d 'debug=true' "https://<HOST>$P"
curl -sS -o /dev/null -w 'header: %{http_code} %{size_download}\n' --max-time 15 \
  -H "X-debug: true" "https://<HOST>$P"
```

Value fuzz on a hit parameter:
```bash
P="<PATH>"; N="<PARAM>"
for v in true 1 0 false admin '*' '%' null; do
  code=$(curl -sS -o /tmp/pmv.body -w '%{http_code} %{size_download}' --max-time 15 \
    "https://<HOST>${P}?${N}=${v}")
  echo "$v -> $code"
done
# 10k-char overflow test
python3 -c "print('A'*10000)" > /tmp/big.txt
curl -sS -o /dev/null -w 'big: %{http_code} %{size_download} %{time_total}\n' --max-time 20 \
  --data-urlencode "debug@/tmp/big.txt" "https://<HOST>$P"
```

Mass-assignment check (verify by re-reading the object):
```bash
# create/update with role param, then GET the object back and inspect
curl -sS --max-time 15 -X POST -H 'Content-Type: application/json' \
  -d '{"name":"probe","role":"admin"}' "https://<HOST><PATH>" | tee /tmp/ma.json
# re-read: only claim if the stored object shows the injected role
```

Parameter pollution:
```bash
P="<PATH>"
for q in "id=1" "id=1&id=2" "id[]=1" "id=1,2"; do
  echo "$q -> $(curl -sS -o /dev/null -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>${P}?${q}")"
done
```

## Completion-bias defenses

- [ ] Baseline fingerprinted 3x; stability confirmed (±3% length)
- [ ] Dynamic noise identified and normalization documented
- [ ] Candidate list built from 4 sources (tier-1 words + built-in + JS-harvested + form names), deduped
- [ ] Query position probed, one parameter per request
- [ ] Body position probed (JSON + form + nested)
- [ ] Header and cookie positions probed
- [ ] Every differential classified (STRONG/MEDIUM/WEAK/TIMING/REFLECTION)
- [ ] STRONG/MEDIUM hits value-fuzzed (boolean/wildcard/type/overflow)
- [ ] Mass-assignment tested on POST/PUT endpoints with re-read verification
- [ ] Parameter pollution tested
- [ ] All STRONG/MEDIUM differentials re-verified 2x with normalization
- [ ] `findings/param_mining.json` written with baselines, normalization rules, and evidence

- **Review step:** agent10_review must verify: (1) the normalization rules are documented and the baseline hashes are reproducible; (2) no WEAK differential is claimed without 3x re-test; (3) mass-assignment claims include the re-read proof; (4) one-parameter-per-request was honored (spot-check the diff log).
- **Nudge prompts:**
  - "Normalize before you diff. An un-normalized timestamp will make every parameter look alive and every finding fake."
  - "One parameter per request. The differential you can't attribute to a single parameter is a differential you can't claim."
  - "A parameter that changes the response exists. Keep going until every candidate is classified — the debug flag is never the first word in the list."
- **Finished artifact definition:** `findings/param_mining.json` on disk: per endpoint — baseline fingerprint (status/len/hash/time × 3), normalization regexes, candidate count, and every STRONG/MEDIUM/REFLECTION parameter with differential type, values tested, and raw request/response evidence.

## Evidence standard

- Baseline: 3x baseline requests with normalization; every differential judged against normalized hashes.
- Reproduction: each claimed parameter re-tested 2x — 3/3 stable differentials to CONFIRMED.
- Raw evidence: baseline trio + the differential request/response (full headers, first 2KB body) per claimed parameter.
- Verdicts: CONFIRMED (3/3 stable differential + raw pairs) / INCONCLUSIVE (differential once, or only WEAK/TIMING — second model run) / NEGATIVE (all candidates dead across query/body/header/cookie — documented per endpoint).

## Handoffs

- Downstream injection/XSS agents: REFLECTION parameters (value reflected — context lead) and STRONG parameters reaching backend logic.
- Downstream auth agents: `debug`/`admin`/`role`-type parameters that changed behavior — privilege-lead.
- `graphql_introspection`: parameter names that look like GraphQL args (`filter`, `where`, `orderBy`) — feed as field candidates.
- `agent10_review`: the mining JSON for the review gate above.
