---
name: old_api_version
agent: agent3_endpoints
description: Deprecated-but-live API versions — /v1//v2//api/v0 siblings with weaker auth, missing rate limits, and forgotten endpoints.
---

# Old API Version

## Purpose

APIs version, but old versions rarely die: `/api/v1` stays live for legacy clients years after `/api/v3` ships — with the old auth model, the old (missing) rate limits, the endpoints that were removed for security reasons, and the verbose errors the new version suppresses. Version enumeration is cheap and the hit rate is high because deprecation is a documentation event, not a shutdown event. This skill takes every versioned API prefix found and tests its version siblings, then compares auth behavior across versions to find the one the developers stopped hardening.

## Division of labor

- **Consumes:** versioned prefixes from `recursive_fuzz_loop` (`/api/v2/...`, `/v1/...`); version hints from `docs_swagger_probe` (multi-version specs); JS references to version strings.
- **Produces:** the finished artifact — `findings/old_api_version.md`: version matrix per API family (version → status/auth behavior/endpoints), cross-version differentials, and verdicts.

## When to use / when NOT to use

- **Use when:** any path contains a version marker (`v1`, `v2`, `2024-01`, `api/`); the spec shows multiple versions; JS references versioned base URLs; the API uses date-versioned paths (Stripe-style).
- **Skip when (time-pass filter):** the API surface is entirely unversioned with no version markers anywhere after a full fuzz (one probe round of `/v1`/`/v2` at root to confirm, then document); version siblings return byte-identical responses to the current version across 10+ sampled endpoints (it's an alias, not a version — document once).

## Methodology

1. **Identify API families.** Group found paths by family: `/api/v2/users` → family `/api/`, current version `v2`. Also catch unversioned-but-versionable families (`/api/users` → family `/api/`, version ``).
2. **Enumerate version siblings.** For each family, probe: `/api/v1`, `/api/v2`, `/api/v3`, `/api/v0`, `/api/beta`, `/api/alpha`, `/api/latest`, `/api/stable`, `/api/` (bare), plus minor versions `/api/v1.1`, `/api/v2.1`, `/api/v2beta` (minor versions are the least-maintained of all), plus date versions if hinted (`/api/2023-01`). Record status/len/hash per version root.
3. **Classify each sibling:** 404-everywhere = dead version (note, move on); redirects to current version = alias (verify the redirect target — a 302 to `/api/v3` is an alias, document once); 200/401/403 with distinct body = LIVE version (full matrix below).
4. **Port the current version's endpoints to the old version.** Take the CONFIRMED endpoint list from the current version and replay each path against the old version root (`/api/v3/users/1` → `/api/v1/users/1`). Classify each: same behavior (parity), weaker (less auth — FINDING), missing (404 — removed endpoint, note), different (diff bodies — behavior change).
5. **Compare auth behavior across versions.** For 3–5 representative endpoints, test unauthenticated on every live version: does v1 require the token v3 requires? Does v1 accept the expired/test token v3 rejects? Weaker auth on the old version is the headline finding — verify 2x.
6. **Compare rate limiting across versions.** Send 20 rapid requests to the same endpoint on v1 vs v3. If v3 429s and v1 doesn't, the old version lacks rate limiting — note as an abuse primitive (do not run sustained load; 20 requests is the test).
7. **Compare error verbosity.** Trigger errors (bad ID, bad JSON) on both versions. Old versions often return stack traces / SQL errors the new version suppresses — error differentials are info-leak findings.
8. **Compare response security headers.** Diff the full response headers v1 vs v3 on the same endpoint: a v1 missing `Content-Security-Policy`, `X-Frame-Options`, or `Strict-Transport-Security` that v3 sends is a hardening gap — the old version is the softer target for clickjacking/MIME-sniffing chains.
8. **Hunt removed endpoints.** Endpoints 404 on v3 but 200 on v1 are endpoints someone deleted for a reason — test each for auth and sensitivity. Check the old spec version (from `docs_swagger_probe`'s multi-version diff) for routes missing from the new spec.
9. **Test version confusion.** `/api/v2/../v1/users`, `/api/v1%2fusers` on the v2 router, `Accept-Version` / `X-API-Version: v1` headers on v3 endpoints — version routing disagreements can serve v1 logic under v3 paths (judge with the denied→non-error bar where gates are involved).
10. **Handle date-versioned families.** Stripe-style APIs version by date (`/2024-06-20/charges`) or by header (`Stripe-Version: 2024-06-20`, `Api-Version: 2023-01`). Harvest date strings and version-header names from JS and docs, probe 3–4 date siblings, and test the version header on the current path — an old date header on the new path can silently downgrade behavior without changing the URL.
11. **Probe the unversioned twin.** `/api/users` alongside `/api/v3/users` — unversioned routes often alias the OLDEST version, not the newest. Diff the responses; if the unversioned twin matches v1's body, it's a stealth old-version endpoint — run the full port+compare against it.
12. **Re-verify differentials 2x** and write the version matrix: per family, per version — root status, endpoint parity table, auth comparison, rate-limit comparison, error verbosity, removed-endpoint findings.

Decision branches: sibling 302s to current → alias, document once · sibling live with distinct body → full port+compare · old version weaker auth → headline finding, verify 2x, chain to auth agents · old version missing rate limit → abuse-primitive note (no sustained load) · removed endpoint live on old → test auth+sensitivity immediately.

## Where version signals hide

- **JS bundles:** `baseURL: "https://api.<host>/v2"`, `API_VERSION = "2024-01"`, fetch calls to `/v1/...` the UI no longer links.
- **Response headers:** `Api-Version`, `X-API-Version`, and the gold pair — `Sunset:` / `Deprecation: true`. A server sending `Deprecation: true` on v1 is telling you that version is unmaintained: test it hardest.
- **Error bodies:** 400 responses like `"supported versions: v2, v3"` enumerate the family for you.
- **Docs:** multi-version spec URLs (`/v2/api-docs` + `/v3/api-docs`) — diff the route lists.
- **Redirects:** `/api/users` → 302 → `/api/v1/users` reveals the default version is v1, whatever the docs claim.

## Exact commands

Version-sibling enumeration:
```bash
F="/api"  # family root
for v in v1 v2 v3 v0 v4 beta alpha latest stable "" 2023-01 2024-01; do
  code=$(curl -sS -o /tmp/ver.body -w '%{http_code} %{size_download}' --max-time 15 \
    "https://<HOST>$F/$v/users")
  h=$(sha256sum /tmp/ver.body | cut -c1-8)
  echo "$code h=$h  $F/$v/users"
done
```

Port current-version endpoints to the old version:
```bash
OLD="v1"; NEW="v3"
while read -r _ _ path; do
  oldpath=$(echo "$path" | sed "s|/api/$NEW/|/api/$OLD/|")
  [ "$oldpath" = "$path" ] && continue
  n=$(curl -sS -o /dev/null -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$path")
  o=$(curl -sS -o /dev/null -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$oldpath")
  [ "$n" != "$o" ] && echo "DIFF new=$n old=$o  $oldpath"
done < endpoints/recursive_fuzz_loop_valid.txt
```

Cross-version auth comparison (unauthenticated):
```bash
for v in v1 v2 v3; do
  echo "== $v =="
  curl -sS -o /dev/null -w '%{http_code} %{size_download}\n' --max-time 15 \
    "https://<HOST>/api/$v/users/me"
  curl -sS -o /dev/null -w '%{http_code} %{size_download}\n' --max-time 15 \
    "https://<HOST>/api/$v/admin/users"
done
```

Rate-limit comparison (20 rapid requests, no sustained load):
```bash
for v in v1 v3; do
  echo "== $v =="
  for i in $(seq 1 20); do
    curl -sS -o /dev/null -w '%{http_code} ' --max-time 10 "https://<HOST>/api/$v/users/1"
  done; echo
done
# v3 429s while v1 stays 200 => old version lacks rate limiting
```

Error-verbosity comparison:
```bash
for v in v1 v3; do
  echo "== $v =="
  curl -sS --max-time 15 -H 'Content-Type: application/json' \
    -d '{"id": "not-an-id-{{{}}}"}' "https://<HOST>/api/$v/users/1" | head -c 600; echo
done
```

Version-confusion probes:
```bash
curl -sS -o /dev/null -w 'dotdot: %{http_code}\n' --max-time 15 "https://<HOST>/api/v2/../v1/users"
curl -sS -o /dev/null -w 'hdr: %{http_code}\n' --max-time 15 \
  -H "X-API-Version: v1" -H "Accept-Version: v1" "https://<HOST>/api/v3/users"
```

## Completion-bias defenses

- [ ] API families identified and grouped from found paths
- [ ] Version siblings enumerated per family (10+ candidates incl. beta/alpha/bare)
- [ ] Each sibling classified (dead / alias / live-distinct)
- [ ] Current-version endpoints ported to every live old version; parity table built
- [ ] Auth compared across versions on 3–5 representative endpoints, unauthenticated
- [ ] Rate limits compared (20-request test per version — no sustained load)
- [ ] Error verbosity compared (bad-ID and bad-JSON triggers)
- [ ] Removed endpoints (404-new/200-old) tested for auth and sensitivity
- [ ] Version-confusion probes fired (path + header)
- [ ] Date-versioned families and version headers tested where hinted
- [ ] Unversioned twin probed and diffed against versioned responses
- [ ] All differentials re-verified 2x
- [ ] `findings/old_api_version.md` written with version matrix and verdicts

- **Review step:** agent10_review must verify: (1) alias-redirects were followed and confirmed (not assumed); (2) weaker-auth claims show the same endpoint on both versions with raw pairs; (3) the rate-limit test stayed at 20 requests; (4) removed-endpoint findings include auth testing.
- **Nudge prompts:**
  - "Deprecation is a documentation event, not a shutdown event. Test the old version like it's the current one — because for the attacker, it is."
  - "Port every confirmed endpoint to the old version. The endpoint they deleted for security reasons is the one that still 200s on v1."
  - "Compare auth, rate limits, and errors across versions. The version they stopped hardening is your finding."
- **Finished artifact definition:** `findings/old_api_version.md` on disk: per API family — version matrix (version → root status → classification), endpoint parity table, cross-version auth/rate-limit/error comparisons, removed-endpoint findings, and verdicts with raw pairs.

## Evidence standard

- Baseline: current-version behavior is the baseline; every old-version claim is a differential against it on the same endpoint.
- Reproduction: each differential re-tested 2x, 30s apart — 3/3 stable to CONFIRMED.
- Raw evidence: same-endpoint request/response pairs on both versions side by side (headers + first 2KB body).
- Verdicts: CONFIRMED (stable cross-version differential + raw pairs) / INCONCLUSIVE (differential once) / NEGATIVE (siblings dead/aliases, or full parity — documented per family).

## Handoffs

- Downstream auth agents: old versions with weaker auth — full endpoint list for auth testing.
- `param_mining`: old-version endpoints returning 400s — parameter surface the new version removed.
- `docs_swagger_probe`: feed the old-version spec URL if discovered (`/v1/api-docs`).
- `header_trick_battery`: old-version 401/403s — bypass the old gate.
- `agent10_review`: the version matrix for the review gate above.
