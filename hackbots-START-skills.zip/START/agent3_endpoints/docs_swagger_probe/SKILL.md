---
name: docs_swagger_probe
agent: agent3_endpoints
description: Machine-readable route maps — openapi.json, /docs, /redoc, /swagger, GraphQL playground discovery and live verification of every documented route.
---

# Docs Swagger Probe

## Purpose

Developers ship machine-readable maps of their own attack surface and forget to take them down: `openapi.json`, `swagger-ui.html`, `/docs`, `/redoc`, GraphQL playgrounds, Postman collections left on the server. One spec file can hand you a hundred endpoints — including deprecated, admin, and internal ones — with their methods, parameters, and auth requirements spelled out. This skill hunts those documents across every known prefix, parses each one for routes, and verifies every documented route live. A documented route that 404s is stale trivia; a documented route that 200s is a confirmed endpoint you didn't have to fuzz for.

## Division of labor

- **Consumes:** every valid prefix from `recursive_fuzz_loop` (probe doc-paths beneath each); the host root; tech-stack hints (frameworks have conventional doc paths).
- **Produces:** the finished artifact — `findings/docs_swagger_probe.md`: documents found (URL + type + route count), per-route live-verification table, and stale-vs-live verdicts.

## When to use / when NOT to use

- **Use when:** starting endpoint discovery on any host (cheap, high-signal); valid API-like prefixes exist; the stack is a framework with conventional doc paths (Spring, .NET, FastAPI, NestJS, Laravel).
- **Skip when (time-pass filter):** 10+ doc-path probes across root and all prefixes return the identical fallback/404 signature (document the sweep once, move on); the only "docs" found are marketing pages with no machine-readable spec.

## Methodology

1. **Probe the conventional doc paths at root.** One request each, record status/len/hash vs the baseline:
   - `/openapi.json`, `/openapi.yaml`, `/openapi.yml`
   - `/swagger.json`, `/swagger.yaml`, `/swagger/v1/swagger.json` (.NET convention)
   - `/v2/api-docs`, `/v3/api-docs`, `/v3/api-docs.yaml` (Springdoc/Springfox)
   - `/swagger-ui.html`, `/swagger-ui/`, `/swagger-ui/index.html`
   - `/docs`, `/redoc`, `/api-docs`, `/api/docs`, `/documentation`
   - `/.well-known/openapi.json`
   - GraphQL: `/graphql`, `/api/graphql`, `/gql`, `/graphiql`, `/playground`, `/altair`
2. **Probe doc paths beneath every valid prefix.** For each prefix `/api/v2`, try `/api/v2/openapi.json`, `/api/v2/docs`, `/api/v2/swagger.json`, etc. Versioned APIs often document themselves under their own prefix.
3. **Fetch and identify what you found.** A JSON doc starting with `{"openapi":` or `{"swagger":` is a spec — parse it. An HTML page containing `swagger-ui` or `redoc` is a UI — find the spec URL it loads (grep for `.json` in the HTML/JS). A GraphQL playground HTML page means a live GraphQL endpoint nearby — hand to `graphql_introspection`.
4. **Parse the spec for routes.** Extract every path + method + parameters + security requirements. Count them. Note: deprecated flags (`"deprecated": true`), admin/internal tags, and servers arrays (they leak internal base URLs).
5. **Verify every documented route live.** For each path+method: send the request with minimal valid parameters. Classify: 200/201 (LIVE — confirmed endpoint), 401/403 (LIVE-BEHIND-GATE — hand to `header_trick_battery`), 404 (STALE — documented but dead, note it), 405 (LIVE wrong verb — hand to `method_verb_matrix`), 400 (LIVE — needs parameters, hand to `param_mining`).
6. **Mine parameters from the spec.** Every documented parameter name goes to `param_mining`'s candidate list — the spec tells you the exact names, types, and which are required.
7. **Mine the spec for secrets.** Scan the raw spec text for: example values that look real (`"example": "sk-live-..."`), server URLs with credentials, internal hostnames in `servers:` arrays, API key names in `securityDefinitions`. Real-looking examples get verified, never assumed.
8. **Check for multiple spec versions.** `/v2/api-docs` AND `/v3/api-docs` on the same host = two API generations; diff their route lists — routes in v2 missing from v3 are `old_api_version` leads.
9. **Check UI-only exposures.** A `swagger-ui.html` that 200s but whose spec URL 404s is still a finding (UI version leaks framework version); a UI whose "Try it out" works unauthenticated means the underlying API is unauth — test one documented POST live.
10. **Write the report**: documents found (URL, type, route count), per-route verification table (route, method, status, verdict), stale-vs-live summary, secrets found, handoff lists.

Decision branches: spec found → parse + verify all routes (never stop at "spec exists") · UI found but spec 404s → framework-version note + try spec-URL variants from the UI's JS · GraphQL playground → hand to `graphql_introspection` immediately · documented 401/403 → bypass battery · documented 400 → parameter mining · two spec versions → diff for deprecated routes.

## Exact commands

Root doc-path sweep:
```bash
for p in openapi.json openapi.yaml swagger.json v2/api-docs v3/api-docs \
         swagger-ui.html docs redoc api-docs .well-known/openapi.json \
         graphql api/graphql graphiql playground; do
  code=$(curl -sS -o /tmp/doc.body -w '%{http_code} %{size_download}' --max-time 15 \
    "https://<HOST>/$p")
  h=$(head -c 60 /tmp/doc.body | tr -d '\n')
  echo "$code  /$p  :: $h"
done
```

Per-prefix doc sweep:
```bash
while read -r _ _ prefix; do
  for d in openapi.json swagger.json docs redoc api-docs; do
    code=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 "https://<HOST>${prefix%/}/$d")
    [ "$code" = "200" ] && echo "HIT $code https://<HOST>${prefix%/}/$d"
  done
done < endpoints/recursive_fuzz_loop_valid.txt
```

Identify + parse a spec:
```bash
curl -sS --max-time 20 "https://<HOST><SPEC_PATH>" -o /tmp/spec.json
head -c 200 /tmp/spec.json; echo
# route extraction: path, methods, deprecated flags
python3 - <<'EOF'
import json
spec = json.load(open("/tmp/spec.json"))
paths = spec.get("paths", {})
print(f"routes: {len(paths)}")
for p, ops in sorted(paths.items()):
    for m, op in ops.items():
        if m.startswith("x-"): continue
        dep = "DEPRECATED" if op.get("deprecated") else ""
        print(f"{m.upper():6} {p} {dep}")
EOF
```

Live-verify documented routes:
```bash
python3 - <<'EOF'
import json, urllib.request
spec = json.load(open("/tmp/spec.json"))
HOST = "https://<HOST>"
for p, ops in sorted(spec.get("paths", {}).items()):
    for m in ops:
        if m.startswith("x-"): continue
        # substitute path params with benign values
        import re
        url = HOST + re.sub(r'\{[^}]+\}', '1', p)
        req = urllib.request.Request(url, method=m.upper(),
            headers={"User-Agent": "Mozilla/5.0 bugbounty-research"})
        try:
            r = urllib.request.urlopen(req, timeout=15)
            print(f"{r.status:3} LIVE  {m.upper():6} {p}")
        except urllib.error.HTTPError as e:
            tag = {401: "GATE", 403: "GATE", 404: "STALE", 405: "WRONG-VERB", 400: "NEEDS-PARAMS"}.get(e.code, "")
            print(f"{e.code:3} {tag:11} {m.upper():6} {p}")
        except Exception as e:
            print(f"ERR {m.upper():6} {p} ({e})")
EOF
```

Secret-scan the raw spec:
```bash
grep -oiE '"example"[ ]*:[ ]*"[^"]{8,80}"' /tmp/spec.json | head -30
grep -oiE 'sk-live-[a-zA-Z0-9]+|xox[bap]-[a-zA-Z0-9-]+|AKIA[0-9A-Z]{16}' /tmp/spec.json
python3 -c "import json; print(json.load(open('/tmp/spec.json')).get('servers'))"
```

Find the spec URL behind a UI page:
```bash
curl -sS --max-time 15 "https://<HOST>/swagger-ui.html" | grep -oE 'url[^,]{0,120}\.json[^"]*' | head -5
curl -sS --max-time 15 "https://<HOST>/docs" | grep -oE 'https?://[^"]*openapi[^"]*|/[^"]*openapi[^"]*\.json' | head -5
```

## Completion-bias defenses

- [ ] All 17 root doc-paths probed; responses compared to baseline
- [ ] Doc-paths probed beneath every valid prefix
- [ ] Each found document fetched and typed (spec / UI / playground / marketing)
- [ ] UI pages traced to their spec URL (or documented unresolvable)
- [ ] Spec parsed: every route + method + deprecated flag extracted and counted
- [ ] Every documented route verified live with per-route verdict (LIVE / GATE / STALE / WRONG-VERB / NEEDS-PARAMS)
- [ ] Documented parameters exported to `param_mining` candidates
- [ ] Spec secret-scan run (examples, servers array, key patterns)
- [ ] Multiple spec versions diffed for deprecated routes
- [ ] UI-only exposures assessed (framework version + unauth "Try it out")
- [ ] `findings/docs_swagger_probe.md` written with verification table

- **Review step:** agent10_review must verify: (1) the route count in the report matches the parsed spec; (2) every route has a live-verification verdict — no "assumed live" rows; (3) STALE routes were actually requested (not inferred); (4) secret-scan ran on the raw spec text.
- **Nudge prompts:**
  - "A spec file is a map, not a finding. Verify every route live — the deprecated admin endpoint in the spec is the one that 200s."
  - "Probe doc paths under every prefix, not just root. Versioned APIs document themselves under their own prefix."
  - "Two spec versions means two API generations. Diff them — the route that vanished from v3 is your old_api_version lead."
- **Finished artifact definition:** `findings/docs_swagger_probe.md` on disk: documents found (URL + type + route count), per-route live-verification table with verdicts, stale-vs-live summary, secret-scan results, and explicit handoff lists.

## Evidence standard

- Baseline: doc-path probes compared against the host's 404 baseline (a 200 serving the fallback page is not a "found document" — verify content type markers).
- Reproduction: each LIVE route re-verified 2x; each claimed secret example re-fetched.
- Raw evidence: the spec file saved (`evidence/spec_<host>.json`), per-route verification log, raw pairs for secrets.
- Verdicts: CONFIRMED (documented + live-verified + raw evidence) / INCONCLUSIVE (documented, unstable verification) / NEGATIVE (sweep complete, no machine-readable docs — documented with probe count).

## Handoffs

- `header_trick_battery`: every documented route verifying as 401/403.
- `method_verb_matrix`: every documented route verifying as 405.
- `param_mining`: every documented parameter name + every route verifying as 400.
- `old_api_version`: routes present in the older spec version but missing from the newer.
- `graphql_introspection`: any GraphQL playground / `/graphql` endpoint found.
- `recursive_fuzz_loop`: every LIVE documented route becomes a new fuzz prefix.
- `agent10_review`: the probe report for the review gate above.
