---
name: method_verb_matrix
agent: agent3_endpoints
description: Per-endpoint HTTP verb matrix — OPTIONS/HEAD/GET/POST/PUT/PATCH/DELETE/TRACE on every path; read 405s and Allow headers for hidden methods.
---

# Method Verb Matrix

## Purpose

Most testers send GET at everything and move on. Frameworks and misconfigured servers routinely expose dangerous methods on the same path: a `DELETE /api/v2/users/1337` that nobody linked, a `PUT /profile` that overwrites another user's data, a `POST /admin/export` hiding behind a GET-only 405. This skill builds a full verb matrix for every interesting endpoint — OPTIONS first (the `Allow` header is the server telling you what's live), then HEAD, GET, POST, PUT, PATCH, DELETE, TRACE — and reads every 405 response as intelligence, not rejection. Verb confusion and method-override parameters turn 405s into access.

## Division of labor

- **Consumes:** endpoint list — `endpoints/recursive_fuzz_loop_valid.txt` paths, plus every METHOD-GATE (405) path the fuzzer classified; one path per line.
- **Produces:** the finished artifact — `findings/method_verb_matrix.csv` with columns `path,verb,status,allow_header,body_len,body_hash,notes` — one row per path×verb, no empty cells. This file's existence with all verbs tested per path is "done".

## When to use / when NOT to use

- **Use when:** you have any valid endpoint; the fuzzer reported 405s; an endpoint returns different behavior by verb (login forms, API routes, file handlers); you suspect framework method-override support (Spring, Rails, Laravel, Express).
- **Skip when (time-pass filter):** the path is a confirmed static asset (`.css`, `.png`, `.woff2` — verbs don't change static files); the host 405s every non-GET verb identically with an empty Allow header across 5+ sampled paths (document the uniformity once, stop matrixing static content).

## Methodology

1. **Build the target list.** Take every CONFIRMED path from the fuzzer plus every METHOD-GATE path. Deduplicate. Prioritize: API-like paths, paths with IDs, admin/internal paths, file-upload-looking paths.
2. **OPTIONS first, always.** Send OPTIONS to each path and record the `Allow` header verbatim. `Allow: GET, HEAD, OPTIONS` is normal. `Allow: GET, HEAD, POST, PUT, DELETE` on a path you only knew as GET is a finding — the server just told you its real surface. Missing `Allow` on a 200 OPTIONS is also signal (lazy CORS/ framework default). Also record `Accept-Post` and `Accept-Patch` headers (RFC 5789/7396) — they name the patch document formats the server accepts.
3. **Run the full verb matrix.** For each path, send HEAD, GET, POST (empty body), PUT (empty body), PATCH (empty body), DELETE, TRACE — each with identical headers. Record status, body length, body hash, and Allow header per cell.
4. **Read 405s as intelligence.** A 405 proves the path EXISTS and the server parsed your method. Compare the 405 body against the baseline 404: different body = distinct handler. Note any `Allow` header on the 405 — it names the permitted verbs.
5. **Hunt verb-differentials.** Flag every cell where status or body differs from the GET cell: POST→200 where GET→405, DELETE→403 where GET→200 (403 means the method reached an ACL — the method is live), PUT→500 (reached application code — live). Differentials are the findings; uniformity is the negative.
6. **Test method-override parameters.** Frameworks honor these even when the raw verb is blocked: Spring `?_method=PUT` / `?_method=DELETE` (HiddenHttpMethodFilter), Rails `?_method=put`, Laravel `?_method=DELETE` + `X-HTTP-Method-Override: DELETE` header, Express `method-override` middleware (`X-HTTP-Method-Override`, `X-Method-Override`). Send `POST /path?_method=DELETE` and compare against raw `DELETE /path` — if the override changes the response, verb smuggling works.
7. **Test override headers.** `X-HTTP-Method-Override: PUT` with a POST body; `X-Method-Override: DELETE`. Some WAFs inspect the raw verb but the app reads the header — a classic bypass split.
8. **Probe TRACE deliberately.** `TRACE /path` — if the server echoes the request (200 with your headers reflected, including `Cookie`), that's Cross-Site Tracing: any XSS becomes header/cookie theft. Mark XST as a finding with the reflected Cookie as evidence.
9. **Check HEAD for info leaks.** HEAD responses sometimes carry `Content-Length` of the real GET body or extra headers (debug headers frameworks strip on GET). Diff HEAD vs GET headers.
10. **Compare against the dead-path verb matrix.** Run the same 8 verbs against a known-dead path. Any verb that returns the identical dead signature on the dead path AND on your target is framework-default noise — only differentials against BOTH the dead path and the GET cell count.
11. **Test with and without trailing slash per verb.** `/api/users` vs `/api/users/` can route to different handlers per verb (common in Django/Flask). Matrix both twins for API-like paths.
12. **Record everything in the CSV.** One row per path×verb: path, verb, status, allow_header, body_len, body_hash, notes (e.g. "differs from GET", "Allow lists DELETE", "XST reflection"). No empty cells — `-` for absent headers.
13. **Vary Content-Type per mutating verb.** Re-send POST/PUT/PATCH with `application/json`, `application/x-www-form-urlencoded`, `text/plain`, and empty `multipart/form-data`. Some endpoints 415 on JSON but 200 on form-encoded — the parser difference is the finding. Record which content types each verb accepts; hand accepted-but-unexpected types to `param_mining`.
14. **Test verb × auth interaction.** On any path with auth, repeat the matrix twice: no token vs garbage token (`Authorization: Bearer x`). A verb that 403s with no token but 200s with a garbage token reveals presence-checks instead of validation — a broken auth finding, not just a verb finding.
15. **Verify framework verb quirks when fingerprinted.** Spring: `HiddenHttpMethodFilter` honors `_method` in body AND query; PUT with form-encoded bodies can populate `@RequestBody`. Rails: `_method=delete` inside POST bodies. Django: ViewSets without explicit mapping 405 on PUT/PATCH but the router still answers OPTIONS — check the Allow header. Express: `app.all()`/`app.use()` handlers answer every verb identically — 8 identical rows usually means middleware, not 8 handlers; verify by body diff, not status.

Decision branches: Allow header lists extra verbs → test each named verb with a real payload · 405 with Allow → override-parameter battery · DELETE→403 while GET→200 → the method reached the ACL: escalate to `header_trick_battery` · TRACE reflects Cookie → XST finding · POST 200 where GET 405 → test parameter smuggling on that verb.

## Interpreting common matrix patterns

| Pattern | Meaning | Next step |
|---|---|---|
| All verbs 405 except GET/HEAD/OPTIONS | Healthy default | Move on |
| DELETE → 403 while GET → 200 | Method reached the ACL — the method is live | `header_trick_battery` on DELETE |
| POST → 200 where GET → 405 | Hidden write endpoint | `param_mining` on POST |
| PUT → 500 with application body | Reached application code | Read the error, then `param_mining` |
| TRACE → 200 echoing Cookie | Cross-Site Tracing (XST) | CONFIRMED finding |
| OPTIONS has no Allow, every verb 200s identically | `app.all()` catch-all or middleware | Verify by body diff, not status |
| `_method=DELETE` changes response vs raw POST | Verb smuggling works | Exploit via the override |
| Allow lists PROPFIND/MKCOL/LOCK | WebDAV is live on this path | Test WebDAV writes (PUT a canary file) |

## Exact commands

OPTIONS + Allow capture:
```bash
curl -sS -X OPTIONS -D - -o /dev/null --max-time 15 "https://<HOST><PATH>" \
  | grep -iE '^HTTP|allow'
```

Full verb matrix for one path (writes comparable lines):
```bash
for v in HEAD GET POST PUT PATCH DELETE TRACE; do
  out=$(curl -sS -X "$v" -D /tmp/v_hdr -o /tmp/v_body -w '%{http_code} %{size_download}' \
    --max-time 15 "https://<HOST><PATH>")
  h=$(sha256sum /tmp/v_body | cut -c1-12)
  allow=$(grep -i '^allow:' /tmp/v_hdr | tr -d '\r' | cut -d: -f2- | xargs)
  echo "$v | $out | hash=$h | allow=[$allow]"
done
```

Method-override battery (Spring / Rails / Laravel / Express):
```bash
for m in PUT DELETE PATCH; do
  echo "== _method=$m =="
  curl -sS -o /dev/null -w '%{http_code} %{size_download}\n' --max-time 15 \
    -X POST "https://<HOST><PATH>?_method=$m"
  echo "== X-HTTP-Method-Override: $m =="
  curl -sS -o /dev/null -w '%{http_code} %{size_download}\n' --max-time 15 \
    -X POST -H "X-HTTP-Method-Override: $m" "https://<HOST><PATH>"
done
```

TRACE reflection test (XST):
```bash
curl -sS -X TRACE -D - -o /tmp/trace_body --max-time 15 \
  -H "Cookie: session=PROBE123" "https://<HOST><PATH>" | head -20
grep -c PROBE123 /tmp/trace_body && echo "XST REFLECTION CONFIRMED"
```

Dead-path verb baseline (noise filter):
```bash
R=$(openssl rand -hex 6)
for v in OPTIONS HEAD GET POST PUT PATCH DELETE TRACE; do
  printf "%s " "$v"
  curl -sS -X "$v" -o /dev/null -w '%{http_code} %{size_download}\n' \
    --max-time 15 "https://<HOST>/$R"
done
```

CSV row writer (append per path after matrixing):
```bash
# columns: path,verb,status,allow_header,body_len,body_hash,notes
echo "<PATH>,DELETE,403,,142,9f3ac2d1e8b4,403-while-GET-200: method reached ACL" \
  >> findings/method_verb_matrix.csv
```

## Completion-bias defenses

- [ ] Target list built from fuzzer CONFIRMED paths + all METHOD-GATE paths, deduplicated
- [ ] OPTIONS sent to every path; Allow headers recorded verbatim
- [ ] Full 8-verb matrix run per path (OPTIONS, HEAD, GET, POST, PUT, PATCH, DELETE, TRACE)
- [ ] Every 405 compared against baseline 404 (different body = distinct handler)
- [ ] Verb-differentials flagged (any cell differing from the GET cell)
- [ ] Method-override parameters tested (`_method` for PUT/DELETE/PATCH)
- [ ] Override headers tested (`X-HTTP-Method-Override`, `X-Method-Override`)
- [ ] TRACE tested for Cookie reflection (XST verdict recorded)
- [ ] Allow header checked for WebDAV methods (PROPFIND/MKCOL/LOCK)
- [ ] Dead-path verb baseline captured; framework-default noise filtered
- [ ] Trailing-slash twins matrixed for API-like paths
- [ ] Content-Type variants tested per mutating verb (json/form/plain/multipart)
- [ ] Verb×auth interaction sampled (no-token vs garbage-token)
- [ ] Framework verb quirks verified where fingerprinted
- [ ] CSV complete: one row per path×verb, no empty cells

- **Review step:** agent10_review must verify: (1) every path has all 8 verb rows; (2) every flagged differential includes the GET-cell value it differs from; (3) override tests were actually sent (not just planned); (4) XST verdict is backed by a grep hit on the probe cookie.
- **Nudge prompts:**
  - "A 405 is not a rejection — it's the server confirming the path exists and naming nothing. Test every override before moving on."
  - "Keep going until every path has all 8 verb rows. The DELETE you skip is the one with the missing ACL."
  - "Do not report done before the CSV exists with zero empty cells."
- **Finished artifact definition:** `findings/method_verb_matrix.csv` on disk with columns `path,verb,status,allow_header,body_len,body_hash,notes`, one row per path×verb, no empty cells; differentials flagged in `notes`.

## Evidence standard

- Baseline: dead-path verb matrix captured on the same host; differentials must differ from BOTH the dead-path signature and the path's own GET cell.
- Reproduction: each flagged differential re-run 2x (same verb, 30s apart) — stable to CONFIRMED.
- Raw evidence: per differential, save the full request line + response headers + body (first 2KB) for the differing verb and the GET cell side by side.
- Verdicts: CONFIRMED (stable differential + raw pairs) / INCONCLUSIVE (differential once, unstable — second model run) / NEGATIVE (all verbs uniform with dead-path signature — documented per path).

## Handoffs

- `header_trick_battery`: every path where a non-GET verb reached an ACL (403/401 on PUT/DELETE/PATCH) — the verb is live, now bypass the gate.
- `param_mining`: every path where POST/PUT returned 200/400 (reached application code) — mine its parameters.
- Downstream auth-testing agents: the full CSV — verbs with missing ACLs are IDOR/priv-escal entry points.
- `agent10_review`: the CSV for the review gate above.
