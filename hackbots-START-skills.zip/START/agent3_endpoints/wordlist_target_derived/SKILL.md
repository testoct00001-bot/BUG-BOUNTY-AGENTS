---
name: wordlist_target_derived
agent: agent3_endpoints
description: Build high-signal wordlists from harvested JS words, tech-stack fingerprints, and already-found endpoints — never generic rockyou noise.
---

# Wordlist Target-Derived

## Purpose

Generic wordlists are the #1 source of wasted probes and missed bugs: 100k dictionary words against a live program finds the login page and nothing else. This skill builds the wordlist FROM the target — its own JavaScript vocabulary, its framework's known routes, its error pages, its robots.txt, its already-found endpoints. A 400-word list built from the target's own strings outperforms a 100k generic list because every word is a word the application itself uses. This wordlist is the fuel for `recursive_fuzz_loop`; garbage in, missed endpoints out.

## Division of labor

- **Consumes:** JS bundle URLs / raw JS text (harvested by recon or fetched in-step); tech-stack fingerprint (framework, server header, error signatures); `endpoints/recursive_fuzz_loop_valid.txt` (already-found endpoints, for mutation); robots.txt / sitemap.xml text.
- **Produces:** the finished artifacts — `wordlists/target_derived.txt` (tier-1: observed verbatim words) and `wordlists/target_derived_tier2.txt` (tier-2: mutations + stack-derived words). Both files on disk with ≥50 words each (or a documented reason) is "done".

## When to use / when NOT to use

- **Use when:** starting any fuzzing round; after `recursive_fuzz_loop` returns VALID hits at a new depth (rebuild with harvested words); when the tech-stack fingerprint reveals a framework with known route conventions.
- **Skip when (time-pass filter):** you already have a fresh target-derived list from this host in this run (check timestamps — rebuilding the identical list is busywork); the host serves zero JS and zero stack signals AND you have no found endpoints — in that case run one shallow generic round first to get seed material, then come back.

## Methodology

1. **Collect the raw material.** Fetch the homepage and every JS bundle referenced (`<script src>`). Also fetch `/robots.txt`, `/sitemap.xml`, and any error page you can trigger (request a dead path — verbose errors leak controller names). Save everything under `evidence/js_raw/`.
2. **Extract quoted strings from JS.** Pull every single/double/backtick-quoted string of length 2–40. These are the application's own vocabulary: route fragments, API names, feature flags.
3. **Extract path-like strings.** Regex for `["'](/[a-zA-Z0-9_\-./]{2,60})["']` — strings that start with `/` are often unlinked routes. Split them into segments; each segment is a word.
4. **Extract from comments.** JS comments (`//`, `/* */`) and sourcemaps (`*.js.map` — fetch them, they list original filenames) leak internal names. Sourcemap `sources` arrays are pure gold: real file paths.
5. **Mine the tech-stack fingerprint.** Map the framework to its known route conventions and add them as tier-2 words:
   - Spring Boot: `actuator`, `health`, `env`, `beans`, `mappings`, `trace`, `dump`, `metrics`, `logfile`, `heapdump`, `threaddump`, `configprops`, `scheduledtasks`
   - Laravel: `telescope`, `horizon`, `_ignition`, `debugbar`
   - Django: `admin`, `static`, `media`, `__debug__`
   - Rails: `rails/info`, `active_storage`, `cable`
   - Express/Node: `api`, `graphql`, `healthz`, `metrics`
   - Next.js: `_next`, `api`, `_vercel`
   - WordPress: `wp-json`, `wp-admin`, `xmlrpc.php`
   - .NET: `swagger`, `hangfire`, `elmah`, `trace.axd`
   - Server header `nginx`/`Apache` alone adds nothing — only add stack words you have evidence for.
6. **Harvest robots.txt and sitemap.** Every `Disallow:` path and every `<loc>` URL contributes segments. Disallow entries are the site telling you where the interesting things are.
7. **Harvest error pages.** Stack traces and framework debug pages name controllers, actions, and modules (`UsersController`, `getInvoiceAction`). Convert CamelCase/snake_case to path words (`users`, `get-invoice`, `get_invoice`).
8. **Mutate already-found endpoints.** For each valid path from `recursive_fuzz_loop`, generate: plural/singular swap (`user`↔`users`), `-admin`/`_admin` suffix, `_internal`/`-internal` suffix, `v1`..`v9` version swap, `.json`/`.xml` extension variants. These catch the sibling endpoints developers deploy next to the one you found.
9. **Clean aggressively.** Lowercase-dedupe, strip quotes/whitespace, drop tokens <2 or >40 chars, drop pure hex hashes ≥16 chars (cache-busters, not routes), drop tokens containing `<>{}();=` (code fragments). Keep version numbers and hyphenated compounds.
10. **Rank by frequency.** Count occurrences across all sources. Words seen in ≥2 independent sources go to the top — a word in both JS and robots.txt is near-certain to be a real route.
11. **Split into tiers.** Tier-1 = observed verbatim in target material (JS, robots, sitemap, errors, sourcemaps). Tier-2 = mutations + stack-derived conventions. Tier-1 is probed first at every depth; tier-2 fills the gaps.
12. **Size check.** Tier-1 should be 50–2,000 words. If <50, you haven't harvested enough — go back to step 1 and fetch more bundles (check `webpack` chunk URLs, lazy-loaded chunks). If >5,000, your cleaning failed — re-run step 9.
13. **Write both artifacts** with one word per line, tier-1 sorted by frequency rank, tier-2 alphabetical.
14. **Rebuild between depth rounds.** After `recursive_fuzz_loop` finishes a depth, feed its new VALID hits through steps 8–11 and append new words. The wordlist is a living file, not a one-time artifact.

Decision branches: sourcemap found → parse `sources` first (highest signal) · verbose error page → controller-name extraction · stack identified → add framework convention words · valid hits exist → mutation pass · <50 words → harvest more bundles before fuzzing.

## Exact commands

Fetch homepage + JS bundles + robots + sitemap:
```bash
mkdir -p evidence/js_raw
UA="Mozilla/5.0 (X11; Linux x86_64) bugbounty-research"
curl -sS -A "$UA" --max-time 20 "https://<HOST>/" -o evidence/js_raw/index.html
grep -oE 'src="[^"]+\.js[^"]*"' evidence/js_raw/index.html | sed 's/src="//;s/"//' | sort -u > evidence/js_raw/js_urls.txt
i=0; while read -r u; do
  case "$u" in http*) full="$u";; /*) full="https://<HOST>$u";; *) full="https://<HOST>/$u";; esac
  curl -sS -A "$UA" --max-time 20 "$full" -o "evidence/js_raw/bundle_$i.js"; i=$((i+1))
done < evidence/js_raw/js_urls.txt
curl -sS -A "$UA" --max-time 15 "https://<HOST>/robots.txt" -o evidence/js_raw/robots.txt
curl -sS -A "$UA" --max-time 15 "https://<HOST>/sitemap.xml" -o evidence/js_raw/sitemap.xml
# sourcemaps: highest-signal source of real filenames
for f in evidence/js_raw/bundle_*.js; do
  grep -oE '[a-zA-Z0-9_./-]+\.js\.map' "$f" | sort -u
done
```

Harvest words (quoted strings + path segments + sourcemap sources):
```bash
python3 - <<'EOF'
import re, glob, json, collections
words = collections.Counter()
srcs = set()
for f in glob.glob("evidence/js_raw/bundle_*.js"):
    t = open(f, errors="ignore").read()
    for m in re.findall(r'''["'`]([A-Za-z][A-Za-z0-9_\-]{1,39})["'`]''', t):
        words[m] += 1
    for m in re.findall(r'''["'`](/[A-Za-z0-9_\-./]{2,60})["'`]''', t):
        for seg in m.strip("/").split("/"):
            if 1 < len(seg) < 40: words[seg] += 2  # path segments score double
    for m in re.findall(r'/\*[\s\S]{0,400}?\*/|//[^\n]{4,80}', t):
        for w in re.findall(r'[A-Za-z][A-Za-z0-9_\-]{2,30}', m):
            words[w] += 1
for f in glob.glob("evidence/js_raw/*.js.map"):
    try:
        for s in json.load(open(f)).get("sources", []):
            for seg in s.strip("/").split("/"):
                seg = seg.split(".")[0]
                if 1 < len(seg) < 40: words[seg] += 3  # sourcemap sources score triple
    except Exception: pass
for f in ("evidence/js_raw/robots.txt", "evidence/js_raw/sitemap.xml"):
    try:
        t = open(f, errors="ignore").read()
        for m in re.findall(r'(?:Disallow:\s*|/)([A-Za-z][A-Za-z0-9_\-]{1,30})', t):
            words[m] += 2
    except FileNotFoundError: pass
# clean
clean = {w: c for w, c in words.items()
         if not re.fullmatch(r'[0-9a-f]{16,}', w) and not re.search(r'[<>{}();=]', w)}
ranked = sorted(clean, key=lambda w: -clean[w])
open("wordlists/target_derived.txt", "w").write("\n".join(ranked) + "\n")
print(f"tier1 words: {len(ranked)}")
EOF
```

Mutation pass over already-found endpoints (tier-2):
```bash
python3 - <<'EOF'
import re, itertools
paths = [l.split(None, 2)[2] for l in open("endpoints/recursive_fuzz_loop_valid.txt")]
out = set()
for p in paths:
    for seg in p.strip("/").split("/"):
        if not seg or "." in seg: continue
        out.add(seg + "s"); out.add(seg.rstrip("s"))
        for suf in ("-admin", "_admin", "-internal", "_internal", "-api", "_api", "-v2", "_v2"):
            out.add(seg + suf)
        for v in ("v1", "v2", "v3", "v0"):
            out.add(re.sub(r'v\d+', v, seg) if re.search(r'v\d+', seg) else seg)
# stack-derived conventions (edit to match the fingerprinted stack)
stack_words = """actuator health env beans mappings metrics heapdump threaddump
telescope horizon admin graphql healthz metrics _next api swagger hangfire""".split()
out.update(stack_words)
open("wordlists/target_derived_tier2.txt", "w").write("\n".join(sorted(out)) + "\n")
print(f"tier2 words: {len(out)}")
EOF
wc -l wordlists/target_derived.txt wordlists/target_derived_tier2.txt
```

## Completion-bias defenses

- [ ] Homepage + all referenced JS bundles fetched into `evidence/js_raw/` (count recorded)
- [ ] robots.txt and sitemap.xml fetched (or documented absent)
- [ ] Sourcemaps checked for every bundle (present/absent recorded — absent is a finding of process, not a skip)
- [ ] Quoted strings + path segments + comments harvested
- [ ] Stack-derived convention words added ONLY for fingerprinted frameworks (no speculative framework words)
- [ ] Error-page controller names extracted (or no verbose errors found — documented)
- [ ] Mutation pass run over already-found endpoints
- [ ] Cleaning applied (hash-like tokens and code fragments removed)
- [ ] Frequency ranking done; multi-source words at top
- [ ] Tier-1 / tier-2 split written; both files ≥50 words or reason documented
- [ ] Size sanity: tier-1 between 50–5,000 words
- [ ] Rebuild hook: wordlist refreshed after each fuzz depth round with new hits

- **Review step:** agent10_review must verify: (1) tier-1 words are traceable to target material (spot-check 10 words against `evidence/js_raw/`); (2) no tier-2 stack words for frameworks without fingerprint evidence; (3) both files exist with one word per line; (4) the rebuild hook ran at least once if fuzzing went past depth 1.
- **Nudge prompts:**
  - "A wordlist with fewer than 50 target-derived words means you haven't harvested enough — fetch more bundles and check sourcemaps before fuzzing."
  - "Every word in tier-1 must come from the target's own material. If you can't point at the source line, it belongs in tier-2 or nowhere."
  - "Rebuild the list after every depth round. New endpoints mean new vocabulary — a stale wordlist is how depth 4 stays hidden."
- **Finished artifact definition:** `wordlists/target_derived.txt` AND `wordlists/target_derived_tier2.txt` on disk, one word per line, tier-1 ≥50 words (or documented reason), tier-1 traceable to `evidence/js_raw/` material.

## Evidence standard

- Baseline: N/A for wordlist building — but every word's provenance is recorded (source file + extraction rule), so a reviewer can reproduce the list.
- Reproduction: re-running the harvest commands on the same `evidence/js_raw/` material must produce the same tier-1 set (deterministic pipeline, no randomness).
- Raw evidence: the raw bundles in `evidence/js_raw/` are the evidence; the harvest script is logged.
- Verdicts: CONFIRMED (list built from ≥3 independent target sources) / INCONCLUSIVE (<50 words — needs more harvesting or a second model run with different regexes) / NEGATIVE (host exposes no JS, no stack signals, no endpoints — documented, fuzzing proceeds on generic seeds only).

## Handoffs

- `recursive_fuzz_loop`: consumes both tier files as its probe vocabulary — the single most important handoff in this agent.
- `param_mining`: receives tier-1 words as candidate parameter names (apps reuse vocabulary across paths and params).
- `graphql_introspection`: receives tier-1 words as candidate field/type names for suggestion bruteforcing.
- `agent10_review`: spot-checks word provenance against `evidence/js_raw/`.
