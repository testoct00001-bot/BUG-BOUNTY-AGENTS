---
name: backup_file_hunt
agent: agent3_endpoints
description: Backup and editor temporaries on live paths — .bak/.old/.swp/~/.git exposures that leak source, configs, and credentials.
---

# Backup File Hunt

## Purpose

Deployments leave their drafts behind: `config.php.bak` with database credentials, `app.js~` with the pre-minification source, `.git/HEAD` exposing the whole repository, `.swp` files with the editor buffer of a secrets file. These are not theoretical — backup-file exposure is one of the highest-hit-rate bug classes in real programs because it's a deployment mistake, not a code flaw, and scanners miss the target-specific filenames. This skill takes every real file-like path the fuzzer found and tests its backup/editor/VCS variants, verifying each hit by content — never by status alone.

## Division of labor

- **Consumes:** file-like VALID hits from `recursive_fuzz_loop` (paths with extensions: `.js`, `.json`, `.xml`, `.php`, `.env`, config names); the host root (for `.git/`, `.svn/`, `.DS_Store`, top-level temporaries).
- **Produces:** the finished artifact — `findings/backup_file_hunt.md`: per original path, variant→response table, content-verification notes, and verdicts with raw pairs for hits.

## When to use / when NOT to use

- **Use when:** the fuzzer found any file-like path; JS bundles exist (their `.map` and unminified twins leak source); the stack suggests server-rendered files (`.php`, `.asp`, `.jsp`); config-ish names appeared (`config`, `settings`, `env`, `database`).
- **Skip when (time-pass filter):** the host serves only extensionless API routes and hashed static assets (`/static/js/main.a1b2c3.js` — backup variants of content-hashed filenames are near-zero signal; one sample to confirm, then document); every variant returns the identical fallback/edge page (the host has no file semantics).

## Methodology

1. **Build the target list.** Every VALID hit with a file extension + the root-level VCS/temporary targets. For each, split into directory + basename + extension.
2. **Fire the backup-extension group** per file (`app.js` →):
   - `app.js.bak`, `app.js.old`, `app.js.orig`, `app.js.orig`, `app.js.backup`, `app.js.save`, `app.js.copy`, `app.js.tmp`, `app.js.temp`
   - `app.bak.js` is wrong — but `app.js~`, `app.js.swp`, `app.js.swo` (vim), `app.js#` (emacs autosave), `.#app.js` (emacs lock)
   - `.app.js.swp`, `.app.js.swx` (vim hidden swapfiles — note the leading dot)
   - `%2e` variants are `path_confusion`'s job; here test literal names only.
3. **Fire the extension-swap group** (source twins): `app.js` → `app.ts`, `app.jsx`, `app.min.js` → `app.js` (unminified), `bundle.js` → `bundle.js.map` (sourcemap — the highest-value target: original source + paths), `config.json` → `config.yaml`/`config.yml`/`config.xml`.
4. **Fire the VCS-exposure group at root and under app prefixes:**
   - `/.git/HEAD` (must contain `ref: refs/heads/...` — content-verified)
   - `/.git/config` (may leak remote URLs with credentials)
   - `/.svn/entries`, `/.hg/requires`
   - `/.DS_Store` (macOS — lists directory filenames; parse it)
   - `/.env`, `/.env.bak`, `/.env.local`, `/.env.production` (the credential jackpot — verify by content, `KEY=value` lines)
   - `/backup/`, `/backups/`, `/old/`, `/tmp/` directory probes (only if directory listing or distinct responses suggest file semantics)
   - `/.well-known/security.txt` — not a backup, but a one-request check during the root sweep that often reveals contact/scope info
   - **Check one level up from asset paths:** VCS exposure often lives above the asset directory — if `/static/js/app.js` is valid, probe `/static/.git/HEAD` and `/.git/HEAD`, not just root. Same for `/.env` under `/api/` and `/app/` prefixes.
5. **Verify every candidate hit BY CONTENT, not status.** A 200 is not a hit until the body proves it:
   - `.bak`/`.old`/`.orig` → body must resemble the original file's type (JS for `.js.bak`, not an HTML error page); diff against the original — near-identical or older version = CONFIRMED
   - `.git/HEAD` → body matches `ref: refs/heads/` pattern
   - `.env` → body contains `=` assignments, not HTML
   - `.DS_Store` → binary with `Bud1` magic — parse filenames out of it
   - sourcemap → valid JSON with `sources` array
   - Compare body hash against the baseline 404 AND the fallback page — backup hunters' #1 false positive is the 200-fallback
6. **Diff backup vs original.** When `app.js.bak` is confirmed, diff it against `app.js`: older API endpoints, commented-out debug code, hardcoded keys the minified version stripped. The backup is often MORE interesting than the live file.
7. **Escalate VCS exposure.** A readable `/.git/HEAD` means try `/.git/logs/HEAD`, `/.git/refs/heads/master`, then `.git/objects/` enumeration is out of scope for this skill — report the exposure with the verified files and hand the host to deeper VCS-dump work downstream.
8. **Scan confirmed files for secrets.** Run the secret patterns over every confirmed backup: `AKIA`, `sk-live`, `xox[bap]-`, `-----BEGIN .*PRIVATE KEY-----`, `password\s*=\s*["'][^"']+`, `api[_-]?key\s*[:=]`. Verify each candidate is real-looking (length/format), never log full secrets in the report — record redacted evidence (`AKIA...XXXX (20 chars, format-valid)`).
9. **Re-verify hits 2x**, 30s apart — deployment artifacts can vanish mid-hunt (someone cleans up); 2/3 stable to CONFIRMED.
10. **Write the report**: per original path, variant table, content-verification notes, diffs of interest, secret-scan results (redacted), verdicts.

Decision branches: variant 200s but body = fallback page → NOT a hit (the classic FP) · `.git/HEAD` verified → escalate VCS paths immediately · `.env` verified → secret-scan + check `.env.bak` siblings · backup confirmed → diff vs original for older endpoints/keys · all variants fallback-identical → NEGATIVE per path.

## Exact commands

Backup-extension battery for one file:
```bash
F="<PATH>"  # e.g. /static/js/app.js
base="${F%.*}"; ext="${F##*.}"
for v in "$F.bak" "$F.old" "$F.orig" "$F.backup" "$F.save" "$F.copy" \
         "$F.tmp" "$F~" "$F.swp" "$F.swo" "$F#" ".$base.swp" "$base.$ext.map"; do
  code=$(curl -sS -o /tmp/bk.body -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$v")
  h=$(sha256sum /tmp/bk.body | cut -c1-8)
  echo "$code h=$h  $v"
done
```

VCS / env exposure sweep:
```bash
for p in /.git/HEAD /.git/config /.svn/entries /.hg/requires /.DS_Store \
         /.env /.env.bak /.env.local /.env.production; do
  out=$(curl -sS -o /tmp/vcs.body -w '%{http_code} %{size_download}' --max-time 15 "https://<HOST>$p")
  sample=$(head -c 80 /tmp/vcs.body | tr -d '\n' | head -c 80)
  echo "$out  $p  :: $sample"
done
```

Content verification (the anti-FP step):
```bash
# .git/HEAD must match the ref pattern; .env must have KEY=value lines
grep -q '^ref: refs/heads/' /tmp/vcs.body && echo "GIT-HEAD CONFIRMED"
grep -qE '^[A-Z_]{3,30}=' /tmp/vcs.body && echo "ENV-FORMAT CONFIRMED"
# backup must differ from fallback AND resemble the original type
sha256sum /tmp/bk.body /tmp/base_body  # must differ
head -c 300 /tmp/bk.body
```

Diff backup vs original:
```bash
curl -sS --max-time 15 "https://<HOST><ORIGINAL>" -o /tmp/orig.body
curl -sS --max-time 15 "https://<HOST><BACKUP_VARIANT>" -o /tmp/bk.body
diff /tmp/orig.body /tmp/bk.body | head -40
```

Parse .DS_Store filenames:
```bash
strings /tmp/vcs.body | grep -E '\.[a-z]{2,4}$' | sort -u | head -30
```

Secret scan over confirmed files (redacted output):
```bash
for f in /tmp/bk.body /tmp/vcs.body /tmp/orig.body; do
  echo "== $f =="
  grep -oE 'AKIA[0-9A-Z]{16}|sk-live-[a-zA-Z0-9]{8,}|xox[bap]-[a-zA-Z0-9-]+|-----BEGIN [A-Z ]*PRIVATE KEY-----' "$f" \
    | sed -E 's/(.{4}).*/\1...REDACTED/' | sort -u
  grep -oiE '(password|passwd|secret|api[_-]?key)["'"'"' ]*[:=]["'"'"' ]*[^"'"'"' ]{4,}' "$f" \
    | sed -E 's/(.{30}).*/\1.../' | head -10
done
```

## Completion-bias defenses

- [ ] Target list built: all file-like VALID hits + root VCS/env targets
- [ ] Backup-extension group fired per file (13+ variants incl. vim/emacs swapfiles)
- [ ] Extension-swap group fired (source twins, sourcemaps)
- [ ] VCS-exposure group fired (git/svn/hg/DS_Store), incl. one-level-up from asset paths
- [ ] Env-file group fired (`.env` + 3 variants)
- [ ] Every candidate hit verified BY CONTENT (type-appropriate check), not status
- [ ] Fallback-page FP check done per hit (hash vs baseline/fallback)
- [ ] Confirmed backups diffed against originals
- [ ] VCS exposure escalated (logs/refs attempted where HEAD verified)
- [ ] Secret scan run on confirmed files; secrets redacted in notes
- [ ] Hits re-verified 2x, 30s apart
- [ ] `findings/backup_file_hunt.md` written with per-path tables and verdicts

- **Review step:** agent10_review must verify: (1) every claimed hit includes the content-verification evidence (the grep/match that proved it); (2) no 200-fallback was claimed as a hit; (3) secrets are redacted in the report; (4) diffs exist for backup-vs-original pairs.
- **Nudge prompts:**
  - "A 200 is not a hit. The body must prove it's the backup — match the content pattern, diff against the fallback, then claim."
  - "The backup is often more interesting than the live file. Diff them — the old endpoint and the stripped key live in the diff."
  - "Redact secrets in your notes. Record the format and length as evidence, never the value."
- **Finished artifact definition:** `findings/backup_file_hunt.md` on disk: per original path, variant→response table, content-verification notes per candidate hit, backup-vs-original diffs, redacted secret-scan results, and verdicts with raw pairs.

## Evidence standard

- Baseline: host 404 baseline + fallback hash; every hit's body hash must differ from both.
- Reproduction: each hit re-fetched 2x, 30s apart — 2/3 stable to CONFIRMED.
- Raw evidence: variant URL + response headers + content-verification match + first 1KB of body (secrets redacted).
- Verdicts: CONFIRMED (content-verified + 2/3 stable) / INCONCLUSIVE (200 with ambiguous body — second model run) / NEGATIVE (all variants fallback-identical — documented per path).

## Handoffs

- `recursive_fuzz_loop`: filenames parsed from `.DS_Store` and sourcemap `sources` — new fuzz seeds.
- `wordlist_target_derived`: words harvested from confirmed backups (older code has older vocabulary).
- Downstream secret-handling: confirmed credential exposures go to the human immediately (report, don't exploit).
- `old_api_version`: older API endpoints found in backup diffs.
- `agent10_review`: the hunt report for the review gate above.
