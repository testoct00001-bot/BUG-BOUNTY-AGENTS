# Build Brief — Hackbot Skill System ("START")

## Origin
This skill system is built from Jason Haddix's DEF CON 34 talk **"Hackbots"** (Bug Bounty Village masterclass, channel: Bug Bounty DEFCON, 27 Sept 2026, 43:29).
Core thesis: fully autonomous hackbots are not here yet, but a well-designed **agent harness with a human in the loop** finds bugs entire teams of hackers would miss. One 6-hour run against a live program returned **4 confirmed criticals and 17 confirmed highs**.

## Talk concepts every file must bake in

1. **Division of labor via skills.** Small modular skills, each doing one job deeply. Agents orchestrated by a harness. Every skill declares what it consumes and what finished artifact it produces.
2. **Completion bias is the #1 enemy.** AI agents do 3 steps of a 20-step methodology and report "done." Defeat it with:
   - Markdown checklists the agent must tick through completely
   - A dedicated **review skill / review step**
   - **Nudge prompts** ("keep going until you have X", "do not stop before Y")
   - Explicitly defined **finished artifacts** — the exact file whose existence proves done
3. **Context engineering tips from the talk:**
   - Give FULL commands (exact curl / python3), never just tool names
   - Markdown checklists for long methodologies
   - Output folders with full paths
   - Run multiple models, multiple times, on the same target
   - Retune on every new model
4. **Human in the loop.** Every agent's output ends at a review gate (agent10_review).
5. **War-story standard.** Skills must aim for real, confirmed, impactful findings — e.g. the SSRF the agent chased into an open Kubernetes admin panel that leaked tenant API keys. Chains beat single bugs.

## User's standing quality bar (non-negotiable)

- Skip "time pass" public surface — hunt what **leaks**, is **sensitive**, and is **reachable unauthenticated**.
- **No false positives, ever.** Every claimed finding needs: baseline comparison against a known-dead path, 2x independent reproduction, raw request/response evidence. Verdicts: CONFIRMED / INCONCLUSIVE / NEGATIVE.
- Turn every lead into an **access ladder**: unauth data → canary → IDOR/parameter ladders; 401/403 → bypass battery → auth confusion → verb smuggling.
- Recon output is subdomains and IPs only (no URLs) when listing hosts.
- The user hunts bug-bounty web targets (dell.com, Cloudflare, etc.). Keep skills **generic and reusable**, never target-specific.

## What you are building

One agent folder: `~/workspace/hackbot-skills/START/<agent-folder>/` containing:
- 10 skill folders (assigned per agent), each with a `SKILL.md` following `SKILL_TEMPLATE.md` exactly
- One `AGENT.md` describing the agent (see template brief below)

## AGENT.md format

```markdown
# Agent N: <Name>

## Role
(1 paragraph: what this agent owns in the hunt)

## The 10 skills
| Skill folder | What it does |
| ... | ... |

## Inputs
(What artifacts it consumes from other agents)

## Outputs
(What finished artifacts it produces)

## Handoffs
(Which agents consume its output next, and what they need)

## Review gate
(What must be true before this agent's work ships to the human)
```

## Rules

- Create files ONLY inside your assigned agent folder. Never touch anything else.
- Use the `write` tool (it creates parent directories).
- Each `SKILL.md`: 150–250 lines of REAL methodology, REAL commands, REAL checklists. No filler, no generic advice, no recycled platitudes. Write for an autonomous agent that will execute this file literally.
- Skill folder names: lowercase_with_underscores, exactly as assigned.
- If a skill's core is a reusable tool, you may add ONE small helper script (python3 or bash) inside that skill folder — only when genuinely needed.
- When finished, reply with the list of files you created and a one-line summary per skill.
